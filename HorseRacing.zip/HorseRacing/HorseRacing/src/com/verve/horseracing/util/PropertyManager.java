package com.verve.horseracing.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.Properties;


public class PropertyManager
{
	 private static Properties props = null;
	 private String fileName = "betfair.properties";
	 
	public  Properties loadPropertiesFromFile() throws IOException{

		try 
                {		
			    Properties props = new Properties();
			    props.load(getClass().getResourceAsStream(fileName));
			    			    			    
			    return props;	    
		} catch (IOException e) {
		    return null;
		}
		
   	}
	 public Properties loadProperties() {
		   try
                   { 
				if( props == null ) {
			    	   	props = loadPropertiesFromFile();			
				}
				return props;
		   } catch ( Exception e ) {
			    return null; 
		   }
	 }
	 public String getProperty(String key) {
		   try
                   {
			   if( props == null)
				   loadProperties( );
			   // The call to trim() is necessary to remove the spaces
			   return props.getProperty(key).trim();
		   } catch ( Exception e ) {
			       return "";
		   }
	   }
	 
	

}
