/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.verve.horseracing.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.Timer;

/**
 *
 * @author dharam
 */
public class BetFairTimer 
{
   private static final int TIMER_PERIOD = 1000;
   protected static final int MAX_COUNT = 240;
   private int count;
   JLabel lblTimer;
   public BetFairTimer(JLabel lblTimer)
   {
       this.lblTimer = lblTimer;
   }
   
   public void start() {
      new Timer(TIMER_PERIOD, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            if (count < MAX_COUNT) {
               count++;
               String text = "(" + (MAX_COUNT - count) + ") seconds left";
               int secsIn = MAX_COUNT -count;
               int hours = secsIn / 3600;
               int remainder = secsIn % 3600;
               int minutes = remainder / 60;
               int    seconds = remainder % 60; 
            //  String text1 =  "Hours " +hours + " Minute "+ minutes + " Seconds " + seconds;
               String timerText = minutes + ":" +seconds;
               lblTimer.setText(timerText);
            } else {
               ((Timer) e.getSource()).stop();
            }
         }
      }).start();
   }
    
}
