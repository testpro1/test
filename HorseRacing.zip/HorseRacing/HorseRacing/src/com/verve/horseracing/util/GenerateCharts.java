/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.verve.horseracing.util;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author dharam
 */
public class GenerateCharts 
{
    
    public JFreeChart generateBarChart() 
    {
	        
		
	     
	     DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
	     
             dataSet.setValue(0, "", "8");
	     dataSet.setValue(20, "", "10");
	     dataSet.setValue(40, "", "12");
	     	 
	     JFreeChart chart = ChartFactory.createBarChart(
	                "", "", "",
	                dataSet, PlotOrientation.VERTICAL, false, true, false);
	 
	        return chart;
	    }
    
}
