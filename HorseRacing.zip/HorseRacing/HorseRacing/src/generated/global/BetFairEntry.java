/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package generated.global;

import java.rmi.RemoteException;
import org.apache.axis2.AxisFault;

/**
 *
 * @author verve
 */
public class BetFairEntry
{
    
    public static void main(String[] args) throws AxisFault, RemoteException 
    {
       
                        
            BFGlobalServiceStub stub = new BFGlobalServiceStub();
            BFGlobalServiceStub.Login login = new BFGlobalServiceStub.Login();
            BFGlobalServiceStub.LoginReq req = new BFGlobalServiceStub.LoginReq();
           
            req.setUsername("Energylight");
            req.setPassword("88change88");
            req.setIpAddress("");
            req.setProductId(82);
            
            login.setRequest(req);
                    
            BFGlobalServiceStub.LoginResponse res = stub.login(login);
            
            if(res.getResult().getErrorCode().equals(BFGlobalServiceStub.LoginErrorEnum.OK))
            {
                System.out.println("Login Successful.........!!!");
                String token = res.getResult().getHeader().getSessionToken();
                
                BFGlobalServiceStub.GetEvents event = new BFGlobalServiceStub.GetEvents();
                BFGlobalServiceStub.GetEventsReq ereq = new BFGlobalServiceStub.GetEventsReq();
                                
                BFGlobalServiceStub.GetActiveEventTypes types = new BFGlobalServiceStub.GetActiveEventTypes();
                BFGlobalServiceStub.GetEventTypesReq eventTypeReq = new BFGlobalServiceStub.GetEventTypesReq();
                BFGlobalServiceStub.GetActiveEventTypesResponse typesRes = new BFGlobalServiceStub.GetActiveEventTypesResponse();
        
                BFGlobalServiceStub.APIRequestHeader header = new BFGlobalServiceStub.APIRequestHeader();
                header.setSessionToken(token);
                eventTypeReq.setHeader(header);
                
                types.setRequest(eventTypeReq);
                typesRes = stub.getActiveEventTypes(types);
     
                BFGlobalServiceStub.EventType[] type = typesRes.getResult().getEventTypeItems().getEventType();
                
                for(int i1=0; i1 < type.length;i1++)
                {
                     System.out.println("Event Type Name:" + type[i1].getName() +  " Type ID :"+ type[i1].getId());
                     ereq.setEventParentId(type[0].getId());
                     ereq.setHeader(header);
                     event.setRequest(ereq);
            
                    BFGlobalServiceStub.GetEventsResponse eres = stub.getEvents(event);
                    BFGlobalServiceStub.BFEvent[] events = eres.getResult().getEventItems().getBFEvent();
                    BFGlobalServiceStub.MarketSummary[] markets = eres.getResult().getMarketItems().getMarketSummary();
                          
                    if(events !=null && events.length > 0)
                    {
                        System.out.println("Event Names: "); 
                        for(int i=0; i < events.length;i++)
                        {
                            System.out.println(events[i].getEventName());
                        }
                    }
                          
                    if(markets !=null && markets.length > 0)
                    {
                        System.out.println("Market Names: ");
                        for(int j = 0; j < markets.length;j++)
                        {
                           System.out.println(markets[j].getMarketName());
                        }   
                    }
                }

            }else
            {
                System.out.println("Error found in login" );
                System.out.println("Failed to log in : " + res.getResult().getErrorCode());
                System.out.println("Header Error  : " + res.getResult().getHeader().getErrorCode());
            }
    }
}
