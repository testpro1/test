Betfair API Demonstration
=========================

This demonstration of the basics of using the Betfair Web Services API
has been created using the Apache AXIS library. The version 1.5.1 of
this library has been bundled into the download.

Required Software:
    Java 5 or later
    Apache Ant 1.7 later
    
Build instructions:
1. Unpack the downloaded file into a new directory.
2. Ensure that ant is in the path and is working correctly.
3. Build the project by typing 'ant' in the unpacked base directory.
4. Once the build succeeds, the executable jar file APIDemo.jar will be
   created. Instructions to run it are shown in the ant output.

Regenerating WSDL stubs:
1. Unpack the downloaded file into a new directory.
2. Ensure that ant is in the path and is working correctly.
3. Regenerate the stub classes  by typing 'ant stubs' in the unpacked base directory.

