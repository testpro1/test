
function reloadPage()
{
	document.location.reload(true);
}
/*
function readURL(input) {
	//alert("read url");
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$('#img_prev').attr('src', e.target.result).width(120).height(120);
		};
		reader.readAsDataURL(input.files[0]);
	}
}
  */	


function runScheduler()
{
	window.location.href = "Admin_Scheduler_Run.jsp";
}

 function makeItPassword()
  {
		
	 	 document.getElementById("passwordbox")
            .innerHTML = "<input id=\"password\" name=\"password\" type=\"password\"/>";
         document.getElementById("password").focus();
  }
 
 function removeEmail()
 {
	 if( document.getElementById("email").value == "Email address")
	 {
	    document.getElementById("email").value ="";
	 }
 }
 
 function getEmail()
 {
	 if( document.getElementById("email").value == "")
	 {
		  document.getElementById("email").value ="Email address";
	 }
	 
 }
 
 function removePassword(){
	 document.getElementById("password").value ="";
 }
 
 function getPassword()
 {
	 if( document.getElementById("password").value == "")
	 {
	  document.getElementById("password").value ="Email address";
	 }
 }
 
function saveCookie(name) {

	if(document.getElementById("remember").checked==true)
	{	var username1 = document.getElementById("email").value;
		var password = document.getElementById("password").value;
		var username = username1+","+password;
		if (username)
		{
			var date=new Date();
			date.setDate(date.getDate()+7);
			document.cookie = name + "=" + username+"; expires=" + date + "; path=/";
		}
	}
	else{
		return true;
	}
}

function checkCookie(name)
{	
	if (document.cookie.indexOf("mycookie") >= 0) 
	{
			//clearCookie(name);
			var today = new Date();
 			var expire = new Date();
 			expire.setTime(today.getTime() + 3600000*24*7);
 			document.cookie = name+"="+"mycookie"+";expires"+expire.toGMTString();
	}
	else
	{
   		return true;
	}
}


$(document).ready(function () {
	
	$('#password-password').show();
	$('#password').hide();
	
	
$('#password-password').focus(function() {
		$('#password').show();
		$('#password').val() == '';
		$('#password-password').hide();
	    $('#password-password').val() == '';
	    $('#password').focus();
	    
		/*if($('#password-password').val() == '') {
	    
	    }*/
		
	});
	
	$('#password').blur(function() {
		if($('#password').val() == '')
	    {
	    	$('#password').hide();
	    	$('#password-password').show();
	    	$('#password-password').val() == 'password';
	    }
	    
	    //$('#password-password').focus()	    
	
	});

	/*
	$('#password-password').blur(function() {
		$('#password').hide();
	    $('#password-password').show();
	    $('#password-password').val() == 'password';
	    
	    $('#password-password').focus()	});*/
	
});


function clearCookie(name) {
	var date=new Date();
	date.setDate(date.getDate()-1);
	document.cookie = name+ "=''; expires=" + date + "; path=/";
}

function getXmlHttpRequestObject() {
	
	if (window.XMLHttpRequest) {
		return new XMLHttpRequest();
	} else if(window.ActiveXObject) {
		return new ActiveXObject("Microsoft.XMLHTTP");
	} else {
		alert("Please upgrade your browser. The current version does not support the request.");
	}
}
setCookie =  function (name, value, expires_in_days) {
    var expiration_date = new Date();
    expiration_date.setDate(expiration_date.getDate() + expires_in_days);
    document.cookie = name + "=" + escape(value) +
    ((expires_in_days == null) ? "": ";expires=" + expiration_date.toUTCString()) + ";path=/;";
}
getCookie = function(name) {
    if (document.cookie.length > 0)
    {
        var cookie_start = document.cookie.indexOf(name + "=");
        if (cookie_start != -1)
        {
            cookie_start = cookie_start + name.length + 1;
            var cookie_end = document.cookie.indexOf(";", cookie_start);
            if (cookie_end == -1) cookie_end = document.cookie.length;
            return unescape(document.cookie.substring(cookie_start, cookie_end));
        }
    }
    return "";function changePasswordView()
{
//alert("changepasswordview");
	var url ="changepassword.jsp";
	var changepasswordView = getXmlHttpRequestObject();
	if(changepasswordView.readyState == 4 || changepasswordView.readyState == 0){
		changepasswordView.open("get", url, true);
		changepasswordView.onreadystatechange = function(){
			if(changepasswordView.readyState == 4 && changepasswordView.status == 200){
				//alert("respone text    "+ changepasswordView.responseText );
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepasswordView.responseText;
				
				/**  this code show curve in IE popup window*/
				var settings_general = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}
				
				var settings_head = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
					}

				var settings_row = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 6 },
					br: { radius: 6 },
					antiAlias: true
			}
			curvyCorners(settings_head, ".generalfrm");
			curvyCorners(settings_head, ".popupheading");
			curvyCorners(settings_row, ".popupmsg");
			
			/**Default focus field when change password page load */
			document.getElementById("oldpassword").focus();
			//callJqueryValidation("#frmchangepassword");
				
			}
		}
		
		changepasswordView.send(null);
	}
			
}
}

/*
//Added by Rupal Kathiriya for image preview dated on 20th july 2012
function readURL(input) {
  
    if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function (e) {
    $('#imageid')
    .attr('src', e.target.result)
    .width(120)
    .height(120);
    };
    reader.readAsDataURL(input.files[0]);
    }
    }
//Ended by Rupal Kathiriya for image preview dated on 20th july 2012
*/
function setDefaultFocus(focusId) {
	focusId.focus();
}
function setCurrentLocation(location) {
	getCity_latitude_longitude(location.split(", ")[0]);
}
function getCity_latitude_longitude(city) 
{
	var url='state.do?city=' +city + '&param=location';
	var ajax_cityData = getXmlHttpRequestObject();
	if(ajax_cityData.readyState == 4 || ajax_cityData.readyState == 0)
	{
		ajax_cityData.open("get", url, true);
		ajax_cityData.onreadystatechange = function()
		{
		  if(ajax_cityData.readyState == 4 && ajax_cityData.status == 200)
		  {
			 showCityOnMap(ajax_cityData.responseText, city);
		  }
		}
		ajax_cityData.send(null);
	}
}

function showCityOnMap(originalRequest, city)	{
	
   jsonRaw = originalRequest;
   var jsoncontent = jsonRaw.replace(/^\s+/, '').replace(/\s+$/, '');
   if(jsoncontent ==""){
	   initialize(40.7488,-73.9846, city);
   }
   else
   {
    var citydataArray = jsoncontent.split(":");
    var html='<p><font size="2px" color="blue">City : </font><font size="2px" color="blue">'+ city +'</font></p><p><font size="2px" color="blue">Latitude : </font><font size="2px" color="blue">' + citydataArray[0] +'</font></p><p><font size="2px" color="blue">Longitude : </font><font size="2px" color="blue">' +citydataArray[1] +'</font></p>';
   	initialize(citydataArray[0],citydataArray[1], html,'','');
   }
  
}
// google map function to get location//
var geocoder = null;
var mile = null;
var address = null;

function initialize(latitude,longitude, info, friendname, socialsiteicon, loggedinuserlatlang, imageName, userProfile)
{
			
			 geocoder = new google.maps.Geocoder();

				/**Condition to indicate that map request has come from People Finder View */
				if(info == 'peoplefinder')
				{
					
					 var latValue = latitude.substr(0,latitude.length - 1);
					 var longValue = longitude.substr(0,longitude.length - 1);
			 		 var friend = friendname.substr(0,friendname.length - 1);
			 		 var socialsite = socialsiteicon.substr(0,socialsiteicon.length - 1);
			 		 var loggedinuserlatlangArray = loggedinuserlatlang.split(":");
			 		 var image = imageName.substr(0,imageName.length-1);
			 		 var userAddress;
			 		 var latArray=new Array();	
			 		
			 		 if(latValue !=null && latValue !="")
			 		 {
			 			 latArray = latValue.split("_");	 
			 		 }
			 		 
					 longArray = longValue.split("_");
					 friendArray = friend.split("_");
					 socialiconArray = socialsite.split(",");
					 imageArray = image.split(",");
					 
					 /**Creating loggedin user's marker and his/her friend's marker on google map */
				  	   if(latArray !=null || latArray.length > 0 || loggedinuserlatlangArray != null || loggedinuserlatlangArray.length > 0)
				  		 {
				  		    var ownMarker,i;
				  		    var image;
				  		    var infowindow = new google.maps.InfoWindow();
				  		    var html = new Array();
			  		        myOptions = {
            								zoom: 14,
            								center: new google.maps.LatLng(loggedinuserlatlangArray[0],loggedinuserlatlangArray[1]),
            								mapTypeId: google.maps.MapTypeId.ROADMAP,
            								mapTypeControlOptions: {
      										style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    										}
        							};
				  		    var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
				  		   	var mgrOptions = { borderPadding: 50, maxZoom: 15, trackMarkers: true};
				  		  	var mgr = new MarkerManager(map, mgrOptions);
				  		  	
							mgr.refresh();
							
							userAddress = getUserAddress(loggedinuserlatlangArray[0],loggedinuserlatlangArray[1]);
							
				  		 	if(latArray != null)
							{
				  		 	for (i=0; i < latArray.length; i++)
				   			{
								var miledistance = ' ';
								html[i] ='<img src='+ imageArray[i]+ ' align="left" width="50px" height="50px" hspace="3px"></img><p><font size="2px" color="red">' + friendArray[i]+'</font></p><p><font size="0px">&nbsp;' + miledistance + ' miles away</font></p>';
																
								 if(socialiconArray[i] == "meetin_icon.png")
				  		  		  {
            							image ="images/meetin_pin.png";
				  		  		  }
								 if(socialiconArray[i] == "1_facebook_icon.png")
				  		  		  {
            							image ="images/facebookpin_small.png"; //facebookpin_small.png
				  		  		  }
								 if(socialiconArray[i] == "2_linkedin_icon.png")
				  		  		  {
            							image ="images/linkedin_pin.png";
				  		  		  }
								 if(socialiconArray[i] == "gmail_icon.png")
				  		  		  {
            							 image ="images/gmail_pin.png";
				  		  		  }
								 if(socialiconArray[i] == "twitter.png")
				  		  		  {
            							 image ="images/twitter_pin.png";
				  		  		  }
								 if(socialiconArray[i] == "4sq.png")
				  		  		  {
									 	image ="images/fs.png"; 
				  		  		  }
								 /**Create Logged In user's friend marker on map */
								var friendmarker = new google.maps.Marker({
           												 clickable:true,
           												 draggable:true,
            											 position:new google.maps.LatLng(latArray[i], longArray[i]),
            											 icon:image,
            											 map: map
        											});
								
								google.maps.event.addListener(friendmarker, 'click', (function(friendmarker, i) {
        							return function() {
        									var ans = getAddress(latArray[i], longArray[i], loggedinuserlatlangArray[0],loggedinuserlatlangArray[1], address);
       										setTimeout(showDistance, 1000, html[i], infowindow, map, friendmarker);
        							}
      							  })(friendmarker, i));
								
								/** Showing the friend's information on marker drag event */
								  friendmarker.setMap(map);
							}
				  		 }
				  		 				  		 	
				  		 	var numMarkers_ = [];
				  		 	google.maps.event.addListener(map, "zoom_changed", function() {
				  		 		var zoomlevel=map.getZoom();
				  		 		MarkerManager.prototype.getMarkerCount = function(zoomlevel) {
				  		 		var total = 0;
								  for (var z = 0; z <= zoomlevel; z++) {
								    	total +=numMarkers_[z];
									}
								  	
								} 
				  		 	});
				  		 	
				  		 	/**Create Logged In user's own marker  on map */
							 	var	ownMarker = new google.maps.Marker({
									position:new google.maps.LatLng(loggedinuserlatlangArray[0],loggedinuserlatlangArray[1]),
            						icon:"images/me_pin.png",
            						map:map
        						});
							 	google.maps.event.addListener(ownMarker, 'click', (function(ownMarker, i) {
        							return function() {
        								var user ='<img src='+userProfile.split("&")[1] + ' align="left" width="50px" height="50px" hspace="3px"></img><p><font size="2px" color="red">' 
        													+ userProfile.split("&")[0]+'</font></p>';
       										setTimeout(showDistance, 1000, user, infowindow, map, ownMarker);
        							}
      							  })(ownMarker, i));
							 	
							 	ownMarker.setMap(map);
							}
				  	   
				  	   return false;
				}
				
				 /**Default Google Map creator when page load */
				 var centerPoint = new google.maps.LatLng(latitude, longitude);
				 
				 var myOptions = {
            				zoom: 14,
            				center: centerPoint,
            				mapTypeId: google.maps.MapTypeId.ROADMAP,
            				mapTypeControlOptions: {
      						style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    					}
        			};
				map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
				// we create draggable marker of the user's location
        		var myLocationMarker = new google.maps.Marker({draggable:true, icon:"images/me_pin.png", map:map});
        		myLocationMarker.setPosition(centerPoint);
        		
        		document.getElementById("destinationLatitude").value = latitude;
				document.getElementById("destinationLongitude").value = longitude;
				
        		google.maps.event.addListener(myLocationMarker, 'dragend', function(event) {
          		// closure is called when draggin ends
            			var point = this.getPosition();
            			map.panTo(point); 
            			document.getElementById("destinationLatitude").value = point.lat();
						document.getElementById("destinationLongitude").value = point.lng();
				});
        		myLocationMarker.setAnimation(google.maps.Animation.DROP);
        		myLocationMarker.setMap(map);
}



function getMarkers(markers){

	document.getElementById("markers").innerHTML;
	
}
/** this function show friend image and location in google map when click on individual */

function getFriendOnGrid(userId)
{
	var url ="peoplefinder.do?action=peoplenearme&selFrdId="+userId;
	var peoplenearme = getXmlHttpRequestObject();
	if(peoplenearme.readyState == 4 || peoplenearme.readyState == 0){
		peoplenearme.open("get", url, true);
		peoplenearme.onreadystatechange = function(){
			if(peoplenearme.readyState == 4 && peoplenearme.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("peoplenearme").style.display = 'block';
				document.getElementById("peoplenearme").innerHTML = peoplenearme.responseText;
					
				/*Code to view the location and details of the friend's on google map*/
				/*var latitude = document.getElementById("latitude").value;
				var langitude =document.getElementById("langitude").value;
				var friendname =document.getElementById("friendname").value;
				var googlemarkericon =document.getElementById("googlemarkericon").value;
				var loggedinuserlatlang =document.getElementById("loggedinuserlatlang").value;
				var imageName =document.getElementById("imageName").value;
				getFriendinitialize(latitude,langitude,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName,userId);
				document.getElementById("map").style.display = 'block';
					*/
				
			}
		}
		
		peoplenearme.send(null);
	}
}

////////////////////////////////

function getFriendforTripinitialize(latitude,longitude, info, friendname, socialsiteicon, loggedinuserlatlang, imageName, userId)
{			
				geocoder = new google.maps.Geocoder();
				/**Condition to indicate that map request has come from People Finder View */
				if(info == 'peoplefinder')
				{
					 var latValue = latitude;
					 var longValue = longitude;
					 var friend = friendname.substr(0,friendname.length );
			 		 var socialsite = socialsiteicon.substr(0,socialsiteicon.length - 1);
			 		 var loggedinuserlatlangArray = loggedinuserlatlang.split(":");
			 		 var image = imageName.substr(0,imageName.length);
			 		 var userAddress;
 			 		 var latArray=new Array();
 			 		 var userid = userId.substr(0,userId.length);
 			 		 //var location = location;
					 //var locationResult = location.split("&");
					 //var friendId = locationResult[0];
					 //var trip_location = locationResult[1];
					// var frdId = friendId.substring(7);
					 //var triplocation = trip_location.substring(9);

			 		 if(latValue !=null && latValue !="")
			 		 {
			 			latArray = latValue.split("_");	 
			 		 }
			 		 
					 longArray = longValue.split("_");
					 friendArray = friend.split("_");
					 socialiconArray = socialsite.split(","); 
					 imageArray = image.split(",");function changePasswordView()
{
//alert("changepasswordview");
	var url ="changepassword.jsp";
	var changepasswordView = getXmlHttpRequestObject();
	if(changepasswordView.readyState == 4 || changepasswordView.readyState == 0){
		changepasswordView.open("get", url, true);
		changepasswordView.onreadystatechange = function(){
			if(changepasswordView.readyState == 4 && changepasswordView.status == 200){
				//alert("respone text    "+ changepasswordView.responseText );
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepasswordView.responseText;
				
				/**  this code show curve in IE popup window*/
				var settings_general = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}
				
				var settings_head = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
					}

				var settings_row = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 6 },
					br: { radius: 6 },
					antiAlias: true
			}
			curvyCorners(settings_head, ".generalfrm");
			curvyCorners(settings_head, ".popupheading");
			curvyCorners(settings_row, ".popupmsg");
			
			/**Default focus field when change password page load */
			document.getElementById("oldpassword").focus();
			//callJqueryValidation("#frmchangepassword");
				
			}
		}
		
		changepasswordView.send(null);
	}
			
}
					 
					 userIdArray = userid.split("_");
					 
					 /**Creating loggedin user's marker and his/her friend's marker on google map */
				  	   if(latArray !=null && latArray.length > 0)
				  		 {
				  		    var ownMarker,i;
				  		    //var image;
				  		    var infowindow = new google.maps.InfoWindow();
				  		    var html = new Array();
				  		    i=0;
			  		    
				  		    myOptions = {
            								zoom: 14,
            								center: new google.maps.LatLng(latArray[i], longArray[i]),
            								mapTypeId: google.maps.MapTypeId.ROADMAP,
            								mapTypeControlOptions: {
      										style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    									}
        							};
				  		    var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
				  		   
				  		 /* this method is used for get Facebook and other friend location and image */
				  		    userAddress = getUserAddress(latArray[i], longArray[i]);
				  		    //userAddress = getAddress(latArray[i], longArray[i]);
							
								var miledistance = ' ';
																
							
								html[i] ='<img src='+ imageArray[i]+ ' align="left" width="50px" height="50px" hspace="3px"></img><p><font size="2px" color="red">' + friendArray[i]+'</font></p><p><font size="0px">&nbsp;' + miledistance + ' miles away</font></p>';
										
								socialsiteicon = socialsiteicon.split("/")[1];
								 if(socialsiteicon== "meetin_icon.png")
				  		  		  {
										  		  		  
										image ="images/meetin_pin.png";
				  		  		  }
								 if(socialsiteicon == "1_facebook_icon.png")
				  		  		  {
									  	image ="images/facebookpin_small.png"; //facebookpin_small.png
				  		  		  }
								 if(socialsiteicon == "2_linkedin_icon.png")
				  		  		  {
            							image ="images/linkedin_pin.png";
				  		  		  }
								 if(socialsiteicon == "gmail_icon.png")
				  		  		  {
			        					 image ="images/gmail_pin.png";
				 		  		  }
								 if(socialsiteicon == "twitter.png")
				  		  		  {
            							 image ="images/twitter_pin.png";
				  		  		  }
								 /**Create Logged In user's friend marker on map */
								var friendmarker = new google.maps.Marker({
           												 clickable:true,
            											 position:new google.maps.LatLng(latArray[i], longArray[i]),
            											 icon:image,
            											 map: map
        											});
								//mgr.addMarkers(friendmarker);
								/**Create Logged In user's own marker  on map */
								ownMarker = new google.maps.Marker({
									position:new google.maps.LatLng(loggedinuserlatlangArray[0],loggedinuserlatlangArray[1]),
            						icon:"images/me_pin.png",
            						map:map
        						});
								
								/** Showing grid on friend name */
								// getFriendOnGridfindpeopleforTrip(userIdArray[i]);
								 //getFriendOnGridforTrip(frdId,triplocation);
								 getFriendOnGridforTrip(userId);
								
								/** Showing the friend's information on marker drag event */
								 google.maps.event.addListener(friendmarker, 'click', (function(friendmarker, i) {
        								return function() {
													
											//mgr.getMarkerCount(map.getZoom());
        									var ans = getAddress(latArray[i], longArray[i], loggedinuserlatlangArray[0],loggedinuserlatlangArray[1], address);
       										setTimeout(showDistance, 1000, html[i-1], infowindow, map, friendmarker);
       										
        								}
      							  })(friendmarker, i));
								  /*ownMarker.setMap(map);*/
								  friendmarker.setMap(map);
								  
				   			/*}*/
								  
						 }		
						return false;
				}
				
}


function getFriendOnGridforTrip(userId)
{
	//var url ="peoplefinder.do?action=findpeopleforTrip&selFrdId="+frdId+"&location=" +triplocation;
	var url ="peoplefinder.do?action=findpeopleforTrip&selFrdId="+userId;
	
	var findpeopleforTrip = getXmlHttpRequestObject();
	if(findpeopleforTrip.readyState == 4 || findpeopleforTrip.readyState == 0){
		findpeopleforTrip.open("get", url, true);
		findpeopleforTrip.onreadystatechange = function(){
			if(findpeopleforTrip.readyState == 4 && findpeopleforTrip.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("content").style.display = 'block';
				document.getElementById("content").innerHTML = findpeopleforTrip.responseText;
					
				/*Code to view the location and details of the friend's on google map*/
				/*var latitude = document.getElementById("latitude").value;
				var langitude =document.getElementById("langitude").value;
				var friendname =document.getElementById("friendname").value;
				var googlemarkericon =document.getElementById("googlemarkericon").value;
				var loggedinuserlatlang =document.getElementById("loggedinuserlatlang").value;
				var imageName =document.getElementById("imageName").value;
				getFriendinitialize(latitude,langitude,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName,userId);
				document.getElementById("map").style.display = 'block';*/
					
					
			}
		}
		
		findpeopleforTrip.send(null);
	}
}

function showDistance(html, infowindow, map, friendmarker){
	
	html = html.replace("  miles away", mile+" miles away");
	infowindow.setContent(html);
	infowindow.open(map, friendmarker);
}
function getAddress(lat, lng, userlat, userlang, address)
	{
	
		var lat = parseFloat(lat);
	    var lng = parseFloat(lng);
    	var latlng = new google.maps.LatLng(lat, lng);
	    geocoder.geocode({'latLng': latlng}, function(results, status) {
	      if (status == google.maps.GeocoderStatus.OK) {
	        if (results[1]) {
	        	showLocation(address, results[1].formatted_address, lat, lng, userlat, userlang);
	        }
	      } else {
	       // alert("Geocoder failed due to: " + status);
	        return false;
	      }
	    });
	    
	}
function getUserAddress(userlat, userlang)
{
		
	var latlng = new google.maps.LatLng(userlat, userlang);
	geocoder.geocode({'latLng': latlng}, function(results, status) {
		if (status == google.maps.GeocoderStatus.OK) {
	     	if (results[1]) {
	        	address = results[1].formatted_address; 
	        }
	    } else {
	        //alert("Geocoder failed due to: " + status);
	    }
	});
	
}

function showLocation(userAddress, friendAddress, lat, lng, userlat, userlang) {

		var origin1 = new google.maps.LatLng(userlat, userlang); //23.04083632821982, 72.52852969311516
		var origin2 = userAddress;
		var destinationA = friendAddress;
		var destinationB = new google.maps.LatLng(lat, lng);
		
		var service = new google.maps.DistanceMatrixService();
		service.getDistanceMatrix(
		  {
		    origins: [origin1, origin2],
		    destinations: [destinationA, destinationB],
		    travelMode: google.maps.TravelMode.DRIVING,
		    avoidHighways: false,
		    unitSystem : google.maps.UnitSystem.IMPERIAL,
		    avoidTolls: false
		  }, callback);
				
		if(mile!=null)
		{
			return true;
		}
	}
 function callback(response, status) {
	 
	 if (status == google.maps.DistanceMatrixStatus.OK) {
	    var origins = response.originAddresses;
	    var destinations = response.destinationAddresses;
	    for (var i = 0; i < origins.length; i++) {
	    	var results = response.rows[i].elements;
	      	for (var j = 0; j < results.length; j++) {
		        var element = results[j];
		        var distance = element.distance.text;
		        var duration = element.duration.text;
		        var from = origins[i];
		        var to = destinations[j];
	      	}
	    }
  		
	    mile = distance.substr(0, distance.indexOf(" mi"));
	
	  }
 }
	function calculateDistance()
	{
		
		try
		{
			var glatlng1 = new GLatLng(location1.lat, location1.lon);
			var glatlng2 = new GLatLng(location2.lat, location2.lon);
			var miledistance = glatlng1.distanceFrom(glatlng2, 3959).toFixed(1);
			var kmdistance = (miledistance * 1.609344).toFixed(1);
 			return kmdistance;
			//document.getElementById('results').innerHTML = '<strong>Address 1: </strong>' + location1.address + '<br /><strong>Address 2: </strong>' + location2.address + '<br /><strong>Distance: </strong>' + miledistance + ' miles (or ' + kmdistance + ' kilometers)';
		}
		catch (error)
		{
			alert(error);
		}
	}
/** This function show the street area view on google map entered by user.
 *  If there is no street area available on google map then location on map should be the name of User City.
*/
	
 function showStreetAddress(streetname,cityname) {
	 
	 /**first attemp will locate the Street and City location on google map */
	 var address ="";
	 if(streetname !="")
	 {	 
		address = streetname+ ", "+cityname;
	}
	else
	{
		address =cityname;
	}
		
	geocoder.geocode( { 'address': address}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
    	var location  =  results[0].geometry.location;
    	var centerPoint = new google.maps.LatLng(location.lat(), location.lng());
    	
      	var myOptions = {
          				zoom: 14,
          				center: centerPoint,
           				mapTypeId: google.maps.MapTypeId.ROADMAP,
           				mapTypeControlOptions: {
    					style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    				}
       			};
      	
		var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
            
        var marker = new google.maps.Marker({
            map: map,
            position: location,
            draggable:true,
            icon:"images/me_pin.png"
        });
        
    	marker.setPosition(centerPoint);
    	
        document.getElementById("destinationLatitude").value = location.lat();
		document.getElementById("destinationLongitude").value = location.lng();
		
		
		/**Marker drag event code */
		google.maps.event.addListener(marker, 'dragend', function(event) {
          		  // closure is called when draggin ends
            			var point = this.getPosition();
            			map.panTo(point);
            			
            			document.getElementById("destinationLatitude").value = point.lat();
						document.getElementById("destinationLongitude").value = point.lng();
        		});
			marker.setMap(map);
		return false;
      } else {
     //	alert("else");
    	  getCity_latitude_longitude(cityname);
      }
    });
	
}
/**  This function will call the server code that check the incoming email is already registered or not */ 

function emailAvailabilityCheck()
{
	var email = document.getElementById("email").value;
	var x = document.getElementById("email");
	var msg =document.getElementById("email_available_msg");
	var url = "register.do?action=emailcheck&email="+email;
	var emailReq = getXmlHttpRequestObject();
	
	if(emailReq.readyState == 4 || emailReq.readyState == 0){
		emailReq.open("get", url, true);
		emailReq.onreadystatechange = function()
		{
			if(emailReq.readyState == 4 && emailReq.status == 200)
			{
				
				if(emailReq.responseText != "")
					{
						
          				msg.style.display ='block';
          				x.value ="";
          				return false;
        			}
				else
					{
						msg.style.display ='none';
					}
			}
		}
		emailReq.send(null);
	}
}
/*
 *  Redirect the Parent Page to signup.jsp after login Complete.
 */
function callsignup()
{
 	window.location.href = "signup.jsp";
}

function callAddTrip1(location)
{
	var startDate = document.getElementById("startDate").value;
	var endDate = document.getElementById("endDate").value 
	window.location.href = "addtrip.jsp?location="+location+"&startDate="+startDate+"&endDate="+endDate+"&suggest=suggesttrip";
}

/**
	facebook login url function for setupnetwork of mobile
*/


function facebookLoginURL(appId, redirect_uri, scope) {
	window.location.href = "https://www.facebook.com/dialog/oauth?client_id="+appId+"&redirect_uri="+redirect_uri+"&scope="+scope;
}

/*
 * 
 * @param {Object} appId
 * @param {Object} redirect_uri
 * @param {Object} scope
 * 
 * Login with facebook and getting Generated Code.
 */
function facebookLogin(appId, redirect_uri, scope)
{
	if(window.location.hash.length == 0)
    {
	    url = "https://www.facebook.com/dialog/oauth?client_id="+appId+"&redirect_uri="+redirect_uri+"&scope="+scope;
        
         newwindow=window.open(url,'name','height=400,width=700,scrollbars=1');
         
        if (window.focus) 
	    {
	    	window.close();
	    }
    }
}

function foursquareLogin(client_id,redirect_url)
{
	if(window.location.hash.length == 0)
    {
		url =authUrl="https://foursquare.com/oauth2/authenticate?client_id="+client_id +"&response_type=code&redirect_uri="+redirect_url;
		newwindow=window.open(url,'name','height=380,width=550,scrollbars=1');
	    if (window.focus) 
	    {
	    	window.close();
	    }
    }	
}


function GmailLogin(URL)
{
	newwindow=window.open(URL,'name','height=400,width=700,scrollbars=1');
    if (window.focus) 
    {
    	window.close();
    }
}
function OrkutLogin()
{
	 url = "orkutAuthentication.jsp"
	newwindow=window.open(url,'name','height=400,width=700,scrollbars=1');
    if (window.focus) 
    {
    	window.close();
    }
}
	function addNetwork_wizard() {
			addSocialNetwork('LinkedIn,Wizard');
		}

	function addGmailNetwork_wizard()
	{
		addSocialNetwork('Gmail,Wizard');
	}
	
	function addtwitterNetwork_wizard()
	{
		addSocialNetwork('Twitter,Wizard');
	}
	
	function addtripitNetwork_wizard()
	{
		addSocialNetwork('Tripit,Wizard');
	}
	
	
	

function LinkedInLogin()
{

    if(window.location.hash.length == 0)
    {
        url = "linkedInAuthentication.jsp";
        newwindow=window.open(url,'name','height=380,width=550,scrollbars=1');
	    if (window.focus) 
	    {
	    	window.close();
	    }
    }
}

function LinkedInLogin_wizard()
{
	
    if(window.location.hash.length == 0)
    {
        url = "linkedInAuthentication.jsp";
        newwindow=window.open(url,'name','height=380,width=550,scrollbars=1');
	    if (window.focus) 
	    {
	    	window.close();
	    }
    }
}

function twitterLogin()
{
	if(window.location.hash.length == 0)
    {
		 url = "twitterAuthentication.jsp"
        newwindow=window.open(url,'name','height=380,width=550,scrollbars=1');
	    if (window.focus) 
	    {
	    	window.close();
	    }
    }	
}

function tripitLogin()
{
	if(window.location.hash.length == 0)
    {
		 url = "tripitAuthentication.jsp"
        newwindow=window.open(url,'name','height=380,width=550,scrollbars=1');
	    if (window.focus) 
	    {
	    	window.close();
	    }
    }	
}

function myspaceLogin()
{
	if(window.location.hash.length == 0)
    {
		 url = "myspaceAccessToken.jsp"
        newwindow=window.open(url,'name','height=380,width=550,scrollbars=1');
	    if (window.focus) 
	    {
	    	window.close();
	    }
    }	
}

function GooglePlusLogin(URL)
{
	newwindow=window.open(URL,'name','height=400,width=700,scrollbars=1');
    if (window.focus) 
    {
    	window.close();
    }
}

function people_upCommingTrip() {
	
	
	//var url = "peoplefinder.do?action=upCommingTrip";
	document.getElementById("map").style.display='none';
	var url = "trip.do?trip=upcomingtrip&peoplefinder=true";
	var people_Req = getXmlHttpRequestObject();
	if(people_Req.readyState == 4 || people_Req.readyState == 0){
		people_Req.open("get", url, true);
		people_Req.onreadystatechange = function(){
			if(people_Req.readyState == 4 && people_Req.status == 200){
				document.getElementById("upcommingtripbtn").className += " active";
				document.getElementById("peoplenearmebtn").className = "iphonebutton";
				document.getElementById("advancesearchbtn").className = "iphonebutton";
				/*document.getElementById("peoplefinder").style.display='none';
				document.getElementById("upcommingtrip").style.display='block';
				document.getElementById("advancesearch").style.display='none';*/
				document.getElementById("content").innerHTML = people_Req.responseText;
				
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{ 
						curvecornerdefault_IE();
					}
			}
		}
		people_Req.send(null);
	}
}
function peoplelist_upcommingtrip(location, tripdate,tripId,latitude,langitude) {
	
	//$("#upcommingtrip").removeClass('iphonebutton').addClass('iphonebutton active');
    //$("#peoplefinder").addClass('iphonebutton');
	
	document.getElementById("map").style.display='block';
	//setCurrentLocation(location);
	
	var url = "peoplefinder.do?action=findpeopleforTrip&location="+location +"&tripdate="+tripdate+"&tripId=" +tripId;
	var people_upcoming_Req = getXmlHttpRequestObject();
	if(people_upcoming_Req.readyState == 4 || people_upcoming_Req.readyState == 0){
		people_upcoming_Req.open("get", url, true);
		people_upcoming_Req.onreadystatechange = function(){
			if(people_upcoming_Req.readyState == 4 && people_upcoming_Req.status == 200){
				document.getElementById("loading").style.display='none';
				/*document.getElementById("upcommingtrip").style.display='none';
				document.getElementById("peoplefinder").style.display='block';*/
				document.getElementById("content").innerHTML = people_upcoming_Req.responseText;
				
				/**Code to view the location and details of the friend's on google map*/
				/*var latitude = document.getElementById("latitude").value;
				var langitude =document.getElementById("langitude").value;
				var friendname =document.getElementById("friendname").value;
				var googlemarkericon =document.getElementById("googlemarkericon").value;
				var loggedinuserlatlang =document.getElementById("loggedinuserlatlang").value;
				var imageName =document.getElementById("imageName").value;
				initialize(latitude,langitude,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName);*/
			
				initialize(latitude,langitude,'','','','','');
				
			}
		}
		people_upcoming_Req.send(null);
	}
}
/** This function will fetch all friends list and display it on upcomming trip page based on trip location selection *//*
function findPeopleFromUpcomingTrip(location, viewreference)
{
	document.getElementById("loading").style.display ='block';
	var url = "peoplefinder.do?action=findpeopleforTrip1&viewref="+viewreference+"&location="+location;
	var peopleReq = getXmlHttpRequestObject();
	if(peopleReq.readyState == 4 || peopleReq.readyState == 0){
		peopleReq.open("get", url, true);
		peopleReq.onreadystatechange = function(){
			if(peopleReq.readyState == 4 && peopleReq.status == 200){
				document.getElementById("loading").style.display ='none';
				document.getElementById("content").style.display ='block';
				document.getElementById("content").innerHTML = peopleReq.responseText;
				document.getElementById("peoplenearme").style.display ='block';
				document.getElementById("peoplenearme").innerHTML = peopleReq.responseText;
				
				this condition/method is called for curve show in IE				if (navigator.appName=="Microsoft Internet Explorer")
					{ 
						curvecorner_IE();
					}
				*//**Code to view the location and details of the friend's on google map*//*
				var latitude = document.getElementById("latitude").value;
				
				var langitude =document.getElementById("langitude").value;
				
				var friendname =document.getElementById("friendname").value;
				var googlemarkericon =document.getElementById("googlemarkericon").value;
				var loggedinuserlatlang =document.getElementById("loggedinuserlatlang").value;
				var imageName =document.getElementById("imageName").value;
				
				initialize(null,null,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName);
			}
		}
		peopleReq.send(null);
		
	}
}
*/





function findPeopleFromUpcomingTrip(location)
{
	document.getElementById("loading").style.display ='block';
	var url = "peoplefinder.do?action=findPeopleFromUpcomingTrip&location="+location;
	var peopleReq = getXmlHttpRequestObject();
	if(peopleReq.readyState == 4 || peopleReq.readyState == 0){
		peopleReq.open("get", url, true);
		peopleReq.onreadystatechange = function(){
			if(peopleReq.readyState == 4 && peopleReq.status == 200){
				document.getElementById("loading").style.display ='none';
				document.getElementById("content").style.display ='block';
				document.getElementById("content").innerHTML = peopleReq.responseText;
				/*document.getElementById("peoplenearme").style.display ='block';
				document.getElementById("peoplenearme").innerHTML = peopleReq.responseText;*/
			}
		}
		peopleReq.send(null);
	}
}

function findPeopleFromUpcomingTrip(location, startDate, endDate)
{
	document.getElementById("loading").style.display ='block';
	var url = "peoplefinder.do?action=findPeopleFromUpcomingTrip&location="+location + 
			  "&startDate="+ startDate+"&endDate="+endDate;

	var peopleReq = getXmlHttpRequestObject();
	if(peopleReq.readyState == 4 || peopleReq.readyState == 0){
		peopleReq.open("get", url, true);
		peopleReq.onreadystatechange = function(){
			if(peopleReq.readyState == 4 && peopleReq.status == 200){
				document.getElementById("loading").style.display ='none';
				document.getElementById("content1").style.display ='block';
				document.getElementById("content1").innerHTML = peopleReq.responseText;
				/*document.getElementById("peoplenearme").style.display ='block';
				document.getElementById("peoplenearme").innerHTML = peopleReq.responseText;*/
			}
		}
		peopleReq.send(null);
	}
}


function navigatefindPeopleFromUpcomingTrip(event)
{
	var paging = document.getElementById("page_combo").value 
	document.getElementById("loading").style.display = 'block';
	var url = "peoplefinder.do?action=navigatefindPeopleFromUpcomingTrip&e="+event + "&paging=" + paging+"&location="+document.getElementById("location").value;
	
	var suggestedFriends = getXmlHttpRequestObject();
	if(suggestedFriends.readyState == 4 || suggestedFriends.readyState == 0){
		suggestedFriends.open("get", url, true);
		suggestedFriends.onreadystatechange = function(){
			if(suggestedFriends.readyState == 4 && suggestedFriends.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("content").style.display ='block';
				document.getElementById("content").innerHTML =suggestedFriends.responseText;
			}
		}
		
		suggestedFriends.send(null);
	}
}

function navigatefindPeopleFromUpcomingTrip(event)
{
	var paging = document.getElementById("page_combo").value 
	document.getElementById("loading").style.display = 'block';
	var url = "peoplefinder.do?action=navigatefindPeopleFromUpcomingTrip&e="+event + "&paging=" + paging+"&location="+document.getElementById("location").value;
	
	var suggestedFriends = getXmlHttpRequestObject();
	if(suggestedFriends.readyState == 4 || suggestedFriends.readyState == 0){
		suggestedFriends.open("get", url, true);
		suggestedFriends.onreadystatechange = function(){
			if(suggestedFriends.readyState == 4 && suggestedFriends.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("content1").style.display ='block';
				document.getElementById("content1").innerHTML =suggestedFriends.responseText;
			}
		}
		
		suggestedFriends.send(null);
	}
}




/*
function findPeopleFromUpcomingTrip(location, viewreference)
{
	document.getElementById("loading").style.display ='block';
	var url = "peoplefinder.do?action=findpeopleforTrip1&viewref="+viewreference+"&location="+location;
	var peopleReq = getXmlHttpRequestObject();
	if(peopleReq.readyState == 4 || peopleReq.readyState == 0){
		peopleReq.open("get", url, true);
		peopleReq.onreadystatechange = function(){
			if(peopleReq.readyState == 4 && peopleReq.status == 200){
				document.getElementById("loading").style.display ='none';
				document.getElementById("content1").style.display ='block';
				document.getElementById("content1").innerHTML = peopleReq.responseText;
				this condition/method is called for curve show in IE				if (navigator.appName=="Microsoft Internet Explorer")
					{ 
						curvecorner_IE();
					}
				*//**Code to view the location and details of the friend's on google map*//*
				var latitude = document.getElementById("latitude").value;
				
				var langitude =document.getElementById("langitude").value;
				
				var friendname =document.getElementById("friendname").value;
				var googlemarkericon =document.getElementById("googlemarkericon").value;
				var loggedinuserlatlang =document.getElementById("loggedinuserlatlang").value;
				var imageName =document.getElementById("imageName").value;
				
				initialize(null,null,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName);
			}
		}
		peopleReq.send(null);
		
	}
}

*/
// This function will display the div for advance friend search.
function gotoAdvanceSearch()
{
	window.location.href="searchfriend.jsp?ref=advancesearch";
	//document.getElementById("simplesearch").style.display='none';
	//document.getElementById("advancesearch").style.display='block';
	//document.getElementById("name").focus();
	//document.getElementById("innercontainer").style.visibility="hidden";
	/* Calling Jquery validation function to perform Validation on Advance Search Page */
	//callSearchValidation("#frmadvancesearch");
}
// This function will display the div for simple friend search.
function gotoSimpleSearch()
{
	window.location.href="searchfriend.jsp?ref=simplesearch";
	//document.getElementById("simplesearch").style.display='block';
	//document.getElementById("advancesearch").style.display='none';
	//document.getElementById("friendname").focus();
	/* Calling Jquery validation function to perform Validation on Simple Search Page */
	//callSearchValidation("#frmsimplesearch");
}


// This function will call server code and fetch the friends list(Simple Search)
function simpleFriendSearch(pagenumber){
	var friendname = document.getElementById("friendname").value;
	if(friendname == "")
		{
		   /* Calling Jquery validation function to perform Validation on Simple Search Page */
		   callSearchValidation("#frmsimplesearch");
		   document.getElementById('friendname').focus();
		   return false;
		}
	else {
	
		document.getElementById("loading").style.display='block';
		
		var friendname = document.getElementById("friendname").value;
		var url = "friend.do?fparam=simplefriendsearch&friendname=" +friendname + "&page=" +pagenumber+"&ref=simplesearch";
		
		var ajaxReq_simplesearch = getXmlHttpRequestObject();
		if(ajaxReq_simplesearch.readyState == 4 || ajaxReq_simplesearch.readyState == 0){
			ajaxReq_simplesearch.open("get", url, true);
			ajaxReq_simplesearch.onreadystatechange = function(){
				if(ajaxReq_simplesearch.readyState == 4 && ajaxReq_simplesearch.status == 200){
					document.getElementById("loading").style.display='none';
					document.getElementById("simplesearch").style.display='none';
					document.getElementById("searchresult").style.display='block';
					document.getElementById("searchresult").innerHTML = ajaxReq_simplesearch.responseText;
					
					//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{ 
						curvecornerdefault_IE();				
					}
				}
			}
	
			ajaxReq_simplesearch.send(null);
	    }
		document.getElementById('friendname').focus();
		return false;
	}
}
// This function call server code and fetch friend list(Advance search)
function advanceFriendSearch(pagenumber)
{
	/*if(document.getElementById("name").value == "")
	{
	     
		 callSearchValidation("#frmadvancesearch");
		 document.getElementById('friendname').focus();
		 return false;
	}
	else {
		document.getElementById("loading").style.display='block';
			
		var name = document.getElementById("name").value;
		var location = document.getElementById("location").value;
		var company =document.getElementById("company").value;
		var keyword =document.getElementById("keyword").value;
	*/	
	var name = document.getElementById("name").value;
	var location = document.getElementById("location").value;
	var company =document.getElementById("company").value;
	var keyword =document.getElementById("keyword").value;
	

	if((name == "" || name == null) && (location =="" || location== null) && (company=="" || company == null) && (keyword =="" || keyword == null))
	{
		alert("Atleast one field must have value");
		return false;
	}
	else
	{
		document.getElementById("loading").style.display='block';
		var url = "friend.do?fparam=advancefriendsearch&name=" +name + "&location="+location +"&company="+company + "&keyword="+keyword +"&page=" + pagenumber+"&ref=advancesearch";
		
		var ajaxReq_searchfriend = getXmlHttpRequestObject();
		if(ajaxReq_searchfriend.readyState == 4 || ajaxReq_searchfriend.readyState == 0){
			ajaxReq_searchfriend.open("get", url, true);
			ajaxReq_searchfriend.onreadystatechange = function(){
				if(ajaxReq_searchfriend.readyState == 4 && ajaxReq_searchfriend.status == 200){
					document.getElementById("loading").style.display='none';
					document.getElementById("advancesearch").style.display='none';
					document.getElementById("searchresult").style.display='block';
					document.getElementById("searchresult").innerHTML = ajaxReq_searchfriend.responseText;
					
					//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{ 
						curvecornerdefault_IE();				
					}
				}
			}
			ajaxReq_searchfriend.send(null);
		}
		document.getElementById('name').focus();
		return false;
	}
}

function editTrip(tripid)
{
	window.location.href='edittrip.jsp?tripid='+tripid;
}

function addMeetInFriends(actionUrl,viewreference){
	document.getElementById("loading").style.display='block';
	var url = actionUrl;
	var ajaxReq_addfriend = getXmlHttpRequestObject();
	if(ajaxReq_addfriend.readyState == 4 || ajaxReq_addfriend.readyState == 0){
		ajaxReq_addfriend.open("get", url, true);
		ajaxReq_addfriend.onreadystatechange = function(){
			if(ajaxReq_addfriend.readyState == 4 && ajaxReq_addfriend.status == 200){
				
				if(viewreference !=null && viewreference == "searchfriend")
					{
					    // This line of code indicate that user has add friend from Search Friend Page
						document.getElementById("loading").style.display='none';
						//document.getElementById("simplesearch").style.display='none';
						//document.getElementById("advancesearch").style.display='none';
						//document.getElementById("searchresult").style.display='block';
						document.getElementById("searchresult").innerHTML = ajaxReq_addfriend.responseText;
						
					}
				else if(viewreference !=null && viewreference == "profilevisitor")
					{
					    // This line of code indicate that user has add friend from Profile Visitor Page
						window.location.href="myprofile.jsp?action=profilevisitors";
					}
			}
		}
		ajaxReq_addfriend.send(null);
	}
}
function viewFriends(socialsite,socialid)
{
	var url = "friend.do?fparam=viewfriends&ref=" +socialsite+"&sid="+socialid;
	var ajaxReq_addfriend = getXmlHttpRequestObject();
	if(ajaxReq_addfriend.readyState == 4 || ajaxReq_addfriend.readyState == 0){
		ajaxReq_addfriend.open("get", url, true);
		ajaxReq_addfriend.onreadystatechange = function(){
			if(ajaxReq_addfriend.readyState == 4 && ajaxReq_addfriend.status == 200){
				document.getElementById("loading").style.display='none';
				document.getElementById("myfriendlist").style.display='block';
				document.getElementById("myfriendlist").innerHTML = ajaxReq_addfriend.responseText;
				
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerdefault_IE();
					}
			}
		}
		ajaxReq_addfriend.send(null);
	}
}

function callUpcomingTrip1(){
	window.location.href='trip.do?trip=' + escape("upcomingtrip");	
}

function callUpcomingTrip(){
	window.location.href='trip.do?trip=' + escape("upcomingtrip");	
}
function callPastTrip(){
	window.location.href='trip.do?trip=' + escape("pasttrip");	
}
function callSuggestTrip(){
		window.location.href='suggestTrip.jsp';
}
function callAddTrip(){
	window.location.href='addtrip.jsp';
}

/** This function will call action servlet to remove the user's trip */
function removeUserTrip(tripid)
{
	var agree=confirm("Are you sure to remove the trip?");
	if (agree)
		{
		   var url = "trip.do?tripId=" +tripid+ "&trip=" + escape("removetrip");
		   var removetrip = getXmlHttpRequestObject();
			if(removetrip.readyState == 4 || removetrip.readyState == 0){
					removetrip.open("get", url, true);
				    removetrip.onreadystatechange = function(){
						if(removetrip.readyState == 4 && removetrip.status == 200){
							window.location.href='trip.do?trip=' + escape("upcomingtrip");
				}
			}
				    
			removetrip.send(null);	    
	  	  }
			
	    }
	   else
	    {
		  return false ; 
	    }

}

function callInviteFriend(){
	window.location.href='invitefriend.jsp';
}
function callPendingFriendRequest(){
	window.location.href='friend.do?fparam=' +escape("pendingfriendrequest");
}
function callSearchFriend(){
	window.location.href='searchfriend.jsp?ref=simplesearch';
}
/** This function will call the Friend Action */
function callMyFriend(){
	window.location.href='friend.do?fparam=' +escape("myfriends");
}

function addSocialNetwork(network) 
{
	n = network.indexOf(",");
		
	 if(n > 0)
	 {
		network =  network.substring(0,n);
	 }
	
	var url = "socialnetwork.do?action=add&network="+network;
	var ajaxReq = getXmlHttpRequestObject();
	if(ajaxReq.readyState == 4 || ajaxReq.readyState == 0){
		ajaxReq.open("get", url, true);
		ajaxReq.onreadystatechange = function(){
			if(ajaxReq.readyState == 4 && ajaxReq.status == 200){
				//if(n>0)
			//	{
								
					window.location.href="myprofile.jsp?action=profilevisitors&wizard_show=wizard_show";
					//window.location.href= "peoplefinder.do?action=people&wizard_show=wizard_show";
				//}
				//else
				{
			//		window.location.href="myprofile.jsp?action=setupnetwork";
				//}
					
				}
			}
		}
		ajaxReq.send(null);
	}
}



function addTripitNetwork(network) 
{
	n = network.indexOf(",");
		
	 if(n > 0)
	 {
		network =  network.substring(0,n);
	 }
	
	var url = "socialnetwork.do?action=add&network="+network;
	var ajaxReq = getXmlHttpRequestObject();
	if(ajaxReq.readyState == 4 || ajaxReq.readyState == 0){
		ajaxReq.open("get", url, true);
		ajaxReq.onreadystatechange = function(){
			if(ajaxReq.readyState == 4 && ajaxReq.status == 200){
				//if(n>0)
			//	{
					window.location.href="setupnetworkmobile.jsp?userid=8";
					//window.location.href= "peoplefinder.do?action=people&wizard_show=wizard_show";
				//}
				//else
				{
				
			//		window.location.href="myprofile.jsp?action=setupnetwork";
				//}
					
				}
			}
		}
		ajaxReq.send(null);
	}
}

function advanceSearch()
{
	var url = "peoplefinder.do?action=advancesearch";
	document.getElementById("loading").style.display='block';
	//document.getElementById("map").style.display='none';
	var searchReq = getXmlHttpRequestObject();
	if(searchReq.readyState == 4 || searchReq.readyState == 0){
		searchReq.open("get", url, true);
		searchReq.onreadystatechange = function(){
			if(searchReq.readyState == 4 && searchReq.status == 200){
				document.getElementById("advancesearchbtn").className += " active";
				document.getElementById("upcommingtripbtn").className = "iphonebutton";
				document.getElementById("peoplenearmebtn").className = "iphonebutton";
				document.getElementById("loading").style.display='none';
				document.getElementById("upcommingtrip").style.display='none';
				//document.getElementById("peoplefinder").style.display='none';
				document.getElementById("advancesearch").style.display='block';
				document.getElementById("advancesearch").innerHTML = searchReq.responseText;
				
			}
		}
		searchReq.send(null);
	}
}


//advanced search


function advanceSearchResult()
{
	
	var location = document.getElementById("location").value;
	var startDate = document.getElementById("startDate").value;
	var endDate = document.getElementById("endDate").value;
	var interest = document.getElementById("interest").value;
	var c_value = "";
	
	for (var i=0; i < document.frmsearch.interest.length; i++)
   	{
   		if (document.frmsearch.interest[i].selected)
    	{
   			c_value = c_value + document.frmsearch.interest[i].value + ",";
    	}
   	}
	
	if((location == "" || location == null) && (startDate == "" || startDate == null) && (endDate=="" || endDate== null) && (c_value == "" || c_value == null))
	{
		alert("Location is required");
		document.getElementById("location").focus;
		return;
	}
	
	if((startDate != "" && endDate =="") || (startDate!= null && endDate == null))
	{
		alert("To Date is required");
		return;
	}
	//validation for start-date cannot be null
	if((endDate != "" && startDate == "") || (endDate!=null && startDate ==null)) 
	{
		alert("From Date is required");
		return;
	}
	if (Date.parse(startDate) > Date.parse(endDate)) {
		alert("Invalid Date Range!\nFrom Date cannot be after To Date!")
		return;
	}
	
	
	var interestid = c_value.substr(0,c_value.length - 1);
		
	var url = "advanceSearch.do?action=advanceSearchResult&location="+document.getElementById("location").value+
	"&startDate="+document.getElementById("startDate").value+"&endDate="+document.getElementById("endDate").value+
	"&interest="+interestid;
		
	document.getElementById("loading").style.display='block';
	var searchReq = getXmlHttpRequestObject();
	
	if(searchReq.readyState == 4 || searchReq.readyState == 0){
		
		searchReq.open("get", url, true);
		searchReq.onreadystatechange = function(){
			if(searchReq.readyState == 4 && searchReq.status == 200){
				document.getElementById("advancesearchbtn").className += " active";
				document.getElementById("upcommingtripbtn").className = "iphonebutton";
				document.getElementById("peoplenearmebtn").className = "iphonebutton";
				document.getElementById("loading").style.display='none';
				document.getElementById("searchform").style.display='none';
				document.getElementById("searchList").style.display='block';
				document.getElementById("searchList").innerHTML = searchReq.responseText;
				
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{ 
						curvecornerdefault_IE();				
					}
			}
		}
		searchReq.send(null);
	}
}
/** This function show the user's profile details in light box popup */
function viewUserProfile(redirect_url)
{
	document.getElementById("loading").style.display='block';
	var url = redirect_url;
	var ajaxReq_viewprofile = getXmlHttpRequestObject();
	if(ajaxReq_viewprofile.readyState == 4 || ajaxReq_viewprofile.readyState == 0){
		ajaxReq_viewprofile.open("get", url, true);
		ajaxReq_viewprofile.onreadystatechange = function(){
			if(ajaxReq_viewprofile.readyState == 4 && ajaxReq_viewprofile.status == 200){
				document.getElementById("loading").style.display='none';
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=ajaxReq_viewprofile.responseText;
				
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		ajaxReq_viewprofile.send(null);
	}
}

function viewUserTripList(redirect_url)
{
	document.getElementById("loading").style.display='block';
	var param = redirect_url;
	var n=param.lastIndexOf("?");
	var url_parameter = param.substring(n+1,param.length); 
    var url ="peoplefinder.do?action=getViewPeopleUpcomingTripDetail&" +url_parameter;
	
	var peopleupcomingtrip = getXmlHttpRequestObject();
	if(peopleupcomingtrip.readyState == 4 || peopleupcomingtrip.readyState == 0){
		peopleupcomingtrip.open("get", url, true);
		peopleupcomingtrip.onreadystatechange = function(){
			if(peopleupcomingtrip.readyState == 4 && peopleupcomingtrip.status == 200){
				document.getElementById("loading").style.display='none';
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML =peopleupcomingtrip.responseText;
				
				//this condition/method is called for curve show in IE				
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		
		peopleupcomingtrip.send(null);
	}
}









/**This is the Ajax function which will Approve OR Reject the Friend Request from different Views */
function approveOrRejectFriendRequest(rediretURL, status, fname, viewref,fid)
{
	document.getElementById("loading").style.display='block';
	if(status == "Approve")
		{
			var agree=confirm("Are you sure to accept the Request?");		
		}
	else if(status =="Reject")
		{
			var agree=confirm("Are you sure to reject the Request?");
		}
	
	if(agree)
		{
			var url = rediretURL;
			
			var approveReq = getXmlHttpRequestObject();
			if(approveReq.readyState == 4 || approveReq.readyState == 0){
				approveReq.open("get", url, true);
				approveReq.onreadystatechange = function(){
			
					if(approveReq.readyState == 4 && approveReq.status == 200){
						document.getElementById("loading").style.display='none'
						if(viewref !=null && viewref =="pendingrequest"){
							// This line of code indicate that user has accepted/ rejected friend request from Pending Friend Request Page
						window.location.href="friend.do?fparam=pendingfriendrequest&rf=" +escape(status) +"&fr=" +escape(fname)+"&fid=" +fid;
						}else if (viewref !=null && viewref =="searchfriend"){
							// This line of code indicate that user has accepted friend request from Search Friend Page
							document.getElementById("searchresult").style.display='block';
							document.getElementById("searchresult").innerHTML = approveReq.responseText;
						}
						else if(viewref !=null && viewref =="profilevisitor"){
							// This line of code indicate that user has accepted friend request from Profile Visitor Page
							
							window.location.href="myprofile.jsp?action=profilevisitors";
						}
							
					}
				}
				approveReq.send(null);
			}
		}
		else
		{
		 return false;
		}
}

/**This is the Ajax function which will show the people upcoming trip details */
function getPeopleUpcomingTripDetail(url_parameter)
{
	document.getElementById("loading").style.display='block';
	var url ="peoplefinder.do?action=getPeopleUpcomingTripDetail&" +url_parameter;
	var peopleupcomingtrip = getXmlHttpRequestObject();
	if(peopleupcomingtrip.readyState == 4 || peopleupcomingtrip.readyState == 0){
		peopleupcomingtrip.open("get", url, true);
		peopleupcomingtrip.onreadystatechange = function(){
			if(peopleupcomingtrip.readyState == 4 && peopleupcomingtrip.status == 200){
				
				document.getElementById("loading").style.display='none';
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML =peopleupcomingtrip.responseText;
				
				//this condition/method is called for curve show in IE				
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		
		peopleupcomingtrip.send(null);
	}
}




function nevigation(navEvent, start_end) {
	
	var url = "myfriendlist1.jsp?event="+navEvent;
	if(start_end != '')
	{
		var index = document.getElementById("pagi_combo").selectedIndex;
		url = url + "&pagi_combo="+document.getElementById("pagi_combo").options[index].value;
	}
	var ajaxReq = getXmlHttpRequestObject();
	if(ajaxReq.readyState == 4 || ajaxReq.readyState == 0){
		ajaxReq.open("get", url, true);
		ajaxReq.onreadystatechange = function(){
			if(ajaxReq.readyState == 4 && ajaxReq.status == 200){
				document.getElementById("myfriendlist").style.display="block";
				document.getElementById("myfriendlist").innerHTML = ajaxReq.responseText;
			}
		}
		ajaxReq.send(null);
	}
}

function nevigation_advancesearch(navEvent, start_end) {
	var url = "advanceSearch_list.jsp?event="+navEvent;
	if(start_end != '')
	{
		var index = document.getElementById("pagi_combo").selectedIndex;
		url = url + "&pagi_combo="+document.getElementById("pagi_combo").options[index].value;
	}
	var ajaxReq = getXmlHttpRequestObject();
	if(ajaxReq.readyState == 4 || ajaxReq.readyState == 0){
		ajaxReq.open("get", url, true);
		ajaxReq.onreadystatechange = function(){
			if(ajaxReq.readyState == 4 && ajaxReq.status == 200){
				document.getElementById("searchList").style.display="block";
				document.getElementById("searchList").innerHTML = ajaxReq.responseText;
			}
		}
		ajaxReq.send(null);
	}
}

function nevigation_listOfPeople(navEvent, start_end, viewrefernce)
{
	var livingLocation = false;
	var m = document.getElementById("locationId");
	var locCheckBox = document.getElementById("loc");
		
	if(locCheckBox !=null && locCheckBox.checked == true){
		livingLocation = true;
	}
	var url = "listofpeople.jsp?event="+navEvent+"&filter="+document.getElementById("filter").options[index1].value;
	var url ="peoplefinder.do?action=peoplenearme&loc=" +livingLocation	
	if(m !=null){
		url = url + "&l=" + m.value;	
	}
	if(socialMedia !=null && socialMedia != ""){		
		url = url + "&socialMedia=" +socialMedia+"&filter="+socialMedia;
	}
	
	document.getElementById("loading").style.display = 'block';
	
	var peoplenearme = getXmlHttpRequestObject();
	if(peoplenearme.readyState == 4 || peoplenearme.readyState == 0){
		peoplenearme.open("get", url, true);
		peoplenearme.onreadystatechange = function(){
			if(peoplenearme.readyState == 4 && peoplenearme.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("peoplenearme").style.display = 'block';
								
				document.getElementById("peoplenearme").innerHTML = peoplenearme.responseText;
				

				
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecorner_IE();
					}
			}
		}
		peoplenearme.send(null);
	}
	
	var index1 = document.getElementById("filter").selectedIndex;
	var url = "listofpeople.jsp?event="+navEvent+"&filter="+document.getElementById("filter").options[index1].value;
	if(start_end != '')
	{
		var index = document.getElementById("pagi_combo").selectedIndex;
		url = url + "&pagi_combo="+document.getElementById("pagi_combo").options[index].value;
	}
	
	if(viewrefernce != null && viewrefernce == "tripview")
	{
		url = url + "&view=trip";
	}
	
	var ajaxReq = getXmlHttpRequestObject();
	if(ajaxReq.readyState == 4 || ajaxReq.readyState == 0){
		ajaxReq.open("get", url, true);
		ajaxReq.onreadystatechange = function(){
			if(ajaxReq.readyState == 4 && ajaxReq.status == 200){
				document.getElementById("content").style.display ='block';
				document.getElementById("content").innerHTML = ajaxReq.responseText;
			}
		}
		ajaxReq.send(null);
	}
}

function callMeetingInviteView(userId,triplocation)
{
	
	var url ="peoplefinder.do?action=meetingInviteView&userId=" +userId+"&triplocation="+triplocation+"&user_travelling="+user_travelling+"&friend_travelling="+friend_travelling;
	var meetingInviteView = getXmlHttpRequestObject();
	if(meetingInviteView.readyState == 4 || meetingInviteView.readyState == 0){
		meetingInviteView.open("get", url, true);
		meetingInviteView.onreadystatechange = function(){
			if(meetingInviteView.readyState == 4 && meetingInviteView.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML = meetingInviteView.responseText;
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		
		meetingInviteView.send(null);
	}

}





/**This is the Ajax function which will show the view to send an meeting invitation to friend on a trip day */
function callMeetingInviteView1(userId,triplocation,user_travelling,friend_travelling)
{
	document.getElementById("loading").style.display = 'block';
	var url ="peoplefinder.do?action=meetingInviteView&userId="+userId+"&triplocation="+triplocation+"&user_travelling="+user_travelling+"&friend_travelling="+friend_travelling;
	var meetingInviteView = getXmlHttpRequestObject();
	if(meetingInviteView.readyState == 4 || meetingInviteView.readyState == 0){
		meetingInviteView.open("get", url, true);
		meetingInviteView.onreadystatechange = function(){
			if(meetingInviteView.readyState == 4 && meetingInviteView.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("loading").style.display = 'none';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML = meetingInviteView.responseText;
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		
		meetingInviteView.send(null);
	}

}



function callFriendMeetingInviteView(userId,friendname)
{
	document.getElementById("loading").style.display = 'block';
	var url ="peoplefinder.do?action=friendMeetingInviteView&userId="+userId+"&friendname="+friendname;
	var meetingInviteView = getXmlHttpRequestObject();
	if(meetingInviteView.readyState == 4 || meetingInviteView.readyState == 0){
		meetingInviteView.open("get", url, true);
		meetingInviteView.onreadystatechange = function(){
			if(meetingInviteView.readyState == 4 && meetingInviteView.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("loading").style.display = 'none';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML = meetingInviteView.responseText;
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		
		meetingInviteView.send(null);
	}

}



function FriendMeetingInvitation()
{
	document.getElementById("loading").style.display = 'block';
	var friend_name = document.getElementById("friendname").value;
	var lastchar = friend_name.length-1;
	var friendname = friend_name.substring(0, friend_name.length);
	if(friend_name.charAt(lastchar) =='_' )
	{	
		var friendname = friend_name.substring(0, friend_name.length-1);
	}
	else
	{
		var friendname = friend_name.substring(0, friend_name.length);
	}
	var friendemail = document.getElementById("friendemail").value;
	
	var message = document.getElementById("invitemessage").value;
	
	var url ="meetinginvite.do?param=meetingfriendinvitation&friendname=" + friendname +"&friendemail="+friendemail +"&message="+message;
		
	var meetingInvitation = getXmlHttpRequestObject();
	if(meetingInvitation.readyState == 4 || meetingInvitation.readyState == 0){
		meetingInvitation.open("get", url, true);
		meetingInvitation.onreadystatechange = function(){
			if(meetingInvitation.readyState == 4 && meetingInvitation.status == 200){
				
				
				document.getElementById("loading").style.display = 'none';
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				
				var div =document.getElementById("popupmsg");
				var child = document.getElementById('frmcontainer');
				div.removeChild(child);
				document.getElementById('button').style.display='none';
				
				document.getElementById("invite").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"><img src=\"images/success_icon.png\" style=\"border: none;float:left; margin-left:35px;\" hspace=\"5\" align=\"absmiddle\"/></a>";
				document.getElementById("invite").innerHTML +="<p style=\"color:black\">Invitation sent successfully</p>"
			}
		}
		meetingInvitation.send(null);
	}
}










/**This is the Ajax function which will send the invitation to friend for meeting on a trip day */
function meetingInvitation()
{
	document.getElementById("loading").style.display = 'block';
	var friend_name = document.getElementById("friendname").value;
	
	var lastchar = friend_name.length-1;
	var friendname = friend_name.substring(0, friend_name.length);
	if(friend_name.charAt(lastchar) =='_' )
	{	
		var friendname = friend_name.substring(0, friend_name.length-1);
	}
	else
	{
		var friendname = friend_name.substring(0, friend_name.length);
	}
	var friendemail = document.getElementById("friendemail").value;
	var message = document.getElementById("invitemessage").value;	
	var url ="meetinginvite.do?param=meetinginvitation&friendname=" + friendname +"&friendemail="+friendemail +"&message="+message;
		
	var meetingInvitation = getXmlHttpRequestObject();
	if(meetingInvitation.readyState == 4 || meetingInvitation.readyState == 0){
		meetingInvitation.open("get", url, true);
		meetingInvitation.onreadystatechange = function(){
			if(meetingInvitation.readyState == 4 && meetingInvitation.status == 200){
				
				
				document.getElementById("loading").style.display = 'none';
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				
				var div =document.getElementById("popupmsg");
				var child = document.getElementById('frmcontainer');
				div.removeChild(child);
				document.getElementById('button').style.display='none';
				
				document.getElementById("invite").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"><img src=\"images/success_icon.png\" style=\"border: none;float:left; margin-left:35px;\" hspace=\"5\" align=\"absmiddle\"/></a>";
				document.getElementById("invite").innerHTML +="<p style=\"color:black\">Invitation sent successfully</p>"
			}
		}
		meetingInvitation.send(null);
	}
}

function navigation_header(navEvent, start_end)
{
	var url = "header.jsp?event="+navEvent;
	if(start_end != '')
	{
		var index = document.getElementById("pagi_combo1").selectedIndex;
		url = url + "&pagi_combo="+document.getElementById("pagi_combo1").options[index].value;
	}
	var ajaxReq = getXmlHttpRequestObject();
	if(ajaxReq.readyState == 4 || ajaxReq.readyState == 0){
		ajaxReq.open("get", url, true);
		ajaxReq.onreadystatechange = function(){
			if(ajaxReq.readyState == 4 && ajaxReq.status == 200){
				document.getElementById("dropdown_menu").style.display ='block';
				document.getElementById("dropdown_menu").innerHTML = ajaxReq.responseText;
			}
		}
		ajaxReq.send(null);
	}
}

function showHideGoogleMap(latitude, langitude, friendname, googlemarkericon, loggedinuserlatlang,imageName, userProfile)
{
		var mapDiv = document.getElementById("map").style;
		if(mapDiv.display == 'none'){
				document.getElementById("googleDiv").innerHTML = "Hide Google Map";
				mapDiv.display = 'block';
				initialize(latitude,langitude,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName, userProfile);
				
		}else{
				mapDiv.display = 'none';
				document.getElementById("googleDiv").innerHTML = "Show Google Map";
		}
}

function setHelpWizard(isChecked)
{
	var helpSettingValue = true;
	
	if(isChecked){
			helpSettingValue = false
	}
	
	var url ="login.do?action=setHelpWizard&helpalert="+helpSettingValue;
	var helpWizard = getXmlHttpRequestObject();
	
	if(helpWizard.readyState == 4 || helpWizard.readyState == 0){
		helpWizard.open("get", url, true);
		helpWizard.send(null);
	}
}
function loadPeopleNearMe(socialMedia)
{	
		
	var livingLocation = false;
	var m = document.getElementById("locationId");
	var locCheckBox = document.getElementById("loc");
		
	if(locCheckBox !=null && locCheckBox.checked == true){
		livingLocation = true;
	}
	
	var url ="peoplefinder.do?action=peoplenearme&loc=" +livingLocation;
	
	if(m !=null){
		url = url + "&l=" + m.value;	
	}
	if(socialMedia !=null && socialMedia != ""){		
		url = url + "&socialMedia=" +socialMedia+"&filter="+socialMedia;
	}
	
	document.getElementById("loading").style.display = 'block';
	
	var peoplenearme = getXmlHttpRequestObject();
	if(peoplenearme.readyState == 4 || peoplenearme.readyState == 0){
		peoplenearme.open("get", url, true);
		peoplenearme.onreadystatechange = function(){
			if(peoplenearme.readyState == 4 && peoplenearme.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("peoplenearme").style.display = 'block';
								
				document.getElementById("peoplenearme").innerHTML = peoplenearme.responseText;
				

				/** This condition/method is called for curve show in IE **/
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecorner_IE();
					}
			}
		}
		peoplenearme.send(null);
	}
}

/*function getFriendNearMe(latitude,langitude,friendname,googlemarkericon,loggedinuserlatlang,imageName,userId)
{
	getFriendinitialize(latitude,langitude,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName,userId);
	document.getElementById("map").style.display = 'block';    
}
function getFriendforTrip(latitude,langitude,friendname,googlemarkericon,loggedinuserlatlang,imageName,userId)
{
	getFriendforTripinitialize(latitude,langitude,'peoplefinder',friendname,googlemarkericon,loggedinuserlatlang,imageName,userId);
	document.getElementById("map").style.display = 'block'; 
	
}*/

function nevigation_PeopleNearMe(navEvent, start_end)
{
	var index1 = document.getElementById("filter").selectedIndex;
	var url = "peoplenearme.jsp?event="+navEvent+"&filter="+document.getElementById("filter").options[index1].value;
	
	if(start_end != '')
	{
		var index = document.getElementById("pagi_combo").selectedIndex;
		url = url + "&pagi_combo="+document.getElementById("pagi_combo").options[index].value;
	}
	var ajaxReq = getXmlHttpRequestObject();
	if(ajaxReq.readyState == 4 || ajaxReq.readyState == 0){
		ajaxReq.open("get", url, true);
		ajaxReq.onreadystatechange = function(){
			if(ajaxReq.readyState == 4 && ajaxReq.status == 200){
				document.getElementById("peoplenearme").style.display ='block';
				document.getElementById("peoplenearme").innerHTML = ajaxReq.responseText;
			}
		}
		ajaxReq.send(null);
	}
}



/** this method is call advance search form people finder tab */
function advanceSearch(){
	window.location.href="peoplefinder.do?action=advancesearch";
}

/** this method is call people finder form people finder tab */
function peopleFinder(){
	window.location.href="peoplefinder.do?action=people";
}

/*function popwindow()
{
	
	var url ="popwindow.jsp";
	var changepasswordView = getXmlHttpRequestObject();
	if(changepasswordView.readyState == 4 || changepasswordView.readyState == 0){
		changepasswordView.open("get", url, true);
		changepasswordView.onreadystatechange = function(){
			if(changepasswordView.readyState == 4 && changepasswordView.status == 200){
				
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepasswordView.responseText;
		

		}
			
	}
		
		ordView.send(null);
	}

}*/

/** This method show curve in IE Browser */
function curvecorner_IE()
{
			    var settings_general = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}

				var settings_head = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
					}

				var settings_row = {
					tl: { radius: 0 },
					tr: { radius: 0 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}

				curvyCorners(settings_head, ".tableheading");
				curvyCorners(settings_row, ".dynamicrow");
				curvyCorners(settings_general, ".generalfrm");
}

/** This method show curve in IE Browser(popup window) */
function curvecornerpopup_IE()
{
				var settings_general = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}
				
				var settings_head = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 6 },
					br: { radius: 6 },
					antiAlias: true
					}
				var settings_row = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}
				
				curvyCorners(settings_head, ".generalfrm");
				curvyCorners(settings_head, ".popupheading");
				curvyCorners(settings_row, ".popupmsg");
}

/** This method show curve in IE Browser(viwe friend,adv search result,peopleupcoming trip) */
function curvecornerdefault_IE()
{
					var settings_head = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
					}

				var settings_row = {
					tl: { radius: 0 },
					tr: { radius: 0 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}

				curvyCorners(settings_head, ".tableheading");
				curvyCorners(settings_row, ".dynamicrow");
}

function public_profile(username){
	
	var url = "publicprofile.do?action=publicprofile&username="+username;
	var public_pro = getXmlHttpRequestObject();
	if(public_pro.readyState == 4 || public_pro.readyState == 0){
		public_pro.open("get", url, true);
		public_pro.onreadystatechange = function(){
			if(public_pro.readyState == 4 && public_pro.status == 200){
				
				document.getElementById("publicprofile").style.display ='block';
				document.getElementById("publicprofile").innerHTML = public_pro.responseText;
			}
		}
		
		public_pro.send(null);
	}
}

/**  This function will call the server code that check the incoming username is already registered or not */ 

function userNameAvailabilityCheck()
{
	var username = document.getElementById("username").value;
	
	var x = document.getElementById("username");
	var msg =document.getElementById("email_available_msg");
	var url = "register.do?action=usernamecheck&username="+username;
		
	var usernameReq = getXmlHttpRequestObject();
	if(usernameReq.readyState == 4 || usernameReq.readyState == 0){
		usernameReq.open("get", url, true);
		usernameReq.onreadystatechange = function(){
			if(usernameReq.readyState == 4 && usernameReq.status == 200){
				if(usernameReq.responseText != "")
					{
						//alert(email + " already registered");
						//document.getElementById("email").value ="";
						//return false;
          				msg.style.display ='block';
         				x.value ="";
          				return false;
          			}
				else
					{
						msg.style.display ='none';
					}
			}
		}
		usernameReq.send(null);
	}
}	

/*/
function mouseout()
{
	var id = document.getElementById("appstore");	
	id.src="images/appstorebtn-meetin-1.png";
}

function mouseover()
{
	var id = document.getElementById("appstore");	
	id.src="images/coming_soon.png";
}
function mouseout1()
{
	var id = document.getElementById("appvideo");	
	id.src="images/appvideo_new.png";	
}

function mouseover1()
{
	var id = document.getElementById("appvideo");
	id.src="images/coming_soon_youtube.png";
}
*/
function validate_Fullname()
{
	var val = document.getElementById("fullname");
	
	if(val.value == "" || val.value == null)
	{
		document.getElementById("fullname").focus();	
		return false;
	}
	
	 var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
	 var val1= val.value;
	 
	for (var i = 0; i < val1.length; i++) 
  	{
    	if (iChars.indexOf(val1.charAt(i)) != -1) 
    	{
    		return false;
        }
    }
}

function TermsCondition()
{
	var url ="terms-conditions.jsp"
	var peopleupcomingtrip = getXmlHttpRequestObject();
	if(peopleupcomingtrip.readyState == 4 || peopleupcomingtrip.readyState == 0){
		
		peopleupcomingtrip.open("get", url, true);
		peopleupcomingtrip.onreadystatechange = function(){
			if(peopleupcomingtrip.readyState == 4 && peopleupcomingtrip.status == 200){
				
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML =peopleupcomingtrip.responseText;
				
				//this condition/method is called for curve show in IE				
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		peopleupcomingtrip.send(null);
	}
}

/***
function callMeetingInviteView(userId,triplocation,param)
{
	alert("meetin ");
	var url ="peoplefinder.do?action=meetingInviteView&userId=" +userId+"&triplocation="+triplocation +"&param="+param;
	var meetingInviteView = getXmlHttpRequestObject();
	if(meetingInviteView.readyState == 4 || meetingInviteView.readyState == 0){
		meetingInviteView.open("get", url, true);
		meetingInviteView.onreadystatechange = function(){
			if(meetingInviteView.readyState == 4 && meetingInviteView.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML = meetingInviteView.responseText;
				this condition/method is called for curve show in I				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		
		meetingInviteView.send(null);
	}

}
*/
function getSuggestTripFriendList(destination, socialParam)
{
	var startDate = document.getElementById("startDate").value;
	var endDate = document.getElementById("endDate").value;
	document.getElementById("loading").style.display = 'block';
	var url = "trip.do?trip=" + escape('suggesttripfriends') + "&socialParam=" +socialParam.value + "&cityName=" + destination + "&startDate=" + startDate + "&endDate=" +endDate;
	
	var suggestedFriends = getXmlHttpRequestObject();
	if(suggestedFriends.readyState == 4 || suggestedFriends.readyState == 0){
		suggestedFriends.open("get", url, true);
		suggestedFriends.onreadystatechange = function(){
			if(suggestedFriends.readyState == 4 && suggestedFriends.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("suggestTripFriendList").style.display ='block';
				document.getElementById("suggestTripFriendList").innerHTML =suggestedFriends.responseText;
			}
		}
		
		suggestedFriends.send(null);
	}
}

function getSuggestFriendsTripDetail(friendId, cityName)
{
	var startDate = document.getElementById("startDate").value;
	var endDate = document.getElementById("endDate").value;
	
	var url ="trip.do?trip=suggesttripfriendsTripDetail&friendId=" +friendId + "&cityName=" +cityName
			+"&startDate=" +startDate + "&endDate=" +endDate;
	
	var suggestTripDetail = getXmlHttpRequestObject();
	if(suggestTripDetail.readyState == 4 || suggestTripDetail.readyState == 0){
		suggestTripDetail.open("get", url, true);
		suggestTripDetail.onreadystatechange = function(){
			if(suggestTripDetail.readyState == 4 && suggestTripDetail.status == 200){
				
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML =suggestTripDetail.responseText;
				
				if (navigator.appName=="Microsoft Internet Explorer"){  
						curvecornerpopup_IE();
					} 
			}
		}
		
		suggestTripDetail.send(null);
	}
}

function navigateSuggestFriendList(event)
{
	var paging = document.getElementById("page_combo").value 
	document.getElementById("loading").style.display = 'block';
	var url = "trip.do?trip=" + escape('navigateFriendList') + "&e="+event + "&paging=" + paging;
	
	var suggestedFriends = getXmlHttpRequestObject();
	if(suggestedFriends.readyState == 4 || suggestedFriends.readyState == 0){
		suggestedFriends.open("get", url, true);
		suggestedFriends.onreadystatechange = function(){
			if(suggestedFriends.readyState == 4 && suggestedFriends.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("suggestTripFriendList").style.display ='block';
				document.getElementById("suggestTripFriendList").innerHTML =suggestedFriends.responseText;
			}
		}
		
		suggestedFriends.send(null);
	}
}
function navigatePeopleMeFriendList(event)
{
	
	var paging = document.getElementById("page_combo").value 
	document.getElementById("loading").style.display = 'block';
	var url = "peoplefinder.do?action=navigatePeopleNearFriendList" + "&e="+event + "&paging=" + paging + "&filter="+document.getElementById("filter").value;
	
	var suggestedFriends = getXmlHttpRequestObject();
	if(suggestedFriends.readyState == 4 || suggestedFriends.readyState == 0){
		suggestedFriends.open("get", url, true);
		suggestedFriends.onreadystatechange = function(){
			if(suggestedFriends.readyState == 4 && suggestedFriends.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("peoplenearme").style.display ='block';
				document.getElementById("peoplenearme").innerHTML =suggestedFriends.responseText;
			}
		}
		suggestedFriends.send(null);
	}
}




function navigateMyFriendSearchList(event)
{
	var paging = document.getElementById("page_combo").value 
	document.getElementById("loading").style.display = 'block';
	var url = "friend.do?fparam=navigateMyFriendSearchList" + "&e="+event + "&paging=" + paging+"&ref="+document.getElementById("ref").value;
	
	var myFriends = getXmlHttpRequestObject();
	if(myFriends.readyState == 4 || myFriends.readyState == 0){
		myFriends.open("get", url, true);
		myFriends.onreadystatechange = function(){
			if(myFriends.readyState == 4 && myFriends.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("searchresult").style.display ='block';
				document.getElementById("searchresult").innerHTML =myFriends.responseText;
			}
		}
		myFriends.send(null);
	}
}

function navigateMyFriendList(event)
{
	var paging = document.getElementById("page_combo").value 
	document.getElementById("loading").style.display = 'block';
	var url = "friend.do?fparam=navigateMyFriendList" + "&e="+event + "&paging=" + paging;
	
	var myFriends = getXmlHttpRequestObject();
	if(myFriends.readyState == 4 || myFriends.readyState == 0){
		myFriends.open("get", url, true);
		myFriends.onreadystatechange = function(){
			if(myFriends.readyState == 4 && myFriends.status == 200){
				document.getElementById("loading").style.display = 'none';
				document.getElementById("myfriendlist").style.display ='block';
				document.getElementById("myfriendlist").innerHTML =myFriends.responseText;
			}
		}
		myFriends.send(null);
	}
}

function feedback()
{
	window.location.href = 'feedback.jsp?param=param';
}

function Validatefriendemail()
{
	var array = document.getElementById("friendemail").value;
	var arr = array.split(",");
	
	if(arr.length > 10)
	{
		alert("Maximum 10 friends can be invited at a time.");
		return false;
	}
	for(i=0;i<arr.length;i++)
	{
		var atpos=arr[i].indexOf("@");
		var dotpos=arr[i].lastIndexOf(".");
		if (atpos<1 || dotpos<atpos+2 || dotpos+2>=arr[i].length)
  		{
  				alert("Please enter valid email address");
  				return false;
  		}
	}
}


function redirect()
{
     window.location = 'contact.jsp';
}

function feedback_paging()
{
	 window.location = 'feedback.jsp?value='+document.getElementById("i").value+"&prev=1";
}
function feedback_paging1()
{
	 window.location = 'feedback.jsp?value='+document.getElementById("i").value+"&next=1";
}
function getEditTripDetail(tripId, view)
{
	window.location = 'trip.do?trip=getedittrip&tp=' +tripId + '&ref='+view;
	
}


function signup()
{
	window.location = 'signup.jsp';
}



//created by Dharam Chag
//Date : 4-6-2013
//function created for help popup in all pages
//takes page name as argument	

function Questionfnc(page)
{
	var url ="helpAlert.jsp?page="+page;
	var peopleupcomingtrip = getXmlHttpRequestObject();
	if(peopleupcomingtrip.readyState == 4 || peopleupcomingtrip.readyState == 0){
		
		peopleupcomingtrip.open("get", url, true);
		peopleupcomingtrip.onreadystatechange = function(){
			if(peopleupcomingtrip.readyState == 4 && peopleupcomingtrip.status == 200){
				
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML =peopleupcomingtrip.responseText;
				
				//this condition/method is called for curve show in IE				
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		peopleupcomingtrip.send(null);
	}
	
	
			
}



















