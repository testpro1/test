// ——————————————————————-
// hasOptions(obj)
//  Utility function to determine if a select object has an options array
// ——————————————————————-
function hasOptions(obj) {
if (obj!=null && obj.options!=null) { return true; }
	return false;
}

function uploadImage (imagename)
{
	//alert("upload image "  + imagename);
	
	var url = "image.jsp?image="+imagename;
	var meetingInviteView = getXmlHttpRequestObject();
	if(meetingInviteView.readyState == 4 || meetingInviteView.readyState == 0){
		meetingInviteView.open("get", url, true);
		meetingInviteView.onreadystatechange = function(){
			if(meetingInviteView.readyState == 4 && meetingInviteView.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML = meetingInviteView.responseText;
				
				//this condition/method is called for curve show in IE
				if (navigator.appName=="Microsoft Internet Explorer")
					{  
						curvecornerpopup_IE();
					} 
			}
		}
		meetingInviteView.send(null);
	}

}


	function imagePage()
	{
		//alert(document.getElementById("imagepath").value);	
		var imagepath = document.getElementById("imagepath").value;
		if(imagepath =="images/male.png")
		{
			//alert("if ---------  ");
		   	window.open("image.jsp?imagepath="+imagepath,"_self");
		}	
		else
		{
			//alert("else case ---------  ");	
	  		var ext = imagepath.lastIndexOf("/");
  			var extension = imagepath.substring(ext+1,imagepath.length);
  			window.open("image.jsp?imagepath="+extension,"_self");
  		}
	}
	
				
	
 function fileSize(form)
 {
	//alert("in fileSize");
	return disableForm(this),ajaxUpload(form,'imagepreview.do?action=imagepreview', '&lt;br&gt;Uploading image please wait.....&lt;br&gt;');
	return false;
  
 }
	
	/*
 function fileSize(form)
{
	alert("image nameis -- ");	
	alert(form);	
	return disableForm(this),ajaxUpload(form,'imagepreview.do?action=imagepreview', '&lt;br&gt;Uploading image please wait.....&lt;br&gt;');
	alert("hello");
	 return false; 
	*/
	 
	 //alert("in fileSize");
//	alert(document.getElementById("userid").value);
//	var userid= document.getElementById("userid").value;
//	var fullimagePath = document.getElementById("imageid").value;
//	var pathint = fullimagePath.lastIndexOf("\\");
//	var imagepath = fullimagePath.substring(pathint+1,fullimagePath.length);
//	var imagename = userid + "_"+imagepath; 
	//var iSize = ($("#imageid")[0].files[0].size / 1024);
    //var filesize = iSize /1024;
   //  if (filesize > 2) 
    // { 
   // 	 alert("Image size cannot be greater than 2 MB");
    //    return false; 
    // } 
     //else
     //{
    //	 alert("else case");
     //  disableForm(this),ajaxUpload(form,'imagepreview.do?action=imagepreview', '&lt;br&gt;Uploading image please wait.....&lt;br&gt;');
	//	uploadImage(imagename);
    //	alert("image.jsp called");
    //
    	 
   //  }
//}

// ——————————————————————-
// selectUnselectMatchingOptions(select_object,regex,select/unselect,true/false)
//  This is a general function used by the select functions below, to
//  avoid code duplication
// ——————————————————————-
function selectUnselectMatchingOptions(obj,regex,which,only) {
if (window.RegExp) {
if (which == "select") {
var selected1=true;
var selected2=false;
}
else if (which == "unselect") {
var selected1=false;
var selected2=true;
}
else {
return;
}
var re = new RegExp(regex);
if (!hasOptions(obj)) { return; }
for (var i=0; i<obj.options.length; i++) {
if (re.test(obj.options[i].text)) {
obj.options[i].selected = selected1;
}
else {
if (only == true) {
obj.options[i].selected = selected2;
}
}
}
}
}

// ——————————————————————-
// selectMatchingOptions(select_object,regex)
//  This function selects all options that match the regular expression
//  passed in. Currently-selected options will not be changed.
// ——————————————————————-
function selectMatchingOptions(obj,regex) {
selectUnselectMatchingOptions(obj,regex,"select",false);
}
// ——————————————————————-
// selectOnlyMatchingOptions(select_object,regex)
//  This function selects all options that match the regular expression
//  passed in. Selected options that don’t match will be un-selected.
// ——————————————————————-
function selectOnlyMatchingOptions(obj,regex) {
selectUnselectMatchingOptions(obj,regex,"select",true);
}
// ——————————————————————-
// unSelectMatchingOptions(select_object,regex)
//  This function Unselects all options that match the regular expression
//  passed in.
// ——————————————————————-
function unSelectMatchingOptions(obj,regex) {
selectUnselectMatchingOptions(obj,regex,"unselect",false);
}

// ——————————————————————-
// sortSelect(select_object)
//   Pass this function a SELECT object and the options will be sorted
//   by their text (display) values
// ——————————————————————-
function sortSelect(obj) {
var o = new Array();
if (!hasOptions(obj)) { return; }
for (var i=0; i<obj.options.length; i++) {
o[o.length] = new Option( obj.options[i].text, obj.options[i].value, obj.options[i].defaultSelected, obj.options[i].selected) ;
}
if (o.length==0) { return; }
o = o.sort(
function(a,b) {
if ((a.text+"") < (b.text+"")) { return -1; }
if ((a.text+"") > (b.text+"")) { return 1; }
return 0;
}
);

for (var i=0; i<o.length; i++) {
obj.options[i] = new Option(o[i].text, o[i].value, o[i].defaultSelected, o[i].selected);
}
}

// ——————————————————————-
// selectAllOptions(select_object)
//  This function takes a select box and selects all options (in a
//  multiple select object). This is used when passing values between
//  two select boxes. Select all options in the right box before
//  submitting the form so the values will be sent to the server.
// ——————————————————————-
function selectAllOptions(obj) {
if (!hasOptions(obj)) { return; }
for (var i=0; i<obj.options.length; i++) {
obj.options[i].selected = true;
}
}

// ——————————————————————-
// moveSelectedOptions(select_object,select_object[,autosort(true/false)[,regex]])
//  This function moves options between select boxes. Works best with
//  multi-select boxes to create the common Windows control effect.
//  Passes all selected values from the first object to the second
//  object and re-sorts each box.
//  If a third argument of ‘false’ is passed, then the lists are not
//  sorted after the move.
//  If a fourth string argument is passed, this will function as a
//  Regular Expression to match against the TEXT or the options. If
//  the text of an option matches the pattern, it will NOT be moved.
//  It will be treated as an unmoveable option.
//  You can also put this into the <SELECT> object as follows:
//    onDblClick=”moveSelectedOptions(this,this.form.target)
//  This way, when the user double-clicks on a value in one box, it
//  will be transferred to the other (in browsers that support the
//  onDblClick() event handler).
// ——————————————————————-
function moveSelectedOptions(from,to) {
	
// Unselect matching options, if required
if (arguments.length>3) {
var regex = arguments[3];
if (regex != "") {
unSelectMatchingOptions(from,regex);
}
}
// Move them over
if (!hasOptions(from)) { return; }
for (var i=0; i<from.options.length; i++) {
var o = from.options[i];
if (o.selected) {
if (!hasOptions(to)) { var index = 0; } else { var index=to.options.length; }
to.options[index] = new Option( o.text, o.value, false, false);
}
}
// Delete them from original
for (var i=(from.options.length-1); i>=0; i--) {
var o = from.options[i];
if (o.selected) {
from.options[i] = null;
}
}
if ((arguments.length<3) || (arguments[2]==true)) {
sortSelect(from);
sortSelect(to);
}
from.selectedIndex = -1;
to.selectedIndex = -1;
}

// ——————————————————————-
// copySelectedOptions(select_object,select_object[,autosort(true/false)])
//  This function copies options between select boxes instead of
//  moving items. Duplicates in the target list are not allowed.
// ——————————————————————-
function copySelectedOptions(from,to) {
var options = new Object();
if (hasOptions(to)) {
for (var i=0; i<to.options.length; i++) {
options[to.options[i].value] = to.options[i].text;
}
}
if (!hasOptions(from)) { return; }
for (var i=0; i<from.options.length; i++) {
var o = from.options[i];
if (o.selected) {
if (options[o.value] == null || options[o.value] == "undefined" || options[o.value]!=o.text) {
if (!hasOptions(to)) { var index = 0; } else { var index=to.options.length; }
to.options[index] = new Option( o.text, o.value, false, false);
}
}
}
if ((arguments.length<3) || (arguments[2]==true)) {
sortSelect(to);
}
from.selectedIndex = -1;
to.selectedIndex = -1;
}

// ——————————————————————-
// moveAllOptions(select_object,select_object[,autosort(true/false)[,regex]])
//  Move all options from one select box to another.
// ——————————————————————-
function moveAllOptions(from,to) {
	//removeAllOptions(to);
	//Document.getElementById(list2).removeAttribute(list2);
selectAllOptions(from);
if (arguments.length==2) {
moveSelectedOptions(from,to);
}
else if (arguments.length==3) {
moveSelectedOptions(from,to,arguments[2]);
}
else if (arguments.length==4) {
moveSelectedOptions(from,to,arguments[2],arguments[3]);
}
}

// ——————————————————————-
// copyAllOptions(select_object,select_object[,autosort(true/false)])
//  Copy all options from one select box to another, instead of
//  removing items. Duplicates in the target list are not allowed.
// ——————————————————————-
function copyAllOptions(from,to) {
selectAllOptions(from);
if (arguments.length==2) {
copySelectedOptions(from,to);
}
else if (arguments.length==3) {
copySelectedOptions(from,to,arguments[2]);
}
}

// ——————————————————————-
// swapOptions(select_object,option1,option2)
//  Swap positions of two options in a select list
// ——————————————————————-
function swapOptions(obj,i,j) {
var o = obj.options;
var i_selected = o[i].selected;
var j_selected = o[j].selected;
var temp = new Option(o[i].text, o[i].value, o[i].defaultSelected, o[i].selected);
var temp2= new Option(o[j].text, o[j].value, o[j].defaultSelected, o[j].selected);
o[i] = temp2;
o[j] = temp;
o[i].selected = j_selected;
o[j].selected = i_selected;
}

// ——————————————————————-
// moveOptionUp(select_object)
//  Move selected option in a select list up one
// ——————————————————————-
function moveOptionUp(obj) {
if (!hasOptions(obj)) { return; }
for (i=0; i<obj.options.length; i++) {
if (obj.options[i].selected) {
if (i != 0 && !obj.options[i-1].selected) {
swapOptions(obj,i,i-1);
obj.options[i-1].selected = true;
}
}
}
}

// ——————————————————————-
// moveOptionDown(select_object)
//  Move selected option in a select list down one
// ——————————————————————-
function moveOptionDown(obj) {
if (!hasOptions(obj)) { return; }
for (i=obj.options.length-1; i>=0; i--) {
if (obj.options[i].selected) {
if (i != (obj.options.length-1) && ! obj.options[i+1].selected) {
swapOptions(obj,i,i+1);
obj.options[i+1].selected = true;
}
}
}
}

// ——————————————————————-
// removeSelectedOptions(select_object)
//  Remove all selected options from a list
//  (Thanks to Gene Ninestein)
// ——————————————————————-
function removeSelectedOptions(from) {
if (!hasOptions(from)) { return; }
if (from.type=="select-one") {
from.options[from.selectedIndex] = null;
}
else {
for (var i=(from.options.length-1); i>=0; i--) {
var o=from.options[i];
if (o.selected) {
from.options[i] = null;
}
}
}
from.selectedIndex = -1;
}

// ——————————————————————-
// removeAllOptions(select_object)
//  Remove all options from a list
// ——————————————————————-
function removeAllOptions(from) {
if (!hasOptions(from)) { return; }
for (var i=(from.options.length-1); i>=0; i--) {
from.options[i] = null;
}
from.selectedIndex = -1;
}

// ——————————————————————-
// addOption(select_object,display_text,value,selected)
//  Add an option to a list
// ——————————————————————-
function addOption(obj,text,value,selected) {
if (obj!=null && obj.options!=null) {
obj.options[obj.options.length] = new Option(text, value, false, selected);
}
}

function getXmlHttpRequestObject() {
	
	if (window.XMLHttpRequest) {
		return new XMLHttpRequest();
	} else if(window.ActiveXObject) {
		return new ActiveXObject("Microsoft.XMLHTTP");
	} else {
		alert("Please upgrade your browser. The current version does not support the request.");
	}
}

function getPage(action) {
	
	document.getElementById("loading").style.display = 'block';
	if(action == "")
	{
		action = "setupnetwork";
	}
	var url = "profile.do?action="+action;
	var profileReq = getXmlHttpRequestObject();
	if(profileReq.readyState == 4 || profileReq.readyState == 0){
		profileReq.open("get", url, true);
		profileReq.onreadystatechange = function(){
			if(profileReq.readyState == 4 && profileReq.status == 200){
				
				setButtonStatus(action);
				document.getElementById("loading").style.display = 'none';
				document.getElementById("content").style.display ='block';
				document.getElementById("content").innerHTML = profileReq.responseText;
	
				//this condition/method is called for curve show in IE.
				if (navigator.appName=="Microsoft Internet Explorer")
					{ 
						curvecorner_IE();
					}
				/**Calling the Jquery validation and datepicker function */
				callJqueryValidation("#frmpostlogin");
				CustomizedHtmlControl();
			}
		}
		profileReq.send(null);
	}
}
function locationPage() {
	
	/*if(action == "")
	{
		action = "setupnetwork";
	}*/
	var url = ".do?action=location_edit";
	var locationReq = getXmlHttpRequestObject();
	if(locationReq.readyState == 4 || locationReq.readyState == 0){
		locationReq.open("get", url, true);
		locationReq.onreadystatechange = function(){
			if(locationReq.readyState == 4 && locationReq.status == 200){
				setButtonStatus(action);
				document.getElementById("content").innerHTML = locationReq.responseText;
				/**Calling the Jquery validation and datepicker function */
				callJqueryValidation("#frmpostlogin");
				CustomizedHtmlControl();
			
			}
		}
		locationReq.send(null);
	}
}



function nextPage(action)
{
	window.location.href ="/"+ action;
}

 

function submitAboutme() {
	
    document.getElementById("frmpostlogin").action="postlogin.do?action=postlogin";
//    alert("1");
 //   document.getElementById("frmpostlogin").action="locationedit.do?action=location_edit";
 //   alert("2");
    
	//window.location.href="http://localhost:8080/MeetIn/postlogin.do?action=postlogin";

	//window.location.href="postlogin.do?action=postlogin";
	
	//var form_submit="frmpostlogin";
	//var sTargetURL = "myprofile.jsp?action=aboutme";

	//setTimeout( "timedRedirect()", 1*1000 );
	//alert(document.body.styleId);
	//document.forms["frmpostlogin"].action="postlogin.do?action=postlogin";
	
	
/*function timedRedirect()
{
	alert("inside redirect");
    window.location.href = sTargetURL;
}*/

	//document.close();
	
	
	//document.forms[1].submit();
	
	//document.getElementById("frmpostlogin").action="postlogin.do?action=postlogin";
	
	
	//document.getElementById("frmpostlogin").submit();
	
	//return true;
	/*return null	document.forms["user"].action.value="postlogin.do?action=postlogin";
	alert(document.forms["user"].action.value);
	
	document.forms["user"].submit();
	
	
	
	document.user.action="postlogin.do?action=postlogin"	
	alert(document.user.action)	
	document.user.submit()	
	var url = "postlogin.do?action=postlogin";
	var profileReq = getXmlHttpRequestObject();
	if(profileReq.readyState == 4 || profileReq.readyState == 0){
		profileReq.open("get", url, true);
		profileReq.onreadystatechange = function(){
			if(profileReq.readyState == 4 && profileReq.status == 200){
				setButtonStatus(action)				document.getElementById("generalfrm").innerHTML = profileReq.responseText;
						
			}
		}
		profileReq.send(null);
	}*/


}

function previewpopup()
      {
        //alert(popup);
          var windowObjectRef;
         windowObjectRef=window.open("postlogin.do?action=imagepreview","preview","menubar=yes,location=yes,resizable=yes,status=yes");
      
      }

function nextUserInterest()
{
	window.location.href ="/myprofile.jsp?action=setupnetwork";
}





/** This function will call the action servlet and update the user's interest */
function setUserInterest()
{
	
	var c_value = "";
	for (var i=0; i < document.getElementById("list2").length; i++)
   	{
   		    if(document.getElementById("list2")[i].value!=null)
   	    	{
   	    	   c_value = c_value + document.getElementById("list2")[i].value + "_";
   	    	}
   	}
	if(c_value == "")
	{
		  alert("Please Select atleast one option");
		  return false;
	}

	document.getElementById("loading").style.display ='block';
	
	var interestid = c_value.substr(0,c_value.length - 1);
	var url = "profile.do?action=updateinterest&interestid=" + interestid;
	
	var interestReq = getXmlHttpRequestObject();
	if(interestReq.readyState == 4 || interestReq.readyState == 0){
		interestReq.open("get", url, true);
		interestReq.onreadystatechange = function(){
			if(interestReq.readyState == 4 && interestReq.status == 200){
				setButtonStatus('setupnetwork');
				document.getElementById("loading").style.display ='none';
				document.getElementById("content").innerHTML = interestReq.responseText;
			}
		}
		interestReq.send(null);
	}
}
function setButtonStatus(action)
{
	if(action == "aboutme")
	{
		document.getElementById("aboutmebtn").className += " active";
		document.getElementById("visitorbtn").className = "iphonebutton";
		document.getElementById("locationbtn").className = "iphonebutton";
		document.getElementById("interestbtn").className = "iphonebutton";
		document.getElementById("setupnetworkbtn").className = "iphonebutton";
		document.getElementById("privacybtn").className = "iphonebutton";
	}
	else if(action == "setupnetwork")
	{
		document.getElementById("setupnetworkbtn").className += " active";
		document.getElementById("visitorbtn").className = "iphonebutton";
		document.getElementById("locationbtn").className = "iphonebutton";
		document.getElementById("interestbtn").className = "iphonebutton";
		document.getElementById("aboutmebtn").className = "iphonebutton";
		document.getElementById("privacybtn").className = "iphonebutton";
	}
	else if(action == "privacysetting")
	{
		/**Calling the Jquery function to customized the html control */
		
		document.getElementById("privacybtn").className += " active";
		document.getElementById("visitorbtn").className = "iphonebutton";
		document.getElementById("locationbtn").className = "iphonebutton";
		document.getElementById("interestbtn").className = "iphonebutton";
		document.getElementById("aboutmebtn").className = "iphonebutton";
		document.getElementById("setupnetworkbtn").className = "iphonebutton";
	}
	else if(action == "profilevisitors")
	{
		document.getElementById("visitorbtn").className += " active";
		document.getElementById("privacybtn").className = "iphonebutton";
		document.getElementById("locationbtn").className = "iphonebutton";
		document.getElementById("interestbtn").className = "iphonebutton";
		document.getElementById("aboutmebtn").className = "iphonebutton";
		document.getElementById("setupnetworkbtn").className = "iphonebutton";
	}
	else if(action == "interest")
	{
		document.getElementById("interestbtn").className +=" active";
		document.getElementById("privacybtn").className = "iphonebutton";
		document.getElementById("locationbtn").className = "iphonebutton";
		document.getElementById("visitorbtn").className = "iphonebutton";
		document.getElementById("aboutmebtn").className = "iphonebutton";
		document.getElementById("setupnetworkbtn").className = "iphonebutton";
	}
}

/**This function show curve in IE8 Browser  */
function curvecorner_IE()
{
					var settings_head = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
				}

				var settings_row = {
					tl: { radius: 0 },
					tr: { radius: 0 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
				}

				var settings_postloginhead = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
				}

				var settings_postloginrow = {
					tl: { radius: 0 },
					tr: { radius: 0 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
				}

				var settings_generalfrm = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
				}

				var settings_networkfrm = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
				}

				curvyCorners(settings_networkfrm, ".networkfrm");
				curvyCorners(settings_generalfrm, ".generalfrm");
				curvyCorners(settings_head, ".tableheading");
				curvyCorners(settings_row, ".dynamicrow");
				curvyCorners(settings_postloginhead, ".postlogin");
				curvyCorners(settings_postloginrow, ".postloginprofile");
}



///////////image uplaod  function 

function uploadImagePage()
{	
		//alert("upload image function");
	  window.open("image.jsp","_self");
	
}



