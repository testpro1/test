		// example with a preview of crop results, must have minimumm dimensions
		
 
	