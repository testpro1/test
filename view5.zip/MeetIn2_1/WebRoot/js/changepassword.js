function getXmlHttpRequestObject() {

	if (window.XMLHttpRequest) {
		return new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		return new ActiveXObject("Microsoft.XMLHTTP");
	} else {
		alert("Please upgrade your browser. The current version does not support the request.");
	}
}

/**This is the Ajax function which will show the view to change password */
function changePasswordView()
{
	var url ="changepassword.jsp";
	var changepasswordView = getXmlHttpRequestObject();
	if(changepasswordView.readyState == 4 || changepasswordView.readyState == 0){
		changepasswordView.open("get", url, true);
		changepasswordView.onreadystatechange = function(){
			if(changepasswordView.readyState == 4 && changepasswordView.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepasswordView.responseText;
				
				/**  this code show curve in IE popup window*/
				var settings_general = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}
				
				var settings_head = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
					}

				var settings_row = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 6 },
					br: { radius: 6 },
					antiAlias: true
			}
			curvyCorners(settings_head, ".generalfrm");
			curvyCorners(settings_head, ".popupheading");
			curvyCorners(settings_row, ".popupmsg");
			
			/**Default focus field when change password page load */
			document.getElementById("oldpassword").focus();
			//callJqueryValidation("#frmchangepassword");
				
			}
		}
		
		changepasswordView.send(null);
	}
			
}


function changePasswordAdminView()
{
//	alert("changepasswordAdminview");
	var url ="changepasswordadmin.jsp";
	var changepasswordView = getXmlHttpRequestObject();
	if(changepasswordView.readyState == 4 || changepasswordView.readyState == 0){
		changepasswordView.open("get", url, true);
		changepasswordView.onreadystatechange = function(){
			if(changepasswordView.readyState == 4 && changepasswordView.status == 200){
				//alert("respone text    "+ changepasswordView.responseText );
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepasswordView.responseText;
				
				/**  this code show curve in IE popup window*/
				var settings_general = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}
				
				var settings_head = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
					}

				var settings_row = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 6 },
					br: { radius: 6 },
					antiAlias: true
			}
			curvyCorners(settings_head, ".generalfrm");
			curvyCorners(settings_head, ".popupheading");
			curvyCorners(settings_row, ".popupmsg");
			
			/**Default focus field when change password page load */
			document.getElementById("oldpassword").focus();
			//callJqueryValidation("#frmchangepassword");
				
			}
		}
		
		changepasswordView.send(null);
	}
			
}


/*
function changePasswordView()
{
	alert("change password view");
	var url ="changepassword.jsp";
	var changepasswordView = getXmlHttpRequestObject();
	if(changepasswordView.readyState == 4 || changepasswordView.readyState == 0){
		
		changepasswordView.open("get", url, true);
		
		changepasswordView.onreadystatechange = function(){
		
			if(changepasswordView.readyState == 4 && changepasswordView.status == 200){
		
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
		
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepasswordView.responseText;
			
				alert(changepasswordView.responseText);
		
				/**  this code show curve in IE popup window*/
	/*			var settings_general = {
					tl: { radius: 10 },
					tr: { radius: 10 },
					bl: { radius: 10 },
					br: { radius: 10 },
					antiAlias: true
					}
		
				var settings_head = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 0 },
					br: { radius: 0 },
					antiAlias: true
					}
		
				var settings_row = {
					tl: { radius: 6 },
					tr: { radius: 6 },
					bl: { radius: 6 },
					br: { radius: 6 },
					antiAlias: true
			}
		
			curvyCorners(settings_head, ".generalfrm");
		
			curvyCorners(settings_head, ".popupheading");
			curvyCorners(settings_row, ".popupmsg");
		
			/**Default focus field when change password page load */
//			document.getElementById("oldpassword").focus();
			//callJqueryValidation("#frmchangepassword");
	/*			
			}
		}
		
		changepasswordView.send(null);
	}
			
}
*/

function test(){
	//alert("test");
	$('#oldpassword').validationEngine('hide');
	$('#newpassword').validationEngine('hide');
	$('#confirmpass').validationEngine('hide');
}

function changePassword()
{
	var oldpassword = document.getElementById("oldpassword").value;
	var newpassword = document.getElementById("newpassword").value;
	var confirmpass = document.getElementById("confirmpass").value;
		var url ="profile.do?action=changepassword&oldpassword="+oldpassword +"&newpassword=" +newpassword;
		var changepassword = getXmlHttpRequestObject();
	if(changepassword.readyState == 4 || changepassword.readyState == 0){
		changepassword.open("get", url, true);
		changepassword.onreadystatechange = function(){
			if(changepassword.readyState == 4 && changepassword.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepassword.responseText;
			}
		}
		changepassword.send(null);
		}
}


function changePasswordAdmin()
{
	alert("change password admin");
	var oldpassword = document.getElementById("oldpassword").value;
	var newpassword = document.getElementById("newpassword").value;
	var confirmpass = document.getElementById("confirmpass").value;
		var url ="profile.do?action=changepasswordAdmin&oldpassword="+oldpassword +"&newpassword=" +newpassword;
		var changepassword = getXmlHttpRequestObject();
	if(changepassword.readyState == 4 || changepassword.readyState == 0){
		changepassword.open("get", url, true);
		changepassword.onreadystatechange = function(){
			if(changepassword.readyState == 4 && changepassword.status == 200){
				document.getElementById("light").style.display='block';
				document.getElementById("fade").style.display='block';
				document.getElementById("light").innerHTML = "<a href=\"javascript:void(0)\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\"></a>";
				document.getElementById("light").innerHTML +=changepassword.responseText;
			}
		}
		changepassword.send(null);
		}
}


//changes made by Dharam Chag
//ajax function common 
function loadXMLDoc(str1)
{
  
//	alert("load");
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }


xmlhttp.onreadystatechange=function()
  {
	
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
	  document.getElementById("errors").style.display = "block";
    	document.getElementById("errors").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","validatepassword.jsp?str="+str1,true);
xmlhttp.send();
}


//changes made by Dharam Chag
//validating change password
function validateChangePassword()
{
	var oldpassword = document.getElementById("oldpassword").value;
	var newpassword = document.getElementById("newpassword").value;
	var confirmpass = document.getElementById("confirmpass").value;
	
	if(oldpassword == "")
	{
			loadXMLDoc("oldpassword");
			return false;
	}
	
	
	if(document.getElementById("oldpassword").value.length <6 || document.getElementById("oldpassword").value.length > 11)
	{
			loadXMLDoc("oldpasswordlength");	
			return false;		
	}
	
	if(newpassword == "")
	{
			loadXMLDoc("newpassword");
			return false;
	}
	if(document.getElementById("newpassword").value.length <6 || document.getElementById("newpassword").value.length > 11)
	{
			loadXMLDoc("newpasswordlength");	
			return false;
	}
	
	
	if(confirmpass == "")
	{
			loadXMLDoc("confirmpassword");
			return false;
	}
	if(document.getElementById("confirmpass").value.length <6 || document.getElementById("confirmpass").value.length > 11)
	{
			loadXMLDoc("confirmpasswordlength");	
			return false;
	}
	
	
	if(newpassword != confirmpass)
	{
			loadXMLDoc("match");
			return false;
	}	
	
	 changePassword();
	// changePasswordAdmin();
		   //Default focus field when change password page load //
		   document.getElementById("oldpassword").focus();
		   return false;
	
	
	/**
	if(oldpassword =="" || newpassword =="" || newpassword != confirmpass || newpassword.length<6 || newpassword.length>11)
		{
		//	callJqueryValidation("#frmchangepassword");  
		  //Default focus field when change password page load //
		
		
		
			document.getElementById("oldpassword").focus();
		  return false;
	
		}
	else
		{
		   changePassword();
		   //Default focus field when change password page load //
		   document.getElementById("oldpassword").focus();
		   return false;
		}
	*/
}


function validateChangePasswordAdmin()
{
	alert("validate");
	var oldpassword = document.getElementById("oldpassword").value;
	var newpassword = document.getElementById("newpassword").value;
	var confirmpass = document.getElementById("confirmpass").value;
	
	if(oldpassword == "")
	{
			loadXMLDoc("oldpassword");
			return false;
	}
	
	
	if(document.getElementById("oldpassword").value.length <6 || document.getElementById("oldpassword").value.length > 11)
	{
			loadXMLDoc("oldpasswordlength");	
			return false;		
	}
	
	if(newpassword == "")
	{
			loadXMLDoc("newpassword");
			return false;
	}
	if(document.getElementById("newpassword").value.length <6 || document.getElementById("newpassword").value.length > 11)
	{
			loadXMLDoc("newpasswordlength");	
			return false;
	}
	
	
	if(confirmpass == "")
	{
			loadXMLDoc("confirmpassword");
			return false;
	}
	if(document.getElementById("confirmpass").value.length <6 || document.getElementById("confirmpass").value.length > 11)
	{
			loadXMLDoc("confirmpasswordlength");	
			return false;
	}
	
	
	if(newpassword != confirmpass)
	{
			loadXMLDoc("match");
			return false;
	}	
	 changePasswordAdmin();
		   //Default focus field when change password page load //
		   document.getElementById("oldpassword").focus();
		   return false;
	
	
	/**
	if(oldpassword =="" || newpassword =="" || newpassword != confirmpass || newpassword.length<6 || newpassword.length>11)
		{
		//	callJqueryValidation("#frmchangepassword");  
		  //Default focus field when change password page load //
		
		
		
			document.getElementById("oldpassword").focus();
		  return false;
	
		}
	else
		{
		   changePassword();
		   //Default focus field when change password page load //
		   document.getElementById("oldpassword").focus();
		   return false;
		}
	*/
}
