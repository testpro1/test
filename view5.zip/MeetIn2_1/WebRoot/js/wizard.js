var geocoder = null;
function showMap(latitude,longitude)
{
						
			 geocoder = new google.maps.Geocoder();

			 /**Default Google Map creator when page load */
			 var centerPoint = new google.maps.LatLng(latitude, longitude);
			 
			 var myOptions = {
        				zoom: 14,
        				center: centerPoint,
        				mapTypeId: google.maps.MapTypeId.ROADMAP,
        				mapTypeControlOptions: {
  						style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
					}
    			};
			map = new google.maps.Map(document.getElementById("map_canvas1"), myOptions);
			
			// we create draggable marker of the user's location
    		var myLocationMarker = new google.maps.Marker({draggable:true, icon:"images/me_pin.png", map:map});
    		myLocationMarker.setPosition(centerPoint);
    		
    		document.getElementById("destinationLatitude").value = latitude;
			document.getElementById("destinationLongitude").value = longitude;
			    		
			google.maps.event.addListener(myLocationMarker, 'dragend', function(event) {
      		// closure is called when draggin ends
        			var point = this.getPosition();
        			map.panTo(point); 
        			document.getElementById("destinationLatitude").value = point.lat();
					document.getElementById("destinationLongitude").value = point.lng();
			});
			
			
    		myLocationMarker.setAnimation(google.maps.Animation.DROP);
    		myLocationMarker.setMap(map);
}
function showStreet(streetname,cityname) {
	 
	 /**first attemp will locate the Street and City location on google map */
	 var address ="";
	 if(streetname !="")
	 {	 
		address = streetname+ ", "+cityname;
	}
	else
	{
		address = cityname;
	}
		
	geocoder.geocode( { 'address': address}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
    	var location  =  results[0].geometry.location;
    	var centerPoint = new google.maps.LatLng(location.lat(), location.lng());
    	
      	var myOptions = {
          				zoom: 14,
          				center: centerPoint,
           				mapTypeId: google.maps.MapTypeId.ROADMAP,
           				mapTypeControlOptions: {
    					style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    				}
       			};
      	
		var map = new google.maps.Map(document.getElementById("map_canvas1"), myOptions);
            
        var marker = new google.maps.Marker({
            map: map,
            position: location,
            draggable:true,
            icon:"images/me_pin.png"
        });
        
    	marker.setPosition(centerPoint);
    	
        document.getElementById("destinationLatitude").value = location.lat();
		document.getElementById("destinationLongitude").value = location.lng();
		
		/**Marker drag event code */
		google.maps.event.addListener(marker, 'dragend', function(event) {
          		  // closure is called when draggin ends
            			var point = this.getPosition();
            			map.panTo(point);
            			
            			document.getElementById("destinationLatitude").value = point.lat();
						document.getElementById("destinationLongitude").value = point.lng();
        		});
			marker.setMap(map);
		return false;
      }
    });
}

function makeActive()
{
	 jQuery("#setupnetworkbtn").addClass("active");
	 jQuery("#visitorbtn").removeClass("active");
	 jQuery("#locationbtn").removeClass("active");
	 jQuery("#interestbtn").removeClass("active");
	 jQuery("#aboutmebtn").removeClass("active");
	 jQuery("#privacybtn").removeClass("active");
	 
}

function showInitialWizard(helpAlert)
{
	
		if(helpAlert)
		{
	
			jQuery("#simplemodal-container").show();
					
			jQuery("#simplemodal-container").modal(
				
				
				{onOpen: function (dialog) {
						dialog.overlay.fadeIn('slow', function () {
						dialog.container.slideDown('slow', function () {
						dialog.data.fadeIn('slow');
						showWizard('inital-help-wizard.html');
					});
				});
		 	},
			onClose: function(dialog){
		 		jQuery.modal.close();
				jQuery("#simplemodal-container").hide();
			}
			});
					
		}
		else
		{
			//alert("else false value ");
			jQuery("#simplemodal-container").modal({onOpen: function (dialog) 
			{
					dialog.overlay.fadeIn('slow', function () {
					dialog.container.slideDown('slow', function () {
					dialog.data.fadeIn('slow');
					showWizard('setup-network-wizard.jsp');
					});
				});
		 	}
		});
			
		}
}

function showWizard(url)
{
	jQuery.ajax({
		type: "GET",
		url: url,
		success: function (msg) {
			jQuery("#wizardContent").html(msg);
		}
	});
	 
	jQuery("#simplemodal-container").css('height', 'auto');
    jQuery("#simplemodal-container").css('width', 'auto');
    
	var h = jQuery(window).height();
    var w = jQuery(window).width();
    
    var h2 = jQuery("#simplemodal-container").outerHeight(!0);
    var w2 = jQuery("#simplemodal-container").outerWidth(!0);
    
     // var top = (h-h2)/6;
     var top = 75;
     var left = (w-w2)/1.5;
    
    jQuery("#simplemodal-container").css('left', left+'px');
    jQuery("#simplemodal-container").css('top', top+'px');
    
}
function showAddTripWizard()
{
	showWizard('add-trip-wizard.jsp');
		
	setTimeout(function() {
		
		jQuery("#startDate").datepicker({
	          	changeMonth: true,
	          	changeYear: true,
	          	dateFormat: 'M dd,yy',
	          	showOn: "button",
	          	gotoCurrent: true,
	          	yearRange: '-50:+15',
	          	constrainInput: false,
	          	duration: '',
				buttonImage: "images/date.png",
				buttonImageOnly: true,
	          	onSelect: function (){this.focus();}
				        
			});
		
			jQuery("#endDate").datepicker({
	          	changeMonth: true,
	          	changeYear: true,
	          	dateFormat: 'M dd,yy',
	          	yearRange: '-50:+15',
	          	gotoCurrent: true,
	          	showOn: "button",
				buttonImage: "images/date.png",
				buttonImageOnly: true,
	          	onSelect: function (){this.focus();},
	          	beforeShow:function(){
	          	var d=jQuery("#startDate").datepicker('getDate');
	    	        if(d) return {minDate: d}
				}
			});
			
			jQuery("#destination").autocomplete(
      			 "state.do",
      		 {
      				extraParams:{"fill":"city","param":"location"},
  					delay:0, 
  					minChars:3,
  					matchSubset:1,
  					matchContains:1,
  					cacheLength:12,
  					maxItemsToShow:10,
  					autoFill:true
  				});
			
			showMap(40.7488,-73.9846);
			
			/*jQuery("#map_canvas1").mouseover(function()
       		{
				jQuery(this).css("cursor","pointer");
          		jQuery(this).stop().animate({height : "200px", top : "-50px", bottom : "0px"}, 'slow');
				
       		});
     
    		jQuery("#map_canvas1").mouseout(function()
      		{  
          		jQuery(this).stop().animate({height : "100px", top : "0px"}, 'slow');
       		});*/
    		
			resetAddTripWizard();
		
	}, 1000);

}
function addTrip()
{
	var destination = jQuery("#destination").val();
	var description = jQuery("#description").val();
	var startDate = jQuery("#startDate").val();
	var endDate = jQuery("#endDate").val();
	
	if(isFieldRequired(destination)){
		jQuery("#validateMessage").show();
		jQuery("#validateMessage").html("Fields marked with asterisk (*) are mandatory.");
		jQuery("#destination").focus();
		return;
	}else if(isFieldRequired(description)){
		jQuery("#validateMessage").show();
		jQuery("#validateMessage").html("Fields marked with asterisk (*) are mandatory.");
		jQuery("#description").focus();
		return;
	}else if(isFieldRequired(startDate)){
		jQuery("#validateMessage").show();
		jQuery("#validateMessage").html("Fields marked with asterisk (*) are mandatory.");
		jQuery("#startDate").focus();
		return;
	}else if(isFieldRequired(endDate)){
		jQuery("#validateMessage").show();
		jQuery("#validateMessage").html("Fields marked with asterisk (*) are mandatory.");
		jQuery("#endDate").focus();
		return;
	}else if(isDateGreater("#startDate", "#endDate")){
		jQuery("#validateMessage").show();
		jQuery("#validateMessage").html("To Date must be greater than From Date.");
		jQuery("#endDate").focus();
		return;
	}
	
	var latitude = jQuery("#destinationLatitude").val();
	var longitude = jQuery("#destinationLongitude").val();
	
	var linkedinchk = jQuery("#linkedinchk").length;
	var facebookchk = jQuery("#facebookchk").length;
	var twitterchk = jQuery("#twitterchk").length;
	
	var linkedinchkValue = false;
	var facebookchkValue = false;
	var twitterchkValue = false;
		
	if(linkedinchk > 0){
		if(jQuery('#linkedinchk').is(':checked')){
				linkedinchkValue = true;
			}
	}
	if(facebookchk > 0){
		if(jQuery('#facebookchk').is(':checked')){
				facebookchkValue = true;	
			}
	}
	if(twitterchk > 0){
		if(jQuery('#twitterchk').is(':checked')){
			twitterchkValue = true;	
		}
	}
	
	jQuery("#loading").show();
	
	var url = "trip.do?trip=addtripwizard&destination=" + destination + "&description=" + description + "&startDate=" + startDate
				+ "&endDate="+ endDate + "&destinationLatitude="+ latitude +"&destinationLongitude="+ longitude
				+ "&linkedinchk="+ linkedinchkValue +"&facebookchk="+facebookchkValue+"&twitterchk="+twitterchkValue;
	
	jQuery.ajax({
		type: "GET",
		url: url,
		cache :false,
		success: function (response) {
			jQuery("#loading").hide(); // Hide the progress spinner
			showWizard('meet-today-wizard.html');
		}
	});
}
function isFieldRequired(elementValue)
{
	var isRequired = false;
	
	if(elementValue == null || elementValue == ""){
		isRequired = true;
	}
	
	return isRequired;
}
function isDateGreater(elementName1, elementName2)
{
	isGreater = false;
	
	if(jQuery(elementName1).datepicker("getDate") > jQuery(elementName2).datepicker("getDate")){
		isGreater = true;			
	}
	
	return isGreater;
}
function resetAddTripWizard()
{
	jQuery("#destination").val('');
	jQuery("#description").val('');
	jQuery("#startDate").val('');
	jQuery("#endDate").val('');
	
	jQuery("#destination").focus();
	
}
function setSocialNetwork(network)
{
	var url = "socialnetwork.do?action=add&network="+network +"&view=wizard";
	jQuery.ajax({
		type: "GET",
		url: url,
		cache :false,
		success: function (response) {
			jQuery("#wizardContent").html(response);
		}
	});
}


function Check_close()
{
	window.location.href= "peoplefinder.do?action=people";
}
