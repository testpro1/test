// JavaScript Document
var currentScreen = 1;
        var screens = [];
        screens[0] = 'images/screen01.jpg';
        screens[1] = 'images/screen02.jpg';
        screens[2] = 'images/screen03.jpg';
        screens[3] = 'images/screen04.jpg';
        screens[4] = 'images/screen05.jpg';
        screens[5] = 'images/screen06.jpg';
        
        var lastTimeout = 0;
        var isSliding = false;

		$(document).ready(function() {
            lastTimeout = setTimeout("slide(500)", 4000);
		});
        
        function switchToSlide(screen) {
            if (!isSliding) {
                $('#screen2').attr('src', screens[screen]);
                currentScreen = screen;
                clearTimeout(lastTimeout);
                slide(500);
            }
        }
        
        function slide(speed) {
            isSliding = true;
            $('#screenImages').animate({left: '-=202'}, speed, 'swing', function() {
                $('#screen1').attr('src', screens[currentScreen]);
                setTimeout("preloadSlide()", 100);
            });
        }
        
        function preloadSlide() {
            $('#screenImages').css('left','0px');
            currentScreen++;
            if (currentScreen >= screens.length)
                currentScreen = 0;
            $('#screen2').attr('src', screens[currentScreen]);
            lastTimeout = setTimeout("slide(500)", 4000);
            isSliding = false;
        }