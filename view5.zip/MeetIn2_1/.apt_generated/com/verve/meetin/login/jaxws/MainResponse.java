
package com.verve.meetin.login.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "mainResponse", namespace = "http://login.meetin.verve.com/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mainResponse", namespace = "http://login.meetin.verve.com/")
public class MainResponse {


}
