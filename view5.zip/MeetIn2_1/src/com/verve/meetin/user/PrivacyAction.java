package com.verve.meetin.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


public class PrivacyAction extends Action {
	
	
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		 	
				String userid = request.getParameter("userid");
				String company= request.getParameter("companyVisible");
				String job = request.getParameter("jobVisible");
				String degree =request.getParameter("degreeVisible");
				String event = request.getParameter("eventAlert");
				String monthly = request.getParameter("monthlyAlert");
				String help = request.getParameter("helpAlert");
				
				boolean companyVisible;
				boolean jobVisible;
				boolean degreeVisible;
				boolean eventAlert;
				boolean monthlyAlert;
				boolean helpAlert;
				
				if(userid !=null)
				{
				
					companyVisible = (company !=null && company.equalsIgnoreCase("on") ? true : false);
					jobVisible = (job !=null && job.equalsIgnoreCase("on") ? true : false);
					degreeVisible = (degree !=null && degree.equalsIgnoreCase("on") ? true : false);
					eventAlert = (event !=null && event.equalsIgnoreCase("on") ? true : false);
					monthlyAlert = (monthly !=null && monthly.equalsIgnoreCase("on") ? true : false);
					helpAlert = (help !=null && help.equalsIgnoreCase("on") ? true : false);

					int row = new UserPrivacySettingDAO().updateUserPrivacySetting(Integer.parseInt(userid), companyVisible, jobVisible, degreeVisible,eventAlert,monthlyAlert, helpAlert);
			
				//if(row > 0)
				//{
	
					// This condition check that wheather user setup privacy setting from my profile menu or it is part of post login 
					// if condition is true then user has come from my profile menu
					HttpSession sc = request.getSession();
	
					if(sc.getAttribute("fromprofile") == null)
					{
						sc.setAttribute("PrivacySettingSaved", "yes");
						return mapping.findForward("failure");
					}
					else
					{
						return mapping.findForward("success");
					}
				//}
				
			}
				
		 return mapping.findForward("failure");				    
	}

}
