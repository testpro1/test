package com.verve.meetin.user;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class UserWS implements java.io.Serializable 
{
	
	private Integer userId;
	private String fullname;
	private String email;
	private String password;
	private Date dob;
	private String image;
	private String aboutMe;
	private String company;
	private Boolean companyVisible;
	private String jobTitle;
	private Boolean jobVisible;
	private String industry;
	private String degreeCollege;
	private Boolean degreeVisible;
	private String locCountry;
	private String locState;
	private String locStreet;
	private String locCity;
	private String locPin;
	private String locLat;
	private String locLang;
	private String otherSpecify;
	private Date registerOn;
	private Date lastLogin;
    private String[] interest;
    private String birthdate;
	private Integer resultId;
	private String loginResult;
	private String profilelink;
	private String gmailauthstatus;
	private String socialIcon;
	private String gender;
	private String SocialURL;
	private String resultString;
	private String relationId;
	private Boolean eventAlert=false ;
    private Boolean monthlyalert=false;
    private String mailStatus;
    private String updateOn;
	public String getUpdateOn() {
		return updateOn;
	}

	public void setUpdateOn(String updateOn) {
		this.updateOn = updateOn;
	}

	public String getMailStatus() {
		return mailStatus;
	}

	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}

	public String getResultString() {
		return resultString;
	}

	public void setResultString(String resultString) {
		this.resultString = resultString;
	}

	public String getRelationId() {
		return relationId;
	}

	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}

	public String getSocialURL() {
		return SocialURL;
	}

	public void setSocialURL(String socialURL) {
		SocialURL = socialURL;
	}
    // Fields for change password

		public Boolean getEventAlert() {
			return eventAlert;
		}

		public void setEventAlert(Boolean eventAlert) {
			this.eventAlert = eventAlert;
		}

		public Boolean getMonthlyalert() {
			return monthlyalert;
		}

		public void setMonthlyalert(Boolean monthlyalert) {
			this.monthlyalert = monthlyalert;
		}

	// Fields for User's Friend status
	
	private String status;
	
	// Error properties
	
	private String errorStatus;
	private String errorMessage;
	
	public String getErrorStatus() {
		return errorStatus;
	}
	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public Integer getResultId() {
		return resultId;
	}
	public void setResultId(Integer resultId) {
		this.resultId = resultId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getAboutMe() {
		return aboutMe;
	}
	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public Boolean getCompanyVisible() {
		return companyVisible;
	}
	public void setCompanyVisible(Boolean companyVisible) {
		this.companyVisible = companyVisible;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public Boolean getJobVisible() {
		return jobVisible;
	}
	public void setJobVisible(Boolean jobVisible) {
		this.jobVisible = jobVisible;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getDegreeCollege() {
		return degreeCollege;
	}
	public void setDegreeCollege(String degreeCollege) {
		this.degreeCollege = degreeCollege;
	}
	public Boolean getDegreeVisible() {
		return degreeVisible;
	}
	public void setDegreeVisible(Boolean degreeVisible) {
		this.degreeVisible = degreeVisible;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getLocCountry() {
		return locCountry;
	}
	public void setLocCountry(String locCountry) {
		this.locCountry = locCountry;
	}
	public String getLocState() {
		return locState;
	}
	public void setLocState(String locState) {
		this.locState = locState;
	}
	public String getLocStreet() {
		return locStreet;
	}
	public void setLocStreet(String locStreet) {
		this.locStreet = locStreet;
	}
	public String getLocCity() {
		return locCity;
	}
	public void setLocCity(String locCity) {
		this.locCity = locCity;
	}
	public String getLocPin() {
		return locPin;
	}
	public void setLocPin(String locPin) {
		this.locPin = locPin;
	}
	public String getLocLat() {
		return locLat;
	}
	public void setLocLat(String locLat) {
		this.locLat = locLat;
	}
	public String getLocLang() {
		return locLang;
	}
	public void setLocLang(String locLang) {
		this.locLang = locLang;
	}
	public String getOtherSpecify() {
		return otherSpecify;
	}
	public void setOtherSpecify(String otherSpecify) {
		this.otherSpecify = otherSpecify;
	}
	public Date getRegisterOn() {
		return registerOn;
	}
	public void setRegisterOn(Date registerOn) {
		this.registerOn = registerOn;
	}
	public Date getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}
	public String[] getInterest() {
		return interest;
	}
	public void setInterest(String[] interest) {
		this.interest = interest;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getLoginResult() {
		return loginResult;
	}
	public void setLoginResult(String loginResult) {
		this.loginResult = loginResult;
	}
	public String getProfilelink() {
		return profilelink;
	}
	public void setProfilelink(String profilelink) {
		this.profilelink = profilelink;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGmailauthstatus() {
		return gmailauthstatus;
	}
	public String getSocialIcon() {
		return socialIcon;
	}
	public void setGmailauthstatus(String gmailauthstatus) {
		this.gmailauthstatus = gmailauthstatus;
	}
	public void setSocialIcon(String socialIcon) {
		this.socialIcon = socialIcon;
	}
	

}
