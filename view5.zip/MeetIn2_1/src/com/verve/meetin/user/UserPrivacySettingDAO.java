package com.verve.meetin.user;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;


public class UserPrivacySettingDAO
{
	
	static Logger log = Logger.getLogger(UserPrivacySettingDAO.class);

/**
 * Author : Vasim Saiyad
 * <p>
 * This method returns the all privacy and notification settings values of a user.
 * @param userid	ID of logged in user
 * @return			Object of User class
 */
public User getUserPrivacySettings(int userid)
{
	
	log.info("Inside user privacy and notification settings.....");
    String queryString = "from User as user where user.userId=?";
    User result = null;
	 try
		{
		    log.info("Trying to fetch the user privacy and notification settings........");
		    Session session  = HibernateUtil.getSessionFactory().getCurrentSession();
		    session.beginTransaction();
		    
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userid);
		    result = (User)query.uniqueResult();
		    session.getTransaction().commit();
		}
		catch(Exception ex)
		{
			log.debug("There is a problem fetching user privacy and notification settings");
			log.debug(ex);
		
		}
		
		return result; 
	}

/**
 * Author : Vasim Saiyad
 * <p>
 * This method is for web application to update the user privacy and notification settings.  
 * @param userid  			ID of logged in user
 * @param companyVisible    true or false 
 * @param jobVisible	 	true or false
 * @param degreeVisible 	true or false
 * @param eventAlert 		true or false
 * @param monthlyAlert 		true or false
 * @param helpAlert 		true or false
 * @return 					Return non zero value if privacy and notification settings updated.
 */
public int updateUserPrivacySetting(int userid,boolean companyVisible,boolean jobVisible,boolean degreeVisible,boolean eventAlert,boolean monthlyAlert, boolean helpAlert)
{

	log.info("Inside user privacy and notification settings update....");
	int update_record_id =0;

	String queryString = "update User set companyVisible=?,jobVisible=?,degreeVisible=?,eventAlert=?,monthlyAlert=?,helpAlert=? where userId =?";
	try
	
	{
		Session session  = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
	    tx = session.beginTransaction();
		Query query = session.createQuery(queryString);
		
		query.setParameter(0, companyVisible);
		query.setParameter(1, jobVisible);
		query.setParameter(2, degreeVisible);
		query.setParameter(3, eventAlert);
		query.setParameter(4, monthlyAlert);
		query.setParameter(5, helpAlert);
		query.setParameter(6, userid);
		
		update_record_id = query.executeUpdate();
        tx.commit();
        
		log.info("User's privacy and notification settings have been updated successfully");
        
	}
	catch(Exception ex)
	{
		log.error("There is a problem updating user's privacy and notification settings details");
		log.debug(ex);
		ex.printStackTrace();
	}
	
	return update_record_id;
	
}

/**
 * Author : Vasim Saiyad
 * <p>
 * This method is for web service to update the user privacy and notification settings. This is overloaded method. 
 * @param userid 			 ID of logged in user
 * @param companyVisible  	 true or false  
 * @param jobVisible		 true or false 
 * @param degreeVisible 	 true or false 
 * @param eventAlert 		 true or false
 * @param monthlyAlert 		 true or false 
 * @return 					 Return non zero value if privacy and notification settings updated.
 */
public int updateUserPrivacySetting(int userid,boolean companyVisible,boolean jobVisible,boolean degreeVisible,boolean eventAlert,boolean monthlyAlert)
{

	log.info("Inside user privacy and notification settings update....");
	int update_record_id =0;

	String queryString = "update User set companyVisible=?,jobVisible=?,degreeVisible=?,eventAlert=?,monthlyAlert=? where userId =?";
	try
	
	{
		Session session  = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
	    tx = session.beginTransaction();
		Query query = session.createQuery(queryString);
		
		query.setParameter(0, companyVisible);
		query.setParameter(1, jobVisible);
		query.setParameter(2, degreeVisible);
		query.setParameter(3, eventAlert);
		query.setParameter(4, monthlyAlert);
		query.setParameter(5, userid);
		
		update_record_id = query.executeUpdate();
        tx.commit();
        
		log.info("User's privacy and notification settings have been updated successfully");
        
	}
	catch(Exception ex)
	{
		log.error("There is a problem updating user's privacy and notification settings details");
		log.debug(ex);
		ex.printStackTrace();
	}
	
	return update_record_id;
	
}
/**
 * Author : Vasim Saiyad
 * <p>
 * This method set the help wizard value to show or hide wizard.
 * @param userId 		ID of logged in user
 * @param settingValue	true or false
 */
public void setHelpWizardSetting(int userId, Boolean settingValue)
{
	log.info("Inside help wizard settings");
	
	try
	{
		log.info("Trying to setup help wizard setting..........");
		String queryString = "update User set helpAlert=? where userId=?";
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		tx = session.beginTransaction();
		
		Query query = session.createQuery(queryString);
		query.setParameter(0, settingValue);
		query.setParameter(1, userId);
		
		int resultId = query.executeUpdate();
		tx.commit();
		log.info("Help wizard setting has been updated successfully to : " +settingValue);
	}
	catch (Exception ex) {
		log.error("There is a problem in setting help wizard setting");
		ex.printStackTrace();
	}
}

}
