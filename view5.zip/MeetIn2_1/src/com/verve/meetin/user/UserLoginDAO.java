
package com.verve.meetin.user;

import java.security.MessageDigest;
import java.util.Date;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import sun.misc.BASE64Encoder;
import com.verve.hibernate.utils.*;


public class UserLoginDAO extends BaseHibernateDAO 
{
	
	static Logger log = Logger.getLogger(UserLoginDAO.class);
	private static String USER_LOGIN_RESULT = "valid";
	
	public User getUserLogin(String username, String password)
	{
		
		log.info("Inside user authentication");
		User user = null;
		String queryString  = "from User as user where user.email =? and user.password =?";
		try
		{
			log.info("Trying to authenticate user.....");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			
			query.setParameter(0, username);
            query.setParameter(1, password);
            user = (User)query.uniqueResult();
            
            session.getTransaction().commit();
            
            if(user !=null)
            {
            	  Integer i = user.getUserId();
                                  
		         if(i != null && i.intValue() > 0)
		            {

		            	user.setLoginResult(USER_LOGIN_RESULT);
		            		            	
		            	log.info("User has been authenticated successfully");
		            	log.info("Trying to get user's login attempts.......");
		
		            	if(getLastLoginAttempt(i) !=null)
		            	{
		            		log.info("Last login attempt for logged in user is  :" + getLastLoginAttempt(i));
		            		user.setLastLogin(getLastLoginAttempt(i));
		            		setLastLoginAttempt(i);
		            		log.info("Current login attempt for logged in user is  :" + setLastLoginAttempt(i));
		            	}
		            	else
		            	{
		            		log.info("User is logging first time");
		            		user.setLastLogin(setLastLoginAttempt(i));
		            		log.info("First login attempt for logged in user is :" +setLastLoginAttempt(i));
		            	}
		            }
            }else{
	           	log.info("User has attempted invalid username/password");
            }
		}
		catch(Exception ex){
			log.error("There is a problem in user authentication");
			ex.printStackTrace();
			return null;
		}
				
	   return user;
	}
	
	private Date getLastLoginAttempt(Integer user_id)
	{
		String queryString  = "select user.lastLogin from User as user where user.userId =?";
		Date loginDate = null;
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query  =session.createQuery(queryString);
			query.setParameter(0, user_id);
			
			loginDate = (Date)query.uniqueResult();
			session.getTransaction().commit();
			
		}
		catch(Exception ex){
			log.error("There is a problem in getting user's last login attempt");
			log.debug(ex);		
		}
		
		return loginDate;
	}
	
	private Date setLastLoginAttempt(Integer user_id)
	{
		String queryString  = "update User set lastLogin = ? where userId =?";
		Date loginDate = null;
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, new Date());
			query.setParameter(1, user_id);
			
			int i = query.executeUpdate();
			tx.commit();
			
			if(i > 0)
			{
				loginDate = getLastLoginAttempt(user_id);
			}

		}
		catch(Exception ex){
			
			log.error("There is a problem in updating user's last login status");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return loginDate;
	}
	
	public synchronized String encrypt(String plaintext)
	{
	   log.info("Trying to encrypt user password......");
	
	   MessageDigest md= null;	
	   String hash ="";	
		try
		{
		   md = MessageDigest.getInstance("SHA");
		   md.update(plaintext.getBytes("UTF-8"));
		   byte row[] = md.digest();
		   
		   hash = (new BASE64Encoder()).encode(row); 
		   log.info("User's password has been encrypted successfully");   

		}
		catch(Exception ex)
		{
			
			log.error("There is a problem in password encryption");
			log.debug(ex);
			System.out.print(ex);
		}
		return hash;
		
	}
}