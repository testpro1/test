package com.verve.meetin.user;

import java.util.Properties;
import java.util.Random;
import java.util.ResourceBundle;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;


public class ForgotPasswordDAO 
{
	static Logger log = Logger.getLogger(ForgotPasswordDAO.class);
	ResourceBundle resource;
	
	/**Author Vasim Saiyad */
	/** This method will use to generate new password for user */
	
	public String generateNewPassword(String email)
	{
		log.info("Inside User Forgot Password");
		StringBuffer sb=new StringBuffer();
		String queryString ="update User set password=? where email=?";
		int result =0;
		try
		{
			log.info("Trying to generate new user password.....");
			String str=new  String("G12HIJdefgPQRSTUVWXYZabc56hijklmnopqAB78CDEF0KLMNO3rstu4vwxyz9");
	        String ar=null;
			Random r = new Random();
			int te=0;
			for(int i=1;i<=11;i++)
			{
				te=r.nextInt(62);
				ar=ar+str.charAt(te);
				sb.append(str.charAt(te));
				
	 		}

			log.info("User's new password has been created successfully");
			log.info("Trying to update new user password in database table.........");

			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
		    Query query  = session.createQuery(queryString);
		    query.setParameter(0, new UserLoginDAO().encrypt(sb.toString()));
		    query.setParameter(1, email);
		    
		    result = query.executeUpdate();
		    tx.commit();
		    
		    if(result > 0)
		    {
		    	log.info("User's new password has been updated successfully in database table");
		    	return sb.toString();
		    }
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem generating user password");
			log.debug(ex);
		}
		
		return "";
	}
	
	
	public void sendGenereatedPasswordByEmail(String recipient, String subject,
                          String message , String from) throws MessagingException    
    {
	
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		
	    log.info("Sending forgotton password by an email");
	    log.info("Email receiver :" + recipient);
	    log.info("Email sender :" + resource.getString("mail.id"));
	    
	    String SMTP_HOST_NAME = resource.getString("mail.hostname");
	    String SMTP_PORT= resource.getString("mail.port");
	   
	    boolean debug = false;
	    Properties props = new Properties();
	    props.put("mail.smtp.host",SMTP_HOST_NAME);
	    props.put("mail.smtp.port",SMTP_PORT);
	    props.put("mail.smtp.auth", "true");
	    props.put("mail.smtp.socketFactory.port", SMTP_PORT);
	  // props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
	    props.put("mail.smtp.socketFactory.fallback", "false");
	  
	    Authenticator auth = new SMTPAuthenticator();
	    javax.mail.Session session = javax.mail.Session.getDefaultInstance(props, auth);
	  
	    session.setDebug(debug);
	
	  // create a message
	    Message msg = new MimeMessage(session);
	 
	  // set the from and to address
	    InternetAddress addressFrom = new InternetAddress(resource.getString("mail.id"));
	    msg.setFrom(addressFrom);
	    
	    InternetAddress addressTo = new InternetAddress(recipient);
	    msg.setRecipient(Message.RecipientType.TO, addressTo);
	
	  // Setting the Subject and Content Type
	    msg.setSubject(subject);
	 
	  // Setting the Email Message and Content Type
	    msg.setContent(message, "text/html");
	
	    Transport.send(msg);
	    log.info("New generated password has been sent successfully to the receiver :" +recipient);
    }
 
	public class SMTPAuthenticator extends javax.mail.Authenticator{
   @Override
   public PasswordAuthentication getPasswordAuthentication()
    {
	   String SMTP_AUTH_USER = resource.getString("mail.id");
	   String SMTP_AUTH_PWD  = resource.getString("mail.password");
       String username = SMTP_AUTH_USER;
       String password = SMTP_AUTH_PWD;
       return new PasswordAuthentication(username, password);
    }
  }
}
