package com.verve.meetin.user;

 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat; 
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.sun.org.apache.regexp.internal.recompile;
import com.sun.research.ws.wadl.Request;
import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.network.peoplefinder.PeopleFinder;
import com.verve.meetin.trip.TripConstraint;

public class UserAccountDAO 
{
	
	static Logger log = Logger.getLogger(UserAccountDAO.class);
	
	public int createUserAccount(User user) {
		
		log.info("Inside CreateUserAccount....");
		int last_record_id = 0;
		
		try 
		{
				try{
				if(user.getLocLang()=="" || user.getLocLat()=="" || user.getLocLang()==null || user.getLocLat()==null){
					String citydata = new LocationDAO().getCityLatitudeLongitude((user.getLocCity().split(",")[0]).trim());
					String lat=citydata.split(":")[0];
					String longitude=citydata.split(":")[1];
					user.setLocLat(lat);
					user.setLocLang(longitude);
				}}catch(Exception e){
					e.printStackTrace();
				}
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			last_record_id = (Integer) session.save(user);
			tx.commit();
			
			log.info("Basic user account has been created successfully");
		} catch (Exception ex) {
			log.error("There is a problem creating basic user account");
			log.debug(ex);
			ex.printStackTrace();
		} 
		
		return last_record_id;
	}

	// Modified by Rupal Kathiriya #864 to display interest, privacy setting
	// with true status
	public int createPostLoginDetails(User user) {

		
		
		int i = 0;
		log.info("Inside post login details...");
		// String queryString =
		// "update User set image=?,aboutMe=?,company=?,companyVisible=?,jobTitle=?,jobVisible=?,industry=?,degreeCollege=?,degreeVisible=?,otherSpecify=?, fullname=?, dob=?, gender=?, username=? where userId =?";
		String queryString = "update User set image=?,aboutMe=?,company=?,jobTitle=?,industry=?,degreeCollege=?,otherSpecify=?, fullname=?, dob=?, gender=?, username=? where userId =?";
		try 
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, user.getImage());
			query.setParameter(1, user.getAboutMe());
			query.setParameter(2, user.getCompany());
			// query.setParameter(3, user.getCompanyVisible());
			query.setParameter(3, user.getJobTitle());
			// query.setParameter(5, user.getJobVisible());
			query.setParameter(4, user.getIndustry());
			query.setParameter(5, user.getDegreeCollege());
			// query.setParameter(8, user.getDegreeVisible());
			query.setParameter(6, user.getOtherSpecify());
			query.setParameter(7, user.getFullname());
			query.setParameter(8, user.getDob());
			query.setParameter(9, user.getGender());
			query.setParameter(10, user.getUsername());
			query.setParameter(11, user.getUserId());
			i = query.executeUpdate();
			
			tx.commit();
			
			log.info("User's post login details has been created successfully");
		} catch (Exception ex) {
			log.error("There is a problem creating post login details");
			log.debug(ex);
			ex.printStackTrace();
		} 
		
		return i;
	}

	/**
	 * This is the method for post login which will be given as rest web service
	 */
	public int updateUserProfileImageforWebservice(User user) {

		int i = 0;

		log.info("Inside post login details...");

		String queryString = "update User set image=? where userId =?";
		try

		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
					
			Query query = session.createQuery(queryString);
			query.setParameter(0, user.getImage());
			query.setParameter(1, user.getUserId());

			i = query.executeUpdate();
			tx.commit();
			
			log.info("User's profile image details has been updated successfully");

		} catch (Exception ex) {
			log.error("There is a problem updating user profile image details");
			log.debug(ex);
			ex.printStackTrace();
		} 
		
		return i;
	}
	public int createPostLoginforWebservice(User user) {

		int i = 0;

		log.info("Inside post login details...");

		String queryString = "update User set aboutMe=?,company=?,companyVisible=?,jobTitle=?,jobVisible=?,industry=?,degreeCollege=?,degreeVisible=?,locCountry=?,locState=?,locStreet=?,locCity=?,locPin=?,locLat=?,locLang=?,otherSpecify=?,gender=?,dob=? where userId =?";
		try

		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
			Query query = session.createQuery(queryString);

			query.setParameter(0, user.getAboutMe());
			query.setParameter(1, user.getCompany());
			query.setParameter(2, user.getCompanyVisible());
			query.setParameter(3, user.getJobTitle());
			query.setParameter(4, user.getJobVisible());
			query.setParameter(5, user.getIndustry());
			query.setParameter(6, user.getDegreeCollege());
			query.setParameter(7, user.getDegreeVisible());
			query.setParameter(8, user.getLocCountry());
			query.setParameter(9, user.getLocState());
			query.setParameter(10, user.getLocStreet());
			query.setParameter(11, user.getLocCity());
			query.setParameter(12, user.getLocPin());
			query.setParameter(13, user.getLocLat());
			query.setParameter(14, user.getLocLang());
			query.setParameter(15, user.getOtherSpecify());
			query.setParameter(16, user.getGender());
			query.setParameter(17, user.getDob());
			query.setParameter(18, user.getUserId());

			i = query.executeUpdate();
			tx.commit();
			log.info("User's post login details has been created successfully");

		} catch (Exception ex) {
			log.error("There is a problem creating post login details");
			log.debug(ex);
			ex.printStackTrace();
		} 
		
		return i;
	}

	public String getUserLocation(int userId) {
		
		String queryString = "select user.locCity, user.locCountry from User as user where user.userId=?";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			Object[] obj = (Object[]) query.uniqueResult();
			session.getTransaction().commit();
			
			if (obj[0] != null && !obj[0].toString().equals("") && obj[1] != null
					&& !obj[1].toString().equals(""))
				return obj[0].toString() + ", " + obj[1].toString();
			else
				return "";
		}catch(Exception e){
			e.printStackTrace();
			
		}
		
		return "";		
		
	}
	
	public List getUserLatLong(String city)
	{
		log.info("Inside get user lat long details...");
		String queryString = "select c.latitude,c.longitude from Cities as c where c.city like ?";
		try {
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			city = "%"+city+"%";
			query.setParameter(0, city);
			List list =  query.list();
			session.getTransaction().commit();
			return list;
		
	} catch (Exception ex) {
		log.error("There is a problem in getting user lat long details");
		log.debug(ex);
		ex.printStackTrace();
	}
			return null;
	}

	/** Author Vasim Saiyad */
	public User getUserLocationDetails(int userId) {
		Object[] object = null;
		String queryString = "select user.locCountry,user.locState,user.locStreet,user.locCity,user.locPin,user.locLat,user.locLang from User as user where user.userId =?";
		User user = new User();
		try 
		{
			log.info("Fetching user's Location details......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			object = (Object[]) query.uniqueResult();
			session.getTransaction().commit();
			
			user.setLocCountry((String) object[0]);
			user.setLocState((String) object[1]);
			user.setLocStreet((String) object[2]);
			user.setLocCity((String) object[3]);
			user.setLocPin((String) object[4]);
			user.setLocLat((String) object[5]);
			user.setLocLang((String) object[6]);
			log.info("User's Location details have been fetched successfully......");
		} catch (Exception ex) {
			log.error("There is a problem fetching user's location details");
			log.debug(ex);
			ex.printStackTrace();
		} 

		return user;
	}

	/** Author Vasim Saiyad */

	/** This method will return the user's profile details */
	public Object getUserProfileDetails(int userId) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		Object object = null;
		String queryString = "from User as user where user.userId =?";
		try 
		{
			log.info("Fetching user's profile details......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			object = query.uniqueResult();
			session.getTransaction().commit();
			log.info("User's profile details have been fetched successfully......");
			
		} catch (Exception ex) {
			log.error("There is a problem fetching user's profile details");
			log.debug(ex);
			ex.printStackTrace();
		} 
		
		return object;
	}

	public List<String> getPostLoginDetails(int userId) 
	{
				
		List<String> aboutme = new ArrayList<String>();
		String queryString = "select user.image, user.aboutMe, user.company, user.companyVisible, user.jobTitle, "
			+ "user.jobVisible, user.industry, user.degreeCollege, user.degreeVisible, user.otherSpecify, user.fullname, "
			+ "user.dob, user.gender,user.username from User as user where user.userId = ?";
		
		try {
				Session session = HibernateUtil.getSessionFactory().getCurrentSession();
				session.beginTransaction();
				
				Query query = session.createQuery(queryString);
				query.setParameter(0, userId);
				Object[] object = (Object[]) query.uniqueResult();
				session.getTransaction().commit();
				
				for (int i = 0; i < object.length; i++) 
				{
					if (object[i] == null)
						aboutme.add("");
					else
						aboutme.add(object[i].toString());
				}
		
		
		} catch (Exception ex) {
			log.error("There is a problem fetching user's profile details");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return aboutme;
	}

	/** Author Vasim Saiyad */
	/** code to get the MeetIn friend's Latitude/longitude */
	public List<User> getMeetInFriendsLatLang(int userId, String location) {
		log.info("Inside the MeetIn Friend's Latitude/Langitude");
		String queryString = "select a.locLat,a.locLang from User a,Friends b where a.userId=b.userId1 and b.userId2=? and b.status='Approve'and a.locCity=? or a.userId=b.userId2 and b.userId1=? and b.status= 'Approve' and a.locCity=?";
		List<User> resultList = null;

		try 
		{
			log.info("Trying to fetch Latitude/Langitude......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, location);
			query.setParameter(2, userId);
			query.setParameter(3, location);
			resultList = query.list();
			session.getTransaction().commit();
			
			log.info("User's MeetIn friend's Latitude/langitude found, Size :"
					+ resultList.size());

		} catch (Exception ex) {
			log.error("There is a problem fetching user's latitude/langitude");
			log.debug(ex);
			ex.printStackTrace();
		}

		return resultList;
	}

	public int setupLocation(User user) {

		int i = 0;
		log.info("Updating Location");
		String queryString = "update User set locCountry=?,locState=?,locStreet=?,locCity=?,locPin=?,locLat=?,locLang=? where userId =?";
		try {
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();

			Query query = session.createQuery(queryString);

			query.setParameter(0, user.getLocCountry());
			query.setParameter(1, user.getLocState());
			query.setParameter(2, user.getLocStreet());
			query.setParameter(3, user.getLocCity());
			query.setParameter(4, user.getLocPin());
			query.setParameter(5, user.getLocLat());
			query.setParameter(6, user.getLocLang());
			query.setParameter(7, user.getUserId());

			i = query.executeUpdate();
			tx.commit();
			
			log.info("User's Location details has been created successfully");

		} catch (Exception ex) {
			log.error("There is a problem creating Location details");
			log.debug(ex);
			ex.printStackTrace();
		} 
		
		return i;
	}

	public String getFriendNames(int friends_id) {
		
		String friendnames = "";
		String queryString = "select fullname from User as user where user.userId = ?";
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, friends_id);
			Object obj = query.uniqueResult();
			session.getTransaction().commit();
			
			friendnames = obj.toString();

		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return friendnames;
	}

	public void sortList(ArrayList myArrayList)
	{
		Collections.sort(myArrayList, new Comparator() {
			public int compare(Object o1, Object o2) {
				
				int result=0;
				String value1 = (String)((List<String>) o1).get(0);
				String value2 = (String)((List<String>) o2).get(0);
				
				result=value1.compareToIgnoreCase(value2);

				return result;
			}
		});
	}
	
	public Hashtable<String, List<String>> getFriendsNames_Ids(String location,
			int userId) {
			
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		
		Hashtable<String, List<String>> friendnames_ids = new Hashtable<String, List<String>>();
		String city = location.split(",")[0];
		String profile_path = "profile_page.jsp";

		// Modified by Rupal Kathiriya to get meetin friends by location wise
		// and not twice shown if trip is added with same living location
		//String queryString ="select a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from User a,Friends b where (a.userId=b.userId1 and b.userId2=? and b.status='Approve'and a.locCity=?) or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve' and a.locCity =?)";
		//String queryString ="select a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from User a,Friends b where (a.userId=b.userId1 and b.userId2=? and b.status='Approve'and a.locCity like concat(?, '%')) or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve' and a.locCity like concat(?,'%'))";
		
		//query by Rupal Kathiriya
		String queryString = "select a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from User a,Friends b, Trips c where a.userId NOT IN " +
				"(SELECT userId FROM Trips WHERE (from_date <=CURDATE() AND to_date >=CURDATE() OR from_date >= CURDATE()) AND " +
				"(from_date >=CURDATE() AND to_date <=CURDATE() OR from_date <= CURDATE())) AND((a.userId=b.userId1 and b.userId2=? and" +
			" b.status='Approve'and a.locCity like concat(?, '%')) or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve'" +
				" and a.locCity like concat(?,'%')))";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, location);
			query.setParameter(2, userId);
			query.setParameter(3, location);
			ScrollableResults obj = query.scroll();
						
			while (obj.next()) {
				List<String> friend_info = new ArrayList<String>();
				friend_info.add(obj.getString(1).toString());
				friend_info.add(profile_path + "?id="+ String.valueOf(obj.getInteger(0)));
				friend_info.add("images/meetin_icon.png");
				friend_info.add(obj.getString(2) == null ? "" : obj.getString(2));
				friend_info.add(obj.getString(3) == null ? "" : obj.getString(3));
				friend_info.add(""); // empty value
				String imageUrl = ((obj.getString(4) !=null && !(obj.getString(4).equals(""))) ? "profileimage/"+obj.getString(4) : (obj.getString(5).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png"));
				friend_info.add(imageUrl); // meetin user's image Url
				friend_info.add(obj.getString(5)); // meetin user's gender
				friendnames_ids.put(String.valueOf(obj.getInteger(0)), friend_info);
			}

			session.getTransaction().commit();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return friendnames_ids;
	}
	
	public Hashtable<String, List<String>> getFriendsNames_Id(String location, int userId, String startDate, String endDate) {
			
				
		Hashtable<String, List<String>> friendnames_ids = new Hashtable<String, List<String>>();
		String city = location.split(",")[0];
		String profile_path = "profile_page.jsp";
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
					
		String queryString = "select a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from User a, Friends b where " +
							" a.userId NOT IN (select userId from  Trips where "
				 				+" (fromDate between ? and ?) or (toDate between ? and ?) or (? between fromDate and toDate) or (? between fromDate and toDate)) and ((a.userId=b.userId1 and b.userId2=? and b.status='Approve' and a.locCity like concat(?,'%')) " 
				 				+" or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve' and a.locCity like concat(?,'%')))";
		try
		{
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);

			query.setParameter(0, sdf1.parse(sdf1.format(sdf.parse(startDate))));
			query.setParameter(1, sdf1.parse(sdf1.format(sdf.parse(endDate))));
			query.setParameter(2, sdf1.parse(sdf1.format(sdf.parse(startDate))));
			query.setParameter(3, sdf1.parse(sdf1.format(sdf.parse(endDate))));
			query.setParameter(4, sdf1.parse(sdf1.format(sdf.parse(startDate))));
			query.setParameter(5, sdf1.parse(sdf1.format(sdf.parse(endDate))));
			query.setParameter(6, userId);
			query.setParameter(7, location);
			query.setParameter(8, userId);
			query.setParameter(9, location);
						
			ScrollableResults obj = query.scroll();
						
			while (obj.next()) {
				List<String> friend_info = new ArrayList<String>();
				friend_info.add(obj.getString(1).toString());
				friend_info.add(profile_path + "?id="+ String.valueOf(obj.getInteger(0)));
				friend_info.add("images/meetin_icon.png");
				friend_info.add(obj.getString(2) == null ? "" : obj.getString(2));
				friend_info.add(obj.getString(3) == null ? "" : obj.getString(3));
				friend_info.add(""); // empty value
				String imageUrl = ((obj.getString(4) !=null && !(obj.getString(4).equals(""))) ? "profileimage/"+obj.getString(4) : (obj.getString(5).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png"));
				friend_info.add(imageUrl); // meetin user's image Url
				friend_info.add(obj.getString(5)); // meetin user's gender
				friendnames_ids.put(String.valueOf(obj.getInteger(0)), friend_info);
			}

			session.getTransaction().commit();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return friendnames_ids;
	}
	
	/** Author Vasim Saiyad */
	/** This method will check wheather the email is already registerd or not */

	public boolean isEmailRegistered(String email) 
	{

		boolean registered = false;
		log.info("Inside Email Existance Check");
		String queryString = "select count(*) from User as user where user.email=?";
		Long countResult = null;
		
		try 
		{
			log.info("Checking the email existance.....");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, email);
			countResult = (Long) query.uniqueResult();
			session.getTransaction().commit();
			
			if (countResult != null && countResult.intValue() > 0) {
				registered = true;
				log.info(email + " is already exist");
			} else {
				log.info(email + " is not exist");
			}
			
		} 
		catch (Exception ex)
		{
			log.error("There is a problem checking email existance");
			log.debug(ex);
		}
		
		return registered;
	}

	/** This method will check wheather the userName is already registerd or not */
	public boolean isUserNameRegistered(String name, int userId) {
		
		boolean registered = false;
		log.info("Inside User Name Existance Check");
		String queryString = "select count(*) from User as user where user.username=? and user.userId <> ?";
		Long countResult = null;
		try 
		{	
			log.info("Checking the user name existance.....");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, name);
			query.setParameter(1, userId);
			countResult = (Long) query.uniqueResult();
			session.getTransaction().commit();
			
			if (countResult != null && countResult.intValue() > 0) {
				registered = true;
				log.info(name + " is already exist");
			} else {
				log.info(name + " is not exist");
			}

		} catch (Exception ex) {
			log.error("There is a problem checking username existance");
			log.debug(ex);
		} 

		return registered;
	}

	/** Author Vasim Saiyad */
	/** This is the method user to change the user password */
	public int changeUserPassword(int userId, String oldpassword, String newpassword) 
	{
	
		log.info("Inside User change password");
		int resultId = 0;
		String queryString = "update User set password=? where password=? and userId=?";
		try {

			log.info("Trying to change the user password....");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, new UserLoginDAO().encrypt(newpassword));
			query.setParameter(1, new UserLoginDAO().encrypt(oldpassword));
			query.setParameter(2, userId);
			resultId = query.executeUpdate();
			tx.commit();
			
			if (resultId > 0) {
				log.info("User's password has been changed successfully");
			} else {
				log.info("User has attempted invalid oldpassword");
			}

		} catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in changing user password");
			ex.printStackTrace();
		}
				
		return resultId;
	}

	
	public int changeUserPasswordAdmin(String username,String oldpassword, String newpassword) 
	{
		
		ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
 		String url = resource.getString("jdbc.connectionValue").trim();
 		String driver = resource.getString("jdbc.driverClass").trim();
 		String userName = resource.getString("jdbc.database.username").trim();
 		String password = resource.getString("jdbc.database.password").trim();
		
 		int resultId = 0;
		try {
				
			Class.forName(driver).newInstance();
			Connection con = null;		
			con = DriverManager.getConnection(url,userName,password);
			String query ="update admin set password=? where password=? and username=?";
			
			PreparedStatement statement = con.prepareStatement(query);
			statement.setString(1,newpassword);
			statement.setString(2,oldpassword);
			statement.setString(3,username);
			resultId = statement.executeUpdate();
			
			System.out.println("result id *** "+resultId);
			
		} catch (Exception e) {
			System.out.println("Exception occured " +e); 
		}
							
		return resultId;
	}
	

	
	
	
	public int getuserId(String username) {

		log.info("Get user id ....");
		List<User> result = null;
		int userid = 0;
		String queryString = "from User as user where user.username=?";
		try 
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, username);
			result = query.list();
			session.getTransaction().commit();
			
			for (User u : result) {
				userid = u.getUserId();
			}
		} catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
				
		return userid;

	}

	public String getUserLocationByCityState(int userId) 
	{
	
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		
		String queryString = "select user.locCity, user.locState from User as user where user.userId=?";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			
			Object[] obj = (Object[]) query.uniqueResult();
			
			session.getTransaction().commit();
			
			if (obj[0] != null && !obj[0].toString().equals("") && obj[1] != null
					&& !obj[1].toString().equals(""))
				return obj[0].toString() + ", " + obj[1].toString();
			else
				return "";
			
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
	
		return "";
}
	/*
	 * public static void main(String[] args) { System.out.print(new
	 * UserAccountDAO().getuserId("Lokesh Pareek")); }
	 */
	public boolean isEmailRegistered1(String email) {
		
		boolean registered = false;
		log.info("Inside Email Existance Check");
		String queryString = "select count(*) from User as user where user.email=?";
		Long countResult = null;
		try 
		{
			log.info("Checking the email existance.....");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, email);
			countResult = (Long) query.uniqueResult();
			session.getTransaction().commit();
			
			if (countResult != null && countResult.intValue() > 0) {
				//System.out.println("inside if case");
				registered = true;
				log.info(email + " is already exist");
			} else {
				//System.out.println("inside else case");
				log.info(email + " is not exist");
			}
		} 
		catch (Exception ex) 
		{
			log.error("There is a problem checking email existance");
			log.debug(ex);
		} 
		
		return registered;
	}


	
	//method created for advance search for finding friends when searching with location only
	//user must get friends with trip on that location 
	//public Hashtable<String, List<String>> getFriendTripLocation(String location,int userId) {

	public Hashtable<String, List<String>> getFriendTripLocation(String location,int userId) {
		
		//System.out.println("userAccountDAO .java --------- getFriendTripLocation methdo called");
		
		Hashtable<String, List<String>> friendnames_ids = new Hashtable<String, List<String>>();
		String city = location.split(",")[0];
		
//		String queryString =
			//"select distinct a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from Trips t,User a,Friends b where "+
//	" a.userId IN ( select distinct t.userId from  Trips t,User a,Friends b where ((a.userId = b.userId1 AND b.userId2= " + userId+ " AND b.status ='Approve') "+  
//	" OR (a.userId = b.userId2 AND b.userId1 = "+userId+" AND b.status = 'Approve')) AND CURDATE() < t.toDate AND t.destination LIKE '"+city+"%')";
		
		
		try
		{
			String queryString ="SELECT  distinct a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender FROM User a WHERE a.userId IN (" +
			"		SELECT t.userId FROM Trips t WHERE t.destination LIKE '%"+city+"%' AND CURDATE() < t.toDate AND t.userId IN(" +
				"		SELECT DISTINCT u.userId FROM Friends b,User u , Trips  t WHERE" +
				" ((u.userId = b.userId1 AND  b.userId2 ="+userId+" AND b.status ='Approve') OR " +
				"(u.userId = b.userId2 AND b.userId1 ="+userId+" AND b.status = 'Approve'))))";
		
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Query query = session.createQuery(queryString);
		ScrollableResults obj = query.scroll();
				
		String profile_path = "profile_page.jsp";
		
		while (obj.next()) 
		{
		

			List<String> friend_info = new ArrayList<String>();

			friend_info.add(obj.getString(1).toString());

			friend_info.add(profile_path + "?id="+ String.valueOf(obj.getInteger(0)));
			friend_info.add("images/meetin_icon.png");
			friend_info.add(obj.getString(2).toString());
			friend_info.add(obj.getString(3).toString());
			friend_info.add(""); // empty value
			friend_info.add(obj.getString(4).toString());
			friend_info.add(obj.getString(5).toString());
			friendnames_ids.put(String.valueOf(obj.getInteger(0)), friend_info);
		}
		
		session.getTransaction().commit();
		
		}catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
			
		}
		
		return friendnames_ids;
	}

	
	public Hashtable<String, List<String>> getFriendsNames_Ids1(String location,
			int userId) {

		
		Hashtable<String, List<String>> friendnames_ids = new Hashtable<String, List<String>>();
		String city = location.split(",")[0];
		
		String profile_path = "profile_page.jsp";

		try
		{	
		
			// Modified by Rupal Kathiriya to get meetin friends by location wise
			// and not twice shown if trip is added with same living location
			//String queryString ="select a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from User a,Friends b where (a.userId=b.userId1 and b.userId2=? and b.status='Approve'and a.locCity=?) or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve' and a.locCity =?)";
			//String queryString ="select a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from User a,Friends b where (a.userId=b.userId1 and b.userId2=? and b.status='Approve'and a.locCity like concat(?, '%')) or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve' and a.locCity like concat(?,'%'))";
		
		//query by Rupal Kathiriya
		String queryString = "select a.userId,a.fullname,a.locLat,a.locLang,a.image,a.gender from User a,Friends b, Trips c where a.userId NOT IN " +
				"(SELECT userId FROM Trips WHERE  (fromDate<=CURDATE() OR toDate=CURDATE())) AND((a.userId=b.userId1 and b.userId2=? and" +
			" b.status='Approve'and a.locCity like concat(?, '%')) or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve'" +
				" and a.locCity like concat(?,'%')))";
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		Query query = session.createQuery(queryString);
		query.setParameter(0, userId);
		query.setParameter(1, location);
		query.setParameter(2, userId);
		query.setParameter(3, location);
		ScrollableResults obj = query.scroll();
				
		while (obj.next()) {
			
			List<String> friend_info = new ArrayList<String>();
			friend_info.add(obj.getString(1).toString());
			
			friend_info.add(profile_path + "?id="+ String.valueOf(obj.getInteger(0)));
			friend_info.add("images/meetin_icon.png");
			friend_info.add(obj.getString(2).toString()); // meetin user's
															// latitude 4
			friend_info.add(obj.getString(3).toString()); // meetin user's
															// langitude 5
			friend_info.add(""); // empty value
			friend_info.add(obj.getString(4)); // meetin user's image name
			friend_info.add(obj.getString(5)); // meetin user's gender
			friendnames_ids.put(String.valueOf(obj.getInteger(0)), friend_info);

		}
		
		session.getTransaction().commit();
		
		}catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
		
		return friendnames_ids;
	}

	
//This method return email ids of the meetin friends with base location 
	
	
	public List getFriendEmailIdsOnBaseLocation(String location,int userId,String startDate, String endDate)  throws Exception
	{
		
		Hashtable<String, List<String>> friendnames_ids = new Hashtable<String, List<String>>();
		String city = location.split(",")[0];
		
		String profile_path = "profile_page.jsp";

				
		SimpleDateFormat format = new SimpleDateFormat("MMM dd,yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");

		//code done for converting start date 
		Date sdate = format.parse(startDate);
		
		//code done for converting end date
		Date edate =format.parse(endDate);
		String enddate = sdf1.format(edate);
		Date eddate = sdf1.parse(enddate);
		
		String queryString = "select distinct a.userId,a.email from User a,Friends b, Trips c where a.eventAlert ='1' and  a.userId NOT IN " +
				"(SELECT userId FROM Trips WHERE  '"+sdf1.format(sdate)+"'=CURDATE() OR '"+sdf1.format(edate)+"'=CURDATE()) AND((a.userId=b.userId1 and b.userId2=? and" +
			" b.status='Approve'and a.locCity like concat(?, '%')) or (a.userId=b.userId2 and b.userId1=? and b.status= 'Approve'" +
				" and a.locCity like concat(?,'%')))";
	
		
		List list = new ArrayList<String>();
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, location);
			query.setParameter(2, userId);
			query.setParameter(3, location);
		
			ScrollableResults obj = query.scroll();
						
			while(obj.next())
			{
				list.add((String)obj.getString(1));
			}
			
			session.getTransaction().commit();
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
					
		return list;

	}
	
	public List getFriendEmailIdsOnTrip(String location,int userId)  throws Exception
	{
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String friend_status ="Approve";
		String profile_path ="profile_page.jsp";
		List list = null;
		
		
		String queryString ="select distinct u.email from  Trips p, Trips t, User u where u.eventAlert ='1' and  p.userId = ?"
	 	+" and ( p.destination like concat('%',?,'%') or ? like concat('%', p.destination, '%'))"
	 	+" and ( p.fromDate <=? and p.toDate >=? or p.fromDate >= ?)"
	 	+" and ((( p.fromDate between t.fromDate and t.toDate and ( p.destination like concat('%', t.destination, '%') or t.destination like concat('%', p.destination, '%')))"
	 	+" or ( t.fromDate between p.fromDate and p.toDate and ( p.destination like concat('%', t.destination, '%') OR t.destination like concat('%', p.destination, '%')) )) and ( t.fromDate <=? AND t.toDate >=? or t.fromDate >= ? ))"
	 	+" and (t.userId in (select userId1 from Friends where userId2 = ? and status = ?) or t.userId in(select userId2 from Friends where userId1 =? and status = ? ))"
	 	+" and t.userId=u.userId";
		
		
		try
		{
			log.info("Trying to user's location on upcoming date.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
		
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, location);
		    query.setParameter(2, location);
		    query.setParameter(3, sdf.parse(sdf.format(new Date())));
		    query.setParameter(4, sdf.parse(sdf.format(new Date())));
		    query.setParameter(5, sdf.parse(sdf.format(new Date())));
		    query.setParameter(6, sdf.parse(sdf.format(new Date())));		    
		    query.setParameter(7, sdf.parse(sdf.format(new Date())));
		    query.setParameter(8, sdf.parse(sdf.format(new Date())));
		    query.setParameter(9, userId);
		    query.setParameter(10, friend_status);
		    query.setParameter(11, userId);
		    query.setParameter(12, friend_status);
		    list = query.list();
		    session.getTransaction().commit();
		    
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
		
		return list;
	}
	
	
	//created by Dharam chag
	//method to get all user id from database used during monthly alert
	public void getUsers()
	{
		String QueryString = "select a.userId,a.email,a.locCity,a.monthlyalert from User as a order by a.userId";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(QueryString);
			List userlist = query.list();
			int k=0;
			
			while(k< userlist.size())
			{
				Object [] obj = (Object[])userlist.get(k);
				
				System.out.println("user id value is "+ (Integer)obj[0]);
				System.out.println("user values "+(Boolean)obj[3]);
				
				if((Boolean)obj[3] == false)
				{
					k++;
					continue;
				}
				
				
				
				Hashtable< String,List<String>> friendlist = new Hashtable<String, List<String>>();
				
				String table ="<br><br><table border='0' align='center' cellpadding='0' cellspacing='0' width='500px' style='border-left:solid 1px #bbbbbb; border-top:solid 1px #bbbbbb;'>";
				table = table + "<tr>	<td align='left' valign='top'>";
			//	table = table +"<table border='0' cellpadding='0' cellspacing='0' width='600px' style='border-bottom:solid 1px #bbbbbb;'>";
				table = table + "<tr><th align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#393939; color:#fff; font-size:14px; font-weight:bold; padding:5px 10px; font-family:arial;'> Destination </th>";
				table = table + "<th align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#393939; color:#fff; font-size:14px; font-weight:bold; padding:5px 10px; font-family:arial;'> Travel Dates (mm/dd/yy)</th>";
				//table = table + "<td align='left' valign='top' width='18%'> to Date<td>";
				table = table + "<th align='left' valign='top' width='24%' style='border-right:solid 1px #bbbbbb; background:#393939; color:#fff; font-size:14px; font-weight:bold; padding:5px 10px; font-family:arial;'> Friends list</th>";
				table = table + "</tr>";
				//table = table + "</table>";
				String checkString ="";
				//getting friends from baselocation 
				Hashtable< String,List<String>> friendsAtBaseLocation = friendsAtBaseLocation((String)obj[2],(Integer)obj[0]);
				ArrayList friendsatBaseLocation = new ArrayList(friendsAtBaseLocation.values());
				if(friendsatBaseLocation != null && friendsatBaseLocation.size() > 0)
				{
					for (int i = 0; i < friendsatBaseLocation.size(); i++) {
						List list1=new ArrayList();
						list1=(List) friendsatBaseLocation.get(i);
				//		table = table+"<table border='0'  cellpadding='0' cellspacing='0' width='600px' style='border-bottom:solid 1px #bbbbbb;'>";
						for (int j = 0; j < list1.size(); j++) 
						{
							SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
							
							int ch = (Integer)list1.get(0);
							String socialid = "";
							switch (ch) {
							case 1:
									socialid ="Facebook";
								break;
							case 2:
								socialid ="Linkedin";
								break;	
							case 3:
								socialid ="Gmail";
								break;			
							case 4:
								socialid ="Twitter";
								break;		
							case 5:
								socialid ="meetIn";
								break;		
							default:
								break;
							}
							table=table+"<tr>";
							if(checkString.equalsIgnoreCase((String)list1.get(2)))
							{
								table=table+"<td align='left' valign='top' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>&nbsp; </td>";
								table=table+"<td align='left' valign='top' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>&nbsp; </td>";
								table=table+"<td align='left' valign='top' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>" + socialid +" : " +list1.get(1) +"</td>";
							}
							else
							{
								table=table+"<td align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>" +list1.get(2) +"</td>";
								table=table+"<td align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'> Default Location </td>";
								table=table+"<td align='left' valign='top' width='24%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>" + socialid +" : " +list1.get(1)+"</td>";
							}
							table=table+"</tr>"; 
							checkString =(String)list1.get(2);
							list1.clear();
							
						}
						//table= table + "</table>";
					}
				}
				
				
				//getting friends  list from trips 
				
				Hashtable< String,List<String>> friendlist1 = getUserTrips((Integer)obj[0],(String)obj[2],friendlist);
				
				ArrayList friends = new ArrayList(friendlist1.values());
			
				
				if(friends != null && friends.size() > 0)
				{
					for (int i = 0; i < friends.size(); i++)
					{
						List list1=new ArrayList();
						list1=(List) friends.get(i);
					//	table = table +"<table border='0' cellpadding='0' cellspacing='0' width='600px' style='border-bottom:solid 1px #bbbbbb;'>";	
						for (int j = 0; j < list1.size(); j++) 
						{
							SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
							Date fromdate = (Date)list1.get(3);
							Date todate = (Date)list1.get(4);
							
							int ch = (Integer)list1.get(0);
							String socialid = "";
							switch (ch) {
							case 1:
									socialid ="Facebook";
								break;
							case 2:
								socialid ="Linkedin";
								break;	
							case 3:
								socialid ="Gmail";
								break;			
							case 4:
								socialid ="Twitter";
								break;		
							case 5:
								socialid ="meetIn";
								break;		
							default:
								break;
							}
							table=table+"<tr> ";
							if(checkString.equalsIgnoreCase((String)list1.get(2)))
							{
								table=table+"<td align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>&nbsp; </td>";
								table=table+"<td align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>&nbsp; </td>";
								table=table+"<td align='left' valign='top' width='24%'style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>" + socialid +" : " +list1.get(1) +"</td>";
							}
							else
							{
								table=table+"<td align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>" +list1.get(2) +"</td>";
								table=table+"<td align='left' valign='top' width='38%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>" +sdf.format(fromdate) + "  to  "+sdf.format(todate)+"</td>";
								table=table+"<td align='left' valign='top' width='24%' style='border-right:solid 1px #bbbbbb; background:#eee; color:#000; font-size:12px; font-weight:normal; padding:5px 10px; font-family:arial;'>" + socialid +" : " +list1.get(1)+"</td>";
							}
							table=table+"</tr>"; 
							checkString =(String)list1.get(2);
							list1.clear();
							
						}
					//	table = table +"</table>";
					}
				}
				
				table=table+"</td></tr></table><br><br>";
				//System.out.println(""+table);
				//mailer part
				String path ="http://www.mymeetin.com";
				String bannar =  path + "/images/banner.jpg";
				String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
				//String htmlmessage ="";
			//	htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>";
				htmlmessage = htmlmessage + table ;
				//htmlmessage = htmlmessage +"</table></td>  </tr>";
				String facebookimage = path + "/images/fb_icon.png";
				String twitterimage =  path + "/images/tw_icon.png";
				String androidimage =  path + "/images/android_icon.png";
				String iphoneimage =   path + "/images/iphone-icon.png";
						
			htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
			

			//	System.out.println("mail id "+(String)obj[1]);
			//	new InviteFriends().postMail((String)obj[1],"meetIn: meet your friend!!!", htmlmessage,"");

			//	System.out.println("mail id "+(String)obj[1]);
				
				//new InviteFriends().postMail("dharamchag88@gmail.com","meetIn: meet your friend!!!", htmlmessage,"");
				new InviteFriends().postMail((String)obj[1],"meetIn: meet your friend!!!", htmlmessage,"");

				k++;
			}
				
			//session.getTransaction().commit();
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
	}
	
	
	public Hashtable< String,List<String>> friendsAtBaseLocation(String baselocation,int userId)
	{
		
		Hashtable< String,List<String>> friendlist = new Hashtable<String, List<String>>();
		List finallist = new ArrayList<String>();
		//socialnetwork friends 
		List list =	getSocialNetworkFriendsCount(userId,baselocation);
		int i=0;
		int cnt = 100;
		while(i<list.size())
		{
			Object object[] = (Object[])list.get(i);
			List finalList = new ArrayList<String>();
			finalList.add((Integer)object[0]);  //socialid
			finalList.add((Long)object[1]);     //count 
			finalList.add(baselocation);   //location
			finalList.add("");    //date
			finalList.add("");    //date
			friendlist.put(String.valueOf(cnt), finalList);
			i++;
			++cnt;
		}
		
		//meetin friends 
		List friendsontrip = getFriendsonFutureTrip(baselocation, userId);
		List friendsatbaselocation = getfriendsonbaselocation(baselocation,userId);
		
		int size = 0;
		if(friendsontrip.size() > 0 && friendsontrip != null)
		{
			size = friendsontrip.size();
		}
		if(friendsatbaselocation.size() > 0 && friendsatbaselocation != null)
		{
			size = friendsatbaselocation.size();
		}
		
		finallist.add(5);						//socialid
		finallist.add(size);					//size of friends
		finallist.add(baselocation);   //location
		finallist.add("");  //date
		finallist.add("");  //date
		friendlist.put(String.valueOf(cnt), finallist);
		
		return friendlist;
		
	}
	
	
	
	
	
	
	
	//Created by : Dharam
	//method to get user trips used during monthly alert
	public Hashtable< String,List<String>> getUserTrips (int userId,String baselocation,Hashtable<String,List<String>> friendlist)
	{
		String QueryString = "select t.userId,t.destination,t.toDate,t.fromDate from Trips as t where t.userId = "+userId+" and toDate >= CURDATE()" ;
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(QueryString);
			List tripList = query.list();	
			String location ="";
			int j=0;
			int cnt = 0;
			while(j < tripList.size())
			{
				Object object1[] = (Object[])tripList.get(j);
				
				//location split done with ,(comma)
				 location = ((String)object1[1]).split(",")[0];
				
				//getting friends from socialnetworking sites with location and date
				List list =	getSocialNetworkFriendsCount(userId,location);
				int i=0;
				while(i<list.size())
				{
					Object object[] = (Object[])list.get(i);
					List finalList = new ArrayList<String>();
					finalList.add((Integer)object[0]);  //socialid
					finalList.add((Long)object[1]);     //count 
					finalList.add((String) object1[1]);   //location
					finalList.add((Date)object1[3]);    //date
					finalList.add((Date)object1[2]);    //date
					friendlist.put(String.valueOf(cnt), finalList);
					i++;
					++cnt;
				}
				
				//get meetin friends count
				List list1 = getfriendsonbaselocation(location, userId);
				List getFriendsonFutureTrip = getFriendsonFutureTrip(location,userId);
				int size = 0;
				
				if(list1.size() > 0 && list1 != null)
				{
					size = list1.size();
				}
				if(getFriendsonFutureTrip.size() > 0 && getFriendsonFutureTrip != null)
				{
					size = getFriendsonFutureTrip.size();
				}
				List finallist = new ArrayList<String>();
				finallist.add(5);						//socialid
				finallist.add(size);					//size of friends
				finallist.add((String) object1[1]);   //location
				finallist.add((Date)object1[3]);  //date
				finallist.add((Date)object1[2]);  //date
				friendlist.put(String.valueOf(cnt), finallist);
				
				++cnt;
				
				
				j++;
				//getFriendonFutureTrip(obj.getString(1), obj.getInteger(0),emailId);
			}
			
		}
		catch (Exception ex) {
			log.debug(ex);
			ex.printStackTrace();
		}
		return friendlist;
	}
	
	//this method is used to get count for social network friends based on location
	public List getSocialNetworkFriendsCount(int userid,String location)
	{
		String queryString = "select socialId,count(*) from SocialNetworkDummy where userId = "+userid + " and location like '%"+location+"%' GROUP BY socialId";
		List resultList = null;
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
		    resultList = query.list();
		    session.getTransaction().commit();
		}
		catch(Exception ex)
		{
			log.debug(ex);
		}
		
		return resultList;
	}
	public static void main(String args[])
	{
		new UserAccountDAO().getUsers();
		
	}
	
	public List getFriendsonFutureTrip(String location,int userId)
	{
		Format dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date =  dateFormat.format(new Date());
		String QueryString ="select u.fullname,t.fromDate,t.toDate from  Trips p, Trips t, User u where u.monthlyalert ='1' and p.userId = "+userId
	 	+" and ( p.destination like concat('%','"+location+"','%') or '"+location+"' like concat('%', p.destination, '%'))"
	 	+" and ( p.fromDate <='"+date+"' and p.toDate >='"+date+"' or p.fromDate >= '"+date+"')"
+" and ((( p.fromDate between t.fromDate and t.toDate and ( p.destination like concat('%', t.destination, '%') or" +
" t.destination like concat('%', p.destination, '%'))) or ( t.fromDate between p.fromDate and p.toDate and" +
" ( p.destination like concat('%', t.destination, '%') OR t.destination like concat('%', p.destination, '%')) )) and " +
"( t.fromDate <='"+date+"' AND t.toDate >='"+date+"' or t.fromDate >= '"+date+"' )) and (t.userId in (select userId1 from Friends where userId2 ="+userId+"  and status = 'Approve') " +
"or t.userId in(select userId2 from Friends where userId1 ="+userId+" and status = 'Approve' )) and t.userId=u.userId";
	
		List list =null;
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(QueryString);
		
			 list = query.list();
			session.getTransaction().commit();
			
			return list;
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		
		return list;
	
	}
	
	public void getFriendonFutureTrip(String location,int userId,String emailId)
	{
		//System.out.println("useraccountdao.java -----   get friend of future trip ");
		int location1 = location.indexOf(",");
		if(location1 != -1)
		{
	
				location = location.substring(0, location1);
		}
		
	
		Format dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date =  dateFormat.format(new Date());
		//String date =  dateFormat.format(addDays(new Date(), 15));
		
	
		
		String QueryString ="select u.fullname,t.fromDate,t.toDate from  Trips p, Trips t, User u where u.monthlyalert ='1' and p.userId = "+userId
			 	+" and ( p.destination like concat('%','"+location+"','%') or '"+location+"' like concat('%', p.destination, '%'))"
			 	+" and ( p.fromDate <='"+date+"' and p.toDate >='"+date+"' or p.fromDate >= '"+date+"')"
	+" and ((( p.fromDate between t.fromDate and t.toDate and ( p.destination like concat('%', t.destination, '%') or" +
		" t.destination like concat('%', p.destination, '%'))) or ( t.fromDate between p.fromDate and p.toDate and" +
		" ( p.destination like concat('%', t.destination, '%') OR t.destination like concat('%', p.destination, '%')) )) and " +
		"( t.fromDate <='"+date+"' AND t.toDate >='"+date+"' or t.fromDate >= '"+date+"' )) and (t.userId in (select userId1 from Friends where userId2 ="+userId+"  and status = 'Approve') " +
		"or t.userId in(select userId2 from Friends where userId1 ="+userId+" and status = 'Approve' )) and t.userId=u.userId";
		
		
		/*
		String QueryString ="SELECT DISTINCT a.userId FROM User a, Friends b, Trips t WHERE a.userId IN" +
		"(SELECT userId FROM Trips as t WHERE fromDate >= '"+date+ "' AND t.destination LIKE '%" +location
		+"%' ) AND	((a.userId=b.userId1 AND b.userId2= "+ userId+ " AND b.status='Approve' )" +
		" OR (a.userId=b.userId2 AND b.userId1="+userId+" AND b.status= 'Approve'))";
			*/
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(QueryString);
		
			List list = query.list();
			session.getTransaction().commit();

			
			
			String friendsname[] = new String[list.size()];
			String fromDate[] = new String [list.size()]; 
			String toDate[] = new String[list.size()];
		
		//message format 
			String htmlmessage = "<div style=\"width: 500px;\">";
			 htmlmessage += "<div style=\"background-color: rgb(255, 153, 0); padding: 5px 10px; color: rgb(255, 255, 255); font-family: 'Trebuchet MS'; font-size: 18px;\"><img src="
				+ " align=\"absmiddle\" hspace=\"5\"></img><strong>meetIn Friends at "+location+"</strong></div><br>";
			
			 String message = "";
		
			if(list.size() > 0)
			{
				//retrieving user's travel date
				
				String queryString = "select t.fromDate,t.toDate from Trips as t where userId = "+ userId;
				session.beginTransaction();
				Query query2 = session.createQuery(queryString);
				List list2 = query2.list();
				session.getTransaction().commit();
				
				Date utoDate = new Date();
				Date ufromDate = new Date();
				for(int j=0;j<list2.size();j++)
				{
					Object[] object = (Object[]) list2.get(j);
					ufromDate=(Date)object[0];
					utoDate = (Date)object[1];
					
				}
				message = "<span style='font-size:16px; font-weight:bold'>meetIn Friends on Trip at "+location+"</span><br><br>";
				message = message + "<table cellspacing=0;cellpading=0; style='border: 1px solid #d9d9d9; border-collapse:collapse;font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:14px;'> <tr> " +
				"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Friends Name </th> " +
				"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Destination </th> " +
				" <th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Date of Travel </th>" +
				"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Your Travel Dates  </th>" +
				"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> meetIn Dates  </th>" +
				"</tr>";
				
				
				/*message = message+ "<style type=text/css>	.tbl{}" +
						".tbl td{ padding:3px 5px; border: 1px solid #d9d9d9;}" +
						".tbl th{padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left}" +
						"</style>";
				*/
				for (int i = 0; i < list.size(); i++) 
				{
					Object[] object = (Object[]) list.get(i);
					friendsname[i] = (String)object[0];
					//fromDate[i] =(String)object[2].toString();
					//toDate[i]=(String)object[3].toString();
					
					message = message + "<tr> <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'>"+(String)object[0]+"</td>"; // friend fullname 
					message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'>"+location+"</td>"; //destination @ which travelling
					message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'>"+dateFormat.format(object[1])+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "+ dateFormat.format(object[2])+"</td>"; // to and from date Friend 
					message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'>"+dateFormat.format(ufromDate)+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "+ dateFormat.format(utoDate)+"</td>"; // to and from date of user
				
					Date d = (Date)object[1]; //friends from date
					Date meetin_fromDate = new Date();
					if(ufromDate.after(d))
					{
						meetin_fromDate = ufromDate;
					}
					else
					{
						meetin_fromDate = d;
						
					}
				
					Date d1 = (Date)object[2]; //friends to date
					Date meetin_toDate = new Date();
					if(utoDate.after(d1))
					{
						meetin_toDate = d1;
					
					}
					else{
						meetin_toDate = utoDate;
					
					}
					
					//	message = message + (String)object[0] + dateFormat.format(object[1]) + dateFormat.format(object[2]);
				
					message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'>"+dateFormat.format(meetin_fromDate)+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "+ dateFormat.format(meetin_toDate)+"</td></tr>"; // to and from date of user
				}
				
				message = message + "</table>";
				
			}
	
			
		List list2 = getfriendsonbaselocation(location, userId);
		
		if(list2.size() > 0)
		{
			message = message + "<br><br><span style='font-size:16px; font-weight:bold'>meetIn Friends at "+location+"</span>";
			message = message + "<br><br><table cellspacing=0;cellpading=0; style='border: 1px solid #d9d9d9; border-collapse:collapse;font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size:14px;'> <tr> " +
			"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Friends Name </th> " +
			"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Destination </th> " +
			/*" <th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Date of Travel </th>" +
			"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> Your Travel Dates  </th>" +
			"<th style='padding:3px 5px; background:#f3f3f3; border: 1px solid #d9d9d9; text-align:left'> meetIn Dates  </th>" +*/
			"</tr>";
			
			for (int j = 0; j < list2.size(); j++) 
			{
				Object[] object = (Object[]) list2.get(j);
				message = message + "<tr> <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'>"+(String)object[1]+"</td>"; // friend fullname 
				message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'>"+location+"</td>"; //destination @ which travelling
				/*message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'></td>"; // to and from date Friend 
				message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'></td>"; // to and from date of user
				message = message + " <td style=' padding:3px 5px; border: 1px solid #d9d9d9;'></td>"*/; // to and from date of user
				message = message + "</tr>";
			}
			message = message + "</table>";
		}
		
	
		if(list.size() >0 || list2.size() > 0)
		{
			try
			{
				new InviteFriends().postMail(emailId, "meetIn Friends at " + location,message ,"info@meetin.com");
			}
			catch (Exception e) {
				//System.out.println("Exception occured :: " +e );
			}
		}	
		
		
		//System.out.println("list size " + list.size());
		
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
		
	}

	public List getfriendsonbaselocation(String location,int userId)
	{
		Format dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		//String date =  dateFormat.format(addDays(new Date(), 15));
		String date =  dateFormat.format(new Date());
		
		String QueryString ="SELECT DISTINCT a.userId,a.fullname FROM User a, Friends b,Trips c WHERE a.userId NOT IN"+
		
		"(SELECT userId FROM Trips WHERE (fromDate = '"+date+"' OR toDate = '"+date+"')) AND ((a.userId =b.userId1 AND b.userId2 ="+userId+" AND "+
		" b.status = 'Approve' AND a.locCity LIKE concat('%','"+location+"', '%') OR " +
				" (a.userId = b.userId2  AND b.userId1 = "+userId+" AND b.status = 'Approve' "+
		" AND a.locCity LIKE concat('%','"+location+"','%'))))";
		
		/*
		SELECT DISTINCT a.user_id,a.fullname FROM mi_users a, mi_friends b,mi_trips c WHERE a.user_id NOT IN
		(SELECT user_id FROM mi_trips WHERE (from_date = CURDATE() OR to_date = CURDATE())) AND ((a.user_id =b.user_id1 AND b.user_id2 =2 AND
		b.status = "Approve" AND a.loc_city LIKE "%ahmedabad%") OR (a.user_id = b.user_id2  AND b.user_id1 = 2 AND b.status = "Approve"
		AND a.loc_city LIKE "%ahmedabad%"))*/
		List list = null;
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(QueryString);
			list = query.list();
			session.getTransaction().commit();
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in getting user id ");
			ex.printStackTrace();
		}
		
		return list;
		
			
	}
	
	public void updateUserScheduleFlagById(int userId, String scheduleFlag)
	{
		log.info("Inside the user social scheduler flag update");
		String queryString = "update User set scheduleFlag=? where userId=?";
		int resultId =0;
		try
		{
			log.info("Trying to update user social schedule flag");	
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, scheduleFlag);
			query.setParameter(1, userId);
			
			resultId = query.executeUpdate();
			tx.commit();
				
			if (resultId > 0) {
					log.info("User's social schedule flag has been updated successfully");
			} 
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in updating user's social schedule flag");
			ex.printStackTrace();
		}
	}
	public void updateAllUserScheduleFlag(String scheduleFlag)
	{
		log.info("Inside the all user social scheduler flag update");
		String queryString = "update User set scheduleFlag=?";
		int resultId =0;
		try
		{
			log.info("Trying to update all user social schedule flag");	
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, scheduleFlag);
			resultId = query.executeUpdate();
			tx.commit();
				
			if (resultId > 0) {
					log.info("All User's social schedule flag has been updated successfully");
			} 
		}
		catch (Exception ex) {
			log.debug(ex);
			log.error("There is a problem in updating all user's social schedule flag");
			ex.printStackTrace();
		}
	}
	
    public static Date addDays(Date date, int days)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); //minus number would decrement the days
        return cal.getTime();
    }
    
    
}

