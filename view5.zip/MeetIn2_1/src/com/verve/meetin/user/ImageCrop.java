package com.verve.meetin.user;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.*;
public class ImageCrop extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ImageCrop() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{

		//System.out.println("Image Crop.java --------   ");
		
		  boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		  
		  if (!isMultipart) 
		  {
			  
		  } 
		  else 
		  {
			
			  FileItemFactory factory = new DiskFileItemFactory();
			  ServletFileUpload upload = new ServletFileUpload(factory);
			  List items = null;

			  try {
				  	items = upload.parseRequest(request);
			
			  }
			  catch (FileUploadException e) 
			  {
				  e.printStackTrace();
			  }

			
			  
			  HttpSession session = request.getSession();
			  int x1 =0,x2=0 ;
			  int y1 =0 ,y2=0;
			
			  String filename,f;
			  int width=0,height=0;
			  Iterator itr = items.iterator();
			  while (itr.hasNext()) 
			  {
				  FileItem item = (FileItem) itr.next();
				  if (item.isFormField())
				  {
			
					  		String name = item.getFieldName();
					  		if(name.equals("x1"))
					  		{
					  			x1 = Integer.parseInt(item.getString());
					  			session.setAttribute("x1", x1);
					  		}
					  		if(name.equals("x2"))
					  		{
					  			x2 = Integer.parseInt(item.getString());
					  			session.setAttribute("x2", x2);
					  		}
					  		if(name.equals("y1"))
					  		{
					  			y1 = Integer.parseInt(item.getString());
					  			session.setAttribute("y1", y1);
					  		}
					  		if(name.equals("y2"))
					  		{
					  			y2 = Integer.parseInt(item.getString());
					  			session.setAttribute("y2", y2);
					  		}
					  		
					  		if(name.equals("f"))
					  		{
					  			f = item.getString();
					  		
					  			session.setAttribute("f",f);
					  		}
					  		
					  		if(name.equals("i"))
					  		{
					  			filename = item.getString();
					  		
					  			session.setAttribute("filename",filename);
					  		}
					  		if(name.equals("width"))
					  		{
					  			width = Integer.parseInt(item.getString());
					  		
					  			session.setAttribute("width",width);
					  		}
					  		if(name.equals("height"))
					  		{
					  			height = Integer.parseInt(item.getString());
					  		
					  			session.setAttribute("height",height);
					  		}
					  		
					  		String value = item.getString();
					  		
				  }
				  else 
				  {
					
					  	try
					  	{
					  		String itemName = item.getName();
					  		
					  		String reg = "[.*]";
					  		String replacingtext = "";
					
					  			
					  		Pattern pattern = Pattern.compile(reg);
					  		Matcher matcher = pattern.matcher(itemName);
					  		StringBuffer buffer = new StringBuffer();

					  		while (matcher.find()) 
					  		{
					  			matcher.appendReplacement(buffer, replacingtext);
					  		}
			  
					  		int IndexOf = itemName.indexOf("."); 
					  		String domainName = itemName.substring(IndexOf);
										  		
					  		String finalimage = buffer.toString()+domainName;
										  		
					  		session.setAttribute("finalimage",finalimage);

					  		
					  		String filePath =getServletContext().getRealPath("/")+"temp/"+finalimage;
			  
					  		item.write(new File(filePath));
				
			  				 } 
					  	catch (Exception e) 
					  	{
					  			e.printStackTrace();
					  	}
			 			 
				  }

			  }
		
			  getServletContext().getRequestDispatcher("/MyJsp1.jsp").forward(request, response);
	}
		
		
		
		
/////////////////////////////////////////////////////////////////////////////////////		
		
		//		  //System.out.println("servlet called --------------   ");
		
	//	int x1=Integer.parseInt(request.getParameter("x1"));
	//	int y1=Integer.parseInt(request.getParameter("y1"));
	//	int x2=Integer.parseInt(request.getParameter("x2"));
	//	int y2=Integer.parseInt(request.getParameter("y2"));

//		int height =Integer.parseInt(request.getParameter("height"));
///		int w =Integer.parseInt(request.getParameter("width"));
		



//		String imagename = request.getParameter("imagename");


//		String path = request.getContextPath();
//		String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";
//		String imagePath = basePath+imagename;							
//		InputStream input = new URL(imagePath).openStream();
//		BufferedImage outImage=ImageIO.read(input);
		
//		int rgb = 4;
			
//		BufferedImage resize = new BufferedImage(120,120, rgb);
//		Graphics2D g= resize.createGraphics();
		
//		g.drawImage(outImage, x1,y1,200,120, null);
		
		
		//String filePath =getServletContext().getRealPath("/")+imagename;
		


		
		//ImageIO.write(resize,request.getParameter("extension"),new File(filePath));
		
	//	HttpSession session = req.getSession();
	//	session.setAttribute("imagename",imagename);
		
		
		//getServletContext().getRequestDispatcher("/myprofile.jsp?action=aboutme").forward(req, res);

		
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*
		//System.out.println("servlet called -------  ");
		
		
		int x1=Integer.parseInt(req.getParameter("x1"));
		int y1=Integer.parseInt(req.getParameter("y1"));
		int x2=Integer.parseInt(req.getParameter("x2"));
		int y2=Integer.parseInt(req.getParameter("y2"));



		int height =Integer.parseInt(req.getParameter("height"));
		int w =Integer.parseInt(req.getParameter("width"));
		
		//System.out.println("Height is ----  " + height + "  width is ---  " + w);

		HttpSession session = req.getSession();
		//System.out.println(session.getAttribute("filepath"));
		String imagePath = session.getAttribute("filepath").toString();
		
		InputStream input = new URL(imagePath).openStream();
		BufferedImage outImage=ImageIO.read(input);
		int rgb = 4;
			
		BufferedImage resize = new BufferedImage(120,120, rgb);
		Graphics2D g= resize.createGraphics();
		
		g.drawImage(outImage, 0, 0,200,120, null);
			
		
		String filePath =getServletContext().getRealPath("/")+"profileimage/"+req.getParameter("imagename");
		//System.out.println("file path is -----  "  + filePath);
		
		String extension = req.getParameter("extension");
		//ImageIO.write(outImage,extension, new File(filePath));
		
		ImageIO.write(resize, req.getParameter("extension"), new File(filePath));	
		//System.out.println("extension name is  --- " + extension);
		//System.out.println("Height width of resize "+resize.getHeight() +  resize.getWidth()); 
		
		//ByteArrayOutputStream out=new ByteArrayOutputStream();

		
		//FileOutputStream fileOutStream = new FileOutputStream(new File(filePath));
		//ImageIO.write(resize,extension,fileOutStream );
	
//		String imagename = req.getParameter("imagename");
	//	//System.out.println("image name is ** ------------   "+imagename);
		
	//	session.setAttribute("imagename", req.getParameter("imagename"));
		
		 
		
		
		//ByteArrayOutputStream out=new ByteArrayOutputStream();
		//ImageIO.write(outImage,req.getParameter("f"), out);
		
	//	ImageIO.write(resize,req.getParameter("f"),new File(filePath));
		
	/*	res.setContentType("image/jpg");
		ServletOutputStream wrt=res.getOutputStream();
		
		wrt.write(out.toByteArray());
		wrt.flush();
		wrt.close();
		input.close();
		
		//out.close();
		*/
		
		//g.dispose();
		//getServletContext().getRequestDispatcher("/myprofile.jsp?action=aboutme").forward(req, res);	
		
	}


	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}





//String imagePath = basePath+imagename;
/*
String path = request.getContextPath();

String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/temp/"+finalimage;
	//System.out.println("base path " + basePath);
	InputStream input = new URL(basePath).openStream();
	BufferedImage outImage=ImageIO.read(input);
	
	int rgb = 4;
		
	BufferedImage resize = new BufferedImage(120,120, rgb);
	Graphics2D g= resize.createGraphics();
	
	g.drawImage(outImage, x1,y1,200,120, null);
	
	String filepath1 = getServletContext().getRealPath("/")+"profileimage/"+finalimage;
	
	File f = new File(filepath1);
	
	
	
	////System.out.println("extension is -----------------   "+req.getParameter("extension"));
	
	ImageIO.write(resize,extension,f);
*/				
//////////////////////////////////////////////////
/*  
File savedFile = new File(filePath);
item.write(savedFile);
out.println("<html>");
out.println("<body>");
out.println("<table><tr><td>");
out.println("<img src=temp/"+finalimage+">");
out.println("</td></tr></table>");
*/