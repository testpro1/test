package com.verve.meetin.user;

import java.util.*;
import javax.xml.bind.annotation.XmlRootElement;
import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;


/**
 * MiUsers entity. @author MyEclipse Persistence Tools
 */

@XmlRootElement
public class User extends ActionForm implements java.io.Serializable
{
	// Fields
    
	private Integer userId;
	private String fullname;
	private String email;
	private String password;
	private String password1;
	public String getPassword1() {
		return password1;
	}

	public void setPassword1(String password1) {
		this.password1 = password1;
	}


	private Date dob;
	private String image;
	private String aboutMe;
	private String company;
	private Boolean companyVisible=false;
	private String jobTitle;
	private Boolean jobVisible=false;
	private String industry;
	private String degreeCollege;
	private Boolean degreeVisible=false;
	private String locCountry;
	private String locState;
	private String locStreet;
	private String locCity;
	private String locPin;
	private String locLat;
	private String locLang;
	private String otherSpecify;
	private Date registerOn;
	private Date lastLogin;
    private FormFile imageFile;
    private String[] interest;
    private String birthdate;
    private Long resultcount;
    private String googleMarkerIcon;
    private String gender;
    private String userKey;
    private String username;
    private Boolean eventAlert = false;
    private Boolean monthlyalert = false;
    private String fwdurl;
    private String scheduleFlag;
    private String status;
    private Boolean helpAlert = true;
    
    public Boolean getHelpAlert() {
		return helpAlert;
	}

	public void setHelpAlert(Boolean helpAlert) {
		this.helpAlert = helpAlert;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	private String relationshipId;
    
    
    
    // Fields for change password

	public String getRelationshipId() {
		return relationshipId;
	}

	public void setRelationshipId(String relationshipId) {
		this.relationshipId = relationshipId;
	}

	public String getFwdurl() {
		return fwdurl;
	}

	public void setFwdurl(String fwdurl) {
		this.fwdurl = fwdurl;
	}

	public Boolean getEventAlert() {
		return eventAlert;
	}

	public void setEventAlert(Boolean eventAlert) {
		this.eventAlert = eventAlert;
	}

	public Boolean getMonthlyalert() {
		return monthlyalert;
	}

	public void setMonthlyalert(Boolean monthlyalert) {
		this.monthlyalert = monthlyalert;
	}

	private String oldpassword;
    private String newpassword;
    private String userId2;
	public String getUserId2() {
		return userId2;
	}

	public void setUserId2(String userId2) {
		this.userId2 = userId2;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String[] getInterest() {
		return interest;
	}

	public void setInterest(String[] interest) {
		this.interest = interest;
	}

	public FormFile getImageFile() {
		return imageFile;
	}

	public void setImageFile(FormFile imageFile) {
		this.imageFile = imageFile;
	}

	private String loginResult;


	public String getLoginResult() {
		return loginResult;
	}

	public void setLoginResult(String loginResult) {
		this.loginResult = loginResult;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	// Constructors

	/** default constructor */
	public User() {
	}

	
	
		/*public User(String fullname, String email,String password, Date dob, String locCountry, String locState,String locStreet,String locCity,String locPin,String locLat,String locLang, Date registerOn, String gender)  
		{
			
			this.fullname = fullname;
			this.email = email;
			this.password = password;
			this.dob = dob;
			this.locCountry =locCountry;
			this.locState =locState;
			this.locStreet =locStreet;
			this.locCity=locCity;
			this.locPin=locPin;
			this.locLat=locLat;
			this.locLang=locLang;
			this.registerOn = registerOn;
			this.gender = gender;
					
		}*/
	//code change by lokesh
	/** create registration constructor */
	public User(String fullname, String email,String password, Date dob, String locCity,String locLat,String locLang, Date registerOn, String gender)  
	{
		
		this.fullname = fullname;
		this.email = email;
		this.password = password;
		this.dob = dob;
		//this.locCountry =locCountry;
		//this.locState =locState;
		//this.locStreet =locStreet;
		this.locCity=locCity;
		//this.locPin=locPin;
		this.locLat=locLat;
		this.locLang=locLang;
		this.registerOn = registerOn;
		this.gender = gender;
		this.scheduleFlag = "Y";		
	}
	
	/** update registration constructor */
	
	public User(Integer userId, String image, String aboutMe, String company,Boolean companyVisible,
			String jobTitle, Boolean jobVisible, String industry, String degreeCollege,Boolean degreeVisible,String otherSpecify) {
		
	
		this.userId = userId;
		this.image = image;
		this.aboutMe = aboutMe;
		this.company = company;
		this.companyVisible=companyVisible;
		this.jobTitle = jobTitle;
		this.jobVisible=jobVisible;
		this.industry = industry;
		this.degreeCollege = degreeCollege;
		this.degreeVisible=degreeVisible;
		this.otherSpecify = otherSpecify;
				
	}
  
	/*
	 * Constructor is for Postlogin (profile)
	 */
	//commented by Rupal Kathiriya #864 to display interest, privacy setting with true status
	/*public User(Integer userId, String fullname, Date dob, String image, String aboutMe, String company,Boolean companyVisible,
			String jobTitle, Boolean jobVisible, String industry, String degreeCollege,Boolean degreeVisible,String otherSpecify, String gender, String username) {
		
	
		this.userId = userId;
		this.fullname = fullname;
		this.dob = dob;
		this.image = image;
		this.aboutMe = aboutMe;
		this.company = company;
		this.companyVisible=companyVisible;
		this.jobTitle = jobTitle;
		this.jobVisible=jobVisible;
		this.industry = industry;
		this.degreeCollege = degreeCollege;
		this.degreeVisible=degreeVisible;
		this.otherSpecify = otherSpecify;
		this.gender = gender;
		this.username = username;
	}*/
	//created by Rupal Kathiriya #864 to display interest, privacy setting with true status
	public User(Integer userId, String fullname, Date dob, String image, String aboutMe, String company,
			String jobTitle, String industry, String degreeCollege,String otherSpecify, String gender, String username) {
		
		this.userId = userId;
		this.fullname = fullname;
		this.dob = dob;
		this.image = image;
		this.aboutMe = aboutMe;
		this.company = company;
		this.jobTitle = jobTitle;
		this.industry = industry;
		this.degreeCollege = degreeCollege;
		this.otherSpecify = otherSpecify;
		this.gender = gender;
		this.username = username;
	}
	
	/** full constructor */
	//create by rupal Kathiriya to set image and user id for web service dated on 28 dec 2012
	public User(Integer userId, String image) {
			this.userId=userId;
			this.image=image;
	}
	//modified by rupal Kathiriya to remove image for web service dated on 28 dec 2012
	public User(Integer userId, String aboutMe, String company,Boolean companyVisible,
			String jobTitle, Boolean jobVisible, String industry, String degreeCollege,Boolean degreeVisible,String locCountry,String locState,String locStreet, String locCity,String locPin,String locLat, String locLang,String otherSpecify,String gender,Date dob) {
		
		this.userId = userId;
		this.aboutMe = aboutMe;
		this.company = company;
		this.companyVisible=companyVisible;
		this.jobTitle = jobTitle;
		this.jobVisible=jobVisible;
		this.industry = industry;
		this.degreeCollege = degreeCollege;
		this.degreeVisible=degreeVisible;
		this.locCountry=locCountry;
		this.locState=locState;
		this.locStreet=locStreet;
		this.locCity=locCity;
		this.locPin=locPin;
		this.locLat=locLat;
		this.locLang= locLang;
		this.otherSpecify = otherSpecify;
		this.gender=gender;
		this.dob = dob;
				
	}
	
	public User(Integer userId, String image, String aboutMe, String company,Boolean companyVisible,
			String jobTitle, Boolean jobVisible, String industry, String degreeCollege,Boolean degreeVisible,String locCountry,String locState,String locStreet, String locCity,String locPin,String locLat, String locLang,String otherSpecify,String gender,Date dob) {
		
	
		this.userId = userId;
		this.image = image;
		this.aboutMe = aboutMe;
		this.company = company;
		this.companyVisible=companyVisible;
		this.jobTitle = jobTitle;
		this.jobVisible=jobVisible;
		this.industry = industry;
		this.degreeCollege = degreeCollege;
		this.degreeVisible=degreeVisible;
		this.locCountry=locCountry;
		this.locState=locState;
		this.locStreet=locStreet;
		this.locCity=locCity;
		this.locPin=locPin;
		this.locLat=locLat;
		this.locLang= locLang;
		this.otherSpecify = otherSpecify;
		this.gender=gender;
		this.dob = dob;
				
	}
	
	/*public User(Integer userId, String image, String aboutMe, String company,Boolean companyVisible,
			String jobTitle, Boolean jobVisible, String industry, String degreeCollege,Boolean degreeVisible,String locCountry,String locState,String locStreet, String locCity,String locPin,String locLat, String locLang,String otherSpecify, String fullname) {
		
	
		this.userId = userId;
		this.fullname = fullname;
		//this.dob = dob;
		this.image = image;
		this.aboutMe = aboutMe;
		this.company = company;
		this.companyVisible=companyVisible;
		this.jobTitle = jobTitle;
		this.jobVisible=jobVisible;
		this.industry = industry;
		this.degreeCollege = degreeCollege;
		this.degreeVisible=degreeVisible;
		this.locCountry=locCountry;
		this.locState=locState;
		this.locStreet=locStreet;
		this.locCity=locCity;
		this.locPin=locPin;
		this.locLat=locLat;
		this.locLang= locLang;
		this.otherSpecify = otherSpecify;
				
	}*/
	// Property accessors

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getFullname() {
		return this.fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getAboutMe() {
		return this.aboutMe;
	}

	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public Boolean getCompanyVisible() {
		return this.companyVisible;
	}

	public void setCompanyVisible(Boolean companyVisible) {
		this.companyVisible = companyVisible;
	}

	public String getJobTitle() {
		return this.jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public Boolean getJobVisible() {
		return this.jobVisible;
	}

	public void setJobVisible(Boolean jobVisible) {
		this.jobVisible = jobVisible;
	}

	public String getIndustry() {
		return this.industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getDegreeCollege() {
		return this.degreeCollege;
	}

	public void setDegreeCollege(String degreeCollege) {
		this.degreeCollege = degreeCollege;
	}

	public Boolean getDegreeVisible() {
		return this.degreeVisible;
	}

	public void setDegreeVisible(Boolean degreeVisible) {
		this.degreeVisible = degreeVisible;
	}

	public String getLocCountry() {
		return this.locCountry;
	}

	public void setLocCountry(String locCountry) {
		this.locCountry = locCountry;
	}

	public String getLocState() {
		return this.locState;
	}

	public void setLocState(String locState) {
		this.locState = locState;
	}

	public String getLocStreet() {
		return this.locStreet;
	}

	public void setLocStreet(String locStreet) {
		this.locStreet = locStreet;
	}

	public String getLocCity() {
		return this.locCity;
	}

	public void setLocCity(String locCity) {
		this.locCity = locCity;
	}

	public String getLocPin() {
		return this.locPin;
	}

	public void setLocPin(String locPin) {
		this.locPin = locPin;
	}

	public String getLocLat() {
		return this.locLat;
	}

	public void setLocLat(String locLat) {
		this.locLat = locLat;
	}

	public String getLocLang() {
		return this.locLang;
	}

	public void setLocLang(String locLang) {
		this.locLang = locLang;
	}

	public String getOtherSpecify() {
		return this.otherSpecify;
	}

	public void setOtherSpecify(String otherSpecify) {
		this.otherSpecify = otherSpecify;
	}

	public Date getRegisterOn() {
		return this.registerOn;
	}

	public void setRegisterOn(Date registerOn) {
		this.registerOn = registerOn;
	}

	public Date getLastLogin() {
		return this.lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Long getResultcount() {
		return resultcount;
	}

	public void setResultcount(Long totalResult) {
		this.resultcount = totalResult;
	}

	public String getGoogleMarkerIcon() {
		return googleMarkerIcon;
	}

	public void setGoogleMarkerIcon(String googleMarkerIcon) {
		this.googleMarkerIcon = googleMarkerIcon;
	}

	public String getOldpassword() {
		return oldpassword;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getGender() {
		return gender;
	}
	
	public String getUserKey() {
		return userKey;
	}
	
	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public String getScheduleFlag() {
		return scheduleFlag;
	}

	public void setScheduleFlag(String scheduleFlag) {
		this.scheduleFlag = scheduleFlag;
	}
	
	
}