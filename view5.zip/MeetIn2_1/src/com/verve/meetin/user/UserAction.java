package com.verve.meetin.user;

 import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.upload.FormFile;

//import com.google.code.facebookapi.schema.UserInfo;
import com.sun.swing.internal.plaf.basic.resources.basic;

import com.verve.meetin.friend.Friends;
import com.verve.meetin.friend.FriendsDAO;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.interest.Interest;
import com.verve.meetin.interest.InterestDAO;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.Usernetworks;
import com.verve.meetin.network.peoplefinder.PeopleFinder;
import com.verve.meetin.network.peoplefinder.ScheduleSocialNetwork;
import com.verve.meetin.trip.TripsDAO;
import com.verve.meetin.mailer_template.*;

import java.io.*;


public class UserAction extends DispatchAction
{
	
	/*public ActionForward login(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{

		User user =(User)form;
		UserLoginDAO userDAO = new UserLoginDAO();
		String email = user.getEmail().toLowerCase();
		String encryptpassword = userDAO.encrypt(user.getPassword());

		
		user = userDAO.getUserLogin(email, encryptpassword);
		String keepmeloggedinValue = request.getParameter("remember");
		if(user !=null)
		{
			HttpSession sc = request.getSession();
			sc.setAttribute("UserID", user.getUserId());
			sc.setAttribute("Email", email);
			
			Cookie[] cookielist = request.getCookies();
		         for (int i = 0; i < cookielist.length; i++) {
		        	 if(cookielist[i].getName().equals ("email_id"))
		             cookielist[i].setMaxAge(0);
		         }
		       

		
			if(keepmeloggedinValue !=null && keepmeloggedinValue.equalsIgnoreCase("on"))
			{
			
				sc.setAttribute("sessionid", sc.getId());
			}
			UserAccountDAO uadao = new UserAccountDAO();
			User userInfo = (User)uadao.getUserProfileDetails(user.getUserId());
			sc.setAttribute("name", userInfo.getFullname());
			String default_location = userInfo.getLocCity();
			//System.out.println("default Location "+default_location);
			
			sc.setAttribute("default_location", default_location);
			
			
			return mapping.findForward("success");
		}
		else
		{   
			request.setAttribute("InvalidLogin", email);
			return mapping.findForward("failure");
			
		}
	}*/
	public ActionForward login(ActionMapping mapping, ActionForm form,HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		
		System.out.println("in login method");
		
	User user = (User) form;
	UserLoginDAO userDAO = new UserLoginDAO();
	String email = "";
	String encryptpassword = "";

	HttpSession session = request.getSession();

	/*if(request.getParameter("username") != null)
	{
		email = request.getParameter("username");
		encryptpassword = userDAO.encrypt(request.getParameter("password").toString());
	}*/
	
	if (session.getAttribute("email") != null) {
		email = session.getAttribute("email").toString();
		encryptpassword = userDAO.encrypt(session.getAttribute("password")
				.toString());
	}		
	else {
		//System.out.println("else");
		email = user.getEmail().toLowerCase();
		encryptpassword = userDAO.encrypt(user.getPassword());
	}
	/* This line code authenticate the user */
	user = userDAO.getUserLogin(email, encryptpassword);
	String keepmeloggedinValue = request.getParameter("remember");
	
	
	if (user != null) {
		HttpSession sc = request.getSession();
		sc.setAttribute("UserID", user.getUserId());
		sc.setAttribute("Email", email);
		sc.setAttribute("userProfile", user);
		/*
		Cookie[] cookielist = request.getCookies();
		for (int i = 0; i < cookielist.length; i++) {
			if (cookielist[i].getName().equals("email_id"))
				cookielist[i].setMaxAge(0);
		}
		
		/** In case user has checked the Keep me logged in check box */
		if (keepmeloggedinValue != null
				&& keepmeloggedinValue.equalsIgnoreCase("on")) {
			
			/** Create cookie for future remember */
			Cookie cookie = new Cookie("keeploggedin", user.getEmail());
			cookie.setMaxAge(604800); 
			response.addCookie(cookie);
		}

		if(user.getScheduleFlag().equalsIgnoreCase("N")){
			/**
			 * Getting the Facebook, LinkedIn, Gmail etc... profile for loggedin user. 
			 */
			new ScheduleSocialNetwork().startscheduleScoialNetwork(user.getUserId(), sc.getId());
			new UserAccountDAO().updateUserScheduleFlagById(user.getUserId(), "Y");
		}
		
		
		
		sc.setAttribute("name", user.getFullname());
		String default_location = user.getLocCity();
	
		/*
		 * if(!userInfo.getLocState().equals("")) default_location =
		 * default_location + ", "+userInfo.getLocState();
		 * if(!userInfo.getLocState().equals("")) default_location =
		 * default_location + ", "+userInfo.getLocCountry();
		 */

		sc.setAttribute("default_location", default_location);
		// Modified by rupal kathiriya to get setupnetwork page directly when seems "fwdurl" after changed in mymeetin.jsp and struts-cofig.xml files for url
		//String chkUrl= session.getAttribute("fwdurl").toString();
	
		if(user.getHelpAlert())
		{
			request.setAttribute("helpalert","helpalert");
			request.setAttribute("helpwizard", user.getHelpAlert());
			return mapping.findForward("myprofile");
		}
		
		
		
		String chkUrl=request.getParameter("fwdurl");
		
		if(chkUrl.equals("fwdurl")){
		
			return mapping.findForward("fwdurl");
			
		}else{
		
			return mapping.findForward("success");
		}	
		//return mapping.findForward("success");
		//code ended
		
	} else {
		request.setAttribute("InvalidLogin", email);
		return mapping.findForward("failure");

	}
}

	public ActionForward signout(ActionMapping mapping, ActionForm form,
		HttpServletRequest request,HttpServletResponse response) throws Exception{
		//System.out.println("UserAction.java ---------------------  signout method called ");
		HttpSession userSession = request.getSession(false);
		userSession.invalidate();
		
		Cookie myCookie = new Cookie("keeploggedin", "");
		myCookie.setMaxAge(0);
		myCookie.setValue("");
		response.addCookie(myCookie);
		return mapping.findForward("logout");
	}
	
	public ActionForward signoutAdmin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
			//System.out.println("UserAction.java ---------------------  signout method called ");
			HttpSession userSession = request.getSession(false);
			userSession.invalidate();
			
			Cookie myCookie = new Cookie("keeploggedin", "");
			myCookie.setMaxAge(0);
			myCookie.setValue("");
			response.addCookie(myCookie);
			return mapping.findForward("logoutAdmin");
		}
	
	
	public ActionForward register(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		String result ="failure";
		User ouser = (User)form;
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		UserAccountDAO accountDAO = new UserAccountDAO();
		UserLoginDAO userDAO = new UserLoginDAO();
		
		String encryptpassword ="";
		if(ouser.getPassword() ==null)
		{
			encryptpassword = userDAO.encrypt(ouser.getPassword1());
			System.out.println("get password 1 "+ouser.getPassword1());
			ouser.setPassword(ouser.getPassword1());
		}
		else
		{
			encryptpassword = userDAO.encrypt(ouser.getPassword());
		}
		
		
		
		//Code Change by lokesh
		//User user = new User(ouser.getFullname(), ouser.getEmail(), encryptpassword, sdf.parse(ouser.getBirthdate()), ouser.getLocCountry(), ouser.getLocState(), ouser.getLocStreet(),ouser.getLocCity(),ouser.getLocPin(),ouser.getLocLat(),ouser.getLocLang(), new Date(), ouser.getGender());
		
		User user = new User(ouser.getFullname(), ouser.getEmail(), encryptpassword, sdf.parse(ouser.getBirthdate()), ouser.getLocCity(),ouser.getLocLat(),ouser.getLocLang(), new Date(), ouser.getGender());
		
		
		
		//------------------------------------------------------------------------
		//code changed
		boolean checkEmailRegistered = accountDAO.isEmailRegistered1(ouser.getEmail());

		if(checkEmailRegistered)
		{
			HttpSession sessionRegistered1 = request.getSession();
			sessionRegistered1.setAttribute("emailRegistered","emailRegistered");
			
			return mapping.findForward("registered1");
		}
		
		//----------------------------------------------------------------------------------
		
		/* This code line save the user basic account details */
		int last_user_id = accountDAO.createUserAccount(user);
		if(last_user_id > 0)
		{
			UserLoginDAO loginDAO = new UserLoginDAO();
			/*This code line perform the auto login process */
			user = loginDAO.getUserLogin(ouser.getEmail(), loginDAO.encrypt(ouser.getPassword()));
			if(user != null)
			{
				HttpSession userSession = request.getSession();
				if(userSession.getAttribute("access_token") != null)
				{
				    Usernetworks onetwork = new Usernetworks(user.getUserId(), 1, "", "", 
				    		userSession.getAttribute("access_token").toString());
					new NetworkDAO().setUserSocialNetworkSite(onetwork);
				}
				
				userSession.setAttribute("UserID", user.getUserId());
				userSession.setAttribute("Email", ouser.getEmail().toLowerCase());
				userSession.setAttribute("name", ouser.getFullname());
				String default_location = ouser.getLocCity();
								
				userSession.setAttribute("default_location", default_location);
				userSession.setAttribute("fromprofile", "false");
				
				result = "register";
			}
		}
		
		String path = request.getContextPath();
		String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
		///mailer format 
		String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
		
	/** body portion of message */ 
			
	htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>You have successfully registered on meetIn, you now have the power to find, contact and meet your friends across the globe while you or they are traveling.</td>" +
			"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><p>You can also download our mobile app (iPhone and Android) from the store.</p>" +
			"      <p>Thank you for joining meetIn.</p>      <p>Happy Traveling!!!</p>" +
			"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p></p></td>" +
			"  </tr>  <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
			"  </tr></table></td>  </tr>";	 
	
		String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
		String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
		String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
		String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
					
		htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);				
		new InviteFriends().postMail(ouser.getEmail(),"Welcome to meetIn: Your central contact finder!!!", htmlmessage,"");
		
		/** Here 1 is the default mymeetin user id and it will be added as friends when user register in the application */
		Friends friend = new Friends(1, last_user_id,"Pending", new Date());
		new FriendsDAO().setFriendRequest(friend);
		
		/** Start the scheduler to send first friend request email */
		String header = new Mailer_Header().getMailerHeader(bannar);
		String footer = new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
		SendFirstFriendRequestScheduler s = new SendFirstFriendRequestScheduler();
		s.SendFirstFriendRequestEmail(last_user_id, "Hurray! You have your first friend request in meetIn!", header, footer);
				
		return mapping.findForward(result);
	}

	public ActionForward postlogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		
		System.out.println("post login.jsp--------------postlogin method");
				
		User user =(User)form;
		HttpSession sc = request.getSession(false);
		int userid = (Integer)sc.getAttribute("UserID");
		UserAccountDAO accountDAO = new UserAccountDAO();
		String filename = user.getImage();
		//HttpSession session=request.getSession();
		//String filename =session.getAttribute("image").toString();
		//System.out.println("fileNAME    :::   "+filename);
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		//Modified by Rupal Kathiriya #864 to display interest, privacy setting with right status
		//User ouser = new User(userid, user.getFullname(), sdf.parse(user.getBirthdate()), filename , user.getAboutMe(),user.getCompany(),true, user.getJobTitle(),true,user.getIndustry(),user.getDegreeCollege(),true,user.getOtherSpecify(), user.getGender(),user.getUsername());
		User ouser = new User(userid, user.getFullname(), sdf.parse(user.getBirthdate()), filename , user.getAboutMe(),user.getCompany(), user.getJobTitle(),user.getIndustry(),user.getDegreeCollege(),user.getOtherSpecify(), user.getGender(),user.getUsername());
		
		String path = request.getSession().getServletContext().getRealPath("")+"/"+"profileimage1/"+ ouser.getImage();
		String basePath = request.getSession().getServletContext().getRealPath("")+ "/";
		
		HttpSession session = request.getSession();
		try	
		{	
			File tempfile = new File(path);
			//System.out.println("temp file path "+path);
			
			if(tempfile.exists())
			{
				InputStream inStream = null;
				OutputStream outStream = null;
				
				String originalpath = basePath + "profileimage/"+ouser.getImage();
				File OriginalFile = new File(originalpath); 
				
			
				//System.out.println("original path :   "+originalpath);
				
				inStream = new FileInputStream(tempfile);
	  	   	    outStream = new FileOutputStream(OriginalFile);
	  	 
	  	   	    byte[] buffer = new byte[1024];
		  	 
	    	    int length;
	    	    //copy the file content in bytes 
	    	    while ((length = inStream.read(buffer)) > 0){
	 
	    	    	outStream.write(buffer, 0, length);
	    	    }
				
	    	    inStream.close();
  	    	    outStream.close();
  	 
  	    	    tempfile.delete();

  	    	    //System.out.println("File is copied successful!");
  	    	    session.removeAttribute("image");
	    	}
			
		}catch (Exception e) {
				//System.out.println("Exception e " +e);
		}	
		
		int record_id = accountDAO.createPostLoginDetails(ouser);
		if(record_id > 0)
		{
		    String[] interestArray = user.getInterest();
			 if(interestArray !=null && interestArray.length >0)
			 {
				InterestDAO interestDAO = new InterestDAO();
				for(int i =0 ; i < interestArray.length; i++)
			 	{
				 Interest interest = new Interest(userid,Integer.parseInt(interestArray[i]));
				 interestDAO.setUserInterest(interest);  
			 	}
			 }
		    if(request.getParameter("fromprofile") !=null)
		    {
		    	
		    	sc.setAttribute("UserProfileSaved", "yes");
		    	/**Storing the updated user name into the session object from My Profile View */ 
			    sc.setAttribute("name", user.getFullname());
		    	//System.out.println("return goprofilereference");
			    return mapping.findForward("goprofilereference");
		    }
		    //System.out.println("setupnetworkaspostlogin");
			 return mapping.findForward("setupnetworkAspostlogin");   
		}
		//System.out.println("null return ");
		return null;
	 }
	
	public ActionForward getProfileImage(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception {
		//System.out.println("UserAction.java ---------------------  getProfileImage method called ");
		User user =(User)form;
		//String filePath = getServlet().getServletContext().getRealPath("/") +"profileimage";
		//File fileToCreate = new File(filePath, "14_sunil.jpg");
		//FileOutputStream fileOutStream = new FileOutputStream(fileToCreate);
		response.getOutputStream().write(user.getImageFile().getFileData());
		return mapping.getInputForward();
	}
	public ActionForward facebookLogin(ActionMapping mapping, ActionForm form,
		HttpServletRequest request,HttpServletResponse response) throws Exception{
		//System.out.println("UserAction.java ---------------------  Facebooklogin method called ");
		String FBLOGIN = "fblogin";
		return mapping.findForward(FBLOGIN);
	}
	public ActionForward location(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		////System.out.println("UserAction.java --------------------- location method called ");
		if(request.getParameter("city")!=null){
			String citydata = new LocationDAO().getCityLatitudeLongitude(request.getParameter("city"));
			////System.out.println(citydata);
			request.setAttribute("latitudelongitude", citydata);
			return mapping.findForward("success");
		}
		else if (request.getParameter("fill") != null){
			if(request.getParameter("fill").equals("country")){
				String query =request.getParameter("q");
				List countryList = new LocationDAO().getCountriesByKey(query);
				request.setAttribute("countries", countryList);
				return mapping.findForward("success");
			}
			else if(request.getParameter("fill").equals("state")) {
				String query =request.getParameter("q");
				List stateList = new ArrayList();
		        stateList = new LocationDAO().getStatesByKey(query);
		        request.setAttribute("states", stateList);
				return mapping.findForward("success");
			}
			else if(request.getParameter("fill").equals("city")) {
				String query =request.getParameter("q");
				List cityList = new ArrayList();
		    	cityList = new TripsDAO().getTripDestination(query); //locationDAO().getCitiesByKey(query);
		    	request.setAttribute("cities", cityList);
				return mapping.findForward("success");
			}
			else if(request.getParameter("fill").equals("gettrip")){
				String query =request.getParameter("q");
				List destination = new ArrayList();
				destination = new TripsDAO().getTripDestination(query);
		    	request.setAttribute("tripdestination", destination);
				return mapping.findForward("success");
			}
		}
		return null;
	}
	
	public ActionForward setupLocation(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		//System.out.println("UserAction.java ---------------------  setuplocation method called ");
		User user =(User)form;
		////System.out.println(user.getLocCountry());
		////System.out.println(user.getLocState());
		////System.out.println(user.getLocStreet());
		////System.out.println(user.getLocCity());
		////System.out.println(user.getLocPin());
		////System.out.println(user.getLocLat());
		////System.out.println(user.getLocLang());
		
		HttpSession userSession = request.getSession(false);
		user.setUserId(Integer.parseInt(userSession.getAttribute("UserID").toString()));
		UserAccountDAO accountdao = new UserAccountDAO();
		accountdao.setupLocation(user);
		/**code to find current location of user (in case user is travelling on current date)*/
		List<String> locationList = new ArrayList<String>();
		locationList = new PeopleFinder().getUserLocationOnCurrentDate(user.getUserId());
		String currentLocation ="";
		/** If the condition is true then user has current location on current date*/
		if(locationList !=null && locationList.size() > 0)
		{
			/**User's current location*/
			currentLocation = locationList.get(0);
			
		}
		else
		{
			/**User's default location*/
			currentLocation =accountdao.getUserLocation(user.getUserId());
			locationList.add(currentLocation);
			/** The below line allow user to edit the default location */
			request.setAttribute("AllowLocationEdit", currentLocation);
			//System.out.println("in else current Location "+currentLocation);
		}
		//System.out.println("current Location "+currentLocation);
		/**Store the location list in userSession object */
		userSession.setAttribute("current_location",locationList);
		userSession.setAttribute("default_location",user.getLocCity());
		userSession.setAttribute("userProfile", accountdao.getUserProfileDetails(user.getUserId()));
		String current_location = accountdao.getUserLocation(user.getUserId());
		
		
		////System.out.println("++++++++++"+current_location);
		/*List<String> locationList = new ArrayList<String>();
		String current_location = accountdao.getUserLocation(user.getUserId());
		locationList.add(current_location);
		userSession.setAttribute("current_location", locationList);*/
		
		PeopleFinder PF = new PeopleFinder();
		Hashtable<String, List<String>> friends = PF.peopleFinder(
				user.getUserId(), current_location.split(",")[0]);
		if(friends==null)
			request.setAttribute("requireNetworkSetup", "true");
		request.setAttribute("friends", friends);
		return mapping.findForward("success");
	}
	
	public ActionForward emailcheck(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
			{
		
		//System.out.println("User Action.java ----------  email check method called");
		
		String email = request.getParameter("email");
		if(email !=null && !email.equals(""))
		{
			boolean emailexist = new UserAccountDAO().isEmailRegistered(email);
			//System.out.println("email exist value ----*-*-*-* "+ emailexist);
			if(emailexist)
			{
				request.setAttribute("EmailCheck", "exist");
				return mapping.findForward("emailcheck");
			}
		}
		 
		return null;
	}
	
	public ActionForward forgotpassword(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		//System.out.println("UserAction.java --------------------- forgot password method called ");
		User user = (User)form;
		String username =user.getFullname();
		String email = user.getEmail();
		boolean emailexist =false;
		String resetPassword ="";
		
		
		if(email !=null && !email.equals(""))
		{
			emailexist = new UserAccountDAO().isEmailRegistered(email);
			
			if(emailexist)
			{
				resetPassword = new ForgotPasswordDAO().generateNewPassword(email);
				
				if(resetPassword !=null && !resetPassword.equals(""))
				{
				
					String path = request.getContextPath();
					String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
					
					String htmlmessage = new Mailer_Header().getMailerHeader(bannar); 
					
					htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
					
					"    <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><p>We have received a new password generation request from you.</p>" +
					"      <p>Your new password is: "+resetPassword+"</p>      <p>We suggest you login with your registered email id and change your password immediately after logging in with this new password. </p>" +
					"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p>Keep your trips updated so your friends can also get alerts and contact you.</p></td>" +
					"  </tr>  <tr>" +
					"    " +
					"  </tr></table></td>  </tr>";	 
				
					String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
						String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
						String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
						String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
							
							
				htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

					
					
					new ForgotPasswordDAO().sendGenereatedPasswordByEmail(email, "meetIn: Your request for new password!!!", htmlmessage, "");				
				}
				
				return mapping.findForward("resetpassword");
			}
			else
			{
				return mapping.findForward("invalidemail");
			}
		}
		
		return null;
	}
	//Added by Rupal Kathiriya to get image files from server folder dated on 21 july 2012
	public void getImageFile(String filePath,String userId){
		
		//System.out.println("UserAction.java ---------------------  getImageFile method called ");		
		//System.out.println("File Path "+filePath);
		//System.out.println("User Id "+userId);
		try
    	{  		
    		File[] files1=finder(filePath,userId);
    		////System.out.println("File Number  : " +files1.length);
    		if(files1==null)
    		{
    			//System.out.println("file not found");
    		}
    		else
    		{
				if(userId.toString().startsWith(userId))
    			{
					if(files1.length!=0)
    				{
    					for(int i=0;i<files1.length;i++)
    					{
    						////System.out.println(files1[i]);
	    					//Files.add(files1[i]);
    						////System.out.println("List"+files1[i]);
    						files1[i].delete();
    					}
    				}
    				else
    				{
    					//System.out.println("invalid file");
    				}
    			}
				else
				{
					//System.out.println("invalid file");
				}
			}	
	    }
    	catch (Exception e) {
    		e.printStackTrace();
			// TODO: handle exception
		}
	}
	//Added by Rupal Kathiriya to get image files from server folder dated on 21 july 2012
	public File[] finder(String dirName,final String userId)
		{
		//System.out.println("dirName:: "+dirName);
	        File dir = new File(dirName);
	        return dir.listFiles(new FilenameFilter() 
	        { 
	                 public boolean accept(File dir, String filename)
	                    { 
	                	 	boolean fileEx=filename.startsWith(userId);
	                	 	return fileEx; 
	                	}
	        } );

	    }
	//Ended by Rupal Kathiriya to get image files from server folder dated on 21 july 2012
/*	
 	public ActionForward imagepreview(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		//System.out.println("inside image preview action......................................");
		
		HttpSession sc = request.getSession();
		
		//System.out.println("1111111");
		
		User fileUploadAndSaveForm = (User)form;// TODO Auto-generated method stub
		// Process the FormFile
		FormFile myFile = fileUploadAndSaveForm.getImageFile();
		//System.out.println("22222222");
		
		String contentType = myFile.getContentType();
		//Get the file name
		
		
		//System.out.println("333333");
		String fileName  = myFile.getFileName();
		
		
		fileName = sc.getAttribute("UserID").toString()+"_"+fileName;
		//System.out.println("44444444444");
		
		HttpSession session = request.getSession();
		session.setAttribute("filename", fileName);
		
		
		//System.out.println("file name is ------   " + fileName );
		
		//fileName = fileName.concat(request.getSession().getId().toString());
		////System.out.println("inside image preview action...and image file name is--"+fileName);
		//int fileSize = myFile.getFileSize();
		
		byte[] fileData  = myFile.getFileData();
		//Get the servers upload directory real path name
		String filePath = getServlet().getServletContext().getRealPath("/")+"profileimage" ;
		
		//System.out.println("file saved at path is --------  " +  filePath);
		
		session.setAttribute("filepath", filePath);
		
	//	//System.out.println("in imagepreview action directory file path"+filePath);
		
		//String homePath = "/home/verve/profileImg"; //local machine directory
		/**The below line is store profile image on server local directory */
		//String homePath = "/home/gaurav/profileImg"; //server directory
/*
	if(!fileName.equals(""))
		{
			//System.out.println("Server path:" +filePath);
			//	Create file
		
			File fileToCreate = new File(filePath, fileName);
			//If file does not exists create file
			if(!fileToCreate.exists())
			{
				FileOutputStream fileOutStream = new FileOutputStream(fileToCreate);
				fileOutStream.write(myFile.getFileData());
				fileOutStream.flush();
				fileOutStream.close();
			}
		
			/**this code is save user profile image in local directory */
		
			//File f =  new  File(homePath+"/"+fileName);
		/*	File f = new File(filePath, fileName);
			if(!f.exists())
			{
				FileOutputStream fileOutStream = new FileOutputStream(f);
				fileOutStream.write(myFile.getFileData());
				//System.out.println("***********************************  Image Saved *********************************");
				fileOutStream.flush();
				fileOutStream.close();
			}
			sc.setAttribute("filename", fileName);
			String imagePath= request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+"/"+request.getContextPath()+"/profileimage/"+fileName;
		//String imagePath="/home/verve/Workspaces/MyEclipse 8.6/MeetIn1/WebRoot/profileimage/"+fileName;
		////System.out.println("Image path is in imagepreview action--"+imagePath);
		
	/*	request.setAttribute("imagename", imagePath);
		
		
		}		
		return mapping.findForward("success");
		
	}
 	*/
 	
	public ActionForward publicprofile(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		
		//System.out.println("UserAction.java --------------------- publicprofile method called ");
		String username = request.getParameter("username");
		
		UserAccountDAO useracc = new UserAccountDAO();
		int userId = useracc.getuserId(username);
		if(userId != 0){
		request.setAttribute("userId", userId);
		return mapping.findForward("success");
		}else
		return mapping.findForward("failure");
	}
	
	public ActionForward usernamecheck(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		//System.out.println("UserAction.java ---------------------  usernamecheck method called ");
		
		UserAccountDAO useracc = new UserAccountDAO();
		String name = request.getParameter("username");
		HttpSession sc = request.getSession(false);
		Integer userId = (Integer)sc.getAttribute("UserID");
		if(name !=null && !name.equals(""))
		{
			boolean nameexist = new UserAccountDAO().isUserNameRegistered(name,userId);
			if(nameexist)
			{
				request.setAttribute("nameCheck", "exist");
				return mapping.findForward("namecheck");
			}
		}
		 
		return null;
	}
	public ActionForward setHelpWizard(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession sc = request.getSession();
		int userId = (Integer) sc.getAttribute("UserID");
		Boolean settingValue = Boolean.parseBoolean(request.getParameter("helpalert"));
		
		new UserPrivacySettingDAO().setHelpWizardSetting(userId, settingValue);
		
		return null;
		
	}

}