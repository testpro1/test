package com.verve.meetin.webservice;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.QueryParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.time.DateFormatUtils;

import com.verve.meetin.friend.Friends;
import com.verve.meetin.friend.FriendsDAO;
import com.verve.meetin.visitor.Visitors;
import com.verve.meetin.visitor.VisitorsDAO;

@Path("Visitor")
public class VisitorService 
{
	@Produces("application/xml")
	@GET
	@Path("setvisitor")
	
	public Visitors setProfileVisitor(@QueryParam("visitorid") Integer visitorid, @QueryParam("visiteeid") Integer visiteeid)
	{
		Visitors visitors =  new Visitors(visitorid, visiteeid, new Date());
		new VisitorsDAO().setProfileVisitor(visitors);
		visitors.setResultString("success");
		return visitors;
	}
	
	@Produces("application/xml")
	@GET
	@Path("getvisitor")
	
	public Response getProfileVisitorList(@QueryParam("userId") Integer userId) 
	{
		  List visitorList = new VisitorsDAO().getProfileVisitorList(userId);
		  List<Visitors> list = new ArrayList<Visitors>();
		 // SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		  
		  
		  Friends friend =null;
		  String status ="";
		  try
		  {
		   for(int i =0 ; i < visitorList.size();i++)
		   {
			   Object[] object =(Object[])visitorList.get(i);
			   Visitors visitors = new Visitors();
			//   visitors.setVisitDate(sdf.format((Date)object[0]));
			   visitors.setVisitDate(DateFormatUtils.format((Date)object[0], "MMM dd, yyyy HH:mm"));
			   visitors.setUserId((Integer)object[1]);
			   visitors.setFullname((String)object[2]);
			   friend =(Friends)new FriendsDAO().checkFriendRequest(userId, (Integer)object[1]);
				
				
	    		if(friend !=null)
	    		{
	    			if(friend.getStatus().equals("Pending") && friend.getUserId2().intValue() != (Integer)object[1])
	    			{
	    				status = "Accept";
	    			}
	    			else if(friend.getStatus().equals("Pending") && friend.getUserId2().intValue() == (Integer)object[1])
	    			{
	    				status ="Pending";
	    			}
	    			else
	    			{
	    				status ="Approve";
	    			}
	    			
	    			visitors.setRelationId(friend.getRelationshipId());
	    		}
	    		else
				{
					status ="0";
				}
	    		
	    	   
	    	   visitors.setResultString(status);
	    	   
			   list.add(visitors);
		   }
		   
		   GenericEntity<List<Visitors>> entity = new GenericEntity<List<Visitors>>(list){};
		   return Response.ok(entity).build();
		   
		  }
		  catch(Exception ex)
		  {
			  ex.printStackTrace();
		  }
		  
		return null;  
	}
		
}
