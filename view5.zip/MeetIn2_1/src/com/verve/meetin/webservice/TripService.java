package com.verve.meetin.webservice;

import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.trip.*;
import com.verve.meetin.tripit.Tripit_Trips;
import com.verve.meetin.tripit.Tripit_Trips_DAO;
import com.verve.meetin.user.User;
import com.verve.meetin.user.UserAccountDAO;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.QueryParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

@Path("Trip")
public class TripService 
{
	@Produces("application/xml")
	@POST
	@Path("settrip")
	public TripWS setUserTrip(@HeaderParam("userId") Integer userId,@HeaderParam("destination") String destination, @HeaderParam("description") String description, @HeaderParam("fromDate") String fromDate, @HeaderParam("toDate") String toDate, @HeaderParam("latitude") String latitude,@HeaderParam("longitude") String longitude,@Context HttpServletRequest request) throws Exception
	{
		User user = (User)new UserAccountDAO().getUserProfileDetails(userId);
		Date fromdate = new Date();
		Date todate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		TripWS tripws = new TripWS();
		try {
			
			fromdate = sdf.parse(URLDecoder.decode(fromDate, "UTF-8"));
			todate = sdf.parse(URLDecoder.decode(toDate, "UTF-8"));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		if((latitude ==null || latitude.equals("")) && (longitude ==null || longitude.equals("")))
		{
		     String latlong = new LocationDAO().getCityLatitudeLongitude(URLDecoder.decode(destination, "UTF-8"));
		     
		     if(latlong !=null && !latlong.equals(""))
		     {
		    	 latitude = latlong.split(":")[0];
			     longitude = latlong.split(":")[1];	 
		     }
		     else
		     {
		    	 latitude = "0.0";
			     longitude = "0.0";
		     }
		     
		}
		
		Trips trips = new Trips(userId, URLDecoder.decode(destination, "UTF-8"), URLDecoder.decode(description, "UTF-8"), fromdate, todate, latitude, longitude);
		int tripId = new TripsDAO().setUserTrip(trips);
		
		if(tripId > 0)
		{
			tripws.setTripId(tripId);
			
			List list =	new UserAccountDAO().getFriendEmailIdsOnBaseLocation(URLDecoder.decode(destination, "UTF-8"),userId,URLDecoder.decode(fromDate, "UTF-8"),URLDecoder.decode(toDate, "UTF-8"));
			
			//return list of friends on trip on that location
			List list1 = new UserAccountDAO().getFriendEmailIdsOnTrip(URLDecoder.decode(destination, "UTF-8"),userId);
			
			List list2 = new ArrayList();
			
			if(list.size() != 0)
			{
				Iterator iterator= list.iterator();
				while(iterator.hasNext())
				{
					list2.add(iterator.next());
				}
			}
			
			if(list1.size() != 0)
			{
				Iterator iterator2 = list1.iterator();
				while(iterator2.hasNext())
				{
					list2.add(iterator2.next());
				}
			}
		
			if(list2.size() != 0)
			{
					Iterator<String> iterator = list2.iterator();
					int i=0;
					String arr[] = new String[list2.size()];
					while(iterator.hasNext())
					{
							arr[i]=iterator.next();
							////System.out.println(arr[i]);
							i++;
					}
					
			//header image
			String path = request.getContextPath();
			String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
			///mailer format 
			String htmlmessage = new Mailer_Header().getMailerHeader(bannar);

			
			String gender ="";
			if(user.getGender().equals("Male"))
			{
				gender="he";
			}
			else
			{
				gender="she";
			}
			
	htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
	"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'></td>" +
	"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
	"<br>Your meetIn friend " + user.getFullname() + " has added a trip and is traveling to "+destination+" between "+URLDecoder.decode(fromDate,"UTF-8")+" to "+URLDecoder.decode(toDate,"UTF-8")+". " +
	"      <br><br>We thought you would be interested in meeting up "+user.getFullname()+" while "+gender+" is there.   <br><br>You can contact "+user.getFullname()+" with your availability on "+user.getEmail()+"" +
	"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><br>Keep your trips updated so your friends can also get alerts and contact you.</td>" +
	"  </tr>  <tr>" +
	"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
	"  </tr></table></td>  </tr>";	 
			

	String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
	String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
	String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
	String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
		
		
	htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

	new InviteFriends().postMails(arr, "meetIn friend alert!!!",htmlmessage, user.getFullname());

			}	
		}
		
		return tripws;
	}
	
	@Produces("application/xml")
	@GET
	@Path("upcomingtrip")
	public List<TripWS> getUserUpcomingTrips(@QueryParam("userId") Integer userId)
	{
	   List upcomingTripList = new TripsDAO().getUserUpcomingTrips(userId);
	   SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
	   List<TripWS> list = new ArrayList<TripWS>();
	   Iterator itr= upcomingTripList.iterator();
	   while(itr.hasNext()){
		   Trips trips = new Trips();
		   trips =(Trips)itr.next();
		   TripWS tripws = new TripWS(trips.getTripId(),trips.getUserId(), trips.getDestination(), trips.getDescription(), sdf.format(trips.getFromDate()), sdf.format(trips.getToDate()),trips.getDestinationLatitude(),trips.getDestinationLongitude());
		   list.add(tripws);
	   }
	   
		return list;  	
	}

	@Produces("application/xml")
	@GET
	@Path("pasttrip")
	public List<TripWS> getUserPastTrips(@QueryParam("userId") Integer userId)
	{
		List pastTripList = new TripsDAO().getUserPastTrips(userId);
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		   List<TripWS> list = new ArrayList<TripWS>();
		   Iterator itr= pastTripList.iterator();
		   while(itr.hasNext()){
			   Trips trips = new Trips();
			   trips =(Trips)itr.next();
			   TripWS tripws = new TripWS(trips.getTripId(),trips.getUserId(), trips.getDestination(), trips.getDescription(), sdf.format(trips.getFromDate()), sdf.format(trips.getToDate()),trips.getDestinationLatitude(),trips.getDestinationLongitude());
			   list.add(tripws);
		   }
		   
			return list;  	
	}

	
	@Produces("application/xml")
	@GET
	@Path("alltrips")
	public List<TripWS> getUserAllTrips(@QueryParam("userId") Integer userId)
	{
		
		List pastTripList = new TripsDAO().getUserAllTripsforWebservice(userId);
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		   
		List<TripWS> list = new ArrayList<TripWS>();
		   Iterator itr= pastTripList.iterator();
		   while(itr.hasNext()){
			   Trips trips = new Trips();
			   trips =(Trips)itr.next();
   TripWS tripws = new TripWS(trips.getTripId(),trips.getUserId(), trips.getDestination(), trips.getDescription(), 
   sdf.format(trips.getFromDate()), sdf.format(trips.getToDate()),trips.getDestinationLatitude(),
   trips.getDestinationLongitude());
			   list.add(tripws);
		   }
		   
		   
		   List<Tripit_Trips> tripitTrips = new Tripit_Trips_DAO().getUserUpcomingTrips(userId);
		   
		   System.out.println("tripit trip size :: "+tripitTrips.size());
		   List<TripWS> tripitfinal = new ArrayList<TripWS>();
		   
		   
		   
		   Iterator itrr = tripitTrips.iterator();
		   while(itrr.hasNext())
		   {
			   Tripit_Trips tripit = new Tripit_Trips();
			   tripit =(Tripit_Trips)itrr.next();
			 TripWS trWs = new TripWS(tripit.getTripId(),tripit.getUserId(),tripit.getDestination()+" (added by tripit)",tripit.getDescription(),
					sdf.format(tripit.getFromDate()),sdf.format(tripit.getToDate()),tripit.getDestinationLatitude(),tripit.getDestinationLongitude() 
			   );
			   list.add(trWs);
		   }
		   
		   
			return list;  	
	}
	
	@Produces("application/xml")
	@GET
	@Path("tripdestination")
	public List<TripWS> getTripDestination(@QueryParam("destinationKey") String destinationKey)
	{
	  List destinationList = new TripsDAO().getTripDestination(destinationKey);
	  List<TripWS> list = new ArrayList<TripWS>();
	  Iterator itr = destinationList.iterator();
	  while(itr.hasNext()){
		  TripWS tripws = new TripWS();
		  String destination =(String)itr.next();
		  tripws.setDestination(destination);
		  list.add(tripws);
	  }
	  return list;
	}
	
	@Produces("application/xml")
	@POST
	@Path("updatetrip")
	
	public TripWS updateUserTrip(@HeaderParam("tripId") Integer tripId,@HeaderParam("userId") Integer userId, @HeaderParam("destination") String destination,@HeaderParam("description") String description, @HeaderParam("fromDate") String fromDate, @HeaderParam("toDate") String toDate,@HeaderParam("latitude") String latitude, @HeaderParam("longitude") String longitude) throws Exception
	{
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		TripWS tripws = new TripWS();
		try {
			Trips trips = new Trips(tripId, userId, URLDecoder.decode(destination, "UTF-8"), URLDecoder.decode(description, "UTF-8"), sdf.parse(URLDecoder.decode(fromDate, "UTF-8")), sdf.parse(URLDecoder.decode(toDate, "UTF-8")), latitude, longitude);
			int updated_tripid = new TripsDAO().updateUserTrip(trips);
			
			if(updated_tripid > 0)
			{
				tripws.setTripId(updated_tripid);
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
	
		return tripws;
	}
	
	@Produces("application/xml")
	@POST
	@Path("removetrip")
	
	public TripWS removeUserTrip(@HeaderParam("tripId") int tripId)
	{
		TripWS tripws = new TripWS();
		try
		{
			int remove_tripid= new TripsDAO().removeUserTrip(tripId);
			
			if(remove_tripid > 0)
			{
				tripws.setTripId(remove_tripid);
			}
		}
		catch(Exception ex)
		{
		   ex.printStackTrace();	
		}
		
		return tripws; 
	}
	
}
