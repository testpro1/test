package com.verve.meetin.webservice;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;

import com.verve.meetin.facebook.Friends;
import com.verve.meetin.foursquare.foursquareDemo;
import com.verve.meetin.friend.FriendsDAO;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.network.peoplefinder.PeopleFinder;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;
import com.verve.meetin.trip.TripWS;
import com.verve.meetin.user.User;
import com.verve.meetin.user.UserAccountDAO;
import com.verve.meetin.user.UserWS;

@Path("PeopleFinder")
public class PeoplefinderService 
{
	@SuppressWarnings("unchecked")
	@Produces("application/xml")
	@GET
	@Path("peoplefinder")
	//Added by rupal kathiriya for optimization dated on 23rd jan 2013
	public Response peopleFinder(@QueryParam("userId") int userId, @QueryParam("location") String location, @Context HttpServletRequest request) throws Exception
	{
		// getting friends from social network on current location
		List list = new SocialNetworkDAO().getAllSocialFriendsWithlocationWise(userId,location.split(",")[0]);
		String latlang = new LocationDAO().getCityLatitudeLongitude(location.split(",")[0].toLowerCase());
		String  latitude = null, langitude =null;
		List friendList = new ArrayList();
		DateFormat df = new SimpleDateFormat("dd MMM yyyy 'at' hh:mm 'Hrs' zzz");
		try{
			if(list !=null && list.size() >0)
			{
				for(int i=0 ;i<list.size();i++){
					Friends f=new Friends();
					Object[] object=(Object[])list.get(i);
					f.setName(String.valueOf(object[1]));
					f.setLink(String.valueOf(object[2]));
					f.setImagePath(String.valueOf(object[3]));
					f.setIcon(String.valueOf(object[7]));
					//System.out.println("date:::::   "+String.valueOf((Timestamp)object[8]));
					//2013-02-07 12:01:09.0
					String text = df.format(object[8]);
					f.setUpdateOn(String.valueOf("Last updated on "+text));
					f.setOnupcomingPeople("0");	
					f.setResultString("other");
					f.setRelationId("0");
					if (!latlang.equals("") || latlang!=null)
					{
						latitude = latlang.split(":")[0];
						langitude = latlang.split(":")[1];
					}
					f.setLatitude(latitude);// latitude
					f.setLangitude(langitude);// langitude
					friendList.add(f);
					
				}
			}
			
			//changes done on 17-05-2013
			// Author dharam
			//four square checkin code added
			List foursquareChekin = new foursquareDemo().getFourSquareCheckInFriends(userId,location.split(",")[0]);
			
			System.out.println("four square checkin size :: "+foursquareChekin.size());
			
			latlang = new LocationDAO().getCityLatitudeLongitude(location.split(",")[0].toLowerCase());
			latitude = null; langitude =null;
			try{
				
			
				if(foursquareChekin !=null && foursquareChekin.size() >0)
				{
					for(int i=0 ;i<foursquareChekin.size();i++)
					{
						Friends f=new Friends();
						Object[] object=(Object[])foursquareChekin.get(i);
						f.setName(String.valueOf(object[1]));
						f.setLink(String.valueOf(object[2]));
						f.setImagePath(String.valueOf(object[6]));
						f.setIcon("images/foursq_chekin.png");
						//System.out.println("date:::::   "+String.valueOf((Timestamp)object[8]));
						//2013-02-07 12:01:09.0
						
						f.setUpdateOn("");
						f.setOnupcomingPeople("0");	
						f.setResultString("other");
						f.setRelationId("0");
						if (!latlang.equals("") || latlang!=null)
						{
							latitude = latlang.split(":")[0];
							langitude = latlang.split(":")[1];
						}
						f.setLatitude(latitude);// latitude
						f.setLangitude(langitude);// langitude
						friendList.add(f);
						
					}
				}
			}
			catch (Exception e) {
				System.out.println("Exception :: "  +e);
			}
			
			
			
			
			
			
			// getting friends from base location
			UserAccountDAO accountdao = new UserAccountDAO();
			Hashtable<String, List<String>> MeetIn_friends = new Hashtable<String, List<String>>();
			MeetIn_friends = accountdao.getFriendsNames_Ids(location,userId);
			if(MeetIn_friends!=null){
				ArrayList meetinList = new ArrayList(MeetIn_friends.values());
		    	//System.out.println(meetinList.toString());
		    	//System.out.println("Size   "+meetinList.size());
				if(meetinList !=null && meetinList.size() >0)
			       {
					int id1=0;
					for(int j=0;j<meetinList.size();j++){
						List list1=new ArrayList();
						list1=(List) meetinList.get(j);
						for(int k=0;k<=list1.size();k++){
							Friends f=new Friends();
							f.setName((String)list1.get(0));
							f.setLink((String)list1.get(1));
							f.setIcon((String)list1.get(2));
							f.setLatitude((String)list1.get(3));// latitude
							f.setLangitude((String)list1.get(4));// langitude
							f.setOnupcomingPeople("0");
							f.setUpdateOn("");
							String imagePath =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
							String imageName=null;
							if((String)list1.get(6) !=null && !list1.get(6).equals(""))
							  {
							   	imageName = imagePath + "/" + (String)list1.get(6);
							   //	System.out.println("getting friends from base location  "+imageName);
							  }
							f.setImagePath(imageName);	
									try{
									String[] id=((String)list1.get(1)).split("=");
									com.verve.meetin.friend.Friends friend =(com.verve.meetin.friend.Friends)new FriendsDAO().checkFriendRequest(userId, Integer.parseInt(id[1]));
										id1=friend.getRelationshipId();
									}catch(Exception e11){
										id1=0;
									}
									try{
										if(id1==0){
											f.setResultString("other");
											f.setRelationId("0");
										}else{
											f.setResultString("approve");
											f.setRelationId(String.valueOf(id1));
										}
									}catch(Exception e12){
											f.setResultString("other");
											f.setRelationId("0");
									}
									
							friendList.add(f);
							list1.clear();
						}
					}
			       }
				
				
				// getting friends from current trip location
				List tripFriendList = new PeopleFinder().getPeopleNearOnUpcomingDateWebservice(userId,location.split(",")[0]);
				if(tripFriendList !=null && tripFriendList.size() >0)
				{
					int id1=0;
					for(int i=0;i < tripFriendList.size();i++)
					{
						Object[] object =(Object[])tripFriendList.get(i);
						Friends f=new Friends();
					    f.setName((String)object[1]);
					    f.setLink("profile_page.jsp?id=" +object[0]);
					    f.setIcon("images/meetin_icon.png");
					    f.setLatitude((String)object[3]); // meetin user's latitude
						f.setLangitude((String)object[4]); // meetin user's langitude
						f.setOnupcomingPeople(object[0] + ":" +location.split(",")[0]);
										
						String imageName = "";
						String imagePath =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
						    
						
						if(object[5] !=null && !object[5].toString().equals(""))
						  {
						   	imageName = imagePath + "/profileimage/" + object[0]+ "_" +object[5];
						   System.out.println("getting friends from current trip location  "+imageName);
						  }
						else
						  {
						    	if(object[6].toString().toLowerCase().equals("male"))
						    		imageName = imagePath + "/images/male.png";
						    	else
						    		imageName = imagePath + "/images/female.png";
						  }
						f.setUpdateOn("");    
						f.setImagePath(imageName);
						try{
							com.verve.meetin.friend.Friends friend =(com.verve.meetin.friend.Friends)new FriendsDAO().checkFriendRequest(userId,Integer.parseInt(object[0].toString()));
								id1=friend.getRelationshipId();
							}catch(Exception e11){
								id1=0;
							}
							try{
								if(id1==0){
									f.setResultString("other");
									f.setRelationId("0");
								}else{
									f.setResultString("approve");
									f.setRelationId(String.valueOf(id1));
								}
							}catch(Exception e12){
									f.setResultString("other");
									f.setRelationId("0");
							}
						friendList.add(f);
					}
				}
			}
	    }catch(Exception e){
			e.printStackTrace();
		}
		GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
		return Response.ok(entity).build();
	}
	// commented by rupal Kathiriya to reduce locading time of peoplefinder dated on 23rd jan 2013
	/*@Produces("application/xml")
	@GET
	@Path("peoplefinder")
	
	public Response peopleFinder(@QueryParam("userId") int userId, @QueryParam("location") String location, @Context HttpServletRequest request) throws Exception
	{
		
		//*//**code to find current location of user (in case user is travelling on current date)*//*
		List<String> locationList = new ArrayList<String>();
		String currentLocation ="";
		String latlong ="";
		if(location != null && !location.equals(""))
		{
			//*//** Incase of multiple location on current day then current location should be selected location by user 
			 * @throws Exception *//*
			currentLocation = location;
			
			//**Code to get the user's own (logged in user) latitude and longitude in case user is doing trip on current day 
			 //* Call from onupcoming trip view
			 //* Get the latitude and longitude from trip table
			 //*//*
			
			latlong = new PeopleFinder().getUserLatLong(userId, currentLocation.split(",")[0]);
		}
		else
		{
				
			locationList = new PeopleFinder().getUserLocationOnCurrentDate(userId);
	
			//** If the condition is true then user has current location on current date*//*
			if(locationList !=null && locationList.size() > 0)
			{
				//**User's current location*//*
				currentLocation = locationList.get(0);
				
				//**Code to get the user's own (logged in user) latitude and longitude in case user is doing trip on current day 
				// Call from people near me view
				// Get the latitude and longitude from trip table
				 //*
				latlong = new PeopleFinder().getUserLatLong(userId, currentLocation.split(",")[0]);
			}
			else
			{
				
			   // currentLocation = new UserAccountDAO().getUserLocation(userId);
				
				
				User u = (User)new UserAccountDAO().getUserProfileDetails(userId);
				latlong = u.getLocLat() + ":" +u.getLocLang();
				
				
				currentLocation = u.getLocCity();
			}
		}
		
		
		List friendList = new ArrayList();
		List tripFriendList = new ArrayList();
		
		
		//**The below code is to show user's friends who are also doing trip on the current/upcomming day on the same place *//*
		tripFriendList = new PeopleFinder().getPeopleNearOnUpcomingDate(userId, currentLocation.split(",")[0]);	
		
		Hashtable<String, List<String>> triphashtable = new Hashtable<String, List<String>>();
		
		if(tripFriendList !=null && tripFriendList.size() >0)
		{
			for(int i=0;i < tripFriendList.size();i++)
			{
				Object[] object =(Object[])tripFriendList.get(i);
				List<String> friend_info = new ArrayList<String>();
			    friend_info.add((String)object[1]);
			    friend_info.add("profile_page.jsp?id=" +object[0]);
			    friend_info.add("images/meetin_icon.png");
			    friend_info.add((String)object[3]); // meetin user's latitude
				friend_info.add((String)object[4]); // meetin user's langitude
				friend_info.add(object[0] + ":" +currentLocation.split(",")[0]);
								
				String imageName = "";
				String imagePath =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
				    
				
				if(object[5] !=null && !object[5].toString().equals(""))
				  {
				   	imageName = imagePath + "/profileimage/" + object[0]+ "_" +object[5];
				   
				  }
				else
				  {
				    	if(object[6].toString().toLowerCase().equals("male"))
				    		imageName = imagePath + "/images/male.png";
				    	else
				    		imageName = imagePath + "/images/female.png";
				  }
				    
				friend_info.add(imageName);    
				triphashtable.put(String.valueOf(object[0]), friend_info);

			}
		}

		// end of code here
		Hashtable<String, List<String>> hashtable = new PeopleFinder().peopleFinder(userId,currentLocation.split(",")[0]);
		com.verve.meetin.friend.Friends friend=new com.verve.meetin.friend.Friends();
		List relId = new ArrayList();

		//merge the hashtable for default location and trip location rows
		Enumeration<String> e = triphashtable.keys();
		while(e.hasMoreElements()) {
			String element = e.nextElement(); 
			hashtable.put(element, triphashtable.get(element));
		}
		if(hashtable !=null && hashtable.size() >0)
		{
			List<String> name = new ArrayList();
			Enumeration<String> em = hashtable.keys();
			while(em.hasMoreElements())
			{
				String key = em.nextElement();
				name.add(hashtable.get(key.toString()).get(0)+"::"+key);
			}
		
			Collections.sort(name, String.CASE_INSENSITIVE_ORDER);
			List<List<String>> sorted_list = new ArrayList<List<String>>();
			
				Iterator<String> iter = name.iterator();
				while(iter.hasNext())
				{
					int id=0;
					String nkey = iter.next();
					List<String> sort_name = new ArrayList<String>();
					sort_name.add(nkey.split("::")[1]);
					sort_name.add(nkey.split("::")[0]);
					sort_name.add(hashtable.get(nkey.split("::")[1]).get(1));
					sort_name.add(hashtable.get(nkey.split("::")[1]).get(2));
					sort_name.add(hashtable.get(nkey.split("::")[1]).get(3)); // user latitude
					sort_name.add(hashtable.get(nkey.split("::")[1]).get(4)); // user langitude
					sort_name.add(hashtable.get(nkey.split("::")[1]).get(5)); 
										
					String imageName = "";
					String imagePath =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
					
					if(hashtable.get(nkey.split("::")[1]).get(6) !=null && !hashtable.get(nkey.split("::")[1]).get(6).equals(""))
					{
						
					 if(hashtable.get(nkey.split("::")[1]).get(2).split("/")[1].equalsIgnoreCase("meetin_icon.png"))
					  {
						
						 ////System.out.println("userId   "+nkey.split("::")[1]);
						imageName = imagePath + "/profileimage/" + nkey.split("::")[1] + "_" +hashtable.get(nkey.split("::")[1]).get(6);
						try{
						friend =(com.verve.meetin.friend.Friends)new FriendsDAO().checkFriendRequest(userId, Integer.parseInt(nkey.split("::")[1]));
						id=friend.getRelationshipId();
						}catch(Exception eid){
							id=0;
						}
						////System.out.println("idddddddd "+id);
						
						////System.out.println("image path in if "+imagePath);
					  }
					 else
					  {
						 ////System.out.println("userId   "+nkey.split("::")[1]);
					
						imageName = hashtable.get(nkey.split("::")[1]).get(6).toString();
						////System.out.println("image path in else  "+imagePath);
					  }
					}
					else
					{
						////System.out.println("idididididid  "+nkey.split("::")[1]);
						try{
							friend =(com.verve.meetin.friend.Friends)new FriendsDAO().checkFriendRequest(userId, Integer.parseInt(nkey.split("::")[1]));
							id=friend.getRelationshipId();
						}catch(Exception e2){
							id=0;
						}
						////System.out.println("idddddddd "+id);
					
						  if(hashtable.get(nkey.split("::")[1]).get(7).toString().toLowerCase().equals("male"))
						  {
					    	imageName = imagePath + "/images/male.png";
						  }
						  else
						  {
							imageName = imagePath + "/images/female.png";
						  }
					}
					////System.out.println("idddddddd "+id);
					
					relId.add(id);
					sort_name.add(imageName); 
					sorted_list.add(sort_name);
				}
				int c=0;
				////System.out.println(relId.size());
				
				for(int i=0;i<=relId.size()-1;i++){
					c++;
					//System.out.println(relId.get(i));
				}
				
			////System.out.println("count c"+c);
			Iterator iter1 = sorted_list.iterator();
			try{
				int c1=0;
				Friends f=null;
				int i=0;
				//for(int i=0;i<=relId.size()-1;i++){
				//	//System.out.println("in"+relId.get(i));
			while(iter1.hasNext())
			{
				c1++;
				//System.out.println(c1);
				f=new Friends();
				
				
				List friend_info = (List)iter1.next();
				
				f.setName(friend_info.get(1).toString());
				f.setLink(friend_info.get(2).toString());
				f.setIcon(friend_info.get(3).toString());
				f.setLatitude(friend_info.get(4).toString());// latitude
				f.setLangitude(friend_info.get(5).toString());// langitude
				if(friend_info.get(6) !=null && !(friend_info.get(6).equals("")))
				{
					f.setOnupcomingPeople(friend_info.get(6).toString());	
				}
				else
				{
					f.setOnupcomingPeople("0");
				}
				
				f.setImagePath(friend_info.get(7).toString());
				////System.out.println("print  "+relId.get(i).toString());
				f.setRelationId(relId.get(i).toString());
				if(relId.get(i).toString().equals("0")){
					////System.out.println(relId.get(i).toString());
					f.setResultString("other");
				}else{
					f.setResultString("approve");
				}
				
				f.setLoggedinuserlatlong(latlong);
				friendList.add(f);
				i++;
		    }
		
			
			}
			catch(Exception e1){
			//System.out.println("ERRRORORORORORORO");
		}
		}
		 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
		 return Response.ok(entity).build();
		 
	   
	}*/
	@Produces("application/xml")
	@GET
	@Path("usercurrentlocation")
	public Response getUserLocationOnCurrentDate(@QueryParam("userId") int userId) throws Exception 
	{
	   /**
	    * This find the user's trip location on a current date.
	    */
	   List<String> currentLocation = new PeopleFinder().getUserLocationOnCurrentDateforWebService(userId);
	   List<UserWS> userLocations = new ArrayList<UserWS>();
	    
	   PeopleFinder finder=new PeopleFinder();
	   
	   if(currentLocation !=null && currentLocation.size() > 0)
	   {
		   
		   for(int i=0;i < currentLocation.size();i++)
		   {
			   UserWS user = new UserWS();
			  String latlong=finder.getUserLatLong(userId,currentLocation.get(i));
			  String latitude = latlong.split(":")[0];
			  String longitude = latlong.split(":")[1];
			 
			  user.setLocCity(currentLocation.get(i));
			  user.setLocLat(latitude);
			  user.setLocLang(longitude);
			  userLocations.add(user);
		   }
		   User usr = (User) new UserAccountDAO().getUserProfileDetails(userId);
			  String defaultLocation = usr.getLocCity();
			  UserWS user = new UserWS();
			  // Added By Vasim Saiyad
			  String latitude = usr.getLocLat();
			  String langitude = usr.getLocLang();
			  
			  if(latitude == null || langitude == null){
				  throw new Exception();
			  }
			  
			  user.setLocCity(defaultLocation);
			  user.setLocLat(latitude);
			  user.setLocLang(langitude);
			  userLocations.add(user);
	   }
	   
	   /**
	    * This find user's default location from User Table.
	    */
	   else
	   {
		  //String defaultLocation = new UserAccountDAO().getUserLocation(userId);
		   UserWS user = new UserWS();
		   try{
		  User usr = (User) new UserAccountDAO().getUserProfileDetails(userId);
		  String defaultLocation = usr.getLocCity();

		  // Added By Vasim Saiyad
		  String latitude = usr.getLocLat();
		  String langitude = usr.getLocLang();
		  
		  if(latitude == null || langitude == null){
			  throw new Exception();
		  }
		  
		  user.setLocCity(defaultLocation);
		  user.setLocLat(latitude);
		  user.setLocLang(langitude);
		  
		   }catch(Exception e){
			  user.setResultString("Please enter valid location first.");
		  }
		   userLocations.add(user);
	   }
	   
	   GenericEntity<List<UserWS>> entity = new GenericEntity<List<UserWS>>(userLocations){};
	   return Response.ok(entity).build();
	}
	
	@Produces("application/xml")
	@GET
	@Path("advancesearch")
	
	// Modified by Rupal Kathiriya regarding loading problem -- added validation for all criteria--dated on 24th dec 2012
	public Response advanceSearch(@QueryParam("location") String location,@QueryParam("fromdate") String fromDate,@QueryParam("todate") String toDate,@QueryParam("interest") String interest,@QueryParam("userId") int userId) throws ParseException
	{
		System.out.println("in advance search");
		if (!location.equals("") && !fromDate.equals("") && !toDate.equals("") && !interest.equals("")) // Searching
			 {
				Hashtable<String, List<String>> hashtable = null;
				hashtable = new PeopleFinder().advanceSearch(location.split(",")[0], fromDate, toDate, interest, userId);
				Enumeration<String> e = hashtable.keys();
				   
				   List<Friends> friendList = new ArrayList<Friends>();
				   while(e.hasMoreElements()) {
						String id =  e.nextElement();
						List<String> l = hashtable.get(id);
						Friends f = new Friends();
						f.setName(l.get(0));
						f.setLink(l.get(1));
						f.setIcon(l.get(2));
						friendList.add(f);
					}
			
					 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
					 return Response.ok(entity).build();

			}else if (!location.equals("") && fromDate.equals("") && toDate.equals("")	&& interest.equals("")) // Searching Meetin and Facebook Critaria
			{
				try 
				{
					// getting friends from social network on current location
					List list = new SocialNetworkDAO().getAllSocialFriendsWithlocationWise(userId,location.split(",")[0]);
					List<Friends> friendList = new ArrayList<Friends>();
					try{
						if(list !=null && list.size() >0)
						{
							for(int i=0 ;i<list.size();i++){
								Friends f=new Friends();
								Object[] object=(Object[])list.get(i);
								f.setName(String.valueOf(object[1]));
								f.setLink(String.valueOf(object[2]));
								f.setIcon(String.valueOf(object[7]));
								friendList.add(f);
							}
						}
						String profile_path = "profile_page.jsp";
						List list1 = new FriendsDAO().viewMeetInFriendsWithLocation(userId,location.split(",")[0]);	
						if(list1 !=null && list1.size() >0)
						{
							for(int i=0 ;i<list1.size();i++){
								Friends f=new Friends();
								Object[] object=(Object[])list1.get(i);
								f.setName(String.valueOf(object[1]));
								f.setLink(profile_path+"?id=" +(Integer)object[0]);
								f.setIcon("images/meetin_icon.png");
								friendList.add(f);
							}
						}
					}catch(Exception e){
							e.printStackTrace();
						}						
						 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
						 return Response.ok(entity).build();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			else if(!location.equals("") && !fromDate.equals("") && !toDate.equals("")	&& interest.equals("")) 
			 // Searching Meetin Only Critaria Condition
			{
				Hashtable<String, List<String>> hashtable = new PeopleFinder().advanceSearchNew(location.split(",")[0], fromDate, toDate, userId);
				Enumeration<String> e = hashtable.keys();
				   
				   List<Friends> friendList = new ArrayList<Friends>();
					
				   while(e.hasMoreElements()) {
						String id =  e.nextElement();
						List<String> l = hashtable.get(id);
						Friends f = new Friends();
						f.setName(l.get(0));
						f.setLink(l.get(1));
						f.setIcon(l.get(2));
						friendList.add(f);
					}
					 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
					 return Response.ok(entity).build();
			} else if(!location.equals("") && fromDate.equals("") && toDate.equals("")	&& !interest.equals("")) 
			{
				Hashtable<String, List<String>> hashtable = new PeopleFinder().advanceSearch(location.split(",")[0], fromDate, toDate,interest, userId);
				Enumeration<String> e = hashtable.keys();
				   
				   List<Friends> friendList = new ArrayList<Friends>();
					
				   while(e.hasMoreElements()) {
						String id =  e.nextElement();
						List<String> l = hashtable.get(id);
						Friends f = new Friends();
						f.setName(l.get(0));
						f.setLink(l.get(1));
						f.setIcon(l.get(2));
						friendList.add(f);
					}
					 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
					 return Response.ok(entity).build();
			}else if (location.equals("") && !fromDate.equals("") && !toDate.equals("")	&& interest.equals("")) {
				Hashtable<String, List<String>> hashtable = new PeopleFinder().advanceSearch(location.split(",")[0], fromDate, toDate,interest, userId);
				Enumeration<String> e = hashtable.keys();
				  List<Friends> friendList = new ArrayList<Friends>();
					while(e.hasMoreElements()) {
						String id =  e.nextElement();
						List<String> l = hashtable.get(id);
						Friends f = new Friends();
						f.setName(l.get(0));
						f.setLink(l.get(1));
						f.setIcon(l.get(2));
						friendList.add(f);
					}
					 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
					 return Response.ok(entity).build();
		
			} 
			else if (location.equals("") && fromDate.equals("") && toDate.equals("") && !interest.equals("")) {

				Hashtable<String, List<String>> hashtable = new PeopleFinder().advanceSearchOnlyInterest(interest, userId);
				Enumeration<String> e = hashtable.keys();
				  List<Friends> friendList = new ArrayList<Friends>();
					while(e.hasMoreElements()) {
						String id =  e.nextElement();
						List<String> l = hashtable.get(id);
						Friends f = new Friends();
						f.setName(l.get(0));
						f.setLink(l.get(1));
						f.setIcon(l.get(2));
						friendList.add(f);
					}
					 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
					 return Response.ok(entity).build();
			}
			else if (location.equals("") && !fromDate.equals("") && !toDate.equals("") && !interest.equals("")) {
				System.out.println("in interest and date");
				
				Hashtable<String, List<String>> hashtable = new PeopleFinder().advanceSearchDateWithInterest(fromDate,toDate,interest, userId);
				Enumeration<String> e = hashtable.keys();
				  List<Friends> friendList = new ArrayList<Friends>();
					while(e.hasMoreElements()) {
						String id =  e.nextElement();
						List<String> l = hashtable.get(id);
						Friends f = new Friends();
						f.setName(l.get(0));
						f.setLink(l.get(1));
						f.setIcon(l.get(2));
						friendList.add(f);
					}
					 GenericEntity<List<Friends>> entity = new GenericEntity<List<Friends>>(friendList){};
					 return Response.ok(entity).build();
			}
		return null;
	}
	
	@Produces("application/xml")
	@GET
	@Path("peopletripdetail")
	public List<TripWS> getPeopleUpcomingTripDetail(@QueryParam("myuserId") int myuserId,@QueryParam("frienduserId") int frienduserId, @QueryParam("destination") String destination)
	 {
		 List tripDetailList = new PeopleFinder().getPeopleUpcomingTripDetail(myuserId, frienduserId, destination);
		 SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		 List<TripWS> finalList = new ArrayList<TripWS>();
		 User user = (User)new UserAccountDAO().getUserProfileDetails(frienduserId);
		 if(tripDetailList !=null && tripDetailList.size()>0)
		 {
			 for(int i=0;i <tripDetailList.size();i++)
			 {
				 Object[] object =(Object[])tripDetailList.get(i);
	              
	             TripWS trip = new TripWS();
	             trip.setFriendname((String)object[1]);
	             trip.setDestination((String)object[2]);
	             trip.setStartDate(sdf.format((Date)object[5]));   
	             trip.setEndDate(sdf.format((Date)object[6]));
	             trip.setFriendemail(user.getEmail()); // friend's email to send the meeting invitation
	             finalList.add(trip);
				 
			 }
		 }
		 return finalList;
	 }
	//Modified by rupal kathiriya to set template using 4 criteria for mail dated on 3rd jan 2013
	@Produces("application/xml")
	@GET
	@Path("meetinginvitation")
	public TripWS sendMeetingInvitation(@QueryParam("invitorId") Integer invitorId,  @QueryParam("friendemail") Integer friendemail,@QueryParam("friendname") String friendname, @QueryParam("invitemessage") String invitemessage,@QueryParam("location") String location, @Context HttpServletRequest request)
	{
		User user = new User();
		User user1 = new User();
		TripWS trip= new TripWS();
		List trip_list=null;
		List friend_trip_list=null;
		String user_travelling = "no";
		String friend_travelling = "no";
		String usersplit=null;
		String frSplit=null;
		try
		{
			//new TripsDAO().getCurrentTripLocation(Integer.valueOf(session.getAttribute("UserID").toString()))
			String path = request.getContextPath();
			String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
			String htmlmessage = new Mailer_Header().getMailerHeader(bannar); 
			String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/profileimage/";
			String imageName="";
			String meetinLogo =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/images/meetin_icon.png";
			
			if(invitorId !=null && invitorId.intValue() !=0)
			{
				user = (User) new UserAccountDAO().getUserProfileDetails(invitorId);
				user1 = (User) new UserAccountDAO().getUserProfileDetails(friendemail);
				//String current_location = new UserAccountDAO().getUserLocation(user.getUserId());
				 List<String> current_location = new PeopleFinder().getUserLocationOnCurrentDate(invitorId);
				 
				 if(current_location !=null && current_location.size() > 0){
					 for(int i=0;i < current_location.size();i++)
					   {
						  usersplit=current_location.get(i).split(",")[0];
						  if(usersplit.equalsIgnoreCase(location.split(",")[0])){
							  user_travelling ="yes";
						  }
					   }
				 }else{
					 user_travelling ="no";
				 }
				 List<String> friend_current_location =  new PeopleFinder().getUserLocationOnCurrentDate(friendemail);
				 
				 if(friend_current_location !=null && friend_current_location.size() > 0){
					 for(int i=0;i < friend_current_location.size();i++)
					   {
						 frSplit=friend_current_location.get(i).split(",")[0];
						  if(frSplit.equalsIgnoreCase(location.split(",")[0])){
							  friend_travelling ="yes";
						  }
					   }
				 }else{
					 friend_travelling ="no";
				 }
				if(user_travelling.equalsIgnoreCase("no") && friend_travelling.equalsIgnoreCase("no")){
					////System.out.println("if both are not travelling ");
					
					String senderName = user.getFullname();
					String subject = user.getFullname()+" would like to meet you";
					htmlmessage = htmlmessage + "  <tr><td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0'  style='background:#000; color:#ffffff; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
					"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>"+"I'm also in "+location+" and we can meet up.<br>Do email me back with your availability on "+user.getEmail()+"</td>" +
					"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
					"      <br><br>" +
					"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><br></td>" +
					"  </tr>  <tr>" +
					"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
					"  </tr></table></td>  </tr>";
					String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
					String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
					String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
					String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";

					htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
					new PeopleFinder().sendMeetingInvitation(user1.getEmail(), subject, htmlmessage,"",senderName);
				}
				if(user_travelling.equalsIgnoreCase("yes") && friend_travelling.equalsIgnoreCase("yes")){
					////System.out.println("if both are travelling ");
					 List tripDetailList = new PeopleFinder().getPeopleUpcomingTripDetail(friendemail, invitorId, location);
					 SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
					 String fdate="";
					 String todate="";
					 if(tripDetailList !=null && tripDetailList.size()>0)
					 {
						 for(int i=0;i <tripDetailList.size();i++)
						 {
							 Object[] object =(Object[])tripDetailList.get(i);
				             fdate=sdf.format((Date)object[5]);   
				             todate=sdf.format((Date)object[6]);
				       	 
						 }
					 }
					 
					 
					String senderName = user.getFullname();
					String subject = user.getFullname()+" would like to meet you";
					htmlmessage = htmlmessage + "  <tr><td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; color:#ffffff; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
					"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>"+"I'm also traveling to "+location+" between "+fdate+" to "+todate+" and we can meet up while we are there.<br><br>Do email me back with your availability on "+user.getEmail()+"</td>" +
					"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
					"      <br><br>" +
					"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><br></td>" +
					"  </tr>  <tr>" +
					"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
					"  </tr></table></td>  </tr>";
					String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
					String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
					String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
					String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";

					htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
					new PeopleFinder().sendMeetingInvitation(user1.getEmail(), subject, htmlmessage,"",senderName);
				}
				if(user_travelling.equalsIgnoreCase("yes") && friend_travelling.equalsIgnoreCase("no")){
					// //System.out.println("if user is travelling ");
					 	String senderName = user.getFullname();
						String subject = user.getFullname()+" would like to meet you";
						htmlmessage = htmlmessage + "  <tr><td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; color:#ffffff; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
						"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>"+"I'm visiting "+location+" and would like to meet you.<br>Do email me back with your availability on "+user.getEmail()+"</td>" +
						"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
						"      <br><br>" +
						"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><br></td>" +
						"  </tr>  <tr>" +
						"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
						"  </tr></table></td>  </tr>";
						String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
						String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
						String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
						String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";

						htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
						new PeopleFinder().sendMeetingInvitation(user1.getEmail(), subject, htmlmessage,"",senderName);
				}
				if(user_travelling.equalsIgnoreCase("no") && friend_travelling.equalsIgnoreCase("yes")){
					////System.out.println("if friend is travelling ");
					
					String senderName = user.getFullname();
					String subject = user.getFullname()+" would like to meet you";
					htmlmessage = htmlmessage + "  <tr><td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; color:#ffffff; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
					"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>"+"I'm available to meet you in "+location+" when you are planning to come.<br>Do email me back with your availability on "+user.getEmail() +"</td>" +
					"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
					"      <br><br>" +
					"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><br></td>" +
					"  </tr>  <tr>" +
					"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
					"  </tr></table></td>  </tr>";
					String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
					String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
					String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
					String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";

					htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
					new PeopleFinder().sendMeetingInvitation(user1.getEmail(), subject, htmlmessage,"",senderName);
				}
				//user = (User) new UserAccountDAO().getUserProfileDetails(invitorId);
				if(user !=null)
				{
					if(user.getImage() !=null && !user.getImage().equals(""))
					{
						imageName = imagePath + user.getUserId()+ "_" +user.getImage();		
					}
				}
					
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		trip.setInviteResult("send");
		return trip;
	}
	
	@Produces("application/xml")
	@GET
	@Path("userlatlong")
	
	public UserWS getUserLatLong(@QueryParam("userId") int userId, @QueryParam("destination") String destination)
	{
		
		List<String> locationList = new PeopleFinder().getUserLocationOnCurrentDate(userId);
		String currentLocation ="";
		String latlong ="";
		/** If the condition is true then user has current location on current date*/
		if(locationList !=null && locationList.size() > 0)
		{
			/**User's current location*/
			currentLocation = locationList.get(0);
			/**LoggedIn User's current Latitude/Langitude */
			latlong = new PeopleFinder().getUserLatLong(userId, currentLocation.split(",")[0]);
			
		}
		else
		{
			//currentLocation =new UserAccountDAO().getUserLocation(userId);
					
			/**LoggedIn User's default Latitude/Langitude */
			User u = (User)new UserAccountDAO().getUserProfileDetails(userId);
			latlong = u.getLocLat() + ":" +u.getLocLang();
			
			/**User's default location*/
			currentLocation = u.getLocCity();
			locationList.add(currentLocation);
			
		}
		UserWS userws = new UserWS();
		String latitude = latlong.split(":")[0];
		String longitude = latlong.split(":")[1];
		userws.setLocLat(latitude);
		userws.setLocLang(longitude);
		
		return userws;
	}

}