package com.verve.meetin.webservice;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.verve.meetin.friend.Friends;
import com.verve.meetin.friend.FriendsDAO;
import com.verve.meetin.friend.FriendsWS;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.mailer_template.SendFirstFriendRequestScheduler;
import com.verve.meetin.network.peoplefinder.ScheduleSocialNetwork;
import com.verve.meetin.user.*;
import com.verve.meetin.visitor.Visitors;
import com.verve.meetin.visitor.VisitorsDAO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.QueryParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@Path("User")
public class UserService 
{
	UserLoginDAO userdao = new UserLoginDAO();
	
	@Produces("application/xml")
	@POST
	@Path("login")
	
public UserWS getUserLogin(@HeaderParam("username") String username, @HeaderParam("password") String password, @HeaderParam("platform") String platform, @HeaderParam("validversion") String validversion, @Context HttpServletRequest request) throws Exception
	{		
		
		UserWS userws =new UserWS();
		String encryptpassword = userdao.encrypt(URLDecoder.decode(password, "UTF-8"));
		User user = new UserLoginDAO().getUserLogin(URLDecoder.decode(username, "UTF-8"), encryptpassword);
		if(user !=null){
			userws.setUserId(user.getUserId());
			userws.setLoginResult(user.getLoginResult());
			userws.setSocialURL("http://meetin.vervesys.com/mymeetin.jsp?fwdurl=http://meetin.vervesys.com/myprofile.jsp?action=profilevisitors");
			try{
			if(platform.equalsIgnoreCase("android")){
				Double double1;
				double1=Double.parseDouble(validversion);
				if(double1<1.0){
					userws.setLoginResult("Please update your application to version 1.0");
				}
			}}catch(Exception e){
				userws.setLoginResult("Please enter valid version details");
			}
			try{
				if(platform.equalsIgnoreCase("iphone")){
					Double double1;
					double1=Double.parseDouble(validversion);
					if(double1<1.0){
						userws.setLoginResult("Please update your application to version 1.0");
					}
				}}catch(Exception e){
					userws.setLoginResult("Please enter valid version details");
				}
				
				HttpSession sc = request.getSession();
				if(user.getScheduleFlag().equalsIgnoreCase("N")){
					/**
					 * Getting the Facebook, LinkedIn, Gmail etc... profile for loggedin user. 
					 */
					new ScheduleSocialNetwork().startscheduleScoialNetwork(user.getUserId(), sc.getId());
					new UserAccountDAO().updateUserScheduleFlagById(user.getUserId(), "Y");
				}
		}
//		http://meetin.vervesys.com/mymeetin.jsp?fwdurl=http://meetin.vervesys.com/myprofile.jsp?action=profilevisitors
		else
		{
			userws.setLoginResult("invalid");	
		}
		return userws;
	}
	
	
	@Produces("application/xml")
	@POST
	@Path("signup")
	
	public UserWS createUserAccount(@HeaderParam("fullname") String fullname, @HeaderParam("email") String email, @HeaderParam("password") String password, @HeaderParam("dob") String dob,
									@HeaderParam("city") String city, @HeaderParam("latitude") String latitude, @HeaderParam("langitude") String langitude,
									@HeaderParam("gender") String gender,@Context HttpServletRequest request) throws Exception
	{
				
		Date bdate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		String encryptpassword = userdao.encrypt(URLDecoder.decode(password, "UTF-8"));
		UserWS userws = new UserWS();
		UserAccountDAO oUserAccountDAO = new UserAccountDAO();
		String[] email1=new String[1];
		email1[0]=URLDecoder.decode(email, "UTF-8");
		
		System.out.println("Passed email in web service :: " + email1[0]);
		System.out.println("email1 :: " + email1);
		//code changes by lokesh
		//User user = new User(fullname, email, encryptpassword,bdate,country,state,street,city,pincode,latitude,langitude,new Date(),gender);
		
		if(!oUserAccountDAO.isEmailRegistered(URLDecoder.decode(email, "UTF-8")))
		{
			try {
			bdate =  sdf.parse(URLDecoder.decode(dob, "UTF-8"));	
			User user = new User(URLDecoder.decode(fullname, "UTF-8"), URLDecoder.decode(email, "UTF-8"), encryptpassword,bdate,URLDecoder.decode(city, "UTF-8"),
								 latitude,langitude, new Date(),URLDecoder.decode(gender, "UTF-8"));
			int record_id = oUserAccountDAO.createUserAccount(user);
		 
			if(record_id > 0)
			{
				userws.setResultId(record_id);
			}
			
				
				boolean flag=false;
				String[] result=email.split(",");
				////System.out.println(result);
				FriendsWS friendws = new FriendsWS();
				String path = request.getContextPath();
				String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
				///mailer format 
				String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
				
				//body portion of message 
				htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
					"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>Dear "+ URLDecoder.decode(fullname, "UTF-8") +",</td>" +
					"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><br><br>You have successfully registered on meetIn, you now have the power to find, contact and meet your friends across the globe while you or they are traveling." +
					"      <br><br>You can also download our mobile app (iPhone and Android) from the store.<br><br>Thank you for joining meetIn.<br><br>Happy Traveling!!!" +
					"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><br>Regards,</td>" +
					"  </tr>  <tr>" +
					"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'>meetIn Team</td>" +
					"  </tr></table></td>  </tr>";	 
			
				String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
				String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
				String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
				String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
				
				htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

				new InviteFriends().postMails(email1, "Welcome to meetIn: Your central contact finder!!!", htmlmessage, "");
				
				/** Here 1 is the default mymeetin user id and it will be added as friends when user register in the application */
				Friends friend = new Friends(1, record_id,"Pending", new Date());
				new FriendsDAO().setFriendRequest(friend);
				
				/** Start the scheduler to send first friend request email */
				String header = new Mailer_Header().getMailerHeader(bannar);
				String footer = new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
				SendFirstFriendRequestScheduler s = new SendFirstFriendRequestScheduler();
				s.SendFirstFriendRequestEmail(record_id, "Hurray! You have your first friend request in meetIn!", header, footer);

				
				} catch (ParseException e) {
					
					e.printStackTrace();
				}
		}
		else
		{
				userws.setErrorStatus("emailregistered");
				userws.setErrorMessage("This email is already registered with the application");
		}
		return userws;
		
	}
	
	@Produces("application/xml")
	@POST
	@Path("postlogin")
	
	public UserWS createPostLoginforWebservice(@HeaderParam("userId") Integer userId,@HeaderParam("profileImage") String profile_image, @HeaderParam("aboutMe") String about_me,
			@HeaderParam("company") String company,@HeaderParam("jobTitle") String jobTitle,@HeaderParam("industry") String industry,@HeaderParam("degree") String degree,@HeaderParam("country") String country,
			@HeaderParam("state") String state, @HeaderParam("street") String street,@HeaderParam("city") String city,@HeaderParam("pincode") String pincode,@HeaderParam("latitude") String latitude,@HeaderParam("langitude") String langitude,
			@HeaderParam("otherspecify") String otherspecify, @HeaderParam("gender") String gender,@HeaderParam("dob") String dob) throws Exception
	{
		
		Date bdate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		
		////System.out.println("image NAME from create postLoginwebservice " + profile_image);
		
		try {
			
			bdate =  sdf.parse(URLDecoder.decode(dob, "UTF-8"));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		User user = new User(userId, URLDecoder.decode(about_me, "UTF-8"),URLDecoder.decode(company, "UTF-8"),
				 true,URLDecoder.decode(jobTitle, "UTF-8"),true,URLDecoder.decode(industry, "UTF-8"),URLDecoder.decode(degree, "UTF-8"),true,
				 URLDecoder.decode(country, "UTF-8"),URLDecoder.decode(state, "UTF-8"),URLDecoder.decode(street, "UTF-8"),URLDecoder.decode(city, "UTF-8"),
				 URLDecoder.decode(pincode, "UTF-8"),URLDecoder.decode(latitude, "UTF-8"),URLDecoder.decode(langitude, "UTF-8"),URLDecoder.decode(otherspecify, "UTF-8"),URLDecoder.decode(gender, "UTF-8"), bdate);
		
		int record_id= new UserAccountDAO().createPostLoginforWebservice(user);
		UserWS userws = new UserWS();
		
		if(record_id > 0){
			userws.setResultId(record_id);
		}
		
	   return userws;
	}
	@Produces("application/xml")
	@POST
	@Path("updateprofile")
	
	public UserWS updateUserProfile(@HeaderParam("userId") Integer userId,@HeaderParam("profileImage") String profile_image, @HeaderParam("aboutMe") String about_me,
			@HeaderParam("company") String company,@HeaderParam("companyVisible") boolean companyVisible, @HeaderParam("jobTitle") String jobTitle,@HeaderParam("jobVisible") boolean jobVisible, @HeaderParam("industry") String industry,@HeaderParam("degree") String degree,@HeaderParam("degreeVisible") boolean degreeVisible, @HeaderParam("country") String country,
			@HeaderParam("state") String state, @HeaderParam("street") String street,@HeaderParam("city") String city,@HeaderParam("pincode") String pincode,@HeaderParam("latitude") String latitude,@HeaderParam("langitude") String langitude,@HeaderParam("otherspecify") String otherspecify, @HeaderParam("gender") String gender,@HeaderParam("dob") String dob) throws Exception
	{
		
		Date bdate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		
		try {
			
			bdate =  sdf.parse(URLDecoder.decode(dob, "UTF-8"));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		User user = new User(userId,URLDecoder.decode(profile_image, "UTF-8"),URLDecoder.decode(about_me, "UTF-8"),URLDecoder.decode(company, "UTF-8"),
				 companyVisible,URLDecoder.decode(jobTitle, "UTF-8"),jobVisible,URLDecoder.decode(industry, "UTF-8"),URLDecoder.decode(degree, "UTF-8"),degreeVisible,
				 URLDecoder.decode(country, "UTF-8"),URLDecoder.decode(state, "UTF-8"),URLDecoder.decode(street, "UTF-8"),URLDecoder.decode(city, "UTF-8"),
				 URLDecoder.decode(pincode, "UTF-8"),URLDecoder.decode(latitude, "UTF-8"),URLDecoder.decode(langitude, "UTF-8"),URLDecoder.decode(otherspecify, "UTF-8"),URLDecoder.decode(gender, "UTF-8"),bdate);
		
		int record_id= new UserAccountDAO().createPostLoginforWebservice(user);
		UserWS userws = new UserWS();
		
		if(record_id > 0){
			userws.setResultId(record_id);
		}
		
	   return userws;
	}
	
	@Produces("text/plain")
	@POST
	@Path("imageupload")

	public String uploadUserImage(@Context HttpServletRequest request) throws IOException {
		 String resultStatus="fail";
		 UserWS userws = new UserWS();
		 if (ServletFileUpload.isMultipartContent(request)) {
			 FileItemFactory factory = new DiskFileItemFactory();
		     ServletFileUpload upload = new ServletFileUpload(factory);
		     List items=null;
		     try {
		    	 items = upload.parseRequest(request);
		     } catch (FileUploadException e) {
		      e.printStackTrace();
		     }
		     if(items!=null) {
		         Iterator iter = items.iterator();
		         while (iter.hasNext()) {
			          FileItem item = (FileItem) iter.next();
			          if(!item.isFormField() && item.getSize() > 0) {
				           try {
				        	   String fileName=null;
				       		   fileName = item.getName().substring(item.getName().lastIndexOf("\\")+1,item.getName().length());
				        	  User user=new User(); 
				       		//String fileName=null;		
							////System.out.println("imagePath"+user.getImage());
							////System.out.println("**************"+user.getUserId());
							//request.getSession().getServletContext().getRealPath("")+"/"+"images/";
				        	 // //System.out.println("******"+_item.getName().split("_")[0]);
							String path=request.getSession().getServletContext().getRealPath("")+"/"+"profileimage/";
							////System.out.println("PATH     ******** "+path);
							File[] files1=finder(path,String.valueOf(fileName.split("_")[0]));
							////System.out.println("File Number  : " +files1.length);
							
							if(files1.length!=0){
										for(int i=0;i<files1.length;i++)
				    					{
											////System.out.println("List"+files1[i]);
											//if(!user.getImage().equals(files1[i].getName().toString())){
												files1[i].delete();
											/*}else{
												fileName=files1[i].getName();
											}*/
					    				}
									}
								////System.out.println("fileName  "+fileName);
				       		   item.write(new File(request.getRealPath("/")+"profileimage/"+fileName));
				        	   ////System.out.println(request);
				        	   //System.out.println("%%%%%%%%%"+request.getRealPath("/")+"profileimage/"+fileName);
				        	   
				        	   int userId = 0;
				        	   try {
				        		   userId = Integer.parseInt(fileName.split("_")[0]);
				        	   } catch (Exception e) {
				        		   e.printStackTrace();
				        		   userId = 0;
				        	   
				        	   }
				        	   
				        	   if (userId > 0) {
				        		   user = new User(userId, fileName);
				      		
				        	   		int record_id = new UserAccountDAO().updateUserProfileImageforWebservice(user);
				        	   		if (record_id == 0) {
				        	   			resultStatus="failure";
				        	   			userws.setStatus(resultStatus);
				        	   		 
				        	   			return "success";
				        	   		}
				        	   }
				        	   
				           } catch (Exception e) {
				        	   e.printStackTrace();
				           }
				           
				           resultStatus="success";
			          }
		         }
		     }
		 }
		 
		 userws.setStatus(resultStatus);
		 
		 return "success";
	}
	
	@Produces("application/xml")
	@GET
	@Path("getprivacysetting")
	
	public UserWS getUserPrivacySettings(@QueryParam("userId") int userid)
	{
		////System.out.println("privacy SEtting");
		UserWS userws =new UserWS();
		User user = new UserPrivacySettingDAO().getUserPrivacySettings(userid);
		if(user != null){
			userws.setCompanyVisible(user.getCompanyVisible());
			userws.setDegreeVisible(user.getDegreeVisible());
			userws.setJobVisible(user.getJobVisible());
			userws.setEventAlert(user.getEventAlert());
			userws.setMonthlyalert(user.getMonthlyalert());
		}
		
		return userws;
	}
	
	@Produces("application/xml")
	@POST
	@Path("setprivacysetting")
	public UserWS updateUserPrivacySetting(@HeaderParam("userId") int userid, @HeaderParam("companyVisible") boolean companyVisible, @HeaderParam("jobVisible") boolean jobVisible, @HeaderParam("degreeVisible") boolean degreeVisible,  @HeaderParam("eventAlert") boolean eventAlert,  @HeaderParam("monthlyAlert") boolean monthlyAlert)
	{
		////System.out.println("set privacy");
		int update_record_id = 0 ;
		UserWS userws =  new UserWS();
		update_record_id = new UserPrivacySettingDAO().updateUserPrivacySetting(userid, companyVisible, jobVisible, degreeVisible,eventAlert, monthlyAlert);
		
		if(update_record_id > 0){
			userws.setResultId(update_record_id);	
		}
		return userws;
	}

	
	/*
	@Produces("application/xml")
	@GET
	@Path("setprivacysetting")
	
	public UserWS updateUserPrivacySetting(@QueryParam("userId") int userid, @QueryParam("companyVisible") boolean companyVisible, @QueryParam("jobVisible") boolean jobVisible, @QueryParam("degreeVisible") boolean degreeVisible)
	{
		int update_record_id = 0 ;
		UserWS userws =  new UserWS();
		update_record_id = new UserPrivacySettingDAO().updateUserPrivacySetting(userid, companyVisible, jobVisible, degreeVisible);
		
		if(update_record_id > 0){
			userws.setResultId(update_record_id);	
		}
		
		return userws;
	}*/

	//Added by Rupal Kathiriya to get image files from server folder dated on 21 july 2012
	public File[] finder(String dirName,final String userId)
		{
		////System.out.println("dirName:: "+dirName);
	        File dir = new File(dirName);
	        return dir.listFiles(new FilenameFilter() 
	        { 
	                 public boolean accept(File dir, String filename)
	                    { 
	                	 	boolean fileEx=filename.startsWith(userId);
	                	 	return fileEx; 
	                	}
	        } );

	    }
	
	@Produces("application/xml")
	@GET
	@Path("getuserprofile")
	
	public UserWS getUserProfileDetails(@QueryParam("userId") int userId,@Context HttpServletRequest request, @QueryParam("visitorId") int visitorId)
	{
		
		User user = (User)new UserAccountDAO().getUserProfileDetails(userId);
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
		UserWS userws = new UserWS();
		
		String imagePath ="";
		String gender ="";
		String aboutme ="";
		String company ="";
		String degreecollege="";
		String birthdate ="";
		String email="";
		String fullname="";
		String industry ="";
		String jobtitle= "";
		String locLat ="";
		String locLong ="";
		String otherspecify ="";
		String city ="";
		String state ="";
		String country ="";
		String street ="";
		String pincode="";
		UserAction userAction=new UserAction();	
			
		if(user !=null)
		{
			if(user.getAboutMe() !=null && !user.getAboutMe().equals(""))
			{
				String[] splitString = user.getAboutMe().toString().split("\n");
				StringBuffer sb = new StringBuffer();
				
				for(int i=0; i < splitString.length; i++)
				{
					sb.append(splitString[i]).append(" ");
				}
				
				aboutme = sb.toString();
			}
			else
			{
				aboutme = " ";
			}
			if(user.getImage() !=null && !user.getImage().equals(""))
			{
				
			imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/profileimage/"+user.getImage();
			}
			else
			{
				if(user.getGender().equalsIgnoreCase("male"))
				{
					imagePath =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath() +"/images/male.png";
				}
				else
				{
					imagePath =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath() +"/images/female.png";
				}
			}
			if(user.getCompany() !=null && !user.getCompany().equals(""))
			{
				company =user.getCompany().toString();
			}
			else
			{
				company =" ";
			}
			if(user.getDegreeCollege() !=null && !user.getDegreeCollege().equals(""))
			{
				degreecollege =user.getDegreeCollege().toString();
			}
			else
			{
				degreecollege =" ";
			}
			if(sdf.format(user.getDob()) !=null && !sdf.format(user.getDob()).equals(""))
			{
				birthdate = sdf.format(user.getDob()).toString();
			}
			else
			{
				birthdate =" ";
			}
			if(user.getEmail() !=null && !user.getEmail().equals(""))
			{
				email = user.getEmail().toString();
			}
			else
			{
				email =" ";
			}
			if(user.getFullname() !=null && !user.getFullname().equals(""))
			{
				fullname = user.getFullname();
			}
			else
			{
			    fullname =" ";	
			}
			if(user.getIndustry() !=null && !user.getIndustry().equals(""))
			{
				industry =user.getIndustry().toString();
			}
			else
			{
				industry =" ";
			}
			if(user.getJobTitle() !=null && !user.getJobTitle().equals(""))
			{
				jobtitle = user.getJobTitle().toString();
			}
			else
			{
			   jobtitle =" ";	
			}
			if(user.getLocLat() !=null && !user.getLocLat().equals(""))
			{
				locLat = user.getLocLat().toString();
			}
			else
			{
			   locLat = " ";	
			}
			if(user.getLocLang() !=null && !user.getLocLang().equals(""))
			{
				locLong = user.getLocLang().toString();
			}
			else
			{
			   locLong = " ";	
			}
			if(user.getOtherSpecify() !=null && !user.getOtherSpecify().equals(""))
			{
				otherspecify =user.getOtherSpecify().toString();
			}
			else
			{
				otherspecify =" ";
			}
			if(user.getGender() !=null && !user.getGender().equals(""))
			{
				gender = user.getGender().toString();
			}
			else
			{
				gender =" ";
			}
			if(user.getLocCity() !=null && !user.getLocCity().equals(""))
			{
				city = user.getLocCity().toString();
			}
			else
			{
				city =" ";
			}
			if(user.getLocState() !=null && !user.getLocState().equals(""))
			{
				state =user.getLocState().toString();
			}
			else
			{
				state = " ";
			}
			if(user.getLocCountry() !=null && !user.getLocCountry().equals(""))
			{
				country =user.getLocCountry().toString();
			}
			else
			{
				country = " ";
			}
			
			if(user.getLocStreet() !=null && !user.getLocStreet().equals(""))
			{
				street =user.getLocStreet().toString();
			}
			else
			{
				street = " ";
			}
			if(user.getLocPin() !=null && !user.getLocPin().equals(""))
			{
				pincode =user.getLocPin().toString();
			}
			else
			{
				pincode = " ";
			}
			
			userws.setAboutMe(aboutme);
			userws.setGender(gender);
			userws.setImage(imagePath);
			userws.setCompany(company);
			userws.setCompanyVisible(user.getCompanyVisible());
			userws.setDegreeCollege(degreecollege);
			userws.setDegreeVisible(user.getDegreeVisible());
			userws.setBirthdate(birthdate);
			userws.setEmail(email);
			userws.setFullname(fullname);
			userws.setIndustry(industry);
			userws.setJobTitle(jobtitle);
			userws.setJobVisible(user.getJobVisible());
			userws.setLocCity(city);
			userws.setLocCountry(country);
			userws.setLocPin(pincode);
			userws.setLocState(state);
			userws.setLocStreet(street);
			userws.setLocLat(locLat);
			userws.setLocLang(locLong);
			userws.setOtherSpecify(otherspecify);
			
			
		}
		
		Visitors visitors =  new Visitors(visitorId, userId, new Date());
		new VisitorsDAO().setProfileVisitor(visitors);

		return userws;
	}
	
	@Produces("application/xml")
	@POST
	@Path("changepassword")
	
	public UserWS changeUserPassword(@HeaderParam("userId") int userId,@HeaderParam("oldpassword") String oldpassword,@HeaderParam("newpassword") String newpassword) throws Exception
	{
		int returnId = 0;
		UserWS userws = new UserWS();
		returnId = new UserAccountDAO().changeUserPassword(userId, URLDecoder.decode(oldpassword, "UTF-8"), URLDecoder.decode(newpassword, "UTF-8"));
		
		if(returnId > 0)
		{
			userws.setStatus("password changed");
		}
		else
		{
			userws.setStatus("invalid oldpassword");
		}
		return userws;
	}
	
	@Produces("application/xml")
	@POST
	@Path("forgotpassword")
	
	public UserWS forgotpassword(@HeaderParam("email") String email,@Context HttpServletRequest request) throws Exception
	{
		boolean emailexist =false;
		String resetPassword ="";
		UserWS userws = new UserWS();
		String status = "Invalid Email";
		String decodedEmail  = URLDecoder.decode(email, "UTF-8");
		
		emailexist = new UserAccountDAO().isEmailRegistered(decodedEmail);
			
		if(emailexist)
		{
				resetPassword = new ForgotPasswordDAO().generateNewPassword(decodedEmail);
				
				if(resetPassword !=null && !resetPassword.equals(""))
				{
					String fromEmail="";
					
					String path = request.getContextPath();
					String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
					
					String htmlmessage = new Mailer_Header().getMailerHeader(bannar); 
					
					htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
					
					"    <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><br>We have received a new password generation request from you." +
					"      <br>Your new password is: "+resetPassword+"<br>We suggest you login with your registered email id and change your password immediately after logging in with this new password." +
					"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><br>Keep your trips updated so your friends can also get alerts and contact you.</td>" +
					"  </tr>  <tr>" +
					"    " +
					"  </tr></table></td>  </tr>";	 
				
					String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
						String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
						String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
						String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
							
							
				htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

					new ForgotPasswordDAO().sendGenereatedPasswordByEmail(decodedEmail, "meetIn: Your request for new password!!!", htmlmessage, fromEmail);
					status ="New Password Sent";
					userws.setStatus(status);
				}
		}
		else
		{
				userws.setStatus(status);
				
		}
		
		
		
		return userws;
	}
	
	
}
