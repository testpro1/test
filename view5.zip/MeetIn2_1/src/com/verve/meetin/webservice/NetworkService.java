package com.verve.meetin.webservice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import com.verve.meetin.network.*;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;

@Path("Network")
public class NetworkService 
{
	@Produces("application/xml")
	@GET
	@Path("getsocialnetworklist")
	public List<Networkmaster> getSocialNetworkSites(@QueryParam("userId") int userId,@Context HttpServletRequest request){
		List networkList = new NetworkDAO().getSocialNetworkSites();
		String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/";
		List<Networkmaster> finalList = new ArrayList<Networkmaster>();
		if(networkList !=null && networkList.size() >0)
		{
			for(int i=0;i < networkList.size();i++)
			{
				  Networkmaster network = new Networkmaster();
	              network = (Networkmaster)networkList.get(i);
	              boolean result = new NetworkDAO().checkUserSocialNetwork(userId,network.getSocialNetworkSiteId());
	              Networkmaster networkmaster = new Networkmaster();
	              if(result)
	              {
	            	network.setResult(1);  
	              }
	              else
	              {
	            	network.setResult(0);
	              }
	              networkmaster.setSocialNetworkSiteId(network.getSocialNetworkSiteId());
	              networkmaster.setSocialNetworkSiteName(network.getSocialNetworkSiteName());
	              networkmaster.setSocialNetworkSiteIcon(imagePath+network.getSocialNetworkSiteIcon());
	              networkmaster.setResult(network.getResult());
	              finalList.add(networkmaster);
			}
		}
		
		return finalList;	
	}
	
	@Produces("application/xml")
	@GET
	@Path("usersocialnetworklist")
	public List<Networkmaster> getUserSocialNetworkSitesByUserId(@QueryParam("userId") int userId,@Context HttpServletRequest request)
	{
		List resultList = new NetworkDAO().getUserSocialNetworkSitesByUserId(userId);
		List<Networkmaster> finalList = new ArrayList<Networkmaster>();
		Iterator itr= resultList.iterator();
		String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/";
		while(itr.hasNext())
		{
			Object[] object = (Object[])itr.next();
			Networkmaster networkmaster = new Networkmaster();
			networkmaster.setSocialNetworkSiteName((String)object[0]);
			networkmaster.setSocialNetworkSiteIcon(imagePath+(String)object[1]);
			finalList.add(networkmaster);
		}
		return finalList;
	}
	
	@Produces("application/xml")
	@GET
	@Path("setusersocialnetwork")
	public Networkmaster setUserSocialNetworkSite(@QueryParam("userId") int userId,@QueryParam("socialsiteid") int socialsiteid,@QueryParam("accesstoken") String accesstoken)
	{
		 Usernetworks usernetwork = new Usernetworks(userId, socialsiteid, "", "",accesstoken);
		 int result = new NetworkDAO().setUserSocialNetworkSite(usernetwork);
		 Networkmaster network = new Networkmaster();
		 if(result > 0)
		 {
			 network.setSocialNetworkSiteId(result);
		 }
		 
		 return network;
	}
	
	@Produces("application/xml")
	@POST
	@Path("removeusersocialnetwork")
	public Networkmaster removeUserSocialNetworkSite(@HeaderParam("userId") int userId,@HeaderParam("socialsiteid") int social_site_id)
	{
		int row = new NetworkDAO().removeUserSocialNetworkSite(userId, social_site_id);
		
		/**
		 * Remove the social network friend list from dummy table for logged in user. 
		 */
			new SocialNetworkDAO().deleteSocialDummyData(userId, social_site_id);
			
		Networkmaster network = new Networkmaster();
		if(row > 0)
		{
			network.setResult(0);
		}
		return network;
	}

}
