package com.verve.meetin.webservice;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import com.verve.meetin.interest.Interest;
import com.verve.meetin.interest.InterestDAO;
import com.verve.meetin.interest.Interestmaster;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.QueryParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("Interest")
public class InterestService 
{
	@Produces("application/xml")
	@POST
	@Path("setuserinterest")
	public Interestmaster setUserInterest(@HeaderParam("userId") int userId, @HeaderParam("interestId") String interestId) throws Exception
	{
		@SuppressWarnings("unused")
		String result ="";
		String[] interestArray = URLDecoder.decode(interestId, "UTF-8").split("_");
		for(int i=0 ;i < interestArray.length;i++)
		{
			Interest interest = new Interest(userId,Integer.parseInt(interestArray[i]));
			new InterestDAO().setUserInterest(interest);	
		}
		Interestmaster interest = new Interestmaster();
		interest.setDescription("success");
		return interest;
	}
   
	@Produces("application/xml")
	@GET
	@Path("getinterest")
	public List<Interestmaster> getInterest(){
		
		return  new InterestDAO().getInterest();		
	}
	
	@Produces("application/xml")
	@GET
	@Path("getuserinterest")
	public List<Interestmaster> getUserInterest(@QueryParam("userId") int userId)
	{
		List resultList = new InterestDAO().getUserInterest(userId);
		List<Interestmaster> finalList = new ArrayList<Interestmaster>();
		
		if(resultList !=null && resultList.size() >0)
		{
			for(int i=0; i < resultList.size();i++)
			{
				Interestmaster interest = new Interestmaster();
				Object[] object = (Object[])resultList.get(i);
				interest.setInterestId((Integer)object[0]);
				interest.setName((String)object[1]);
				finalList.add(interest);
			}
		}
		
		return finalList;
	}
	
	@Produces("application/xml")
	@POST
	@Path("updateuserinterest")
	
	public Interestmaster updateUserInterest(@HeaderParam("userId") int userId, @HeaderParam("InterestId") String InterestId) throws Exception
	{
		String result ="";
		String[] interestArray = URLDecoder.decode(InterestId, "UTF-8").split("_");
		int countResult =0;
		Interestmaster interestmaster =null;
		if(interestArray !=null && interestArray.length > 0)
		{
			countResult = new InterestDAO().removeUserInterest(userId);
					
				for(int i=0 ;i < interestArray.length;i++)
				{
					Interest interest = new Interest(userId,Integer.parseInt(interestArray[i]));
					new InterestDAO().setUserInterest(interest);	
				}
			
		    	
			interestmaster = new Interestmaster();
			interestmaster.setDescription("success");
			
		}
		
		return interestmaster;
	}
}
