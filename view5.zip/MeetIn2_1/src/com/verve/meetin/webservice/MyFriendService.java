package com.verve.meetin.webservice;


import java.net.URLDecoder;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;

import com.verve.meetin.foursquare.foursquareDemo;
import com.verve.meetin.friend.Friends;
import com.verve.meetin.friend.FriendsDAO;
import com.verve.meetin.friend.FriendsWS;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.gmail.GmailFriends;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;
import com.verve.meetin.user.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.QueryParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;

import org.apache.commons.codec.net.URLCodec;

@Path("MyFriend")
public class MyFriendService {

	@POST
	@Path("setfriendrequest")
	@Produces("application/xml")

	public FriendsWS setFriendRequest(@HeaderParam("useridfrom") Integer useridfrom, @HeaderParam("useridto") Integer useridto,@Context HttpServletRequest request) throws MessagingException
	{
		Friends friend = new Friends(useridfrom, useridto,"Pending", new Date());
		FriendsWS friendws = new FriendsWS();
		int friend_request_id = new FriendsDAO().setFriendRequest(friend);
		
		if(friend_request_id > 0)
		{
			friendws.setRelationshipId(friend_request_id);
			 List<String> list =  new FriendsDAO().retrieveEmailId(useridto);
		     List<String> list2=new FriendsDAO().retrieveName(useridfrom);
		     String femailId ="";
		     String username="";
		     for(int j=0;j<list.size();j++)
		     {
		    	 femailId = list.get(j);
		    	 ////System.out.println("email id "+ femailId);
		     }
		     for(int k=0;k<list2.size();k++)
		     {
		    	 username = list2.get(k);
		    	 ////System.out.println("username "+ username);
		     }
		     
			String path = request.getContextPath();
		   	String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
		   		///mailer format 
		   	String htmlmessage = new Mailer_Header().getMailerHeader(bannar);

			htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
					
					"    <tr><td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><br> "+username+" has sent you friends request in meetIn." +
					"      <br><br>Login to your account to see their profile and take further action on this request.<br><br>Keep your trips updated so your friends can also get alerts and contact you." +
					"</td>  </tr>   " +
					"  </table> </td>  </tr>";	 	     
		    
			String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
			String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
			String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
			String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
			
				htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

				new InviteFriends().postMail(femailId,"meetIn friend add request", htmlmessage,"");
		}
		
	   return friendws;
	}
	
	// Added by rupal kathiriya to get allfriends dated on 19th jan 2013
	@GET
	@Path("viewallfriend")
	@Produces("application/xml")
	public static List<UserWS> viewAllFriends(@QueryParam("userId") int userId,@Context HttpServletRequest request)
	{
		//System.out.println("hello");
		SocialNetworkDAO dao=new SocialNetworkDAO();
		List<UserWS> finalList1= new ArrayList<UserWS>();
		List list1= dao.getAllSocialFriends(userId);
		DateFormat df = new SimpleDateFormat("dd MMM yyyy 'at' hh:mm 'Hrs' zzz");
		//System.out.println("size:: "+list1.size());
		 
		List meetinfriendList = new FriendsDAO().viewMeetInFriends(userId);
		
		String profile_path = "profile_page.jsp";
		//int id=0;
		
		//System.out.println("Addd size:: "+list1.size());
		String profileUrl = "";
		try{
		if(list1 !=null && list1.size() >0)
		{
			
			for(int i=0 ;i<list1.size();i++){
				UserWS userWS=new UserWS();
				Object[] object=(Object[])list1.get(i);
				userWS.setFullname(String.valueOf(object[1]));
				userWS.setLocCity(String.valueOf(object[4]));
				profileUrl = (object[2]== null ? "(null)" : String.valueOf(object[2]));
				userWS.setProfilelink(profileUrl);
				userWS.setSocialIcon(String.valueOf(object[7]));
				String text = df.format(object[8]);
				userWS.setUpdateOn(String.valueOf("Last updated on "+text));
				userWS.setResultString("other");
				userWS.setRelationId("0");
				userWS.setImage(String.valueOf(object[3]));
				System.out.println(String.valueOf(object[3]));
				finalList1.add(userWS);
			}
			//System.out.println("hello");
		}
		
		
		//Author Dharam Chag
		//Changes done on 17-05-2013
		// including foursquare checkin friends into list from database
		
		List fourSquareCheckin = new foursquareDemo().getFourSquareCheckInFriends(userId);
		System.out.println("checkin size "+fourSquareCheckin.size());
		if(fourSquareCheckin != null && fourSquareCheckin.size() > 0)
		{
			for (int i = 0; i < fourSquareCheckin.size(); i++) 
			{
				UserWS userWS = new UserWS();
				Object[] object=(Object[])fourSquareCheckin.get(i);
				userWS.setFullname(String.valueOf(object[1]));
				userWS.setLocCity(String.valueOf(object[2]));
				userWS.setProfilelink("");
				userWS.setSocialIcon("images/foursq_chekin.png");
				userWS.setUpdateOn("");
				userWS.setResultString("other");
				userWS.setRelationId("0");
				userWS.setImage(String.valueOf(object[6]));
				finalList1.add(userWS);
			}
		}
		
		
		
		if(meetinfriendList !=null && meetinfriendList.size() >0)
	       {
			int id1=0;
	    	   for(int j=0;j < meetinfriendList.size();j++)
	    	   {
	    		   
				   UserWS userWS=new UserWS();
	    		   Object[] object1 = (Object[])meetinfriendList.get(j);
	    		   try{
	    			   com.verve.meetin.friend.Friends friend =(com.verve.meetin.friend.Friends)new FriendsDAO().checkFriendRequest(userId, (Integer)object1[0]);
						id1=friend.getRelationshipId();
						}catch(Exception e11){
							id1=0;
						}
						try{
							if(id1==0){
								userWS.setResultString("other");
								userWS.setRelationId("0");
							}else{
								userWS.setResultString("approve");
								userWS.setRelationId(String.valueOf(id1));
							}
						}catch(Exception e12){
								userWS.setResultString("other");
								userWS.setRelationId("0");
						}
					userWS.setFullname(String.valueOf(object1[1]));
					userWS.setLocCity(String.valueOf(object1[2]));
					userWS.setProfilelink(profile_path+"?id=" +(Integer)object1[0]);
					userWS.setSocialIcon("images/meetin_icon.png");
					userWS.setUpdateOn("");	
					
					String imagePath =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
					String imageName=null;
					if(object1[3] != null && !((String) object1[3]).equals(""))
					  {
					   	imageName = imagePath + "/" + (String)object1[3];
					   //	System.out.println("getting friends from base location  "+imageName);
					   	userWS.setImage(imageName);
					  }
					 else
		    		   {
		    			   if(((String)object1[4]).equalsIgnoreCase("Male"))
		    			   {
		    				   userWS.setImage(imagePath+"/images/male.png");
		    				   //finalResultList.add("images/male.png");   
		    			   }
		    			   else
		    			   {
		    				   userWS.setImage(imagePath+"/images/female.png");
		    				   //finalResultList.add("images/female.png");
		    			   }
		    		   }
					
					
					
					finalList1.add(userWS);
	    		}
	       }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return finalList1;
	}
	@GET
	@Path("pendingrequestcount")
	@Produces("application/xml")
	public FriendsWS getUserPendingRequestCount(@QueryParam("userId") int userId)
	{
		Long requestCount = new FriendsDAO().getUserPendingRequestCount(userId);
		FriendsWS friend = new FriendsWS();
		friend.setPendingrequestCount(requestCount);
		
		return friend;
		
	}
	  
	@GET
	@Path("pendingrequest")
	@Produces("application/xml")
	 
	public Response getPendingFriendRequest(@QueryParam("userId") Integer userId)
	{
	   List pendingList = new FriendsDAO().getPendingFriendRequest(userId);
	   List<FriendsWS> list = new ArrayList<FriendsWS>();
	   
	   List<Object> list1 = new ArrayList<Object>();
	   for(int i =0 ; i < pendingList.size();i++)
	   {
		   Object[] object =(Object[])pendingList.get(i);
		   FriendsWS friendws = new FriendsWS();
		   friendws.setFullname((String)object[1]);
		   friendws.setRelationshipId((Integer)object[0]);
		   friendws.setUserid((Integer)object[2]);
		   list.add(friendws);
	   }
	   
	   GenericEntity<List<FriendsWS>> entity = new GenericEntity<List<FriendsWS>>(list){};
	   return Response.ok(entity).build();
	   			
	}
	
	@POST
	@Path("approverequest")
	@Produces("application/xml")
	public FriendsWS approveOrRejectFriendRequest(@HeaderParam("requestId") String requestId, @HeaderParam("requestTaken") String requestTaken,@Context HttpServletRequest request) throws MessagingException
	{
	   ////System.out.println("request Id "+requestId);
	   
		 int resultID = 0;
		   FriendsWS friendws = new FriendsWS();
		   if(!requestTaken.equals("") && requestTaken.equals("Approve"))
		   {
			  resultID = new FriendsDAO().approveFriendRequest(Integer.parseInt(requestId));	   
		   }
		   else if (!requestTaken.equals("") && requestTaken.equals("Reject"))
		   {
			   resultID = new FriendsDAO().rejectFriendRequest(Integer.parseInt(requestId));
		   }
		   if(resultID > 0 && !requestTaken.equals("") && requestTaken.equals("Approve"))
		   {
			   friendws.setResultId(resultID);
			   
			   List<String> list1 =  new FriendsDAO().getFriendsIDs(Integer.parseInt(requestId));
		       ////System.out.println(list1.size());
			     String femailId ="";
			     for(int j=0;j<list1.size();j++)
			     {
			    	 femailId = String.valueOf(list1.get(j));
			    	
			     }
			     
			     System.out.println(femailId);
			     /*List<String> list2 =  new FriendsDAO().getFriendsIDs(Integer.parseInt(requestId));
			     String friendname1 ="";
			     for(int j=0;j<list2.size();j++)
			     {
			    	 friendname1 = String.valueOf(list2.get(j));
			    	 
			     }*/
			     //System.out.println("friendname1"+friendname1);
			     List<String> listuser =  new FriendsDAO().getUserIds(Integer.parseInt(requestId));
			     
			     String userId ="";
			     for(int j=0;j<listuser.size();j++)
			     {
			    	 userId = String.valueOf(listuser.get(j));
			     }
			     System.out.println("femailId  "+userId);
			     
			     List<String> list3 =  new FriendsDAO().retrieveEmailId(Integer.parseInt(userId));
			     List<String> list4=new FriendsDAO().retrieveName(Integer.parseInt(femailId));
			    
			     String femailId1 ="";
			     for(int j=0;j<list3.size();j++)
			     {
			    	 femailId1 = list3.get(j);
			    	
			     }
			     System.out.println(femailId1);
			     
			     String friendname2 ="";
			     for(int j=0;j<list4.size();j++)
			     {
			    	 friendname2 = list4.get(j);
			    	 
			     }
			     System.out.println("friendname2"+friendname2);
			String path = request.getContextPath();
		   	String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
	  		///mailer format 
		   	String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
		       // HttpSession session = request.getSession();
		   htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
		  "  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'> </td>" +
		  "  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>"+friendname2+" has accepted your friends request in meetIn." +
		  "      <br><br>Login to your account to see more details.<br><br>Keep your trips updated so your friends can also get alerts and contact you." +
		  "</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
		  "  </tr>  <tr>" +
		  "    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
		  "  </tr></table></td>  </tr>";	      
				     
				 
			String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
			String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
			String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
			String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
			
			  
			 htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
			 new InviteFriends().postMail(femailId1,"meetIn friend request accepted", htmlmessage,"");		
			   }else if(resultID > 0){
				   friendws.setResultId(resultID);
			   }
			   return friendws;   	
			}
	
	@GET
	@Path("simplesearch")
	@Produces("application/xml")
	
	public List<UserWS> searchMeetInFriends(@QueryParam("friendname") String friendname,@QueryParam("pageNumber") Integer pageNumber,@QueryParam("userId") int userId,@Context HttpServletRequest request)
	{
		List resultList = new FriendsDAO().searchMeetInFriends(friendname, pageNumber);
		List<UserWS> list = new ArrayList<UserWS>();
		String status ="";
		Friends friend =null;
		String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
		String image="";
		
		if(resultList !=null && resultList.size() >0)
		{
		    for(int i=0;i<resultList.size();i++)
			 {
				User user =(User)resultList.get(i);
				UserWS userws = new UserWS();
				userws.setUserId(user.getUserId());
				userws.setFullname(user.getFullname());
				
				if(user.getImage() !=null && !user.getImage().equals(""))
				{
					image = imagePath + "/profileimage/"+user.getUserId() + "_" + user.getImage();
				}
				else
				{
					if(user.getGender() !=null && user.getGender().equalsIgnoreCase("male"))
					{
						image = imagePath + "/images/male.png";
					}
					else
					{
						image = imagePath + "/images/female.png";
					}
				}
				userws.setImage(image);
				userws.setLocCity(user.getLocCity());
				//status  = new FriendsDAO().checkFriendRequest(userId, user.getUserId());
				friend =(Friends)new FriendsDAO().checkFriendRequest(userId, user.getUserId());
				int id=0;
				if(userId == user.getUserId())
	    		{
	    			status ="You";
	    		}
	    		else if(friend !=null)
	    		{
	    			if(friend.getStatus().equalsIgnoreCase("Pending") && friend.getUserId2().intValue() != user.getUserId())
	    			{
	    				status = "Accept";
	    			}
	    			else if(friend.getStatus().equalsIgnoreCase("Pending") && friend.getUserId2().intValue() == user.getUserId())
	    			{
	    				status ="Pending";
	    			}
	    			else
	    			{
	    				status ="Approve";
	    			}
	    		}
	    		else
				{
					status ="0";
				}
				try{
					if((!friend.getRelationshipId().equals(null)) ||(!friend.getRelationshipId().equals(""))){
						id=friend.getRelationshipId();	
						userws.setRelationId(String.valueOf(id));	
					}else{
						id=0;
						userws.setRelationId(String.valueOf(id));	
					}
				}catch(Exception e){
					////System.out.println("idididid"+id+"****");
					userws.setRelationId(String.valueOf(id));
					//System.out.println("");
				}
				////System.out.println("ididididid "+id);
				//userws.setRelationId(String.valueOf(id));	
	    		userws.setStatus(status);
				list.add(userws);
			 }
		}
	    	
	  return list;	
	}
	@GET
	@Path("advancesearch")
	@Produces("application/xml")
	
	public List<UserWS> searchMeetInFriends(@QueryParam("name") String name,@QueryParam("location") String location,@QueryParam("company") String company,@QueryParam("keyword") String keyword,@QueryParam("pageNumber") Integer pageNumber,@QueryParam("userId") int userId,@Context HttpServletRequest request) throws ClassNotFoundException, SQLException
	{
		
	   // List resultList = new FriendsDAO().searchMeetInFriends(name, location, company, keyword, pageNumber);
	   List resultList=new FriendsDAO().searchMeetInFriendsOptimized(userId, name, location, company, keyword);
	   System.out.println(resultList.size());
	    List<UserWS> list = new ArrayList<UserWS>();
	    Friends friend =null;
	    String status ="";
		String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
		String image="";
		try{
	    if(resultList !=null && resultList.size() > 0)
	    {
	    	for(int i=0;i<resultList.size();i++)
	    	{
	    		User user =(User)resultList.get(i);
	    		System.out.println("status:::::  "+user.getStatus());
	    		UserWS userws = new UserWS();
	    		userws.setUserId(user.getUserId());
	    		userws.setFullname(user.getFullname());
	    		if(user.getImage() !=null && !user.getImage().equals(""))
				{
					image = imagePath + "/profileimage/"+user.getUserId() + "_" + user.getImage();
				}
				else
				{
					if(user.getGender() !=null && user.getGender().equals("male"))
					{
						image = imagePath + "/images/male.png";
					}
					else
					{
						image = imagePath + "/images/female.png";
					}
				}
				
				userws.setImage(image);
	    		
	    		userws.setLocCity(user.getLocCity());
	    		
	    		//friend =(Friends)new FriendsDAO().checkFriendRequest(userId, user.getUserId());
	    		int id=0;
	    	//	status  = new FriendsDAO().checkFriendRequest(userId, user.getUserId());
	    		if(userId == user.getUserId())
	    		{
	    			status ="You";
	    		}
	    		else if(user.getStatus() !=null)
	    		{
	    			if(user.getStatus().equals("Pending") && Integer.parseInt(user.getUserId2()) != user.getUserId())
	    			{
	    				status = "Accept";
	    			}
	    			else if(user.getStatus().equals("Pending")  && Integer.parseInt(user.getUserId2()) == user.getUserId())
	    			{
	    				status ="Pending";
	    			}
	    			else
	    			{
	    				status ="Approve";
	    			}
	    		}
	    		else
				{
					status ="0";
				}
	    		try{
					if((!user.getStatus().equals(null)) ||(!user.getRelationshipId().equals(""))){
						id=Integer.parseInt(user.getRelationshipId());	
						userws.setRelationId(String.valueOf(id));	
					}else{
						id=0;
						userws.setRelationId(String.valueOf(id));	
				}
				}catch(Exception e){
					////System.out.println("idididid"+id+"****");
					userws.setRelationId(String.valueOf(id));
					//System.out.println("");
				}
	    		userws.setStatus(status);
	    		list.add(userws);
	    	}
	    }}catch(Exception e){
	    	e.printStackTrace();
	    }
		
		return list; 
	}
	
	@GET
	@Path("viewmeetinfriend")
	@Produces("application/xml")
	public List<UserWS> viewMeetInFriends(@QueryParam("userId") int userId, @Context HttpServletRequest request)
	{
		List meetInList = new FriendsDAO().viewMeetInFriends(userId);
		List<UserWS> finalList= new ArrayList<UserWS>();
	    String iconPath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath() +"/";
	    
		if(meetInList !=null && meetInList.size() >0)
		{
			for(int j=0;j < meetInList.size();j++)
			{
				
				Object[] object = (Object[])meetInList.get(j);
				UserWS userws = new UserWS();
				userws.setUserId((Integer)object[0]);
				userws.setFullname((String)object[1]);
				userws.setLocCity((String)object[2]);
				userws.setSocialIcon(iconPath+"images/meetin_icon.png");
				finalList.add(userws);
			}
		}
		
		return finalList;
	}
	
	@GET
	@Path("viewfacebookfriend")
	@Produces("application/xml")
	public List<UserWS> viewFacebookFriends(@QueryParam("userId") int userId,@Context HttpServletRequest request)
	{
		Hashtable<String, List<String>> facebookList = new FriendsDAO().viewFacebookFriends(userId);
		
		List<UserWS> finalList= new ArrayList<UserWS>();
		List sortedList = new ArrayList();
		String iconPath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath() +"/";
		 
		if(facebookList !=null && facebookList.size() > 0)
		{
			 Enumeration e = facebookList.keys();
			 List<String> friendname = new ArrayList();
			 Enumeration<String> em = facebookList.keys();
			 while(em.hasMoreElements())
				{
					String key = em.nextElement();
					friendname.add(facebookList.get(key.toString()).get(0)+"::"+key);
					
				}
			 	
			 	Collections.sort(friendname, String.CASE_INSENSITIVE_ORDER);
			 	
			 	List sorted_list = new ArrayList();
				Iterator<String> iter = friendname.iterator();
				 
				 while(iter.hasNext())
					{
						List sort_name = new ArrayList();
						String nkey = iter.next();
						sort_name.add(nkey.split("::")[1]);
						sort_name.add(nkey.split("::")[0]);
						sort_name.add(facebookList.get(nkey.split("::")[1]).get(1));
						sort_name.add(facebookList.get(nkey.split("::")[1]).get(2));
						sort_name.add(facebookList.get(nkey.split("::")[1]).get(3));
						sorted_list.add(sort_name);
					}
				 if(sorted_list !=null && sorted_list.size() >0)
				 {
					 Iterator iterator = sorted_list.iterator();
						while(iterator. hasNext())
						{
							List friend_info = (List)iterator.next();
							UserWS userws = new UserWS();
							userws.setFullname((String)friend_info.get(1));
							userws.setLocCity((String)friend_info.get(2));
							userws.setProfilelink((String)friend_info.get(3));
							userws.setSocialIcon(iconPath+(String)friend_info.get(4));
							finalList.add(userws);
						}
				 }
				 
		}
		
	    	return finalList;
	}

	@GET
	@Path("viewlinkedinfriend")
	@Produces("application/xml")
	public List<UserWS> viewLinkedInFriends(@QueryParam("userId") int userId,@Context HttpServletRequest request)
	{
		Hashtable<String, List<String>> linkedinList = new FriendsDAO().viewLinkedInFriends(userId);
		
		List<UserWS> finalList= new ArrayList<UserWS>();
		List sortedList = new ArrayList();
		String iconPath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath() +"/";
		if(linkedinList !=null && linkedinList.size() > 0)
		{
			 Enumeration e = linkedinList.keys();
			 List<String> friendname = new ArrayList();
			 Enumeration<String> em = linkedinList.keys();
			 while(em.hasMoreElements())
				{
					String key = em.nextElement();
					friendname.add(linkedinList.get(key.toString()).get(0)+"::"+key);
					
				}
			 	
			 	Collections.sort(friendname, String.CASE_INSENSITIVE_ORDER);
			 	
			 	List sorted_list = new ArrayList();
				Iterator<String> iter = friendname.iterator();
				 
				while(iter.hasNext())
				{
					List sort_name = new ArrayList();
					String nkey = iter.next();
					sort_name.add(nkey.split("::")[1]);
					sort_name.add(nkey.split("::")[0]);
					sort_name.add(linkedinList.get(nkey.split("::")[1]).get(1));
					sort_name.add(linkedinList.get(nkey.split("::")[1]).get(2));
					sort_name.add(linkedinList.get(nkey.split("::")[1]).get(3));
					sorted_list.add(sort_name);
				}
				 if(sorted_list !=null && sorted_list.size() >0)
				 {
					 Iterator iterator = sorted_list.iterator();
						while(iterator. hasNext())
						{
							List friend_info = (List)iterator.next();
							UserWS userws = new UserWS();
							userws.setFullname((String)friend_info.get(1));
							userws.setLocCity((String)friend_info.get(2));
							userws.setProfilelink((String)friend_info.get(3));
							userws.setSocialIcon(iconPath+(String)friend_info.get(4));
							finalList.add(userws);
						}
				 }
		}
		return finalList;
	}
	@GET
	@Path("viewgmailfriend")
	@Produces("application/xml")
	public List<UserWS> viewGmailFriends(@QueryParam("email") String email, @QueryParam("password") String password,@Context HttpServletRequest request)
	{
		String gmailloginstatus = new GmailFriends().getGmailUserAuthenticate(email, password);
		List<UserWS> finalList= new ArrayList<UserWS>();
		String iconPath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath() +"/";
		
		if(!gmailloginstatus.equals("") && gmailloginstatus.equalsIgnoreCase("valid"))
		{
		Hashtable<String, List<String>> gmailList = new FriendsDAO().viewGmailFriends(email, password);
		
		List sortedList = new ArrayList();
		if(gmailList !=null && gmailList.size() > 0)
		{
			 Enumeration e = gmailList.keys();
			 List<String> friendname = new ArrayList();
			 Enumeration<String> em = gmailList.keys();
			 while(em.hasMoreElements())
				{
					String key = em.nextElement();
					friendname.add(gmailList.get(key.toString()).get(0)+"::"+key);
					
				}
			 	
			 	Collections.sort(friendname, String.CASE_INSENSITIVE_ORDER);
			 	
			 	List sorted_list = new ArrayList();
				Iterator<String> iter = friendname.iterator();
				 
				 while(iter.hasNext())
					{
						List sort_name = new ArrayList();
						String nkey = iter.next();
						sort_name.add(nkey.split("::")[1]);
						sort_name.add(nkey.split("::")[0]);
						sort_name.add(gmailList.get(nkey.split("::")[1]).get(1));
						sort_name.add(gmailList.get(nkey.split("::")[1]).get(2));
						sort_name.add(gmailList.get(nkey.split("::")[1]).get(3));
						sorted_list.add(sort_name);
					}
				 if(sorted_list !=null && sorted_list.size() >0)
				 {
					 Iterator iterator = sorted_list.iterator();
						while(iterator. hasNext())
						{
							List friend_info = (List)iterator.next();
							UserWS userws = new UserWS();
							userws.setFullname((String)friend_info.get(1));
							userws.setLocCity((String)friend_info.get(2));
							userws.setProfilelink((String)friend_info.get(3));
							userws.setSocialIcon(iconPath+(String)friend_info.get(4));
							finalList.add(userws);
						}
				 }
				 
			}
		
		}
		else if(!gmailloginstatus.equals("") && !gmailloginstatus.equalsIgnoreCase("valid"))
		{
		   	UserWS userws = new UserWS();
		   	userws.setStatus(gmailloginstatus);
		   	finalList.add(userws);
		}
		
		 return finalList;
			
	}
	//Commented by rupal kathiriya to getallfriends dated on 19th jan 2013
	/*@GET
	@Path("viewallfriend")
	@Produces("application/xml")
	
	public List<UserWS> viewAllFriends(@QueryParam("userId") int userId,@Context HttpServletRequest request)
	{
		Hashtable<String, List<String>> Facebook_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> LinkedIn_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> MeetIn_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> Gmail_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> twitter_friends = new Hashtable<String, List<String>>(); 
		
		com.verve.meetin.friend.Friends friend=new com.verve.meetin.friend.Friends();
		
		List socialnetworklist = null;
		List meetinfriendList = null;
		List<UserWS> finalList= new ArrayList<UserWS>();
		
		socialnetworklist = new NetworkDAO().getUserSocialNetworkSitesByUserId(userId);
		
		String iconPath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath() +"/";
		if(socialnetworklist !=null && socialnetworklist.size() >0)
		{
			for(int i=0;i<socialnetworklist.size(); i++)
			{
				Object[] obj = (Object[])socialnetworklist.get(i);
				if(obj[0].toString().toLowerCase().equals("facebook"))
				{
					Facebook_friends = new FriendsDAO().viewFacebookFriends(userId);
				}
				if(obj[0].toString().toLowerCase().equals("linkedin"))
				{
					LinkedIn_friends = new FriendsDAO().viewLinkedInFriends(userId);
				}
				if(obj[0].toString().toLowerCase().equals("gmail"))
				{
					Gmail_friends = new FriendsDAO().viewGmailFriends(userId);
				}
				if(obj[0].toString().toLowerCase().equals("twitter"))
				{
					twitter_friends = new FriendsDAO().viewtwitterFriends(userId);
				}
			}
		}
		meetinfriendList = new FriendsDAO().viewMeetInFriends(userId);
		String profile_path = "profile_page.jsp";
		//int id=0;
		if(meetinfriendList !=null && meetinfriendList.size() >0)
	       {
	    	   for(int i=0;i < meetinfriendList.size();i++)
	    	   {
	    		   Object[] object = (Object[])meetinfriendList.get(i);
	    		   List<String> finalResultList = new ArrayList<String>();
	    		  
	    		   finalResultList.add((String)object[1]);
	    		   finalResultList.add((String)object[2]);
	    		   finalResultList.add(profile_path+"?id=" +(Integer)object[0]);
	    		  
	    		   finalResultList.add("images/meetin_icon.png");
	    		   MeetIn_friends.put(String.valueOf((Integer)object[0]), finalResultList);
	    	   }
	       }
		Enumeration<String> e3 = twitter_friends.keys();
		
		// Merge all the Social Network data
		friends = Facebook_friends;
		Enumeration<String> e = LinkedIn_friends.keys();
		while(e.hasMoreElements()) {
			String element = e.nextElement(); 
			friends.put(element, LinkedIn_friends.get(element));
		}
		Enumeration<String> e1 = MeetIn_friends.keys();
		while(e1.hasMoreElements())
		{
			String element = e1.nextElement(); 
			friends.put(element, MeetIn_friends.get(element));
		}
		
		Enumeration<String> e2 = Gmail_friends.keys();
        while(e2.hasMoreElements())
        {
                String element = e2.nextElement(); 
                friends.put(element, Gmail_friends.get(element));
        }
        while(e3.hasMoreElements()) {
			////System.out.println("Twitter Friends : -- " + twitter_friends);
			////System.out.println("Twitter Friends : -- " + twitter_friends);
			String element = e3.nextElement(); 
			friends.put(element, twitter_friends.get(element));
		}
        List RelId=new ArrayList();
        Sorting the all social network friends 
        List sortedList = new ArrayList();
		if(friends !=null && friends.size() > 0)
		{
			 List<String> friendname = new ArrayList();
			 Enumeration<String> em = friends.keys();
			 while(em.hasMoreElements())
				{
					String key = em.nextElement();
					friendname.add(friends.get(key.toString()).get(0)+"::"+key);
				}			 	
			 	Collections.sort(friendname, String.CASE_INSENSITIVE_ORDER);
			 	
			 	List sorted_list = new ArrayList();
				Iterator<String> iter = friendname.iterator();
				 
				 while(iter.hasNext())
					{
						List sort_name = new ArrayList();
						String nkey = iter.next();
						sort_name.add(nkey.split("::")[1]);
						sort_name.add(nkey.split("::")[0]);
						sort_name.add(friends.get(nkey.split("::")[1]).get(1));
						sort_name.add(friends.get(nkey.split("::")[1]).get(2));
						sort_name.add(iconPath+friends.get(nkey.split("::")[1]).get(3));
						
						try{
						String image=iconPath+friends.get(nkey.split("::")[1]).get(3).split("/")[1];
						
						String[] splitImg=image.split("/");
						int i=0;
						int id1=0;
						for(i=0;i<splitImg.length;i++){
							if(splitImg[i].equalsIgnoreCase("meetin_icon.png")){
								try{
								friend =(com.verve.meetin.friend.Friends)new FriendsDAO().checkFriendRequest(userId, Integer.parseInt(nkey.split("::")[1]));
								id1=friend.getRelationshipId();
								}catch(Exception e11){
									id1=0;
								}
								//System.out.println("idididididididididididid    ********  "+id1);
							}
						}
						RelId.add(id1);
						}catch(Exception e10){
							e10.printStackTrace();
						}
						sorted_list.add(sort_name);
					}
				 if(sorted_list !=null && sorted_list.size() >0)
				 {
					 UserWS userws =null;
					 int i=0;
					 Iterator iterator = sorted_list.iterator();
						while(iterator. hasNext())
						{
							List friend_info = (List)iterator.next();
							userws=new UserWS();
							userws.setFullname((String)friend_info.get(1).toString().trim());
							userws.setLocCity((String)friend_info.get(2).toString().trim());
							userws.setProfilelink((String)friend_info.get(3).toString().trim());
							userws.setSocialIcon((String)friend_info.get(4).toString().trim());
							
							try{
								if(RelId.get(i).toString().equals("0")){
									userws.setResultString("other");
									userws.setRelationId(RelId.get(i).toString());
								}else{
									userws.setResultString("approve");
									userws.setRelationId(RelId.get(i).toString());
								}
							}catch(Exception e12){
									userws.setResultString("other");
									userws.setRelationId("0");
							}
							
							finalList.add(userws);
							i++;
						}
				 }
		}
		return finalList;
	}
*/
	@POST
	@Path("invitefriend")
	@Produces("application/xml")

	public FriendsWS postMail(@HeaderParam("friendname") String friendname, @HeaderParam("recipient") String recipient, @HeaderParam("message") String invitemessage,@HeaderParam("userId") int userId,@Context HttpServletRequest request) throws Exception
	{
		boolean flag=false;
		////System.out.println("recipient:::::: "+recipient);
		String[] result = URLDecoder.decode(recipient, "UTF-8").split(",");
		////System.out.println(result);
		FriendsWS friendws = new FriendsWS();
		User user = (User) new UserAccountDAO().getUserProfileDetails(userId);
		String subject = URLDecoder.decode(user.getFullname(), "UTF-8")+" has invited you to use meetIn";
		String path = request.getContextPath();
		String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
		
		String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
		//htmlmessage += "<br><br><table cellpadding='0' cellspacing='0' border='0'><tr><td style='font-size:14px;font-weight:normal;color:#fff; padding-left:25px; font-family:Helvetica,Arial,sans-serif'>Hi "  + friendname +",</td></tr></table><br/><br/>";
		//htmlmessage += invitemessage +"</p> ";
		htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
		"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
	  	URLDecoder.decode(invitemessage, "UTF-8")+"</td>" +
		"  </tr> <tr>" +
		"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
		"  </tr></table></td>  </tr>";	
	
		String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
		String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
		String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
		String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
			
			
		htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

    	try
		{
			new InviteFriends().postMails(result, subject, htmlmessage, "");
			flag=true;
			if(flag==true){
				friendws.setFriendemail(recipient);
				friendws.setMailStatus("success");
			}
			else{
				friendws.setFriendemail(recipient);
				friendws.setMailStatus("failure");
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return friendws;
	}
	
	
}