package com.verve.meetin.webservice;

import java.util.ResourceBundle;

import com.verve.meetin.common.CommonUtil;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("Common")
public class CommonService 
{
	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");

	@Produces("application/xml")
	@GET
	@Path("geturls")
	public CommonUtil getUrl()
	{
		String webserviceurl = resource.getString("webservice.url");
		String weburl = resource.getString("website.url");
		String privacyurl=resource.getString("privacy.url");
		String setupnetworkurl=resource.getString("setupnetwork.url");
		
		CommonUtil commonUtil = new CommonUtil();
		
		commonUtil.setWebserviceurl(webserviceurl);
		commonUtil.setWeburl(weburl);
		commonUtil.setPrivacyurl(privacyurl);
		commonUtil.setSetupnetworkurl(setupnetworkurl);
		return commonUtil;
	}
	/*@GET
    @Produces("text/plain")
    @Path("findCustomersByCity/{city}")
    public String findCustomersByCity(@PathParam("city") String city) {
        
        return city;
        
    }*/
}
