package com.verve.meetin.network;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;

public class NetworkDAO 
{
	
	static Logger log = Logger.getLogger(NetworkDAO.class);
		
	public int setUserSocialNetworkSite(Usernetworks usernetwork)
	{
	
		log.info("Inside set user network site....");
		int last_record_id = 0;
		try
		{
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();		
			last_record_id = (Integer)session.save(usernetwork);
			tx.commit();
			log.info("User social network site details have been submitted successfully");

		}
		catch(Exception ex){
			log.error("There is a problem in user social network site details");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return last_record_id;
	}
	
	public List getSocialNetworkSites()
	{
		
		List result =null;
		String queryString ="from Networkmaster as network order by network.socialNetworkSiteName";
		try
		{
			log.info("Trying to fetch social network sites list.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    log.info("Social network sites list returned from DataSource,Size:" +result.size());
		    
		    return result;
		}
		catch(Exception ex)
		{
			log.error("There is a problem in network master");
			log.debug(ex);
		}
				
	   return result;	
	}
	public boolean checkUserSocialNetwork(int userId, int social_site_id){
		
		boolean result=false;
		String queryString ="select usernetwork.socialNetworkSiteId from Usernetworks as usernetwork where usernetwork.userId=? and usernetwork.socialNetworkSiteId=?"; 
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query =session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, social_site_id);
		    Integer result_count = (Integer)query.uniqueResult();
		    session.getTransaction().commit();
		    
		    if(result_count !=null && result_count.intValue() > 0)
		    {
		          result =true;
		    }
		  
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return result;
	}
	public int removeUserSocialNetworkSite(int userId, int social_site_id)
	{
		
		log.info("Inside remove user network site....");	
		int row=0;
		String queryString ="delete from Usernetworks as usernetwork where usernetwork.userId=? and usernetwork.socialNetworkSiteId=?";
		
		try
		{
			
			log.info("Trying to remove social network site ....");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, social_site_id);
		    row = query.executeUpdate();
		    tx.commit();
		    
		    log.info("Social network site has been removed successfully....");
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem removing user's social networking site detail");
			log.debug(ex);
			ex.printStackTrace();
		}
				
		return row;
	}
	public int updateUserSocialNetworkSite(Usernetworks onetwork){
		
		log.info("Inside user social network site updates....");
		int update_record_id =0;
	
		String queryString = "update Usernetworks set username=?,password=? where userId =? and socialNetworkSiteId=?";
		try
		
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, onetwork.getUsername());
			query.setParameter(1, onetwork.getPassword());
			query.setParameter(2, onetwork.getUserId());
			query.setParameter(3, onetwork.getSocialNetworkSiteId());
			
			update_record_id = query.executeUpdate();
			tx.commit();
			
			log.info("User's Social network sites details has been updated successfully");
            
		}
		catch(Exception ex)
		{
			log.error("There is a problem updating user's social networking sites details");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return update_record_id;
		
	}
	
	public List getUserSocialNetworkSites(int userId)
	{
		List result = null;
		String queryString ="select networkmaster.socialNetworkSiteId, networkmaster.socialNetworkSiteName, usernetwork.access_token from Networkmaster as networkmaster, Usernetworks as usernetwork where networkmaster.socialNetworkSiteId = usernetwork.socialNetworkSiteId and usernetwork.userId=?";
		try
		{
			log.info("Trying to fetch social network sites list setup by current user.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    log.info("Social network sites list for current user returned from DataSource,Size:" +result.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in fetching network site list for current user");
			log.debug(ex);
			ex.printStackTrace();
		}
				
	   return result;	
	}
	/*
	 * @param : userId
	 * 
	 * get the social network site name and icon for a given user's ID
	 */
	public List getUserSocialNetworkSitesByUserId(int userId)
	{
		List result =null;
		String queryString ="select networkmaster.socialNetworkSiteName,networkmaster.socialNetworkSiteIcon, networkmaster.socialNetworkSiteId from Networkmaster as networkmaster, Usernetworks as usernetwork where networkmaster.socialNetworkSiteId = usernetwork.socialNetworkSiteId and usernetwork.userId=?";
		try
		{
			log.info("Trying to fetch social network sites list setup by current user.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    log.info("Social network sites list for current user returned from DataSource,Size:" +result.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in fetching network site list for current user");
			log.debug(ex);
			ex.printStackTrace();
		}
				
	   return result;	
		
	}
	
	/*
	 * @param : userId
	 * 
	 * get the social site id for the user.
	 */
	public List<Integer> getUserSocialNetworkSiteId(int userId) {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   Date date = new Date();
		System.out.println("getsocialnetwork IDs method called " + dateFormat.format(date));
		
		List<Integer> social_site_ids = null;
		String queryString ="select usernetwork.socialNetworkSiteId from Usernetworks" +
				" as usernetwork where usernetwork.userId=?"; 
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    System.out.println("before query  " + dateFormat.format(date));
		    social_site_ids = query.list();
		    System.out.println("after query  " + dateFormat.format(date));
		    session.getTransaction().commit();
		    
		}
		
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return social_site_ids;
	}
	
	public List<String> getUserSocialNetworkSiteNames(List<Integer> social_site_ids) {
				
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   Date date = new Date();
		System.out.println("getusersocialnetworksitenames called " + dateFormat.format(date));
		
	    List<String> social_site_names = new ArrayList<String>();
		String queryString ="select socialNetworkSiteName from Networkmaster as network " +
		" where network.socialNetworkSiteId=?";
		
		for(int i=0;i<social_site_ids.size();i++) 
		{
			try
			{
				Session session = HibernateUtil.getSessionFactory().getCurrentSession();
				session.beginTransaction();
				
				Query query = session.createQuery(queryString);
			    query.setParameter(0, social_site_ids.get(i));
			    System.out.println("before query " + dateFormat.format(date));
			    String socialSite = (String) query.uniqueResult();
			    System.out.println("after query " + dateFormat.format(date));
			    session.getTransaction().commit();
			    
			    social_site_names.add(socialSite);
			    
			    
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
		
	   return social_site_names;
	}
	public int getSocialNetworkId(String socialNetwokName) {
		
		String queryString ="select socialNetworkSiteId from Networkmaster as network " +
							" where network.socialNetworkSiteName=?";
		int networkId = 0;
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
		    query.setParameter(0, socialNetwokName);
		    networkId = (Integer)query.uniqueResult();
		    session.getTransaction().commit();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
	   return networkId;
	}
	public String getSocailNetworkIcon(String socialNetwokName) 
	{
		
		String queryString ="select socialNetworkSiteIcon from Networkmaster as network " +
		" where network.socialNetworkSiteName=?";
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, socialNetwokName);
			String networkIcon = (String)query.uniqueResult();
			session.getTransaction().commit();
			return networkIcon;
			
		}catch(Exception ex){
			ex.printStackTrace();
			return "";
		}
		
	}
	
	public String getAccessToken(int userId, int networkId) {
		
		String queryString ="select access_token from Usernetworks as usernetwork " +" where usernetwork.userId=? and usernetwork.socialNetworkSiteId=?";
		String access_token = "";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query =session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, networkId);
			access_token = (String)query.uniqueResult();
			session.getTransaction().commit();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		return access_token;
	}
	
	public int setNetworkUserName(Usernetworks onetwork, String networkUserName)
	{
		
		String username = networkUserName;

		int update_record_id = 0 ;
		String queryString = "update Usernetworks set username=?,password=? where userId =? and socialNetworkSiteId=?";
		try
		{

			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx =  session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0,username);
			query.setParameter(1, onetwork.getPassword());
			query.setParameter(2, onetwork.getUserId());
			query.setParameter(3, onetwork.getSocialNetworkSiteId());
			
			update_record_id = query.executeUpdate();
			tx.commit();
			
			log.info("User's Social network sites details has been updated successfully");
            
		}
		catch(Exception ex)
		{
			log.error("There is a problem updating user's social networking sites details");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return update_record_id;
	}
	
	public String getNetworkUserName(int userId, int networkId)
	{
		
		String networkusername = "";
		String queryString = "select username from Usernetworks where userId =? and socialNetworkSiteId=?";
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, networkId);
			if(query.uniqueResult() != null)
				networkusername = query.uniqueResult().toString();
			session.getTransaction().commit();
		}
		catch(Exception ex)
		{
			log.error("There is a problem updating user's social networking sites details");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return networkusername;
	}
	
	public int twitterCheck(int userId) {
		
		Long result = null;
		String queryString = "select count(*) from Usernetworks as usernetwork where usernetwork.userId = ? AND usernetwork.socialNetworkSiteId= 4";
		try 
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			result =(Long)query.uniqueResult();
			session.getTransaction().commit();
				
		} catch (Exception ex) {
			ex.printStackTrace();
		}
				
		return result.intValue();
	}

	public int linkedInCheck(int userId) {
		
		Long result = null;
		String queryString = "select count(*) from Usernetworks as usernetwork where usernetwork.userId = ? AND usernetwork.socialNetworkSiteId= 2";
		try 
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			result = (Long)query.uniqueResult();
			session.getTransaction().commit();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
				
		return result.intValue();
	}
	public int facebookCheck(int userId) {
		
		Long result = null;
		String queryString = "select count(*) from Usernetworks as usernetwork where usernetwork.userId = ? AND usernetwork.socialNetworkSiteId= 1";
		try 
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			result = (Long)query.uniqueResult();
			session.getTransaction().commit();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return result.intValue();
	}

}
