package com.verve.meetin.network;

public class NetworkConstraint 
{
	public static final int SOCIAL_NETWORK_MEETIN = 0;
	public static final int SOCIAL_NETWORK_FACEBOOK = 1;
	public static final int SOCIAL_NETWORK_LINKEDIN = 2;
	public static final int SOCIAL_NETWORK_GMAIL = 3;
	public static final int SOCIAL_NETWORK_TWITTER = 4;
	public static final int SOCIAL_NETWORK_TRIPIT = 5;
	public static final int SOCIAL_NETWORK_MYSPACE = 6;
	public static final int SOCIAL_NETWORK_FOURSQUARE = 7;
	public static final int SOCIAL_NETWORK_FOURSQUARE_CHECKIN =8;
	public static final int SOCIAL_NETWORK_ALL = 10;	
}
