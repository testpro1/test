package com.verve.meetin.network;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * MiNetworkmaster entity. @author MyEclipse Persistence Tools
 */

@XmlRootElement
public class Networkmaster implements java.io.Serializable {

	// Fields

	private Integer socialNetworkSiteId;
	private String socialNetworkSiteName;
	private String socialNetworkSiteIcon;
	private Integer result;
	// Constructors

	/** default constructor */
	public Networkmaster() {
	}

	/** full constructor */
	public Networkmaster(String socialNetworkSiteName,
			String socialNetworkSiteIcon) {
		this.socialNetworkSiteName = socialNetworkSiteName;
		this.socialNetworkSiteIcon = socialNetworkSiteIcon;
	}

	// Property accessors

	public Integer getSocialNetworkSiteId() {
		return this.socialNetworkSiteId;
	}

	public void setSocialNetworkSiteId(Integer socialNetworkSiteId) {
		this.socialNetworkSiteId = socialNetworkSiteId;
	}

	public String getSocialNetworkSiteName() {
		return this.socialNetworkSiteName;
	}

	public void setSocialNetworkSiteName(String socialNetworkSiteName) {
		this.socialNetworkSiteName = socialNetworkSiteName;
	}

	public String getSocialNetworkSiteIcon() {
		return this.socialNetworkSiteIcon;
	}

	public void setSocialNetworkSiteIcon(String socialNetworkSiteIcon) {
		this.socialNetworkSiteIcon = socialNetworkSiteIcon;
	}

	public Integer getResult() {
		return result;
	}

	public void setResult(Integer result) {
		this.result = result;
	}

}