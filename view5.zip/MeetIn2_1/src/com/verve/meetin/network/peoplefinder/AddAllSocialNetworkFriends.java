package com.verve.meetin.network.peoplefinder;

import java.net.InetAddress; 
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.mail.MessagingException;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;

import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.LinkedIn.LinkedIn;
import com.verve.meetin.facebook.facebookGraphAPI;
import com.verve.meetin.foursquare.foursquareDemo;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.gmail.GmailAPI;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.tripit.Tripit_Trips_DAO;
import com.verve.meetin.twitter.twitter;
import com.verve.meetin.user.UserAccountDAO;

public class AddAllSocialNetworkFriends implements Job 
{
	static Logger log = Logger.getLogger(AddAllSocialNetworkFriends.class);
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		
		StringBuffer emailmessage = new StringBuffer("Add All Social Network Friends Scheduler Started on  " + new Date());
		
		log.info("Add All Social Network Friends Scheduler Started........");
		List userIdList = getAllUserSocialNetwork();
		NetworkDAO oNetworkDAO = new NetworkDAO();
		String sessionid = null;
		int userid = 0;
		SocialNetworkDAO oSocialNetworkDAO =  new SocialNetworkDAO();
		
		if(userIdList !=null && userIdList.size() > 0 )
		{

			for(int i=0;i < userIdList.size();i++) 
			{
						List<SocialNetworkDummy> friends = null;
						Object[] object = (Object[]) userIdList.get(i);
						userid = (Integer)object[1];
						
						System.out.println("user id is " + userid);
						
						switch ((Integer) object[0]) 
						{
							case NetworkConstraint.SOCIAL_NETWORK_FACEBOOK:
								friends = new facebookGraphAPI().getFacebookFriendsDump((String) object[2],  userid, sessionid, (Integer)object[0]);
								break;
								
							case NetworkConstraint.SOCIAL_NETWORK_LINKEDIN:
								friends = new LinkedIn().getLinkedInFriendsDump((String) object[2], userid,sessionid, (Integer)object[0]);
								break;
								
							case NetworkConstraint.SOCIAL_NETWORK_GMAIL:
								friends = new GmailAPI().getGmailFriendsDump((String) object[2], userid, sessionid, (Integer) object[0]);
								break;
						
							case NetworkConstraint.SOCIAL_NETWORK_TWITTER:
								friends = new twitter().getTwitterFriendsDump((String) object[2], userid, sessionid, (Integer) object[0]);
								break;
							
							case NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE:
									new foursquareDemo().getFoursquareCheckinDump((String)object[2], userid, sessionid, (Integer)object[0]);	
									friends = new foursquareDemo().getFoursquareFriendsDump((String)object[2], userid, sessionid, (Integer)object[0]);
								break;
							
							default:
								break;
						}			
						
						oSocialNetworkDAO.saveSocialDummyData(friends);
						new UserAccountDAO().updateUserScheduleFlagById(userid, "Y");
				}
		}
		
		log.info("Add All Social Network Friends Scheduler Finished........");
		
		emailmessage.append(" and Finished on  " +new Date());
		
		try 
		{
			
				InetAddress remoteAddress = InetAddress.getLocalHost();
				new InviteFriends().postMail("chirendu@mymeetin.com", "Social Network Scheduler Info @" + remoteAddress.getHostName(), emailmessage.toString(), "");
				
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	
	}

	public List getAllUserSocialNetwork()
	{
		List list=null;
		String queryString = "select socialNetworkSiteId,userId,access_token from Usernetworks";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
						
			list = query.list();
			
			session.getTransaction().commit();
			
			System.out.print(list.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}
	
	public static void main(String[] args) throws SchedulerException{
		
		JobDetail job = new JobDetail();
		
    	job.setName("Demo Job");
    	job.setJobClass(AddAllSocialNetworkFriends.class);
    	
    	
    	SimpleTrigger trigger = new SimpleTrigger();
    	trigger.setName("Demo Trigger");
    	trigger.setStartTime(new Date(System.currentTimeMillis() + 1000));
        	 
    	Scheduler scheduler = new StdSchedulerFactory().getScheduler();
    	scheduler.start();
    	scheduler.scheduleJob(job, trigger);
	}
}
