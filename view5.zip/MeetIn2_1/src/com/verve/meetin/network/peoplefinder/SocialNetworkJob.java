package com.verve.meetin.network.peoplefinder;


import java.util.List;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.verve.meetin.LinkedIn.LinkedIn;
import com.verve.meetin.facebook.facebookGraphAPI;
import com.verve.meetin.gmail.GmailAPI;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.twitter.twitter;

public class SocialNetworkJob implements Job 
{
	
	public void execute(JobExecutionContext arg0) throws JobExecutionException 
	{
		
		JobDataMap data = arg0.getJobDetail().getJobDataMap();
		int userid = (Integer)data.get("userid");
		String sessionid = (String)data.get("sessionid");
		List socialSites = new NetworkDAO().getUserSocialNetworkSites(userid);
		SocialNetworkDAO socialnetworkDAO = new SocialNetworkDAO();
		
		if(socialSites !=null && socialSites.size() > 0)
		{
	
			for(int i=0;i < socialSites.size();i++) 
			{
				List<SocialNetworkDummy> friends = null;
				Object[] object = (Object[]) socialSites.get(i);
				switch ((Integer) object[0]) 
				{
					case NetworkConstraint.SOCIAL_NETWORK_FACEBOOK:
						friends = new facebookGraphAPI().getFacebookFriendsDump((String) object[2],  userid, sessionid, (Integer)object[0]);
						break;
						
					case NetworkConstraint.SOCIAL_NETWORK_LINKEDIN:
						friends = new LinkedIn().getLinkedInFriendsDump((String) object[2], userid,sessionid, (Integer)object[0]);
						break;
						
					case NetworkConstraint.SOCIAL_NETWORK_GMAIL:
						friends = new GmailAPI().getGmailFriendsDump((String) object[2], userid, sessionid, (Integer) object[0]);
						break;
					case NetworkConstraint.SOCIAL_NETWORK_TWITTER:
						friends = new twitter().getTwitterFriendsDump((String) object[2], userid, sessionid, (Integer) object[0]);
						break;
					default:
						break;
				}			
				
				//socialnetworkDAO.deleteSocialDummyData(userid,(Integer)object[0]);
				socialnetworkDAO.saveSocialDummyData(friends);
			}
		}
	}
	
}
