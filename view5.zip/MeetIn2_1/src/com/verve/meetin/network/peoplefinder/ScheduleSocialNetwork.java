package com.verve.meetin.network.peoplefinder;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;

import com.verve.meetin.LinkedIn.LinkedIn;
import com.verve.meetin.facebook.facebookGraphAPI;
import com.verve.meetin.gmail.GmailAPI;
import com.verve.meetin.myspace.myspace;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.twitter.twitter;



public class ScheduleSocialNetwork 
{
	public void startscheduleScoialNetwork(int userid, String sessionid) throws Exception
	{
				
		JobDetail job = new JobDetail();
		
    	job.setName(userid+"_"+sessionid);
    	job.setJobClass(SocialNetworkJob.class);
    	job.getJobDataMap().put("userid", userid);
    	job.getJobDataMap().put("sessionid", sessionid);
    	
    	SimpleTrigger trigger = new SimpleTrigger();
    	trigger.setName(userid+"_"+sessionid);
    	trigger.setStartTime(new Date(System.currentTimeMillis() + 1000));

    	Scheduler scheduler = new StdSchedulerFactory().getScheduler();
    	scheduler.start();
    	scheduler.scheduleJob(job, trigger);
    	
	}

		
	public void startscheduleScoialNetwork(int userid, String sessionid, int socialid) throws SchedulerException
	{
		
		JobDetail job = new JobDetail();
		
    	job.setName(userid+"_"+sessionid+"_"+socialid);
    	job.setJobClass(SocialSingleNetworkJob.class);
    	job.getJobDataMap().put("userid", userid);
    	job.getJobDataMap().put("sessionid", sessionid);
    	job.getJobDataMap().put("socialid", socialid);
    	
    	SimpleTrigger trigger = new SimpleTrigger();
    	trigger.setName(userid+"_"+sessionid+"_"+socialid);
    	trigger.setStartTime(new Date(System.currentTimeMillis() + 1000));
        	 
    	Scheduler scheduler = new StdSchedulerFactory().getScheduler();
    	scheduler.start();
    	scheduler.scheduleJob(job, trigger);
	}
	
	public static void main(String[] args) throws SchedulerException
	{
		new ScheduleSocialNetwork().startscheduleScoialNetwork(1, null, 2);
	}
	
}
