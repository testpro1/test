package com.verve.meetin.network.peoplefinder;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.TimeZone;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.apache.struts.taglib.html.ImgTag;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.LinkedIn.LinkedIn;
import com.verve.meetin.facebook.facebookGraphAPI;
import com.verve.meetin.gmail.GmailAPI;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.myspace.myspace;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.Networkmaster;
import com.verve.meetin.trip.Trips_detail;
import com.verve.meetin.twitter.twitter;
import com.verve.meetin.user.UserAccountDAO;

public class PeopleFinder 
{
	static Logger log = Logger.getLogger(PeopleFinder.class);
	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	String DriverClass = resource.getString("jdbc.driverClass");
	String connectionValue=resource.getString("jdbc.connectionValue");
	String username=resource.getString("jdbc.database.username");
	String password=resource.getString("jdbc.database.password");
	//ResourceBundle resource;
	public synchronized Hashtable<String, List<String>> peopleFinder(int userId, String location) throws Exception {
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> Facebook_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> LinkedIn_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> MeetIn_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> Gmail_friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> twitter_friends = new Hashtable<String, List<String>>(); 
		Hashtable<String, List<String>> myspace_friends = new Hashtable<String, List<String>>();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println("peoplefinder method called " + dateFormat.format(date));
		
		//List socialSites = new NetworkDAO().getUserSocialNetworkSites(userId);
				
		/*	if(socialSites !=null && socialSites.size() > 0)
		{
	
			for(int i=0;i < socialSites.size();i++) 
			{
				Object[] object = (Object[]) socialSites.get(i);
								
				if(object[0].toString().equalsIgnoreCase(NetworkConstraint.SOCIAL_NETWORK_FACEBOOK))
				{
					try {
					
						facebookGraphAPI fbapi = new facebookGraphAPI();
						Facebook_friends = fbapi.getFacebookFriendList((String) object[1], location);
												
					} catch (Exception e) {
						log.error("Exception occured in facebook ---  "+e);
					}
					
				}
				else if(object[0].toString().equalsIgnoreCase(NetworkConstraint.SOCIAL_NETWORK_LINKEDIN))
				{
					try 
					{
						LinkedIn linkedinapi = new LinkedIn();
						LinkedIn_friends = linkedinapi.getFriendsInfo((String) object[1], location);    //  here the code will change with Consumer key and secret key for different User.
					} catch (Exception e) {
						log.error("Exception occured in Linked in --- - - - "+e);
					}
				}
				else if(object[0].toString().equalsIgnoreCase(NetworkConstraint.SOCIAL_NETWORK_GMAIL))
                {
					    try {
					    	GmailAPI gmailapi = new GmailAPI();
					    	Gmail_friends = gmailapi.getFriends((String) object[1], location);
					    } catch (Exception e) {
					    	log.error("Exception in Gmail Occured --  "+e);
						}
                }
				else if(object[0].toString().equalsIgnoreCase(NetworkConstraint.SOCIAL_NETWORK_TWITTER))
                {
						try {
							
							twitter twitterapi = new twitter();
							twitter_friends = twitterapi.getFriendsInfo((String) object[1], location);
						} catch (Exception e) {
							log.error("Exception in twitter occured --  "+e);
						}
                }
				else if(object[0].toString().equalsIgnoreCase(NetworkConstraint.SOCIAL_NETWORK_MYSPACE))
				{
					try {
						myspace myspace = new myspace();
						myspace_friends = myspace.getFriendsInfo((String) object[1]);
												
					} catch (Exception e) {
							log.error("Exception in Myspace"+e);
							
					}
										
				}
			}
			
			UserAccountDAO accountdao = new UserAccountDAO();
			
			try {
				
			MeetIn_friends = accountdao.getFriendsNames_Ids(location,userId);
			
			// Merge all the Social Network data
			friends = Facebook_friends;
			
			Enumeration<String> e = LinkedIn_friends.keys();
			while(e.hasMoreElements()) {
				String element = e.nextElement(); 
				friends.put(element, LinkedIn_friends.get(element));
			}
			
			Enumeration<String> e3 = twitter_friends.keys();
			while(e3.hasMoreElements()) {
				//System.out.println("Twitter Friends : -- " + twitter_friends);
				//System.out.println("Twitter Friends : -- " + twitter_friends);
				String element = e3.nextElement(); 
				friends.put(element, twitter_friends.get(element));
			}
			
	
			Enumeration<String> e1 = MeetIn_friends.keys();
			while(e1.hasMoreElements())
			{
				String element = e1.nextElement(); 
				friends.put(element, MeetIn_friends.get(element));
			}
			if(!Gmail_friends.containsKey("ERROR"))
			{
				Enumeration<String> e2 = Gmail_friends.keys();
	            while(e2.hasMoreElements())
	            {
	                    String element = e2.nextElement(); 
	                    friends.put(element, Gmail_friends.get(element));
	            }
			}
			
			} catch (Exception e) {
				log.error("Exception Error --  "+e);
			}	
		}
		else  
		{*/
			try {
			
			UserAccountDAO accountdao = new UserAccountDAO();
			
			
			MeetIn_friends = accountdao.getFriendsNames_Ids(location,userId);
			
			System.out.println("meetin friends size *** * * * * * * "+MeetIn_friends.size());
			
			return MeetIn_friends;
			
			} catch (Exception e) {
				log.error("Exception in meetin else case ---  "+e);
			}
			
	//	}
		return friends;
	}

	public Hashtable<String, List<String>> peopleFinder(int userId, String location, int socialMedia) throws Exception 
	{
		System.out.println("people finder ");
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		NetworkDAO socialnetwork = new NetworkDAO();
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy 'at' hh:mm 'Hrs' zzz");
				
		try
		{
			
			String latlang = new LocationDAO().getCityLatitudeLongitude(location.toLowerCase());
			
			List list =null;
			if(socialMedia == NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE_CHECKIN)
			{
				list = new SocialNetworkDAO().getFourSquareCheckinFriendProfile(userId, socialMedia, location);
				System.out.println("foursquare checkins returnred *** * * * * ** * " + list.size());
			}
			else{
				 list = new SocialNetworkDAO().getSocialFriendsProfile(userId, socialMedia, location);	
			}
			
			System.out.println(list.size());
			
			Iterator itr = list.iterator();
			String  latitude = "", langitude = "";
			while(itr.hasNext())
			{
				Object[] object = (Object[]) itr.next();
				List<String> friend_info = new ArrayList<String>();
				friend_info.add((String)object[1]);
				friend_info.add((String) object[2]);
				friend_info.add((String) object[7]);
			
				if (!latlang.equals(""))
				{
					latitude = latlang.split(":")[0];
					langitude = latlang.split(":")[1];
				}
				
				friend_info.add(latitude); // facebok user's latitude
				friend_info.add(langitude); // facebook user's langitude
				friend_info.add(""); // empty value
				friend_info.add((String) object[3]); // user profile image
				friend_info.add(""); // meetin user's gender
				friend_info.add(sdf.format((Date) object[8]));
				friends.put(String.valueOf((Integer) object[6]), friend_info);
							
			}
			
			//MeetIn_friends = accountdao.getFriendsNames_Ids(location,userId);
			//System.out.println("Friend List ::" +friends.size());
			
		}catch (Exception e) {
			e.printStackTrace();
		}	
		
		return friends;
	}
	public Hashtable<String, List<String>> peopleFinder1(int userId, String location) throws Exception 
	{
		
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		Hashtable<String, List<String>> MeetIn_friends = new Hashtable<String, List<String>>();
		
		UserAccountDAO accountdao = new UserAccountDAO();
		MeetIn_friends = accountdao.getFriendsNames_Ids(location,userId);
		NetworkDAO socialnetwork = new NetworkDAO();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy HH:mm ");
				
		try
		{
			
			String latlang = new LocationDAO().getCityLatitudeLongitude(location.toLowerCase());
			List list = new SocialNetworkDAO().getAllSocialFriendsWithlocationWise(userId, location);
			
			Iterator itr = list.iterator();
			String  latitude = "", langitude = "";
			while(itr.hasNext())
			{
				Object[] object = (Object[]) itr.next();
				List<String> friend_info = new ArrayList<String>();
				friend_info.add((String)object[1]);
				friend_info.add((String) object[2]);
				friend_info.add((String) object[7]);
			
				if (!latlang.equals(""))
				{
					latitude = latlang.split(":")[0];
					langitude = latlang.split(":")[1];
				}
				
				friend_info.add(latitude); // facebok user's latitude
				friend_info.add(langitude); // facebook user's langitude
				friend_info.add(""); // empty value
				friend_info.add((String) object[3]); // user profile image
				friend_info.add(""); // meetin user's gender
				//friend_info.add(sdf.format((Date) object[8]));
				friends.put(String.valueOf((Integer) object[6]), friend_info);
							
			}
			friends.putAll(MeetIn_friends);
			//System.out.println("Friend List ::" +friends.size());
			
		}catch (Exception e) {
			e.printStackTrace();
		}	
		
		return friends;
	}
	
	public int callStoredProcAdvanceSearch(String fromDate,String toDate,Integer userId,String location){
		int last_trip_id = 0;
		try{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			Query query = session.createSQLQuery("CALL advance_search3('"+fromDate+"','"+toDate+"','"+location+"','"+userId+"')")
			.addEntity(Temp.class);
			query.executeUpdate();
			tx.commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return last_trip_id;
	}
	
	public Hashtable<String, List<String>> advanceSearchNew(String location, String fromDate, String toDate,Integer userId) throws ParseException
	{
		Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		List resultList =null;
		try{
		
		Hashtable queryParam = new Hashtable();
		String profile_path = "profile_page.jsp";
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		
		if(!location.trim().equals("") || !fromDate.trim().equals("") || !toDate.trim().equals(""))
			{
			String fromDate1=sdf1.format(sdf.parse(fromDate));
			String toDate1=sdf1.format(sdf.parse(toDate));
			callStoredProcAdvanceSearch(fromDate1,toDate1,userId,location);
				//String queryString ="SELECT userId,fullname,location FROM Temp";
			String queryString ="SELECT t.userId,t.fullname,t.location,u.image,u.gender FROM Temp as t,User as u WHERE t.userId=u.userId";		
						System.out.println("fromDate "+fromDate1);
						System.out.println("toDate "+toDate1);
					
					Session session = HibernateUtil.getSessionFactory().getCurrentSession();
					session.beginTransaction();
					Query query = session.createQuery(queryString);
					//System.out.println("query  "+query);
					Enumeration e = queryParam.keys();
					while( e.hasMoreElements())
					{
						String key = e.nextElement().toString();
						//System.out.println("key:: "+key);
						query.setParameter(key, queryParam.get(key));
						 
					}
					resultList = query.list();
					session.getTransaction().commit();
					//System.out.println("resultList "+resultList.size());
					for(int k=0;k < resultList.size();k++)
					{
						Object[] object= (Object[])resultList.get(k);
						
						List<String> friendinfo = new ArrayList<String>();
						//System.out.println("name:::: "+(String)object[1]);
						friendinfo.add((String)object[1]);
						friendinfo.add(profile_path+"?id=" + object[0]);
						friendinfo.add("images/meetin_icon.png");
						friendinfo.add("");
						friendinfo.add("");
						friendinfo.add((String)object[2]);
						String imageUrl = ((String)object[3] !=null ? "profileimage/"+(String)object[3] : (((String) object[4]).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png")); //user image
						friendinfo.add(imageUrl);
						friendinfo.add((String)object[4]);
						//System.out.println("Friend info elements in people finder action"+friendinfo.toString());
						friendList.put(String.valueOf(object[0]), friendinfo);
						
					}
				}else
				{
					System.out.print("No Result due to empty search string");
				}
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		//System.out.println("listttttt "+friendList.size());
	return friendList;

 }
	public int callStoredProcAdvanceSearchWithInte(String fromDate,String toDate,Integer userId,String interest,String location){
		int last_trip_id = 0;
		try{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			Query query = session.createSQLQuery("CALL advance_search4('"+fromDate+"','"+toDate+"','"+location+"','"+interest+"','"+userId+"')")
			.addEntity(Temp.class);
			query.executeUpdate();
			tx.commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return last_trip_id;
	}
	public Hashtable<String, List<String>> advanceSearchWithInterest(String location, String fromDate, String toDate,String interest,int userId)
	{
		Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		List resultList =null;
		try{
		
		Hashtable queryParam = new Hashtable();
		String profile_path = "profile_page.jsp";
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		
		if(!location.trim().equals("") || !fromDate.trim().equals("") || !toDate.trim().equals("") || !interest.trim().equals("") )
			{
			String fromDate1=sdf1.format(sdf.parse(fromDate));
			String toDate1=sdf1.format(sdf.parse(toDate));
			callStoredProcAdvanceSearchWithInte(fromDate1,toDate1,userId,interest,location);
			String queryString ="SELECT t.userId,t.fullname,t.location,u.image,u.gender FROM Temp as t,User as u WHERE t.userId=u.userId";
			//String queryString ="SELECT userId,fullname,location FROM Temp";
						
					//System.out.println("fromDate "+fromDate1);
					//System.out.println("toDate "+toDate1);
			
					Session session = HibernateUtil.getSessionFactory().getCurrentSession();
					session.beginTransaction();
					Query query = session.createQuery(queryString);
			//		System.out.println("query  "+query);
					Enumeration e = queryParam.keys();
					while( e.hasMoreElements())
					{
						String key = e.nextElement().toString();
						System.out.println("key:: "+key);
						query.setParameter(key, queryParam.get(key));
						 
					}
					resultList = query.list();
					session.getTransaction().commit();
					//System.out.println("resultList "+resultList.size());
					for(int k=0;k < resultList.size();k++)
					{
						Object[] object= (Object[])resultList.get(k);
						List<String> friendinfo = new ArrayList<String>();
						//System.out.println("name:::: "+(String)object[1]);
						friendinfo.add((String)object[1]);
						friendinfo.add(profile_path+"?id=" + object[0]);
						friendinfo.add("images/meetin_icon.png");
						friendinfo.add("");
						friendinfo.add("");
						friendinfo.add((String)object[2]);
						String imageUrl = ((String)object[3] !=null ? "profileimage/"+(String)object[3] : (((String) object[4]).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png")); //user image
						friendinfo.add(imageUrl);
						friendinfo.add((String)object[4]);
						//System.out.println("Friend info elements in people finder action"+friendinfo.toString());
						friendList.put(String.valueOf(object[0]), friendinfo);
						
					}
				}else
				{
					System.out.print("No Result due to empty search string");
				}
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		//System.out.println("listttttt "+friendList.size());
	return friendList;

 }
	public Hashtable<String, List<String>> advanceSearchLocationAndInterest(String location,String interest,int userId)
	{
		
		Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		List resultList =null;
		try{
		
		Hashtable queryParam = new Hashtable();
		String profile_path = "profile_page.jsp";
		
		if(!location.trim().equals("") && !interest.trim().equals("") )
			{
			
				String queryString ="SELECT DISTINCT a.userId,a.fullname,c.destination,a.image,a.gender  FROM User AS a,Friends AS b,Trips_detail AS c,Interestmaster AS interestmaster," +
						"Interest AS interest WHERE ((a.userId=b.userId1 AND b.userId2='"+userId+"' AND b.status='Approve')OR (a.userId=b.userId2 AND b.userId1='"+userId+"' AND b.status= 'Approve' ))" +
						"	 AND interestmaster.interestId IN ('"+interest+"') AND a.userId=interest.userId AND interestmaster.interestId=interest.interestId" +
						" AND a.locCity LIKE CONCAT('"+location+"', '%') AND a.userId NOT IN (SELECT userId FROM Trips_detail WHERE a.locCity LIKE CONCAT('"+location+"', '%') AND" +
								" (fromDate <=CURDATE() AND toDate >=CURDATE() OR fromDate >= CURDATE()) AND (fromDate >=CURDATE() AND toDate <=CURDATE() OR fromDate <= CURDATE()))" +
								" GROUP BY a.userId";
						
						
					Session session = HibernateUtil.getSessionFactory().getCurrentSession();
					session.beginTransaction();
					Query query = session.createQuery(queryString);
					System.out.println("query  "+query);
					Enumeration e = queryParam.keys();
					while( e.hasMoreElements())
					{
						String key = e.nextElement().toString();
						System.out.println("key:: "+key);
						query.setParameter(key, queryParam.get(key));
						 
					}
					resultList = query.list();
					session.getTransaction().commit();
					System.out.println("resultList "+resultList.size());
					for(int k=0;k < resultList.size();k++)
					{
						Object[] object= (Object[])resultList.get(k);
						
						List<String> friendinfo = new ArrayList<String>();
						friendinfo.add((String)object[1]);
						friendinfo.add(profile_path+"?id=" + object[0]);
						friendinfo.add("images/meetin_icon.png");
						friendinfo.add("");
						friendinfo.add("");
						friendinfo.add("");
						String imageUrl = ((String)object[3] !=null ? "profileimage/"+(String)object[3] : (((String) object[4]).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png")); //user image
						friendinfo.add(imageUrl);
						friendinfo.add((String)object[4]);
						//System.out.println("Friend info elements in people finder action"+friendinfo.toString());
						friendList.put(String.valueOf(object[0]), friendinfo);
					}
				}else
				{
					System.out.print("No Result due to empty search string");
				}
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		//System.out.println("listttttt "+friendList.size());
	return friendList;

 }public Hashtable<String, List<String>> advanceSearchDateWithInterest(String fromDate,String toDate,String interest,int userId)
	{
		Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		List resultList =null;
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		Hashtable queryParam = new Hashtable();
		String profile_path = "profile_page.jsp";
		
		
		if(!fromDate.trim().equals("") && !fromDate.trim().equals("") && !interest.trim().equals("") )
			{
			String fromDate1=sdf1.format(sdf.parse(fromDate));
			String toDate1=sdf1.format(sdf.parse(toDate));
				String queryString ="SELECT DISTINCT a.userId,a.fullname,c.destination,a.image,a.gender  FROM User AS a,Friends AS b,Trips_detail AS c,Interestmaster AS interestmaster, " +
						"Interest AS interest 	WHERE (a.userId IN (SELECT userId FROM Trips_detail WHERE " +
						"(((fromDate BETWEEN '"+fromDate1+"' AND '"+toDate1+"') OR (toDate BETWEEN '"+fromDate1+"' AND '"+toDate1+"'))OR " +
						"(((fromDate>='"+fromDate1+"' OR fromDate='"+toDate1+"' ) AND (toDate<='"+toDate1+"' OR toDate='"+fromDate1+"')) OR	" +
						"((from_date<='"+fromDate1+"' OR fromDate='"+toDate1+"') AND (toDate>='"+toDate1+"' OR toDate='"+fromDate1+"'))))) AND " +
						" interestmaster.interestId IN ('"+interest+"') AND a.userId=interest.userId AND interestmaster.interestId=interest.interestId AND " +
						"((a.userId=b.userId1 AND b.userId2='"+userId+"' AND b.status='Approve')OR (a.userId=b.userId2 AND b.userId1='"+userId+"' AND b.status= 'Approve' ))) " +
						" GROUP BY a.userId";
						
						
					Session session = HibernateUtil.getSessionFactory().getCurrentSession();
					session.beginTransaction();
					Query query = session.createQuery(queryString);
					//System.out.println("query  "+query);
					Enumeration e = queryParam.keys();
					while( e.hasMoreElements())
					{
						String key = e.nextElement().toString();
						//System.out.println("key:: "+key);
						query.setParameter(key, queryParam.get(key));
						 
					}
					resultList = query.list();
					session.getTransaction().commit();
					System.out.println("resultList "+resultList.size());
					for(int k=0;k < resultList.size();k++)
					{
						Object[] object= (Object[])resultList.get(k);
						
						List<String> friendinfo = new ArrayList<String>();
						friendinfo.add((String)object[1]);  // fullname
						friendinfo.add(profile_path+"?id=" + object[0]); // profilepath
						friendinfo.add("images/meetin_icon.png"); // socialicon
						friendinfo.add("");
						friendinfo.add("");
						friendinfo.add("");
						String imageUrl = ((String)object[3] !=null ? "profileimage/"+(String)object[3] : (((String) object[4]).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png")); //user image
						friendinfo.add(imageUrl);
						friendinfo.add((String)object[4]);
						//System.out.println("Friend info elements in people finder action"+friendinfo.toString());
						friendList.put(String.valueOf(object[0]), friendinfo);
					}
				}else
				{
					System.out.print("No Result due to empty search string");
				}
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		//System.out.println("listttttt "+friendList.size());
	return friendList;

}
	public Hashtable<String, List<String>> advanceSearchWithDate(String fromDate,String toDate,int userId) throws ParseException
	{
		
		//System.out.println(fromDate);
		//System.out.println(toDate);
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		
		Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		List resultList =null;
		try{
		
		Hashtable queryParam = new Hashtable();
		String profile_path = "profile_page.jsp";
		
		
		if(!fromDate.trim().equals("") && !toDate.trim().equals("") )
			{
			String fromDate1=sdf1.format(sdf.parse(fromDate));
			String toDate1=sdf1.format(sdf.parse(toDate));
				String queryString ="SELECT DISTINCT a.userId,a.fullname,c.destination,a.image,a.gender  FROM User AS a,Friends AS b,Trips_detail AS c	WHERE " +
						"(a.userId IN (SELECT userId FROM Trips_detail WHERE (((fromDate BETWEEN '"+fromDate1+"' AND '"+toDate1+"') OR (toDate BETWEEN '"+fromDate1+"' AND '"+toDate1+"')) " +
						"OR (((fromDate>='"+fromDate1+"' OR fromDate='"+toDate1+"' ) AND (toDate<='"+toDate1+"' OR toDate='"+fromDate1+"'))	OR" +
						"((fromDate<='"+fromDate1+"' OR fromDate='"+toDate1+"') AND (toDate>='"+toDate1+"' OR toDate='"+fromDate1+"'))))) AND" +
						"((a.userId=b.userId1 AND b.userId2='"+userId+"' AND b.status='Approve') OR (a.userId=b.userId2 AND b.userId1='"+userId+"' AND b.status= 'Approve' )))" +
						" GROUP BY a.userId";
					Session session = HibernateUtil.getSessionFactory().getCurrentSession();
					session.beginTransaction();
					Query query = session.createQuery(queryString);
					
					Enumeration e = queryParam.keys();
					while( e.hasMoreElements())
					{
						String key = e.nextElement().toString();
						query.setParameter(key, queryParam.get(key));
						 
					}
					resultList = query.list();
					session.getTransaction().commit();
					
					for(int k=0;k < resultList.size();k++)
					{
						Object[] object= (Object[])resultList.get(k);
						List<String> friendinfo = new ArrayList<String>();
						friendinfo.add((String)object[1]);
						friendinfo.add(profile_path+"?id=" + object[0]);
						friendinfo.add("images/meetin_icon.png");
						friendinfo.add("");
						friendinfo.add("");
						friendinfo.add("");
						String imageUrl = ((String)object[3] !=null ? "profileimage/"+(String)object[3] : (((String) object[4]).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png")); //user image
						friendinfo.add(imageUrl);
						friendinfo.add((String)object[4]);
						//System.out.println("Friend info elements in people finder action"+friendinfo.toString());
						friendList.put(String.valueOf(object[0]), friendinfo);
					}
				}else
				{
					System.out.print("No Result due to empty search string");
				}
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		
	return friendList;

 }
	public Hashtable<String, List<String>> advanceSearchOnlyInterest(String interest,int userId)
	{
		
		Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		List resultList =null;
		try{
		
		Hashtable queryParam = new Hashtable();
		String profile_path = "profile_page.jsp";
		
		if( !interest.trim().equals("") )
			{
			
				String queryString ="SELECT DISTINCT a.userId,a.fullname,c.destination,a.image,a.gender  FROM User AS a,Friends AS b,Trips_detail AS c,Interestmaster AS interestmaster," +
						"Interest AS interest WHERE (((a.userId=b.userId1 AND b.userId2='"+userId+"' AND b.status='Approve')OR (a.userId=b.userId2 AND b.userId1='"+userId+"' AND b.status= 'Approve' ))" +
						"	 AND interestmaster.interestId IN ("+interest+") AND a.userId=interest.userId AND interestmaster.interestId=interest.interestId )" +
						"	 GROUP BY a.userId";
						
				    
					Session session = HibernateUtil.getSessionFactory().getCurrentSession();
					session.beginTransaction();
					Query query = session.createQuery(queryString);
					
					Enumeration e = queryParam.keys();
					while( e.hasMoreElements())
					{
						String key = e.nextElement().toString();
						query.setParameter(key, queryParam.get(key));
						 
					}
					resultList = query.list();
					session.getTransaction().commit();
					
					for(int k=0;k < resultList.size();k++)
					{
						Object[] object= (Object[])resultList.get(k);
						
						List<String> friendinfo = new ArrayList<String>();
						friendinfo.add((String)object[1]);
						friendinfo.add(profile_path+"?id=" + object[0]);
						friendinfo.add("images/meetin_icon.png");
						friendinfo.add("");
						friendinfo.add("");
						friendinfo.add("");
						
						String imageUrl = ((String)object[3] !=null ? "profileimage/"+(String)object[3] : (((String) object[4]).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png")); //user image
						
						friendinfo.add(imageUrl);
						friendinfo.add((String)object[4]);
						friendList.put(String.valueOf(k), friendinfo);
					}
				}else
				{
					System.out.print("No Result due to empty search string");
				}
		
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		
	return friendList;

 }
	//Modified by Rupal Kathiriya to get tripwise  by date wise and location wise dated on 8th august 2012
	public Hashtable<String, List<String>> advanceSearch(String location, String fromDate, String toDate, String interest,int userId)
	{
		System.out.println("location "+location);
		System.out.println("fromDate "+fromDate);
		System.out.println("toDate "+toDate);
		System.out.println("interest "+interest);
		System.out.println("userId "+userId);
		Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		//System.out.println("advance search");
		List resultList =null;
		try{
		//String queryString ="select distinct user.userId,user.fullname  from User as user,Trips as trip,Interestmaster as interestmaster,Interest as interest  where";
		String queryString ="SELECT DISTINCT a.userId,a.fullname,c.destination  FROM User a as a,Friends b as b, Trips c as c,Interestmaster as interestmaster,Interest as interest WHERE ";
		Hashtable queryParam = new Hashtable();
		//Hashtable<String, List<String>> friendList = new Hashtable<String, List<String>>();
		int i =0;
		
		String profile_path = "profile_page.jsp";
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		//try{
		
			if(!location.trim().equals("") || !fromDate.trim().equals("") || !toDate.trim().equals("") || !interest.trim().equals(""))
			{
			if(!location.trim().equals(""))
				{
				//System.out.println("locationnnnnnnnnn");
				//queryString +=" user.locCity=:locCity";
					queryString +="(a.locCity like concat(:locCity,'%') AND ((a.userId=b.userId1 AND b.userId2=:userId AND b.status='Approve') OR (a.userId=b.userId2 AND b.userId1=:userId AND b.status= 'Approve' )))";
					queryParam.put("locCity", location);
					queryParam.put("userId", userId);
					i++;
				}
			if(!fromDate.trim().equals("") && !toDate.trim().equals(""))
			{
				if(i > 0)
				{
					//System.out.println("ifffffffff");
					queryString+="OR (a.userId IN (SELECT c.userId FROM Trips WHERE c.destination like concat(:locCity,'%') " +
							"AND(((c.fromDate>=:fromDate OR c.fromDate=:toDate) AND (c.toDate<=:toDate OR c.toDate=:fromDate))OR ((c.fromDate<=:fromDate OR c.fromDate=:toDate) AND (c.toDate>=:toDate  OR c.toDate=:fromDate)))) " +
							"AND ((a.userId=b.userId1 AND b.userId2=:userId AND b.status='Approve')OR (a.userId=b.userId2 AND b.userId1=:userId AND b.status= 'Approve' )))"; 
				 //queryString +=" and trip.fromDate >=:fromDate and trip.toDate <=:toDate and trip.userId=user.userId";
				}	
				else
				{
					//System.out.println("elseeeeeeee");
					queryString+=" (a.userId IN (SELECT c.userId FROM Trips WHERE c.destination like concat(:locCity,'%') " +
							"AND(((c.fromDate>=:fromDate OR c.fromDate=:toDate) AND (c.toDate<=:toDate OR c.toDate=:fromDate))OR ((c.fromDate<=:fromDate OR c.fromDate=:toDate) AND (c.toDate>=:toDate  OR c.toDate=:fromDate)))) " +
							"AND ((a.userId=b.userId1 AND b.userId2=:userId AND b.status='Approve')OR (a.userId=b.userId2 AND b.userId1=:userId AND b.status= 'Approve' )))"; 
				 //queryString +=" trip.fromDate >=:fromDate and trip.toDate <=:toDate and trip.userId=user.userId";
			    }
				queryParam.put("fromDate", sdf1.parse(sdf1.format(sdf.parse(fromDate))));
				queryParam.put("toDate", sdf1.parse(sdf1.format(sdf.parse(toDate))));
				queryParam.put("locCity", location);
				queryParam.put("userId", userId);
			}
			if(!interest.trim().equals(""))
			{
				//System.out.println("interest *********************************");
				if(i > 0)
				{
					//System.out.println("interest ********************************* if");
					 queryString +=" and interestmaster.interestId in ("+ interest +") and a.userId=interest.userId and interestmaster.interestId=interest.interestId";
				}
				else
				{
					//System.out.println("interest ********************************* else ");
					queryString +=" interestmaster.interestId in ("+ interest +") and a.userId=interest.userId and interestmaster.interestId=interest.interestId";
				}
				
			}
			
			queryString +=" order by a.fullname asc";
			System.out.println("queryString "+queryString);
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
		
			Enumeration e = queryParam.keys();
			while( e.hasMoreElements())
			{
				String key = e.nextElement().toString();
				query.setParameter(key, queryParam.get(key));
				 
			}
			
			resultList = query.list();
			session.getTransaction().commit();
			
			for(int k=0;k < resultList.size();k++)
			{
				Object[] object= (Object[])resultList.get(k);
				
				List<String> friendinfo = new ArrayList<String>();
				friendinfo.add((String)object[1]);
				friendinfo.add(profile_path+"?id=" + object[0]);
				friendinfo.add("images/meetin_icon.png");
				friendinfo.add((String)object[2]);
				//System.out.println("Friend info elements in people finder action"+friendinfo.toString());
				friendList.put(String.valueOf(object[0]), friendinfo);
			}
		}
		else
		{
			System.out.print("No Result due to empty search string");
		}
	
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		
	return friendList;

 }
	
	/** This method is used to store date of meeting invitation send and friends email id */
	  /*public void storeData(int userid ,String sendername , String toEmail , String message)
	  {
		  //System.out.println("store data method called -----------------------------------");
		  //System.out.println("sender name is --- "+sendername+ " --- email id -- " +toEmail+" -- message is -- "+message);

			Connection connection = null;
			Statement statement = null;
			try {
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection("jdbc:mysql://192.168.1.6:3306/meetin2","gaurav","google.com");
				
				PreparedStatement preparedStatement  = connection.prepareStatement("insert into invitation_master (user_id,username,email,message) values(?,?,?,?)");
				preparedStatement.setInt(1, userid);
				preparedStatement.setString(2,sendername);
				preparedStatement.setString(3,toEmail);
				preparedStatement.setString(4, message);
				preparedStatement.executeUpdate();
			
			} catch (Exception e) {
				//System.out.println("unable to insert Data ");
				//System.out.println("Exception occured " + e );
			}
		  
	  }*/
	
	
// overloaded method
/**This is the method to get the friends on a current date and on a given location */
 public List getPeopleNearOnCurrentDate(int userId, String location)
	  {
		  	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String friend_status ="Approve";
			String profile_path ="profile_page.jsp";
			List list = null;
			
			try{
				String queryString ="select t.userId,u.fullname,t.destination,t.destinationLatitude,t.destinationLongitude,u.image,u.gender from Trips t, User u where (t.destination like concat('%', ?, '%') or ? like concat('%', t.destination, '%'))" 
					+ " and t.fromDate <=? and t.toDate >=?"
					+ " and (t.userId in (select userId1 from Friends where userId2 = ? and status = ?) or t.userId in (select userId2 from Friends"
					+ " where userId1 = ? and status = ?)) and t.userId=u.userId";
			
			
				log.info("Trying to user's current location friends on current date.......");
				
				Session session = HibernateUtil.getSessionFactory().getCurrentSession();
				session.beginTransaction();
				
			    Query query = session.createQuery(queryString);
			    query.setParameter(0, location);
			    query.setParameter(1, location);
			    query.setParameter(2, sdf.parse(sdf.format(new Date())));
			    query.setParameter(3, sdf.parse(sdf.format(new Date())));
			    query.setParameter(4, userId);
			    query.setParameter(5, friend_status);
			    query.setParameter(6, userId);
			    query.setParameter(7, friend_status);
			    list = query.list();
			    session.getTransaction().commit();
			}
			catch(Exception ex)
			{
				log.error("There is a problem in getting current location friends on current date");
				log.debug(ex);
				ex.printStackTrace();
			}
			return list;
	  }
 
  /**This is the method to get the friends on a upcoming date on a given location */
  public List getPeopleNearOnUpcomingDate(int userId, String location)
 {
	  
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String friend_status ="Approve";
		String profile_path ="profile_page.jsp";
		List list = null;
				
		try{
			String queryString ="select t.userId,u.fullname,t.destination,t.destinationLatitude,t.destinationLongitude,u.image,u.gender from  Trips p, Trips t, User u where p.userId = ?"
			 	+" and ( p.destination like concat('%',?,'%') or ? like concat('%', p.destination, '%'))"
			 	+" and ( p.fromDate <=? and p.toDate >=? or p.fromDate >= ?)"
			 	+" and ((( p.fromDate between t.fromDate and t.toDate and ( p.destination like concat('%', t.destination, '%') or t.destination like concat('%', p.destination, '%')))"
			 	+" or ( t.fromDate between p.fromDate and p.toDate and ( p.destination like concat('%', t.destination, '%') OR t.destination like concat('%', p.destination, '%')) )) and ( t.fromDate <=? AND t.toDate >=? or t.fromDate >= ? ))"
			 	+" and (t.userId in (select userId1 from Friends where userId2 = ? and status = ?) or t.userId in(select userId2 from Friends where userId1 =? and status = ? ))"
			 	+" and t.userId=u.userId";

			
			log.info("Trying to user's upcoming location friends on upcoming date.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    
		    query.setParameter(0, userId);
		    query.setParameter(1, location);
		    query.setParameter(2, location);
		    query.setParameter(3, sdf.parse(sdf.format(new Date())));
		    query.setParameter(4, sdf.parse(sdf.format(new Date())));
		    query.setParameter(5, sdf.parse(sdf.format(new Date())));
		    query.setParameter(6, sdf.parse(sdf.format(new Date())));		    
		    query.setParameter(7, sdf.parse(sdf.format(new Date())));
		    query.setParameter(8, sdf.parse(sdf.format(new Date())));
		    query.setParameter(9, userId);
		    query.setParameter(10, friend_status);
		    query.setParameter(11, userId);
		    query.setParameter(12, friend_status);
		    
		    list = query.list();
		    session.getTransaction().commit();
		    		    
		    log.info("People near on upcoming date found, Size :" +list.size());
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting friend on upcoming date");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return list;
 }
 
  public List getPeopleNearOnUpcomingDateWebservice(int userId, String location)
  {
 	 
 		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
 		Date date = new Date();
 		System.out.println("getpeoplenearmeonpcoming date called " + dateFormat.format(date));
 		
 		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
 		String friend_status ="Approve";
 		String profile_path ="profile_page.jsp";
 		List list = null;
 				
 		try{
 		String queryString ="select DISTINCT p.userId,u.fullname,p.destination,p.destinationLatitude,p.destinationLongitude,u.image,u.gender from  Trips p,  User u where"
 		+"( p.destination like concat('%',?,'%') or ? like concat('%', p.destination, '%'))"
 	 	+" and (p.fromDate <=CURDATE() AND p.toDate >=CURDATE() OR p.fromDate >= CURDATE()) AND " +
 	 			"(p.fromDate >=CURDATE() AND p.toDate <=CURDATE() OR p.fromDate <= CURDATE())"
 	 	+" and ((( p.fromDate between p.fromDate and p.toDate and ( p.destination like concat('%', p.destination, '%') or p.destination like concat('%', p.destination, '%')))"
 	 	+" or ( p.fromDate between p.fromDate and p.toDate and ( p.destination like concat('%', p.destination, '%') OR p.destination like concat('%', p.destination, '%')) )) and ( p.fromDate <=? AND p.toDate >=? or p.fromDate >= ? ))"
 	 	+" and (p.userId in (select userId1 from Friends where userId2 = ? and status = ?) or p.userId in(select userId2 from Friends where userId1 =? and status = ? ))"
 	 	+" and p.userId=u.userId group by u.userId";
 			
 			log.info("Trying to user's location on upcoming date.......");
 			
 			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
 			session.beginTransaction();
 			
 		    Query query = session.createQuery(queryString);
 		    
 		    query.setParameter(0, location);
 		    query.setParameter(1, location);
 		    //query.setParameter(2, sdf.parse(sdf.format(new Date())));
 		    //query.setParameter(3, sdf.parse(sdf.format(new Date())));
 		    //query.setParameter(4, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(2, sdf.parse(sdf.format(new Date())));		    
 		    query.setParameter(3, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(4, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(5, userId);
 		    query.setParameter(6, friend_status);
 		    query.setParameter(7, userId);
 		    query.setParameter(8, friend_status);
 		    
 		    System.out.println("before query " + dateFormat.format(date));
 		    list = query.list();
 		    System.out.println("after query called " + dateFormat.format(date));
 		    session.getTransaction().commit();
 		    /*
 		    for(int i=0;i<list.size();i++)
 		    {
 		    	Object object[] =(Object[]) list.get(i);
 		    }*/
 		    
 		    log.info("People near on upcoming date found, Size :" +list.size());
 		    
 		}
 		catch(Exception ex)
 		{
 			log.error("There is a problem in getting upcoming trips");
 			log.debug(ex);
 			ex.printStackTrace();
 		}
		
 		return list;
  }
  public List getViewPeopleUpcomingTripDetail(int myuserid,int frienduserid)
  {
	  	  
	  List list = null;
	  String queryString  = "select t.destination, t.fromDate, t.toDate from Trips t where t.userId = "+frienduserid + " AND CURDATE() <= to_date ";
	  
	  try
	  {
		  Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		  session.beginTransaction();
			
		  Query query = session.createQuery(queryString);
		  list = query.list();  
		  session.getTransaction().commit();
		  
	  }
	  catch (Exception ex) 
	  {
			log.error("There is a problem in getting View user's upcoming trips details");
 			log.debug(ex);
	  }
 		
	  return list;
  }
  //Modified by rupal Kathiriya to get trip friends on base location dated on 2nd jan 2013
  public List getPeopleUpcomingTripDetail(int myuserId,int frienduserId, String location)
  {
	
 		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
 		String friend_status ="Approve";
 		String profile_path ="profile_page.jsp";
 		List list = null;
 		try{
 			String queryString ="select distinct t.userId,u.fullname,t.destination,t.destinationLatitude,t.destinationLongitude,t.fromDate,t.toDate from  Trips p, Trips t, User u where t.userId=?"
 								+" and ( t.destination like concat('%',?,'%') or ? like concat('%', t.destination, '%'))"
 							 	+" and ( p.destination like concat('%',?,'%') or ? like concat('%', p.destination, '%'))"
 							 	+" and ( p.fromDate <=? and p.toDate >=? or p.fromDate >= ?)"
 							 	+" and ((( p.fromDate between t.fromDate and t.toDate and ( p.destination like concat('%', t.destination, '%') or t.destination like concat('%', p.destination, '%')))"
 							 	+" or ( t.fromDate between p.fromDate and p.toDate and ( p.destination like concat('%', t.destination, '%') OR t.destination like concat('%', p.destination, '%')) )) and ( t.fromDate <=? AND t.toDate >=? or t.fromDate >= ? ))"
 							 	+" and (t.userId in (select userId1 from Friends where userId2 = ? and status = ?) or t.userId in(select userId2 from Friends where userId1 =? and status = ? ))"
 							 	+" and t.userId=u.userId";
 			
 			log.info("Trying to get user's trip details on upcoming date.......");
 			
 			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
 		    Query query = session.createQuery(queryString);
 		   
 		    query.setParameter(0, frienduserId);
 		    query.setParameter(1, location);
 		    query.setParameter(2, location);
 		    query.setParameter(3, location);
 		    query.setParameter(4, location);
 		    query.setParameter(5, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(6, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(7, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(8, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(9, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(10, sdf.parse(sdf.format(new Date())));
 		    query.setParameter(11, myuserId);
 		    query.setParameter(12, friend_status);
 		    query.setParameter(13, myuserId);
 		    query.setParameter(14, friend_status);
 		    		   		    
 		    list = query.list();
 		    session.getTransaction().commit();
 		   
 		    log.info("User's upcoming trip details found, Size :" +list.size());
 		}
 		catch(Exception ex)
 		{
 			log.error("There is a problem in getting user's upcoming trips details");
 			log.debug(ex);
 			ex.printStackTrace();
 		}
 		 		
 		return list;
  }
  public List getPeopleNearOnCurrentDate(int userId)
  {
	  
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String friend_status ="Approve";
		String profile_path ="profile_page.jsp";
		List list = null;
		try{
			
			String queryString ="select t.userId,u.fullname,t.destination from  Trips p, Trips t, User u where ( p.destination LIKE CONCAT('%', t.destination, '%') OR t.destination LIKE CONCAT('%', p.destination, '%') ) and p.userId = ?" 
				+ " and p.fromDate <=? and p.toDate >=? and t.fromDate <=? and t.toDate >=?"
				+ " and (t.userId in (select userId1 from Friends where userId2 = ? and status = ?) or t.userId in (select userId2 from Friends"
				+ " where userId1 = ? and status = ?)) and t.userId=u.userId";
							 
				
			log.info("Trying to user's location on current date.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(2, sdf.parse(sdf.format(new Date())));
		    query.setParameter(3, sdf.parse(sdf.format(new Date())));
		    query.setParameter(4, sdf.parse(sdf.format(new Date())));
		    query.setParameter(5, userId);
		    query.setParameter(6, friend_status);
		    query.setParameter(7, userId);
		    query.setParameter(8, friend_status);
		    list = query.list();
		    session.getTransaction().commit();
		   
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting upcoming trips");
			log.debug(ex);
			ex.printStackTrace();
		}
				
		return list;
  }
  /**This is the method for getting the user's current location on current date */
  public List<String> getUserLocationOnCurrentDate(int userId)
	{
	  
	  
	    log.info("Inside user Current location on current date");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   Date date = new Date();
		System.out.println(" " + dateFormat.format(date));
		
		List<String> destination =null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="select trip.destination from Trips as trip where trip.fromDate <= ? and toDate >=? and userId=? order by trip.destination"; 
		try
		{
			
			log.info("Trying to user's location on current date.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(2, userId);
		    System.out.println("before query " + dateFormat.format(date));
		    destination =query.list();
		    session.getTransaction().commit();
		    System.out.println("after comming query " + dateFormat.format(date));
		    
		    log.info("User's location on current date :" +destination);
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting upcoming trips");
			log.debug(ex);
			ex.printStackTrace();
		}
		System.out.println("size:::"+destination.size());
	   return destination;	
	   
	}
  

  public List<String> geTripitUserLocationOnCurrentDate(int userId)
	{
	  
	  
	    log.info("Inside user Current location on current date");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   Date date = new Date();
		System.out.println(" " + dateFormat.format(date));
		
		List<String> destination =null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="select trip.destination from Tripit_Trips as trip where trip.fromDate <= ? and toDate >=? and userId=? order by trip.destination"; 
		try
		{
			
			log.info("Trying to user's location on current date.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(2, userId);
		    destination =query.list();
		    session.getTransaction().commit();
		    
		    log.info("User's location on current date :" +destination);
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting upcoming trips");
			log.debug(ex);
			ex.printStackTrace();
		}
		System.out.println("size:::"+destination.size());
	   return destination;	
	   
	}

  
  
  
  
  public List<String> getUserLocationOnCurrentDateforWebService(int userId)
	{
	  	  
	    log.info("Inside user Current location on current date");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println(" " + dateFormat.format(date));
		
		List<String> destination =null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="select distinct trip.destination from Trips as trip where trip.fromDate <= ? and toDate >=? and userId=? order by trip.destination"; 
		try
		{
			
			log.info("Trying to user's location on current date.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(2, userId);
		    System.out.println("before query " + dateFormat.format(date));
		    destination =query.list();
		    session.getTransaction().commit();
		    System.out.println("after comming query " + dateFormat.format(date));
		    
		    log.info("User's location on current date :" +destination);
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting upcoming trips");
			log.debug(ex);
			ex.printStackTrace();
		}
		System.out.println("size:::"+destination.size());
	   return destination;	
	   
	}
  /**This is the method for getting the user's current lat/long on current date or upcoming date based on destination */
  public String getUserLatLong(int userId, String destination)
	{
	  
		log.info("Inside User Get User Latitude/Langitude ");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println("getuserlatlong method called " + dateFormat.format(date));
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="select trip.destinationLatitude,trip.destinationLongitude from Trips as trip where ((trip.fromDate <= ? and toDate >=?) or trip.fromDate >=?) and userId=? and ( trip.destination LIKE CONCAT('%', ?, '%') OR ? LIKE CONCAT('%', trip.destination, '%') )  order by trip.destination";
		String latlong ="";
		List list = null;
		try
		{
			
			log.info("Trying to get user's lat/long on current date.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(2, sdf.parse(sdf.format(new Date())));
		    query.setParameter(3, userId);
		    query.setParameter(4, destination);
		    query.setParameter(5, destination);
		    System.out.println("before query " + dateFormat.format(date));
		    list = query.list();
		    System.out.println("after query " + dateFormat.format(date));
		    session.getTransaction().commit();
		    
		    
		    if(list !=null && list.size() >0)
		    {
		    	Object[] object =(Object[])list.get(0);
		    	latlong = object[0]+ ":" +object[1];
		    	
		    }
		    
		    log.info("User's lat/long on current date/upcoming date:" +destination);
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting user's lat/long");
			log.debug(ex);
			ex.printStackTrace();
		}
		
	   return latlong;	
	}
  
  /**This is the method for getting the user's current lat/long on current date or upcoming date based on destination & trip id */
  /** Overloaded method */
  public String getUserLatLong(int userId, String destination, int tripId)
	{
		log.info("Inside User Get Latitude/Langitude ");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="select trip.destinationLatitude,trip.destinationLongitude from Trips as trip where ((trip.fromDate <= ? and toDate >=?) or trip.fromDate >=?) and userId=? and trip.tripId=? and ( trip.destination LIKE CONCAT('%', ?, '%') OR ? LIKE CONCAT('%', trip.destination, '%') )  order by trip.destination";
		String latlong ="";
		List list = null;
		try
		{
			log.info("Trying to get user's lat/long on current date.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(2, sdf.parse(sdf.format(new Date())));
		    query.setParameter(3, userId);
		    query.setParameter(4, tripId);
		    query.setParameter(5, destination);
		    query.setParameter(6, destination);
		    list = query.list();
		    session.getTransaction().commit();
		    
		    if(list !=null && list.size() >0)
		    {
		    	Object[] object =(Object[])list.get(0);
		    	latlong = object[0]+ ":" +object[1];
		    }
		    
		    log.info("User's lat/long on current date/upcoming date :" +destination);
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting user's lat/long");
			log.debug(ex);
			ex.printStackTrace();
		}
		
	   return latlong;	
	}
  /**This method will send the invitation to meet the friend on a trip day */
  public void sendMeetingInvitation(String recipient, String subject,
          String message , String from, String senderName) throws MessagingException    
   {
	  
	 try
	 {
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		log.info("Sending meeting invitation by an email");
		log.info("Meeting invitation receiver :" + recipient);
		log.info("Meeting invitation sender :" + resource.getString("mail.id"));
		
		String SMTP_HOST_NAME = resource.getString("mail.hostname");
		String SMTP_PORT= resource.getString("mail.port");
		
		boolean debug = false;
		Properties props = new Properties();
		props.put("mail.smtp.host",SMTP_HOST_NAME);
		props.put("mail.smtp.port",SMTP_PORT);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.socketFactory.port", SMTP_PORT);
		// props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
		props.put("mail.smtp.socketFactory.fallback", "false");
		
		Authenticator auth = new SMTPAuthenticator();
		javax.mail.Session session = javax.mail.Session.getDefaultInstance(props, auth);
		
		session.setDebug(debug);
		
		// create a message
		Message msg = new MimeMessage(session);
		
		// set the from and to address
		InternetAddress addressFrom = new InternetAddress(resource.getString("mail.id"),senderName);
		msg.setFrom(addressFrom);
		
		InternetAddress addressTo = new InternetAddress(recipient);
		msg.setRecipient(Message.RecipientType.TO, addressTo);
		
		// Setting the Subject and Content Type
		msg.setSubject(subject);
		
		// Setting the Email Message and Content Type
		msg.setContent(message, "text/html");
		
		Transport.send(msg);
		log.info("Meeting invitation has been sent successfully to the receiver :" +recipient);
	 }
	 catch(Exception ex)
	 {
		 log.error("There is a problem in sending meeting invitaton");
		 log.debug(ex);
		 ex.printStackTrace();
	 }
 }
	
  public class SMTPAuthenticator extends javax.mail.Authenticator{
	@Override
		public PasswordAuthentication getPasswordAuthentication()
		{
			String SMTP_AUTH_USER = resource.getString("mail.id");
			String SMTP_AUTH_PWD  = resource.getString("mail.password");
			String username = SMTP_AUTH_USER;
			String password = SMTP_AUTH_PWD;
			return new PasswordAuthentication(username, password);
		}
  }
  public String getUserTripDate(int userId, String location)
  {
	   log.info("Inside User Get Latitude/Langitude ");
	  
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
		String queryString ="select trip.fromDate,trip.toDate from Trips as trip where trip.userId=? and (trip.fromDate <=? and trip.toDate >=? or trip.fromDate >= ?) and ( trip.destination LIKE CONCAT('%', ?, '%') OR ? LIKE CONCAT('%', trip.destination, '%') )"; 
		String tripDate ="";
		List list = null;
		try
		{
			
			log.info("Trying to get user's Trip Date.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(2, sdf.parse(sdf.format(new Date())));
		    query.setParameter(3, sdf.parse(sdf.format(new Date())));
		    query.setParameter(4, location);
		    query.setParameter(5, location);
		    
		    list = query.list();
		    session.getTransaction().commit();
		    
		    if(list !=null && list.size() >0)
		    {
		    	Object[] object =(Object[])list.get(0);
		    	tripDate = sdf1.format((Date)object[0])+ ":" +sdf1.format((Date)object[1]);
		    }
		    
		    log.info("User's lat/long on current date/upcoming date :" );
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting user's lat/long");
			log.debug(ex);
			ex.printStackTrace();
		}
			
	  return tripDate;
  }
  
  public int getFutureTrip(int userid)
  {
	  log.info("checking for user future trip");
	  String queryString  = "from Trips t where t.userId = "+userid + " AND CURDATE() between t.fromDate and t.toDate";
	  List list =null ;
	  try
	  {
		  Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		  session.beginTransaction();
		  Query query = session.createQuery(queryString);
		  list = query.list();  
		  session.getTransaction().commit();
		  
		  if(list.size() > 0 && list != null)
		  {
			  return 1;
		  }
		  else
		  {
			  return 0;
		  }
	  }
	  catch (Exception ex) 
	  {
			log.error("There is a problem in getting View user's upcoming trips details");
 			log.debug(ex);
	  }
	  return 0;
  }
  
  public static void main(String[] args) throws Exception{
	
	  int i = new PeopleFinder().getFutureTrip(8);
	  System.out.println(""+i);
  }
}