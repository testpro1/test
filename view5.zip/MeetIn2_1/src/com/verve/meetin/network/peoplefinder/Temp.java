package com.verve.meetin.network.peoplefinder;

import java.util.Date;

import org.apache.struts.action.ActionForm;
/**
 * 
 * @author Rupal Kathiriya 
 *	to get result for advance search 
 */
public class Temp extends ActionForm  implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
	private Integer userId;
    private String fullname;
    private String location;
    
    public Temp(){
    	
    }
    public Temp(Integer userId,String fullname,String location){
    	this.userId = userId;
    	this.fullname=fullname;
    	this.location = location;
    	
    }
    public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
    public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
      
}
