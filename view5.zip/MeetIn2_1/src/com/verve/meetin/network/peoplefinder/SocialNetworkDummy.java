package com.verve.meetin.network.peoplefinder;

import java.util.Date;



/**
 * SocialNetworkDummy entity. @author MyEclipse Persistence Tools
 */

public class SocialNetworkDummy  implements java.io.Serializable {


    // Fields    

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
     private String sessionId;
     private Integer userId;
     private Integer socialId;
     private String fullname;
     private String profileUrl;
     private String profileImage;
     private String location;
     private String gender;
     private Date updatedOn;
     
    // Constructors
     /** full constructor */
     public SocialNetworkDummy(String sessionId, Integer userId, Integer socialId, String fullname, String profileUrl, String profileImage, String location) {
         this.sessionId = sessionId;
         this.userId = userId;
         this.socialId = socialId;
         this.fullname = fullname;
         this.profileUrl = profileUrl;
         this.profileImage = profileImage;
         this.location = location;
         
     }
  
	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	/** default constructor */
    public SocialNetworkDummy() {
    }

	/** minimal constructor */
    public SocialNetworkDummy(String sessionId, Integer userId, Integer socialId) {
        this.sessionId = sessionId;
        this.userId = userId;
        this.socialId = socialId;
    }
       
    // Property accessors

    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }

    public String getSessionId() {
        return this.sessionId;
    }
    
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getUserId() {
        return this.userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getSocialId() {
        return this.socialId;
    }
    
    public void setSocialId(Integer socialId) {
        this.socialId = socialId;
    }

    public String getFullname() {
        return this.fullname;
    }
    
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getProfileUrl() {
        return this.profileUrl;
    }
    
    public void setProfileUrl(String profileUrl) {
        this.profileUrl = profileUrl;
    }

    public String getProfileImage() {
        return this.profileImage;
    }
    
    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getLocation() {
        return this.location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
   
}