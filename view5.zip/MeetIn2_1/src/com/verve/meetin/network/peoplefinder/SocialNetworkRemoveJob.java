package com.verve.meetin.network.peoplefinder;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import twitter4j.UserList;

import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.user.UserAccountDAO;

public class SocialNetworkRemoveJob implements Job
{

	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		
		new SocialNetworkDAO().deleteSocialDummyData();
		List<Integer> userIDList = getAllUserIdFromSocialNetwork();
		
		if(userIDList !=null && userIDList.size() > 0)
		{
			Iterator itr = userIDList.iterator();
			while(itr.hasNext())
			{
				int userid = (Integer)itr.next();
				new UserAccountDAO().updateUserScheduleFlagById(userid, "N");		
			}
		}
		
	}
	
	public List<Integer> getAllUserIdFromSocialNetwork()
	{
		List<Integer> list=null;
		String queryString = "select distinct(userId) from Usernetworks";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			list = query.list();
			
			session.getTransaction().commit();

		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}

}
