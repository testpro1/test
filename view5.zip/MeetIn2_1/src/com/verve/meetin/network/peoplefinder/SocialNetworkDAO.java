package com.verve.meetin.network.peoplefinder;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.network.NetworkConstraint;

public class SocialNetworkDAO 
{
	static Logger log = Logger.getLogger(SocialNetworkDAO.class);
	
	
	public int deleteSocialDummyData(int userId,int socialId)
	{
		int row=0;
		
	/*	if(socialId == NetworkConstraint.SOCIAL_NETWORK_FACEBOOK)
		{
			deleteFacebookCheckInData(userId,8);
		}*/
		String queryString ="delete from SocialNetworkDummy as s where s.userId=? and s.socialId = ?";
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			log.info("Trying to delete data from social network user details.....");
			
			tx = session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, socialId);
		    row = query.executeUpdate();
		    tx.commit();
		    log.info("Social Network Friends data deleted successfully");
		}
		catch(Exception ex)
		{
			tx.rollback();
			log.error("There is a problem in deleting social network user details");
			log.debug(ex);
			ex.printStackTrace();
		}
		return row;
	}
	
	public int deleteFacebookCheckInData(int userId,int socialId)
	{
		int row=0;
		String queryString ="delete from Facebook_Checkin as s where s.userId=? and s.socialId = ?";
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			log.info("Trying to delete data from social network user details.....");
			
			tx = session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, socialId);
		    row = query.executeUpdate();
		    tx.commit();
		    log.info("Social Network Friends data deleted successfully");
		}
		catch(Exception ex)
		{
			tx.rollback();
			log.error("There is a problem in deleting social network user details");
			log.debug(ex);
			ex.printStackTrace();
		}
		return row;
	}
	
	public int deleteSocialDummyData()
	{
		int row=0;
		String queryString ="delete from SocialNetworkDummy";
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			log.info("Trying to delete data from social network user details.....");
			
			tx = session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    row = query.executeUpdate();
		    tx.commit();
		    log.info("Social Network Friends data deleted successfully");
		}
		catch(Exception ex)
		{
			tx.rollback();
			log.error("There is a problem in deleting social network user details");
			log.debug(ex);
			ex.printStackTrace();
		}
		return row;
	}
	
	public void saveSocialDummyData(List<SocialNetworkDummy> list)
	{
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			tx = session.beginTransaction();
						
			if(list !=null && list.size() > 0)
			{
				log.info("Trying to save social network user details........");
				log.info("Social network friends found to save : " +list.size());
				
				Iterator itr = list.iterator();
				while(itr.hasNext())
				{
					SocialNetworkDummy s = (SocialNetworkDummy)itr.next();
					session.save(s);
				}
				
				tx.commit();
				log.info("Social Network user details have been saved successfully.");
			}
		}
		catch(Exception ex)
		{
			tx.rollback();
			log.error("There is a problem in saving social details for a user");
			ex.printStackTrace();
		}

	}
	public void saveFacebookCheckIn(List<Facebook_Checkin> list)
	{
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			tx = session.beginTransaction();
						
			if(list !=null && list.size() > 0)
			{
				log.info("Trying to save social network user details........");
				log.info("Social network friends found to save : " +list.size());
				
				Iterator itr = list.iterator();
				while(itr.hasNext())
				{
					Facebook_Checkin s = (Facebook_Checkin)itr.next();
					session.save(s);
				}
				
				tx.commit();
				log.info("Social Network user details have been saved successfully.");
			}
		}
		catch(Exception ex)
		{
			tx.rollback();
			log.error("There is a problem in saving social details for a user");
			ex.printStackTrace();
		}

	}
	
	
	public List getSocialFriendsProfile(int userId,int socialnetwork_Id,String location) 
	{
		List list=null;
		String queryString = "select s.userId,s.fullname,s.profileUrl,s.profileImage,s.location,s.gender,s.id, u.socialNetworkSiteIcon, s.updatedOn from SocialNetworkDummy as s , Networkmaster u"+
		" where s.socialId = u.socialNetworkSiteId and s.userId = ? and s.socialId = ? and (s.location like concat('%',?,'%') or ? like concat('%',s.location,'%'))";
		System.out.println(""+queryString);
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, socialnetwork_Id);
			query.setParameter(2, location);
			query.setParameter(3, location);
			
			list = query.list();
			
			session.getTransaction().commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}	
	
	public List getFacebookCheckinFriendProfile(int userId,int socialnetwork_Id,String location)
	{
		List list=null;
		String queryString = "select s.userId,s.fullname,s.profileUrl,s.profileImage,s.location,s.gender,s.id, u.socialNetworkSiteIcon, s.date from Facebook_Checkin as s , Networkmaster u"+
		" where s.socialId = u.socialNetworkSiteId and s.userId = ? and s.socialId = ? and (s.location like concat('%',?,'%') or ? like concat('%',s.location,'%'))";
		System.out.println(""+queryString);
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, socialnetwork_Id);
			query.setParameter(2, location);
			query.setParameter(3, location);
			
			list = query.list();
			
			session.getTransaction().commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}
	
	
	//this method return the list of foursquare friends who have checkedin on current day 
	public List getFourSquareCheckinFriendProfile(int userId,int socialnetwork_Id,String location)
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd ");
		Date date = new Date();
		
		List list=null;
		String queryString = "select s.userId,s.fullname,s.profileUrl,s.profileImage,s.location,s.gender,s.id, u.socialNetworkSiteIcon, s.date from FourSquareCheckin as s , Networkmaster u"+
		" where s.socialId = u.socialNetworkSiteId and s.userId = ? and s.socialId = ? and (s.location like concat('%',?,'%') or ? like concat('%',s.location,'%')) and date >= curdate() ";
		System.out.println(""+queryString);
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, socialnetwork_Id);
			query.setParameter(2, location);
			query.setParameter(3, location);
			list = query.list();
			
			session.getTransaction().commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}
	
	
	
	
	// added by rupal - to get all social friends from social network dummy dated on 19th jan 2013 
	public List getAllSocialFriends(int userId) 
	{
		List list=null;
		String queryString = "select s.userId,s.fullname,s.profileUrl,s.profileImage,s.location,s.gender,s.id, u.socialNetworkSiteIcon,s.updatedOn from SocialNetworkDummy as s , Networkmaster u"+
		" where s.socialId = u.socialNetworkSiteId and s.userId = ?";
		System.out.println(""+queryString);
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			
			list = query.list();
			
			session.getTransaction().commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}	
	// added by rupal - to get all social friends from social network dummy dated on 19th jan 2013 
	public List getAllSocialFriendsWithlocationWise(int userId,String location) 
	{
		List list=null;
		String queryString = "select s.userId,s.fullname,s.profileUrl,s.profileImage,s.location,s.gender,s.id, u.socialNetworkSiteIcon,s.updatedOn from SocialNetworkDummy as s , Networkmaster u"+
		" where s.socialId = u.socialNetworkSiteId and s.userId = ? and (s.location like concat(?,'%') or ? like concat(s.location,'%')) ";
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, location);
			query.setParameter(2, location);
			
			list = query.list();
		
			session.getTransaction().commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("list size "+list.size());
		return list;
	}	
	
	/**
	 * This method is made by Vasim Saiyad to find out the social network friends on a particular given location
	 * @param userId - Id of the user
	 * @param location - Location of the user
	 * @return - List of social friends 
	 */
	public List getAllSocialFriendsByLocation(int userId,String location) 
	{
		List list=null;
		String queryString = "select s.userId,s.fullname,s.profileUrl,s.profileImage,s.location,s.gender,s.id, u.socialNetworkSiteIcon,s.updatedOn from SocialNetworkDummy as s , Networkmaster u"+
		" where s.socialId = u.socialNetworkSiteId and s.userId = ? and (s.location like concat('%', ?,'%') or ? like concat('%',s.location,'%')) ";
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			query.setParameter(1, location);
			query.setParameter(2, location);
			
			list = query.list();
		
			session.getTransaction().commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
	
	public int deleteFourSquareCheckinData(int userId,int socialId)
	{
		int row=0;
		
	/*	if(socialId == NetworkConstraint.SOCIAL_NETWORK_FACEBOOK)
		{
			deleteFacebookCheckInData(userId,8);
		}*/
		String queryString ="delete from FourSquareCheckin as s where s.userId=? and s.socialId = ?";
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			log.info("Trying to delete data from social network user details.....");
			tx = session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, socialId);
		    row = query.executeUpdate();
		    tx.commit();
		    log.info("Social Network Friends data deleted successfully");
		}
		catch(Exception ex)
		{
			tx.rollback();
			log.error("There is a problem in deleting social network user details");
			log.debug(ex);
			ex.printStackTrace();
		}
		return row;
	}
	
	
}
