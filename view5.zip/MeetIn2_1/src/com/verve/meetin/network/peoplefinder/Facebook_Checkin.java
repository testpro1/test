package com.verve.meetin.network.peoplefinder;

import java.util.Date;

public class Facebook_Checkin {

	  private Integer id;
	     private String sessionId;
	     private Integer userId;
	     private Integer socialId;
	     private String fullname;
	     private String profileUrl;
	     private String profileImage;
	     private String location;
	     private String gender;
	     private Date date;
	     
	  // Constructors

	     
	 	public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

	 	public String getGender() {
	 		return gender;
	 	}

	 	public void setGender(String gender) {
	 		this.gender = gender;
	 	}

	 	/** default constructor */
	     public Facebook_Checkin() {
	     }

	 	/** minimal constructor */
	     public Facebook_Checkin(String sessionId, Integer userId, Integer socialId) {
	         this.sessionId = sessionId;
	         this.userId = userId;
	         this.socialId = socialId;
	     }
	     
	     /** full constructor */
	     public Facebook_Checkin(String sessionId, Integer userId, Integer socialId, String fullname, String profileUrl, String profileImage, String location,Date date) {
	         this.sessionId = sessionId;
	         this.userId = userId;
	         this.socialId = socialId;
	         this.fullname = fullname;
	         this.profileUrl = profileUrl;
	         this.profileImage = profileImage;
	         this.location = location;
	         this.date = date;
	         
	     }

	    
	     // Property accessors

	     public Integer getId() {
	         return this.id;
	     }
	     
	     public void setId(Integer id) {
	         this.id = id;
	     }

	     public String getSessionId() {
	         return this.sessionId;
	     }
	     
	     public void setSessionId(String sessionId) {
	         this.sessionId = sessionId;
	     }

	     public Integer getUserId() {
	         return this.userId;
	     }
	     
	     public void setUserId(Integer userId) {
	         this.userId = userId;
	     }

	     public Integer getSocialId() {
	         return this.socialId;
	     }
	     
	     public void setSocialId(Integer socialId) {
	         this.socialId = socialId;
	     }

	     public String getFullname() {
	         return this.fullname;
	     }
	     
	     public void setFullname(String fullname) {
	         this.fullname = fullname;
	     }

	     public String getProfileUrl() {
	         return this.profileUrl;
	     }
	     
	     public void setProfileUrl(String profileUrl) {
	         this.profileUrl = profileUrl;
	     }

	     public String getProfileImage() {
	         return this.profileImage;
	     }
	     
	     public void setProfileImage(String profileImage) {
	         this.profileImage = profileImage;
	     }

	     public String getLocation() {
	         return this.location;
	     }
	     
	     public void setLocation(String location) {
	         this.location = location;
	     }
}
