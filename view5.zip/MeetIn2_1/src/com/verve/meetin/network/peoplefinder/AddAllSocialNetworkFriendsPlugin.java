package com.verve.meetin.network.peoplefinder;

import java.text.ParseException;
import java.util.Date;

import javax.servlet.ServletException;

import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.CronTrigger;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;

public class AddAllSocialNetworkFriendsPlugin implements PlugIn 
{

	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void init(ActionServlet arg0, ModuleConfig arg1)
			throws ServletException {

		try 
		{
			JobDetail job = new JobDetail();
			
	    	job.setName("Add All Social Network Job");
	    	job.setJobClass(AddAllSocialNetworkFriends.class);
	    	
	    	CronTrigger trigger = new CronTrigger();
	    	
	    	trigger.setName("Add All Social Network Trigger");
	    	trigger.setCronExpression("0 0 12 * * ?");
	    	trigger.setStartTime(new Date(System.currentTimeMillis() +  300000));
			
	    	Scheduler scheduler = new StdSchedulerFactory().getScheduler();
			scheduler.start();
			scheduler.scheduleJob(job, trigger);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
