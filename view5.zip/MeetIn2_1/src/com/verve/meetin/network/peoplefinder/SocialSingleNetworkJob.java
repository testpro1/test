package com.verve.meetin.network.peoplefinder;

import java.util.List;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.verve.meetin.LinkedIn.LinkedIn;
import com.verve.meetin.facebook.facebookGraphAPI;
import com.verve.meetin.foursquare.foursquareDemo;
import com.verve.meetin.gmail.GmailAPI;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.twitter.twitter;

public class SocialSingleNetworkJob implements Job 
{

	public void execute(JobExecutionContext arg0) throws JobExecutionException 
	{
		System.out.println("Job Started");
		JobDataMap data = arg0.getJobDetail().getJobDataMap();
		int userid = (Integer)data.get("userid");
		System.out.println(userid);
		String sessionid = (String)data.get("sessionid");
		System.out.println(sessionid);
		int socialid = (Integer)data.get("socialid");
		System.out.println(socialid);
		List<SocialNetworkDummy> friends = null;
		String accessToken = new NetworkDAO().getAccessToken(userid, socialid);
		SocialNetworkDAO socialnetworkDAO = new SocialNetworkDAO();

		switch (socialid) 
		{
			case NetworkConstraint.SOCIAL_NETWORK_FACEBOOK:
				friends = new facebookGraphAPI().getFacebookFriendsDump(accessToken,  userid, sessionid, socialid);
				break;
			case NetworkConstraint.SOCIAL_NETWORK_LINKEDIN:
				friends = new LinkedIn().getLinkedInFriendsDump(accessToken,  userid, sessionid, socialid);
				break;
			case NetworkConstraint.SOCIAL_NETWORK_GMAIL:
				friends = new GmailAPI().getGmailFriendsDump(accessToken,  userid, sessionid, socialid);
				break;
			case NetworkConstraint.SOCIAL_NETWORK_TWITTER:
				friends = new twitter().getTwitterFriendsDump(accessToken, userid, sessionid, socialid);
				break;
			case NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE:
				friends = new foursquareDemo().getFoursquareFriendsDump(accessToken,userid,sessionid,socialid);
			default:
				break;
		}			
		socialnetworkDAO.saveSocialDummyData(friends);						
	}
}
