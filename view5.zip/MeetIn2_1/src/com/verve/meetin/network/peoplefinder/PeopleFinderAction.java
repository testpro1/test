package com.verve.meetin.network.peoplefinder;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.verve.meetin.friend.FriendsDAO;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.interest.InterestDAO;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.trip.TripsDAO;
import com.verve.meetin.user.User;
import com.verve.meetin.user.UserAccountDAO;

/*
 *  PeopleFinderAction class
 *  
 *  Fetch User's friends information. 
 */
public class PeopleFinderAction extends DispatchAction {

	/*
	 * People action will call the Social site API and geting all the
	 * information about the Friends, like, Friendid, name, location, profile
	 * URL.
	 * 
	 * set all the data to request.
	 */
	public ActionForward people(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		return mapping.findForward("success");
	}

	public ActionForward upCommingTrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		System.out.println("upcoming trip");
		return mapping.findForward("upcommingtrip");
	}
	public ActionForward findpeopleforTrip1(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		//System.out.println("People finder action ***   find people for trip method");

		if (request.getParameter("location") != null
				|| request.getParameter("selFrdId") != null) {
			HttpSession userSession = request.getSession(false);
			int userId = (Integer) userSession.getAttribute("UserID");
			PeopleFinder PF = new PeopleFinder();
			String currentLocation = "";
			String locationLabel = "Current Location"; // define the default
														// location label
			String latlong = "";
			List<String> locationList = new ArrayList<String>();
			String location = request.getParameter("location");

			//System.out.println("Location in people finder Action servlet---"+ location);

			// ///////////Changes by sarika for Living location shown
			userSession.setAttribute("showlivinglocation", null);
			List upcomingTrip = new ArrayList();
			upcomingTrip = new TripsDAO().getUserUpcomingTrips(userId);
			if (upcomingTrip != null && upcomingTrip.size() > 0) {
				userSession.setAttribute("upcomingtrip", upcomingTrip);
			} else {
				userSession.setAttribute("upcomingtrip", null);
			}
			// //////////////////////////////////////////////////

			/** Get Select friend id for grid shown */
			if (request.getParameter("selFrdId") != null) {
				String selectFrd_id = request.getParameter("selFrdId");
				// Integer selectfrdid =
				// Integer.parseInt(request.getParameter("userId"));
				// //System.out.println("Sel Friend id is -"+selectfrdid);
				// String selectFrd_id = selectFrd_id1.substring(7);
				request.setAttribute("selectFrd_id", selectFrd_id);
				userSession.setAttribute("selectFrd_id", selectFrd_id);
				// //System.out.println("select frd id is in findpeopleforTrip action "+selectFrd_id);
			}

			if (request.getParameter("location") != null) {
				/**
				 * Store the selected location value into request object to keep
				 * location selected into dropdown list
				 */
				request.setAttribute("SelectedLocation", request.getParameter(
						"location").toString());
				userSession.setAttribute("SelectedLocation", request
						.getParameter("location").toString());
				// //System.out.println("Selected location in findpeople for trip -"+request.getParameter("location").toString());
			}

			/**
			 * Checking the action servlet has been called from My Upcoming Trip
			 * Page
			 */
			if (request.getParameter("viewref") != null
					&& request.getParameter("viewref").equalsIgnoreCase(
							"tripview")) {
				/**
				 * Storing the some value in request object to show/hide some
				 * part of page while coming from my upcoming trip
				 */
				request.setAttribute("FromTripView", "tripview");
				/** User's current location from My Upcomming Trip View */
				currentLocation = request.getParameter("location").toString();
				locationList.add(currentLocation);

			} else if (request.getParameter("viewref") != null
					&& request.getParameter("viewref").equalsIgnoreCase(
							"peoplefinder")) {
				/**
				 * code to find current location of user (in case user is
				 * travelling on current date)
				 */
				locationList = new PeopleFinder()
						.getUserLocationOnCurrentDate(userId);
				/**
				 * If the condition is true then user has current location on
				 * current date
				 */
				if (locationList != null && locationList.size() > 0) {
					/** User's current location */
					if (request.getParameter("location") != null) {
						currentLocation = request.getParameter("location")
								.toString();
						//System.out.println("Current location in people Finder Action class"	+ currentLocation);
					}
					// ///////////////////changes by sarika
					String liveing_location = new UserAccountDAO().getUserLocationByCityState(userId);
					
					if (currentLocation.toLowerCase().equals(
							liveing_location.toLowerCase())) {
						userSession.setAttribute("upcomingtrip", null);
					}
					// ///////////////////////////////////
				} else {
					/** User's default location */
					currentLocation = request.getParameter("location");
				}
			} else {
				/** User's default location */
				currentLocation = request.getParameter("location");
				locationList.add(currentLocation);
			}
			/**
			 * Check that user is viewing the trip on current date or before it
			 * to display the appropriate location label
			 */
			if (request.getParameter("tripdate") != null
					&& !request.getParameter("tripdate").equals("")) {
				SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
				Date tripdate = sdf.parse(request.getParameter("tripdate"));
				Date currentdate = sdf.parse(sdf.format(new Date()));

				if (tripdate.after(currentdate)) {
					locationLabel = "Upcoming Location";
				}
				latlong = new PeopleFinder().getUserLatLong(userId,
						currentLocation.split(",")[0], Integer.parseInt(request
								.getParameter("tripId")));
				//System.out.println("latlong in trip people finder action "+ latlong);

			} else {
				latlong = new PeopleFinder().getUserLatLong(userId,
						currentLocation.split(",")[0]);
				//System.out.println("latlong in trip people finder action in else part "+ latlong);
			}

			/** Store the location label in request object */
			userSession.setAttribute("LocationLabel", locationLabel);

			/** Store the location list in userSession object */
			userSession.setAttribute("current_location", locationList);
			request.setAttribute("current_location", locationList);

			/** Store the loggedin user's own lat/long in request object */
			request.setAttribute("LatLong", latlong);

			// Find friends from trips //
			// start code here
			// List tripFriendList = new
			// PeopleFinder().getPeopleNearOnCurrentDate(userId,request.getParameter("location").toString().split(", ")[0]);
			List tripFriendList = new PeopleFinder()
					.getPeopleNearOnUpcomingDate(userId, currentLocation
							.split(",")[0]);

			Hashtable<String, List<String>> hashtable = new Hashtable<String, List<String>>();
			List latlongList = new ArrayList();
			List upcomingPeople = new ArrayList();
			if (tripFriendList != null && tripFriendList.size() > 0) {
				for (int i = 0; i < tripFriendList.size(); i++) {
					Object[] object = (Object[]) tripFriendList.get(i);
					List<String> friend_info = new ArrayList<String>();
					friend_info.add((String) object[1]);
					friend_info.add("profile_page.jsp?id="
							+ (Integer) object[0]);
					friend_info.add("images/meetin_icon.png");
					friend_info.add((String) object[3]);
					friend_info.add((String) object[4]);
					friend_info.add("userid=" + (Integer) object[0]
							+ "&location=" + currentLocation.split(",")[0]);
					hashtable.put(String.valueOf((Integer) object[0]),
							friend_info);

					/**
					 * The below code is to get the user's friend
					 * name,latitude,langitude, image and social site icon from
					 * Trip table
					 */
					User user = new User();
					// setup parameter to show user details on google map
					user.setFullname((String) object[1]);
					user.setLocLat((String) object[3]);
					user.setLocLang((String) object[4]);
					user.setGoogleMarkerIcon("images/meetin_icon.png");

					String imageName = "";
					String imagePath = request.getScheme() + "://"
							+ request.getServerName() + ":"
							+ request.getServerPort()
							+ request.getContextPath();

					/**
					 * Checking for the user friend's profile image to show in
					 * google map
					 */
					if (object[5] != null && !object[5].toString().equals("")) {
						imageName = imagePath + "/profileimage/" + object[0]
								+ "_" + object[5];
					} else {
						if (object[6].toString().toLowerCase().equals("male")) {
							imageName = imagePath + "/images/male.png";
						} else {
							imageName = imagePath + "/images/female.png";
						}

					}
					friend_info.add(imageName);
					hashtable.put(String.valueOf(object[0]), friend_info);
					user.setImage(imageName);
					latlongList.add(user);
					// //System.out.println("Friend image when in findpeopleforTrip--"+imageName);

				}

			}
			// end of code here

			/**
			 * The below code is to show user's friends who are at their default
			 * location
			 */

			Hashtable<String, List<String>> friends = PF.peopleFinder1(userId,request.getParameter("location").split(",")[0]);
			// Hashtable<String, List<String>> friends = PF.peopleFinder(userId,
			// request.getParameter("location"));
			// System.out.print("People On Default Location  :"
			// +friends.size());
			// System.out.print("People On Upcomming" +tripFriendList.size());

			/**
			 * The below code is to get the latitude and langitude of the user
			 * from User table(Lat/Lang for MeetIn,Facebook and Linkedin
			 * Friends)
			 */
			Enumeration latlangEnum = friends.keys();

			while (latlangEnum.hasMoreElements()) {
				String key = latlangEnum.nextElement().toString();
				List<String> list = (List<String>) friends.get(key);
				User u = new User();
				// setup parameter to show user details on google map
				u.setFullname(list.get(0).toString());
				u.setLocLat(list.get(3).toString());
				u.setLocLang(list.get(4).toString());
				u.setGoogleMarkerIcon(list.get(2));

				String imageName = "";
				String imagePath = request.getScheme() + "://"
						+ request.getServerName() + ":"
						+ request.getServerPort() + request.getContextPath();

				/**
				 * Checking for the user friend's profile image to show in
				 * google map
				 */
				if (list.get(6) != null && !list.get(6).toString().equals("")) {
					String image = list.get(2).split("/")[1];

					/** Checking for MeetIn friend's image */
					if (image.equalsIgnoreCase("meetin_icon.png")) {
						/** This is meetin user's image path */
						imageName = imagePath + "/profileimage/" + key + "_"
								+ list.get(6);
					} else {
						/** This is facebook user's image path */
						imageName = list.get(6).toString();
					}
				} else {
					/** This is the default image path for all user friend */
					if (list.get(7).toString().toLowerCase().equals("male")) {
						imageName = imagePath + "/images/male.png";
					} else {
						imageName = imagePath + "/images/female.png";
					}

				}

				u.setImage(imageName);
				// //System.out.println("Image in  trip in another findpeopleTrip--"+imageName);
				u.setUserKey(key);
				latlongList.add(u);

			}

			/** Storing the all latitude and langitude value in request object */
			request.setAttribute("LatLongList", latlongList);

			// merge the hashtable data
			Enumeration<String> e = hashtable.keys();
			while (e.hasMoreElements()) {
				String element = e.nextElement();
				friends.put(element, hashtable.get(element));
			}

			// if(friends == null)
			// request.setAttribute("requireNetworkSetup", "true");
			userSession.setAttribute("friends", friends);
			userSession.setAttribute("start", 0);
			request.setAttribute("filter", "all");
			if (friends.size() < 10)
				userSession.setAttribute("end", friends.size());
			else
				userSession.setAttribute("end", 10);
			// userSession.setAttribute("friends", friends);

		}
		return mapping.findForward("listofpeopleForTrip");
	}
	
	public ActionForward findPeopleFromUpcomingTrip(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
	{
		System.out.println("find people from upcoming trip ");
		
		HttpSession userSession = request.getSession();
		int userId = (Integer) userSession.getAttribute("UserID");
		String currentLocation = request.getParameter("location"); 
		List friendlist = new ArrayList();
		List latlongList = new ArrayList();
		//get meetin friends on trip
		List list =	new SocialNetworkDAO().getAllSocialFriendsByLocation(userId,currentLocation.split(",")[0]);
		String imagePath = request.getScheme() + "://"	+ request.getServerName() + ":"	+ request.getServerPort() + request.getContextPath();
		
		String latlanString = new LocationDAO().getCityLatitudeLongitude(currentLocation.split(",")[0].toLowerCase());
		String latitude = "", langitude = "";
		Iterator itr = list.iterator();
		String imageName = "";
		
		while(itr.hasNext())
		{
			Object[] obj = (Object[])itr.next();
			User u = new User();	
			u.setFullname((String) obj[1]);
			
			if (!latlanString.equals(""))
			{
				latitude = latlanString.split(":")[0];
				langitude = latlanString.split(":")[1];
			}
			
			u.setLocLat(latitude);
			u.setLocLang(langitude);
			u.setGoogleMarkerIcon((String) obj[7]);
			if((String)obj[3]!=null && !((String) obj[3]).equals(""))
			{
				imageName = (String) obj[3];		
			}
			else
			{
				/** This is the default spacer image path for respected social network */
				imageName = imagePath + "/" +(String) obj[7];
			}
			
			u.setImage(imageName);
			latlongList.add(u);
		}
		
		System.out.println("---  "+currentLocation);
		System.out.println("**  "+currentLocation.split(",")[0]);
		List tripFriendList = new PeopleFinder().getPeopleNearOnUpcomingDate(userId, currentLocation.split(",")[0]);
		
		System.out.println("meetin trip friend size " +tripFriendList.size());
		if (tripFriendList != null)
		{
			for(int i =0 ; i < tripFriendList.size();i++)
			{
				Object[] o = new Object[8];
				Object[] object = (Object[])tripFriendList.get(i);
				o[0] = (Integer)object[0];
				o[1] = (String)object[1];
				o[2] = "profile_page.jsp?id="+((Integer)object[0]).toString();
				
				if(object[5] != null && !((String)object[5]).equals(""))
				{
					o[3] = "profileimage/"+(String)object[5];
				}
				else
				{
					if(((String)object[6]).equalsIgnoreCase("Male"))
	    			   {
	    				   o[3] = "images/male.png";   
	    			   }
	    			   else
	    			   {
	    				   o[3] = "images/female.png";
	    			   }
				}
				System.out.println(""+o[3].toString());
				
				
				o[4] = (String)object[2];
				o[5] = (String)object[6];
				o[6] = "";
				o[7] = "images/meetin_icon.png";
				
				list.add(o);
				
				User u = new User();
				u.setFullname((String)object[1]);
				u.setLocLat((String) object[3]);
				u.setLocLang((String) object[4]);
				u.setGoogleMarkerIcon("images/meetin_icon.png");
				
				if((String)object[5]!=null && !((String) object[5]).equals(""))
				{
					imageName = imagePath + "/profileimage/" + (String) object[5];		
				}
				else
				{
					if (((String)object[6]).toString().equalsIgnoreCase("Female"))
						imageName = imagePath + "/images/female.png";	
						
					else
						imageName = imagePath + "/images/male.png";
				}
				
				u.setImage(imageName);
				latlongList.add(u);
			}
		}
			
		//friends from base location 
		UserAccountDAO accountdao = new UserAccountDAO();
		Hashtable<String, List<String>> MeetIn_friends = new Hashtable<String, List<String>>();
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
				
		MeetIn_friends = accountdao.getFriendsNames_Id(currentLocation.split(",")[0],userId, startDate, endDate);
		System.out.println("meetin friends size :: "+MeetIn_friends.size());
		if(MeetIn_friends!=null){
			ArrayList meetinList = new ArrayList(MeetIn_friends.values());
	    	//System.out.println(meetinList.toString());
	    	//System.out.println("Size   "+meetinList.size());
			if(meetinList !=null && meetinList.size() >0)
		       {
				int id1=0;
				for(int j=0;j<meetinList.size();j++)
				{
					List list1=new ArrayList();
					list1=(List) meetinList.get(j);
					Object[] o = new Object[8];
					o[0] ="";   												//id
					o[1] =list1.get(0).toString();								//fullname
					o[2] = list1.get(1).toString();								//profile path
					o[3] = list1.get(6);													
					o[4] = "";													//location
					o[5] = list1.get(5).toString();								//gender
					o[6] = "";													//
					o[7] = "images/meetin_icon.png";							//icon 
					list.add(o);
					
					User u = new User();
					u.setFullname(list1.get(0).toString());
					u.setLocLat(list1.get(3).toString());
					u.setLocLang(list1.get(4).toString());
					u.setGoogleMarkerIcon(list1.get(2).toString());
					u.setImage(imagePath + "/" + list1.get(6));
					latlongList.add(u);
				}
		      }
		}
		
		
		/**Sorting the list of friends for grid view */
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				
				int result=0;
				String value1 = (String)((Object[]) o1)[1];
				String value2 = (String)((Object[]) o2)[1];
				
				result=value1.compareToIgnoreCase(value2);

				return result;
			}
		});

		/** Sorting the Map data with User fullname */
		Collections.sort(latlongList, new Comparator() {
			public int compare(Object o1, Object o2) {
				
				int result=0;
				String value1 = (String)((User)o1).getFullname();
				String value2 = (String)((User)o2).getFullname();
				
				result=value1.compareToIgnoreCase(value2);

				return result;
			}
		});
		
			
		if(list.size() > 0 && list != null)
		{
			userSession.setAttribute("upcomingTripFriends",list);
		}
		else
		{
			userSession.setAttribute("upcomingTripFriends",null);
		}
		
		
		request.setAttribute("LatLong", new PeopleFinder().getUserLatLong(userId, currentLocation.split(",")[0]));
		userSession.setAttribute("start", 0);
		if (list.size() < 10)
			userSession.setAttribute("end", list.size());
		else
			userSession.setAttribute("end", 10);
		
		userSession.setAttribute("latlongList", latlongList);
		return mapping.findForward("listofpeopleForTrip");
	}

	
	public ActionForward navigatefindPeopleFromUpcomingTrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession session = request.getSession();
		ArrayList friends = (ArrayList) session.getAttribute("upcomingTripFriends");
		String event = (String) request.getParameter("e");
		int start = Integer.parseInt(session.getAttribute("start").toString());
        int end = Integer.parseInt(session.getAttribute("end").toString());
        
		
		if(event !=null && event.equalsIgnoreCase("Last")){
			end = friends.size();
	    	if(friends.size() < 10)
	    		start = 0;
	    	else
	    	{
	    		start = (friends.size() / 10) * 10;
	    		if(start == friends.size())
					start = start - 10;
	    	}	
		}if(event !=null && event.equalsIgnoreCase("First")){
			start = 0;
			end = (friends.size() < 10) ? friends.size(): 10;
        	
		}if(event !=null && event.equalsIgnoreCase("Next")){
			 start = end;
			 				
             if(friends.size() < 10){
                     end = friends.size();
             }else if((end+10) < friends.size()){ 
                     end = end + 10;
             }else if((end+10) > friends.size()){
                     end = end + (friends.size() - end);
             }else if((end+10) >= friends.size()){
                     end = friends.size();
             }
             
		}if(event != null && event.equalsIgnoreCase("Prev")){
			 
			if(start >= 10){
                     start = start - 10;
             }else if(start < 10){
                     start = start - start;
             }
             end = start + 10;
             
         }if(event !=null && event.equalsIgnoreCase("page_combo")){
        	 
        	String[] s = request.getParameter("paging").split("-");
         	start = Integer.parseInt(s[0]);
         	end = Integer.parseInt(s[1]);
         }
			
    	session.setAttribute("end", end);
    	session.setAttribute("start", start);
    	
    	return mapping.findForward("listofpeopleForTrip");
	}
	
	public ActionForward findpeopleforTrip(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		System.out.println("People finder action ***   find people for trip method");

		if (request.getParameter("location") != null
				|| request.getParameter("selFrdId") != null) {
			HttpSession userSession = request.getSession(false);
			int userId = (Integer) userSession.getAttribute("UserID");
			PeopleFinder PF = new PeopleFinder();
			String currentLocation = "";
			String locationLabel = "Current Location"; // define the default
														// location label
			String latlong = "";
			List<String> locationList = new ArrayList<String>();
			String location = request.getParameter("location");

			//System.out.println("Location in people finder Action servlet---"+ location);

			// ///////////Changes by sarika for Living location shown
			userSession.setAttribute("showlivinglocation", null);
			List upcomingTrip = new ArrayList();
			upcomingTrip = new TripsDAO().getUserUpcomingTrips(userId);
			
			System.out.println(upcomingTrip.toString());
			System.out.println("list printed");
			
			if (upcomingTrip != null && upcomingTrip.size() > 0) {
				userSession.setAttribute("upcomingtrip", upcomingTrip);
			} else {
				userSession.setAttribute("upcomingtrip", null);
			}
			// //////////////////////////////////////////////////

			/** Get Select friend id for grid shown */
			if (request.getParameter("selFrdId") != null) {
				String selectFrd_id = request.getParameter("selFrdId");
				// Integer selectfrdid =
				// Integer.parseInt(request.getParameter("userId"));
				// //System.out.println("Sel Friend id is -"+selectfrdid);
				// String selectFrd_id = selectFrd_id1.substring(7);
				request.setAttribute("selectFrd_id", selectFrd_id);
				userSession.setAttribute("selectFrd_id", selectFrd_id);
				// //System.out.println("select frd id is in findpeopleforTrip action "+selectFrd_id);
			}

			if (request.getParameter("location") != null) {
				/**
				 * Store the selected location value into request object to keep
				 * location selected into dropdown list
				 */
				request.setAttribute("SelectedLocation", request.getParameter(
						"location").toString());
				userSession.setAttribute("SelectedLocation", request
						.getParameter("location").toString());
				// //System.out.println("Selected location in findpeople for trip -"+request.getParameter("location").toString());
			}

			/**
			 * Checking the action servlet has been called from My Upcoming Trip
			 * Page
			 */
			if (request.getParameter("viewref") != null
					&& request.getParameter("viewref").equalsIgnoreCase(
							"tripview")) {
				/**
				 * Storing the some value in request object to show/hide some
				 * part of page while coming from my upcoming trip
				 */
				request.setAttribute("FromTripView", "tripview");
				/** User's current location from My Upcomming Trip View */
				currentLocation = request.getParameter("location").toString();
				locationList.add(currentLocation);

			} else if (request.getParameter("viewref") != null
					&& request.getParameter("viewref").equalsIgnoreCase(
							"peoplefinder")) {
				/**
				 * code to find current location of user (in case user is
				 * travelling on current date)
				 */
				locationList = new PeopleFinder()
						.getUserLocationOnCurrentDate(userId);
				/**
				 * If the condition is true then user has current location on
				 * current date
				 */
				if (locationList != null && locationList.size() > 0) {
					/** User's current location */
					if (request.getParameter("location") != null) {
						currentLocation = request.getParameter("location")
								.toString();
						//System.out.println("Current location in people Finder Action class"	+ currentLocation);
					}
					// ///////////////////changes by sarika
					String liveing_location = new UserAccountDAO().getUserLocationByCityState(userId);
					
					if (currentLocation.toLowerCase().equals(
							liveing_location.toLowerCase())) {
						userSession.setAttribute("upcomingtrip", null);
					}
					// ///////////////////////////////////
				} else {
					/** User's default location */
					currentLocation = request.getParameter("location");
				}
			} else {
				/** User's default location */
				currentLocation = request.getParameter("location");
				locationList.add(currentLocation);
			}
			/**
			 * Check that user is viewing the trip on current date or before it
			 * to display the appropriate location label
			 */
			if (request.getParameter("tripdate") != null
					&& !request.getParameter("tripdate").equals("")) {
				SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
				Date tripdate = sdf.parse(request.getParameter("tripdate"));
				Date currentdate = sdf.parse(sdf.format(new Date()));

				if (tripdate.after(currentdate)) {
					locationLabel = "Upcoming Location";
				}
				latlong = new PeopleFinder().getUserLatLong(userId,
						currentLocation.split(",")[0], Integer.parseInt(request
								.getParameter("tripId")));
				//System.out.println("latlong in trip people finder action "+ latlong);

			} else {
				latlong = new PeopleFinder().getUserLatLong(userId,
						currentLocation.split(",")[0]);
				//System.out.println("latlong in trip people finder action in else part "+ latlong);
			}

			/** Store the location label in request object */
			userSession.setAttribute("LocationLabel", locationLabel);

			/** Store the location list in userSession object */
			userSession.setAttribute("current_location", locationList);
			request.setAttribute("current_location", locationList);

			/** Store the loggedin user's own lat/long in request object */
			request.setAttribute("LatLong", latlong);

			// Find friends from trips //
			// start code here
			// List tripFriendList = new
			// PeopleFinder().getPeopleNearOnCurrentDate(userId,request.getParameter("location").toString().split(", ")[0]);
			List tripFriendList = new PeopleFinder()
					.getPeopleNearOnUpcomingDate(userId, currentLocation
							.split(",")[0]);

			Hashtable<String, List<String>> hashtable = new Hashtable<String, List<String>>();
			List latlongList = new ArrayList();
			List upcomingPeople = new ArrayList();
			if (tripFriendList != null && tripFriendList.size() > 0) {
				for (int i = 0; i < tripFriendList.size(); i++) {
					Object[] object = (Object[]) tripFriendList.get(i);
					List<String> friend_info = new ArrayList<String>();
					friend_info.add((String) object[1]);
					friend_info.add("profile_page.jsp?id="
							+ (Integer) object[0]);
					friend_info.add("images/meetin_icon.png");
					friend_info.add((String) object[3]);
					friend_info.add((String) object[4]);
					friend_info.add("userid=" + (Integer) object[0]
							+ "&location=" + currentLocation.split(",")[0]);
					hashtable.put(String.valueOf((Integer) object[0]),
							friend_info);

					/**
					 * The below code is to get the user's friend
					 * name,latitude,langitude, image and social site icon from
					 * Trip table
					 */
					User user = new User();
					// setup parameter to show user details on google map
					user.setFullname((String) object[1]);
					user.setLocLat((String) object[3]);
					user.setLocLang((String) object[4]);
					user.setGoogleMarkerIcon("images/meetin_icon.png");

					String imageName = "";
					String imagePath = request.getScheme() + "://"
							+ request.getServerName() + ":"
							+ request.getServerPort()
							+ request.getContextPath();

					/**
					 * Checking for the user friend's profile image to show in
					 * google map
					 */
					if (object[5] != null && !object[5].toString().equals("")) {
						imageName = imagePath + "/profileimage/" + object[0]
								+ "_" + object[5];
					} else {
						if (object[6].toString().toLowerCase().equals("male")) {
							imageName = imagePath + "/images/male.png";
						} else {
							imageName = imagePath + "/images/female.png";
						}

					}
					friend_info.add(imageName);
					hashtable.put(String.valueOf(object[0]), friend_info);
					user.setImage(imageName);
					latlongList.add(user);
					// //System.out.println("Friend image when in findpeopleforTrip--"+imageName);

				}

			}
			// end of code here

			/**
			 * The below code is to show user's friends who are at their default
			 * location
			 */

			Hashtable<String, List<String>> friends = PF.peopleFinder(userId,request.getParameter("location").split(",")[0]);
			// Hashtable<String, List<String>> friends = PF.peopleFinder(userId,
			// request.getParameter("location"));
			// System.out.print("People On Default Location  :"
			// +friends.size());
			// System.out.print("People On Upcomming" +tripFriendList.size());

			/**
			 * The below code is to get the latitude and langitude of the user
			 * from User table(Lat/Lang for MeetIn,Facebook and Linkedin
			 * Friends)
			 */
			Enumeration latlangEnum = friends.keys();

			while (latlangEnum.hasMoreElements()) {
				String key = latlangEnum.nextElement().toString();
				List<String> list = (List<String>) friends.get(key);
				User u = new User();
				// setup parameter to show user details on google map
				u.setFullname(list.get(0).toString());
				u.setLocLat(list.get(3).toString());
				u.setLocLang(list.get(4).toString());
				u.setGoogleMarkerIcon(list.get(2));

				String imageName = "";
				String imagePath = request.getScheme() + "://"
						+ request.getServerName() + ":"
						+ request.getServerPort() + request.getContextPath();

				/**
				 * Checking for the user friend's profile image to show in
				 * google map
				 */
				if (list.get(6) != null && !list.get(6).toString().equals("")) {
					String image = list.get(2).split("/")[1];

					/** Checking for MeetIn friend's image */
					if (image.equalsIgnoreCase("meetin_icon.png")) {
						/** This is meetin user's image path */
						imageName = imagePath + "/profileimage/" + key + "_"
								+ list.get(6);
					} else {
						/** This is facebook user's image path */
						imageName = list.get(6).toString();
					}
				} else {
					/** This is the default image path for all user friend */
					if (list.get(7).toString().toLowerCase().equals("male")) {
						imageName = imagePath + "/images/male.png";
					} else {
						imageName = imagePath + "/images/female.png";
					}

				}

				u.setImage(imageName);
				// //System.out.println("Image in  trip in another findpeopleTrip--"+imageName);
				u.setUserKey(key);
				latlongList.add(u);

			}

			/** Storing the all latitude and langitude value in request object */
			request.setAttribute("LatLongList", latlongList);

			// merge the hashtable data
			Enumeration<String> e = hashtable.keys();
			while (e.hasMoreElements()) {
				String element = e.nextElement();
				friends.put(element, hashtable.get(element));
			}

			// if(friends == null)
			// request.setAttribute("requireNetworkSetup", "true");
			userSession.setAttribute("friends", friends);
			userSession.setAttribute("start", 0);
			request.setAttribute("filter", "all");
			if (friends.size() < 10)
				userSession.setAttribute("end", friends.size());
			else
				userSession.setAttribute("end", 10);
			// userSession.setAttribute("friends", friends);

		}
		return mapping.findForward("listofpeopleForTrip");
	}


	public ActionForward advancesearch(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		List interestList = new InterestDAO().getInterest();
		request.setAttribute("interestList", interestList);
		return mapping.findForward("advanceSearch");
	}

	public ActionForward advanceSearchResult(ActionMapping mapping,	ActionForm form, HttpServletRequest request,	HttpServletResponse response) throws Exception {
		
		HttpSession userSession = request.getSession();
		int userId = (Integer) userSession.getAttribute("UserID");
		String fromDate = "";
		String toDate = "";
		String location = "";
		String interest = "";

		if (request.getParameter("location") != null) {
			location = request.getParameter("location");
			HttpSession session = request.getSession();
			session.setAttribute("location", location);
		}
		if (request.getParameter("startDate") != null)
			fromDate = request.getParameter("startDate");
		if (request.getParameter("endDate") != null)
			toDate = request.getParameter("endDate");
		if (request.getParameter("interest") != null)
			interest = request.getParameter("interest");

		List<Integer> friends_id = new FriendsDAO().getFriendsId(userId);
		if (location != "" && fromDate != "" && toDate != "" && interest != "") {
			System.out.println("advance search with location date and interest");
			Hashtable<String, List<String>> searchfriends = null;
			searchfriends = new PeopleFinder().advanceSearchWithInterest(location.split(",")[0], fromDate, toDate, interest, userId);
			
			if (searchfriends != null && searchfriends.size() > 0) {
				request.setAttribute("friends", searchfriends);
				userSession.setAttribute("friends", searchfriends);
			} else {
				request.setAttribute("friends", null);
				userSession.setAttribute("friends", null);
			}
			request.setAttribute("filter", "all");
			userSession.setAttribute("start", "0");
			if (searchfriends.size() < 10)
				userSession.setAttribute("end", searchfriends.size());
			else
				userSession.setAttribute("end", 10);
			return mapping.findForward("searchResult");

		}
		// Added on 9th august 2012 by Rupal Kathiriya to get friends as trip wise in between dates
		else if (location == "" && fromDate != "" && toDate != ""&& interest == "") {
			Hashtable<String, List<String>> searchfriends = new PeopleFinder().advanceSearchWithDate(fromDate, toDate, userId);
			//System.out.println(searchfriends);
			userSession.setAttribute("searchfriends", searchfriends);
			if (searchfriends != null && searchfriends.size() > 0) {
				request.setAttribute("friends", searchfriends);
				userSession.setAttribute("friends", searchfriends);
			} else {
				request.setAttribute("friends", null);
				userSession.setAttribute("friends", null);
			}
			request.setAttribute("filter", "all");
			userSession.setAttribute("start", "0");
			if (searchfriends.size() < 10)
				userSession.setAttribute("end", searchfriends.size());
			else
				userSession.setAttribute("end", 10);
			return mapping.findForward("searchResult");
		} else if (location == "" && fromDate == "" && toDate == ""	&& interest != "") {

			System.out.println("with interest only");
			Hashtable<String, List<String>> searchfriends = new PeopleFinder().advanceSearchOnlyInterest(interest, userId);
			if (searchfriends != null && searchfriends.size() > 0) {
				request.setAttribute("friends", searchfriends);
				userSession.setAttribute("friends", searchfriends);
			} else {
				request.setAttribute("friends", null);
				userSession.setAttribute("friends", null);
			}
			request.setAttribute("filter", "all");
			userSession.setAttribute("start", "0");
			if (searchfriends.size() < 10)
				userSession.setAttribute("end", searchfriends.size());
			else
				userSession.setAttribute("end", 10);
			return mapping.findForward("searchResult");
		}

		// Ended by Rupal Kathiriya to get friends as trip wise in between dates
		

		else if (location != "" && fromDate != "" && toDate != ""		&& interest == "") // Searching Meetin Only Critaria Condition
		{
			System.out.println("locatin with date");
			Hashtable<String, List<String>> searchfriends = new PeopleFinder().advanceSearchNew(location.split(",")[0], fromDate, toDate,userId);
			if (searchfriends != null && searchfriends.size() > 0) {
				request.setAttribute("friends", searchfriends);
				userSession.setAttribute("friends", searchfriends);
			} else {
				request.setAttribute("friends", null);
				userSession.setAttribute("friends", null);
			}
			request.setAttribute("filter", "all");
			userSession.setAttribute("start", "0");
			if (searchfriends.size() < 10)
				userSession.setAttribute("end", searchfriends.size());
			else
				userSession.setAttribute("end", 10);
			return mapping.findForward("searchResult");
		}
		else if (location != "" && fromDate == "" && toDate == ""	&& interest != "") {
			System.out.println("with location and interest ");
			Hashtable<String, List<String>> searchfriends = new PeopleFinder().advanceSearchLocationAndInterest(location.split(",")[0],interest, userId);
			if (searchfriends != null && searchfriends.size() > 0) {
				request.setAttribute("friends", searchfriends);
				userSession.setAttribute("friends", searchfriends);
			} else {
				request.setAttribute("friends", null);
				userSession.setAttribute("friends", null);
			}
			request.setAttribute("filter", "all");
			userSession.setAttribute("start", "0");
			if (searchfriends.size() < 10)
				userSession.setAttribute("end", searchfriends.size());
			else
				userSession.setAttribute("end", 10);
			return mapping.findForward("searchResult");
		}
		 else if (location == "" && fromDate != "" && toDate != ""	&& interest != "") {
			 System.out.println("advance search with location and Date");
				Hashtable<String, List<String>> searchfriends = new PeopleFinder().advanceSearchDateWithInterest(fromDate,toDate,interest, userId);
				if (searchfriends != null && searchfriends.size() > 0) {
					request.setAttribute("friends", searchfriends);
					userSession.setAttribute("friends", searchfriends);
				} else {
					request.setAttribute("friends", null);
					userSession.setAttribute("friends", null);
				}
				request.setAttribute("filter", "all");
				userSession.setAttribute("start", "0");
				if (searchfriends.size() < 10)
					userSession.setAttribute("end", searchfriends.size());
				else
					userSession.setAttribute("end", 10);
				return mapping.findForward("searchResult");
			}
		else if (location != "" && fromDate == "" && toDate == ""	&& interest == "") // Searching Meetin and Facebook Critaria
									// Condition
		{
			System.out.println("with locatin only");
			try 
			{
				Hashtable<String, List<String>> searchfriends = new Hashtable<String, List<String>>();
				String profile_path = "profile_page.jsp";
				List list1 = new FriendsDAO().viewMeetInFriendsWithLocation(userId,location.split(",")[0]);	
				if(list1 !=null && list1.size() >0)
				{
					for(int i=0 ;i<list1.size();i++){
						List<String> friend_info = new ArrayList<String>();
						Object[] object=(Object[])list1.get(i);
						friend_info.add(object[1].toString()); //fullname
						
						friend_info.add(profile_path + "?id="
								+ String.valueOf(object[0]));
						friend_info.add("images/meetin_icon.png");
						
						friend_info.add((String)object[3] == null ? "" : (String)object[3]); //lat
						friend_info.add((String)object[4] == null ? "" : (String)object[4]); //long
						friend_info.add(""); // empty value
						String imageUrl = ((String)object[5] !=null ? "profileimage/"+(String)object[5] : (((String) object[6]).equalsIgnoreCase("Male") ? "images/male.png" : "images/female.png")); //user image
						
						//System.out.println("******************  "+imageUrl);
						friend_info.add(imageUrl); // meetin user's image Url
						friend_info.add((String)object[6]); // meetin user's gender
						searchfriends.put(String.valueOf(object[0]), friend_info);
					}
				}
				List friendList = new SocialNetworkDAO().getAllSocialFriendsWithlocationWise(userId, location.split(",")[0]);
				
				//System.out.println(friendList.size());
				if (friendList != null && friendList.size() > 0) {
					for (int i = 0; i < friendList.size(); i++) {
						Object[] object = (Object[]) friendList.get(i);
						List<String> friend_info = new ArrayList<String>();
						
						friend_info.add((String) object[1]);  //name
						String profile_url =(String) object[2]; 
						
						if(profile_url == null)
						{
							friend_info.add("");
						}
						else
						{
							friend_info.add(profile_url );   // profile url
						}
						
						friend_info.add((String)object[7]);   //icon
						friend_info.add(""); 	//lat
						friend_info.add(""); 	//lang
						friend_info.add(""); 	
						friend_info.add((String)object[3]);
						friend_info.add("");
						searchfriends.put(String.valueOf((Integer) object[6]),friend_info);
					}
				}
						
				System.out.println(searchfriends.size());
				if (searchfriends != null && searchfriends.size() > 0) 
				{
					request.setAttribute("friends", searchfriends);
					userSession.setAttribute("friends",searchfriends);
					
				}
				else 
				{
					request.setAttribute("friends", null);
					userSession.setAttribute("friends", null);
				}
				request.setAttribute("filter", "all");
				userSession.setAttribute("start", "0");
				if (searchfriends.size() < 10)
					userSession.setAttribute("end", searchfriends.size());
				else
					userSession.setAttribute("end", 10);
			} 
			catch (Exception ex) 
			{
				ex.printStackTrace();
			}
			return mapping.findForward("searchResult");
		}

		return mapping.findForward("searchResult");
	}

	public ActionForward getPeopleUpcomingTripDetail(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		HttpSession sc = request.getSession();
		Integer myuserId = (Integer) sc.getAttribute("UserID");
		if (myuserId != null && myuserId.intValue() != 0) {
			Integer frienduserId = Integer.parseInt(request.getParameter("userid"));
			String destination = request.getParameter("location");
			List tripdetailsList = new PeopleFinder().getPeopleUpcomingTripDetail(myuserId, frienduserId,destination);

			if (tripdetailsList != null && tripdetailsList.size() > 0) {
				request.setAttribute("PeopleTripDetail", tripdetailsList);
			} else {
				request.setAttribute("PeopleTripDetail", null);
			}

			return mapping.findForward("upcomingtripdetail");
		}

		return null;
	}

	public ActionForward getViewPeopleUpcomingTripDetail(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			HttpSession sc = request.getSession();
			Integer myuserId = (Integer) sc.getAttribute("UserID");
			if (myuserId != null && myuserId.intValue() != 0) 
			{
			Integer frienduserId = Integer.parseInt(request.getParameter("id"));

			//System.out.println("friend user id  is " + frienduserId);
			List tripdetailsList = new PeopleFinder().getViewPeopleUpcomingTripDetail(myuserId, frienduserId);

			if (tripdetailsList != null && tripdetailsList.size() > 0) 
			{
				request.setAttribute("ViewPeopleTripDetail", tripdetailsList);
			} else {
				request.setAttribute("ViewPeopleTripDetail", null);
			}

			return mapping.findForward("viewuserupcomingtrips");
		}

		return null;
	}

	public ActionForward meetingInviteView(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		System.out
				.println("People Finder Action .java---- meetingInviteView method called");

		HttpSession sc = request.getSession();
		
		Integer userId = Integer.parseInt(request.getParameter("userId"));

		String tripLocation = request.getParameter("triplocation");
		
		String user_travelling = request.getParameter("user_travelling");
		
		String friend_travelling = request.getParameter("friend_travelling");
		Integer userid = (Integer) sc.getAttribute("UserID");

		String tripDate = new PeopleFinder().getUserTripDate(userid,tripLocation);


		if (userId != null && userId.intValue() != 0) {

			User user = (User) new UserAccountDAO().getUserProfileDetails(userId);

			HttpSession session =request.getSession();
			
			if (user != null) {

				session.setAttribute("UserDetails", user);
				session.setAttribute("TripLocation", tripLocation);
				session.setAttribute("TripDate", tripDate);
				session.setAttribute("user_travelling",user_travelling);
				session.setAttribute("friend_travelling",friend_travelling);
				
				return mapping.findForward("meetinginviteview");
			}

		}

		return null;
	}
					
	
	public ActionForward friendMeetingInviteView(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		return mapping.findForward("meetingfriendinviteview");
	}
	public ActionForward meetinginvitation(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		HttpSession session = request.getSession();
		// //System.out.println("full name of friend is  ++ "+session.getAttribute("fname"));

		String friendname1 = session.getAttribute("fname").toString();
		HttpSession sc = request.getSession();

		/** Getting the Details of the Invitor */
		Integer userId = (Integer) sc.getAttribute("UserID");
		User user = new User();
		String path = request.getContextPath();
		String imagePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/profileimage/";
		String imageName = "";
		String meetinLogo = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/images/meetin_icon.png";

		if (userId != null && userId.intValue() != 0) {
			user = (User) new UserAccountDAO().getUserProfileDetails(userId);
			if (user != null) {
				if (user.getImage() != null && !user.getImage().equals(""))
				{
					imageName = imagePath + user.getUserId() + "_"
							+ user.getImage();
				}
			}

			String senderName = user.getFullname();
			String subject = user.getFullname() + " would like to meet you";
			String toEmail = request.getParameter("friendemail");

			
			
			
			String invitemessage = request.getParameter("message");
			
			
			String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
			///mailer format 
			String htmlmessage = new Mailer_Header().getMailerHeader(bannar);

			
			htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>"+invitemessage+"</td>" +
			"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><p></p>" +
			"      <p></p>      <p></p>" +
			"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p></p></td>" +
			"  </tr>  <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
			"  </tr></table></td>  </tr>";	 
	
			
			String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
			String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
			String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
			String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
				
				
			htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
			new InviteFriends().postMail(toEmail,subject, htmlmessage,user.getEmail());
			
			
			
/*			
			
			htmlmessage += "<div style=\"background-color: rgb(255, 153, 0); padding: 5px 10px; color: rgb(255, 255, 255); font-family: 'Trebuchet MS'; font-size: 18px;\"><img src="
					+ meetinLogo
					+ " align=\"absmiddle\" hspace=\"5\"></img><strong>Meeting Invitation</strong></div>";
			htmlmessage += "<div style=\"margin-top: 10px; padding: 0px 10px; font-family: 'Trebuchet MS';\"> ";
			htmlmessage += "<div style=\"color: rgb(0, 153, 255); font-size: 13px; font-weight: bold;\">Hi "
					+ friendname1 + ",</div> ";
			htmlmessage += "<div style=\"padding: 10px 10px 10px 0px;float:left;\"><img src="
					+ imageName + " width=\"75px\" height=\"75px\"></div>";
			htmlmessage += "<div style=\"font-family: 'Trebuchet MS';padding: 10px 0px;float:left;\">"
					+ invitemessage + "</div>";
			htmlmessage += "<div style=\"font-family: 'Trebuchet MS'; font-size: 13px;clear:both;\">Regards, <br> meetIn Team</div></div></div>";
*/
			
			

			//new PeopleFinder().sendMeetingInvitation(toEmail, subject,htmlmessage, "", senderName);

		}

		return mapping.findForward("success");
	}


	public ActionForward meetingfriendinvitation(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		
		HttpSession session = request.getSession();
		String path = request.getContextPath();
		String imagePath = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/profileimage/";
		String imageName = "";
		String meetinLogo = request.getScheme() + "://"
				+ request.getServerName() + ":" + request.getServerPort()
				+ path + "/images/meetin_icon.png";

		String subject = session.getAttribute("name")+" has sent you a message from meetIn";
		
		String toEmail = request.getParameter("friendemail");
		
			
		String invitemessage = request.getParameter("message");
		
			
		String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
			///mailer format 
			String htmlmessage = new Mailer_Header().getMailerHeader(bannar);

			
			htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>"+invitemessage+"</td>" +
			"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><p></p>" +
			"      <p></p>      <p></p>" +
			"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p></p></td>" +
			"  </tr>  <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
			"  </tr></table></td>  </tr>";	 
	
			
			String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
			String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
			String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
			String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
				
				
			htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
			new InviteFriends().postMail(toEmail,subject, htmlmessage,"");
			
				
			//new PeopleFinder().sendMeetingInvitation(toEmail, subject,htmlmessage, "", senderName);

		return mapping.findForward("meetingfriendinvitation");
	}
	
	
	
	public ActionForward peoplenearme(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		System.out.println("people near me method called ");
		
		User user = new User();
		HttpSession sc = request.getSession();
		UserAccountDAO uadao = new UserAccountDAO();

		String imagePath = request.getScheme() + "://"	+ request.getServerName() + ":"	+ request.getServerPort() + request.getContextPath();
		int userId = (Integer) sc.getAttribute("UserID");
		/**
		 * code to find current location of user (in case user is travelling on
		 * current date)
		 */
		List<String> locationList = new ArrayList<String>();
		
		
		List<String> meetInlocationList = new ArrayList<String>();
		meetInlocationList = new PeopleFinder().getUserLocationOnCurrentDate(userId);
		
		
		List<String> TripitlocationList = new ArrayList<String>();
		TripitlocationList = new PeopleFinder().geTripitUserLocationOnCurrentDate(userId);
		
		System.out.println("Tripit user location list " + TripitlocationList.size());
		
		
		if(meetInlocationList.size() > 0 && meetInlocationList != null)
		{
			locationList.addAll(meetInlocationList);
		}
		
		
		if(TripitlocationList.size() > 0 && TripitlocationList != null)
		{
			locationList.addAll(TripitlocationList);
		}
		
		System.out.println("user location on current date "+locationList.size());

		String currentLocation = "";
		String latlang = "";
		
		/** Changes by Sarika */
		sc.setAttribute("showlivinglocation", null);
		/** Shoe grid on Select friend name in people finder page */
		if (request.getParameter("selFrdId") != null) {
			String selectFrd_id = request.getParameter("selFrdId");
			request.setAttribute("selectFrd_id", selectFrd_id);

		}

		
		System.out.println("tripit trpits ");
		
		
	//	List TripitUserUpcomingTrip = new ArrayList();
	//	TripitUserUpcomingTrip = new TripsDAO().getTripitUserUpcomingTrips(userId);
	
	//	System.out.println("tripit user upcoming trips ***  "+TripitUserUpcomingTrip.size());
		
		
		/** Chanages by Sarika */
		/* Code start to find user has upcoming trips */
		
		List meetInUserUpcomingTrip = new ArrayList();
		meetInUserUpcomingTrip = new TripsDAO().getUserUpcomingTrips(userId);
		
		List upcomingTrip = new ArrayList();
		/*
		if(TripitUserUpcomingTrip.size() > 0 && TripitUserUpcomingTrip != null)
		{
			upcomingTrip.addAll(TripitUserUpcomingTrip);
		}*/
		
		if(meetInUserUpcomingTrip.size() > 0 && meetInUserUpcomingTrip != null) 
		{
			upcomingTrip.addAll(meetInUserUpcomingTrip);
		}
		
		
		System.out.println("upcoming trip size *****  " + upcomingTrip.size());

		if (upcomingTrip != null && upcomingTrip.size() > 0) {
			sc.setAttribute("upcomingtrip", upcomingTrip);
		} else {
			sc.setAttribute("upcomingtrip", null);
		}

		/* code end */

		
		if(upcomingTrip.size() > 0)
		{
		//int futureTrip =new PeopleFinder().getFutureTrip(userId);
			sc.setAttribute("futureTrip",upcomingTrip.size());
		}
		else
		{
			sc.setAttribute("futureTrip","0");
		}
		
		
		/** LoggedIn User's profile details */
		User userProfile = (User) sc.getAttribute("userProfile");
			
		if(request.getParameter("l") !=null & Boolean.parseBoolean(request.getParameter("loc")) == false){
			
			currentLocation = request.getParameter("l").toString();
			latlang = new PeopleFinder().getUserLatLong(userId, currentLocation.split(",")[0]);
			request.setAttribute("SelectedLoc", currentLocation);
			
		}else if ((locationList != null && locationList.size() > 0)
				& (Boolean.parseBoolean(request.getParameter("loc")) == false)) {
			
			// /////////////Code change by sarika
			/** User's current location */
			currentLocation = locationList.get(0);
			/** LoggedIn User's current Latitude/Langitude */
			latlang = new PeopleFinder().getUserLatLong(userId, currentLocation
					.split(",")[0]);
			sc.setAttribute("showlivinglocation", null);
			String liveing_location = new UserAccountDAO()
					.getUserLocationByCityState(userId);
			
			if (currentLocation.toLowerCase().equals(
					liveing_location.toLowerCase())) {
				sc.setAttribute("upcomingtrip", null);
			}
		}else{
			
			/** User's default location */
			currentLocation = userProfile.getLocCity();
			locationList.add(0, currentLocation);

			latlang = userProfile.getLocLat() + ":" + userProfile.getLocLang();
			for (int i = locationList.size() - 1; i > 0; i--) {
				locationList.remove(i);
			}
			sc.setAttribute("showlivinglocation", true);
			/** The below line allow user to edit the default location */
			request.setAttribute("AllowLocationEdit", currentLocation);
		}

		/** Store the location list in request object */
		sc.setAttribute("current_location", locationList);

		/** Store the loggedin user's own lat/long in request object */
		request.setAttribute("LatLong", latlang);

		/**Store the loggedin user's profile details */
		request.setAttribute("Profile", userProfile);
	
		PeopleFinder PF = new PeopleFinder();
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();

		/**
		 * Code to get the list of specific social media friends
		 * Starting code point
		 */
			if(request.getParameter("socialMedia")!=null)
			{
				/**
				 * This is for meetIn friend list
				 */
				if(request.getParameter("socialMedia").equalsIgnoreCase("meetIn")){
					
					friends = getMeetInPeopleNearMe(userId, currentLocation.split(",")[0]);
					
				}else if (request.getParameter("socialMedia").equalsIgnoreCase("All")){
					
					friends = getMeetInPeopleNearMe(userId, currentLocation.split(",")[0]);

					/**
					 * This is for Facebook, Gmail, LinkedIn, twitter etc.. friend list
					 */
					List l = new SocialNetworkDAO().getAllSocialFriendsByLocation(userId, currentLocation.split(",")[0]);
					String latlanString = new LocationDAO().getCityLatitudeLongitude(currentLocation.split(",")[0].toLowerCase());

					Iterator itr = l.iterator();
					String  latitude = "", langitude = "";
					while(itr.hasNext())
					{
						Object[] object = (Object[]) itr.next();
						List<String> friend_info = new ArrayList<String>();
						friend_info.add((String)object[1]);
						friend_info.add((String) object[2]);
						friend_info.add((String) object[7]);
					
						if (!latlanString.equals(""))
						{
							latitude = latlanString.split(":")[0];
							langitude = latlanString.split(":")[1];
						}
						
						friend_info.add(latitude); // facebok user's latitude
						friend_info.add(langitude); // facebook user's langitude
						friend_info.add(""); // empty value
						friend_info.add((String) object[3]); // user profile image
						friend_info.add(""); // meetin user's gender
						
						friends.put(String.valueOf((Integer) object[6]), friend_info);
									
					}

				}else{
					/**
					 * This is for Facebook, Gmail, LinkedIn, twitter etc.. friend list
					 */
					System.out.println(request.getParameter("socialMedia"));
					int socialId = new NetworkDAO().getSocialNetworkId(request.getParameter("socialMedia"));
					
					System.out.println(socialId);
					
					friends = PF.peopleFinder(userId, currentLocation.split(",")[0], socialId);
					
					System.out.println(friends.size());	
				}
			}
		
			ArrayList f = new ArrayList(friends.values());
			System.out.println(f.toString());
	    	new UserAccountDAO().sortList(f);
	    	
	    	sc.setAttribute("LastModifiedDate", (f.size() > 0 && (!request.getParameter("socialMedia").equalsIgnoreCase("meetIn") && !request.getParameter("socialMedia").equalsIgnoreCase("All"))  ? ((ArrayList) f.get(0)).get(8) : null));
			sc.setAttribute("friends", f);
			request.setAttribute("filter", request.getParameter("socialMedia"));
			
			/** Storing the all latitude and langitude value in request object with sorting */
			sc.setAttribute("LatLongList", getMapData(friends, new ArrayList(), imagePath));
			
			sc.setAttribute("start", "0");
			if (friends.size() < 10)
				sc.setAttribute("end", friends.size());
			else
				sc.setAttribute("end", 10);

		return mapping.findForward("peoplenearme");

	}
 
    public Hashtable<String, List<String>> getMeetInPeopleNearMe(int userId, String currentLocation)
    {
    	Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
    	/**
		 * The below code is to show user's friends who are at their travel
		 * location
		 */
		// start code here
		List tripFriendList = new PeopleFinder().getPeopleNearOnCurrentDate(userId, currentLocation.split(",")[0]);
			
		Hashtable<String, List<String>> hashtable = new Hashtable<String, List<String>>();
		List latlongList = new ArrayList();

		if (tripFriendList != null && tripFriendList.size() > 0) {
			for (int i = 0; i < tripFriendList.size(); i++) {

				Object[] object = (Object[]) tripFriendList.get(i);
				List<String> friend_info = new ArrayList<String>();
				friend_info.add((String) object[1]);
				friend_info.add("profile_page.jsp?id=" + object[0]);
				friend_info.add("images/meetin_icon.png");
				friend_info.add((String) object[3]);
				friend_info.add((String) object[4]);
				friend_info.add("userid=" + (Integer) object[0] + "&location="+ currentLocation.split(",")[0]);

				String imageName = "";
				
				/**
				 * Checking for the user friend's profile image to show in
				 * google map
				 */
				if (object[5] != null && !object[5].toString().equals("")) {
					imageName = "profileimage/" + (String) object[5];
				} else {
					if (object[6].toString().toLowerCase().equalsIgnoreCase("Male"))
						imageName =  "images/male.png";
					else
						imageName =  "images/female.png";
				}
				
				friend_info.add(imageName);
				friend_info.add((String)object[6]);
				hashtable.put(String.valueOf(object[0]), friend_info);
				
			}
		}
		// end of code here
		
		friends = new UserAccountDAO().getFriendsNames_Ids(currentLocation.split(",")[0], userId);
		Enumeration e = hashtable.keys();
		while(e.hasMoreElements())
		{
			String ele = (String)e.nextElement();
			friends.put(ele, hashtable.get(ele));
		}
		
		return friends;
    }
	public List getMapData(Hashtable<String, List<String>> friends, List latlongList, String imagePath)
	{
		/**
		 * The below code is to get the details of the user's friend from User
		 * table(Lat/Lang for MeetIn,Facebook and Linkedin Friends)
		 */
		
		Enumeration latlangEnum = friends.keys();
		while (latlangEnum.hasMoreElements()) {
			String key = latlangEnum.nextElement().toString();
			List<String> list = friends.get(key);
			
			User u = new User();
			u.setFullname(list.get(0).toString());
			u.setLocLat(list.get(3).toString());http://vpcl013:8080/MeetIn2/
			u.setLocLang(list.get(4).toString());
			u.setGoogleMarkerIcon(list.get(2));

			String imageName = "";
			
			/**
			 * Checking for the user friend's profile image to show in google
			 * map
			 */
			if (list.get(6) != null && !list.get(6).toString().equals("")) {
				String image = list.get(2).split("/")[1];

				/** Checking for MeetIn friend's image */
				if (image.equalsIgnoreCase("meetin_icon.png")) {
					/** This is meetin user's image path */
					imageName = imagePath + "/" + list.get(6);
				} else {
					/** This is facebook user's image path */
					imageName = list.get(6).toString();
				}

			} else {
				/** This is the default spacer image path for respected social network */
					imageName = imagePath + "/" +list.get(2).toString();
			}
			u.setImage(imageName);
			u.setUserKey(key);
			
			latlongList.add(u);
		}
		
		/** Sorting the Map data with User fullname */
		Collections.sort(latlongList, new Comparator() {
			public int compare(Object o1, Object o2) {
				
				int result=0;
				String value1 = (String)((User)o1).getFullname();
				String value2 = (String)((User)o2).getFullname();
				
				result=value1.compareToIgnoreCase(value2);

				return result;
			}
		});
		
		return latlongList;
	}
	/*public ActionForward getPeopleFinder(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{http://vpcl013:8080/MeetIn2/
		HttpSession sc = request.getSession();	
		Hashtable<String, List<String>> MeetIn_friends  = new PeopleFinder().getpeopleFinder( Integer.parseInt(sc.getAttribute("UserID").toString()) , "ahmedabad");
		
		sc.setAttribute("friends", MeetIn_friends);
		
		return mapping.findForward("peoplenearme");
	}
	
	
	*/
	
	
	public ActionForward navigatePeopleNearFriendList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession session = request.getSession();
		ArrayList friends = (ArrayList) session.getAttribute("friends");
		System.out.println("inaction "+friends.size());
		String event = (String) request.getParameter("e");
		int start = Integer.parseInt(session.getAttribute("start").toString());
        int end = Integer.parseInt(session.getAttribute("end").toString());
        
		
		if(event !=null && event.equalsIgnoreCase("Last")){
			end = friends.size();
	    	if(friends.size() < 10)
	    		start = 0;
	    	else
	    	{
	    		start = (friends.size() / 10) * 10;
	    		if(start == friends.size())
					start = start - 10;
	    	}	
		}if(event !=null && event.equalsIgnoreCase("First")){
			start = 0;
			end = (friends.size() < 10) ? friends.size(): 10;
        	
		}if(event !=null && event.equalsIgnoreCase("Next")){
			 start = end;
			 				
             if(friends.size() < 10){
                     end = friends.size();
             }else if((end+10) < friends.size()){ 
                     end = end + 10;
             }else if((end+10) > friends.size()){
                     end = end + (friends.size() - end);
             }else if((end+10) >= friends.size()){
                     end = friends.size();
             }
             
		}if(event != null && event.equalsIgnoreCase("Prev")){
			 
			if(start >= 10){
                     start = start - 10;
             }else if(start < 10){
                     start = start - start;
             }
             end = start + 10;
             
         }if(event !=null && event.equalsIgnoreCase("page_combo")){
        	 
        	String[] s = request.getParameter("paging").split("-");
         	start = Integer.parseInt(s[0]);
         	end = Integer.parseInt(s[1]);
         }
			
    	session.setAttribute("end", end);
    	session.setAttribute("start", start);
    	
    	return mapping.findForward("peoplenearme");
	}
	
}