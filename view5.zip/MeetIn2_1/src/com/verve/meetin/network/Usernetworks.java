package com.verve.meetin.network;

import org.apache.struts.action.ActionForm;

/**
 * MiUsernetworks entity. @author MyEclipse Persistence Tools
 */

public class Usernetworks extends ActionForm implements java.io.Serializable {

	// Fields

	private Integer userNetworkId;
	private Integer userId;
	private Integer socialNetworkSiteId;
	private String username;
	private String password;
	private String access_token;
	
	// Constructors

	/** default constructor */
	public Usernetworks() {
	}

	/** full constructor */
	public Usernetworks(Integer userId, Integer socialNetworkSiteId,
			String username, String password, String access_token) {
		this.userId = userId;
		this.socialNetworkSiteId = socialNetworkSiteId;
		this.username = username;
		this.password = password;
		this.access_token = access_token;
	}

	// Property accessors

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String accessToken) {
		access_token = accessToken;
	}
	
	public Integer getUserNetworkId() {
		return this.userNetworkId;
	}

	public void setUserNetworkId(Integer userNetworkId) {
		this.userNetworkId = userNetworkId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getSocialNetworkSiteId() {
		return this.socialNetworkSiteId;
	}

	public void setSocialNetworkSiteId(Integer socialNetworkSiteId) {
		this.socialNetworkSiteId = socialNetworkSiteId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}