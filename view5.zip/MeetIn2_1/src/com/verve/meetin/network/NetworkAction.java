package com.verve.meetin.network;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.verve.meetin.network.peoplefinder.ScheduleSocialNetwork;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;
import com.verve.meetin.tripit.Tripit;

public class NetworkAction extends DispatchAction{

	public ActionForward remove(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		if(request.getParameter("userid") !=null && request.getParameter("siteid")!=null)
		{
			int userid =Integer.parseInt(request.getParameter("userid"));
			int siteid= Integer.parseInt(request.getParameter("siteid"));
			
			
			/*if(siteid ==NetworkConstraint.SOCIAL_NETWORK_FACEBOOK)
			{
				System.out.println(siteid);
				//new NetworkDAO().setNetworkUserName(onetwork1, sc.getAttribute("network_user").toString());
				new NetworkDAO().removeUserSocialNetworkSite(userid, 8);
			}*/
			
			
			int row = new NetworkDAO().removeUserSocialNetworkSite(userid, siteid);
			
			
			System.out.println("rows affected : "+row);
			
			/**
			 * Remove the social network friend list from dummy table for logged in user. 
			 */
			
			//seperate function call for tripit
			if(siteid == NetworkConstraint.SOCIAL_NETWORK_TRIPIT){
				new Tripit().deleteTripit_Trips(userid);
			}
			else
			{
				if(siteid == NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE)
				{
					new NetworkDAO().removeUserSocialNetworkSite(userid, NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE_CHECKIN);
					new SocialNetworkDAO().deleteFourSquareCheckinData(userid, NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE_CHECKIN);
				}
				
				new SocialNetworkDAO().deleteSocialDummyData(userid, siteid);
			}
			
			if(row > 0)
			{
				return mapping.findForward("success");
			}
			else
			{
				return mapping.findForward("failure");
			}
		}
		
		return mapping.findForward("failure");
	}
	public ActionForward add(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		   		System.out.println("add method called ");
				
				//Usernetworks usernetwork =(Usernetworks)form;
				NetworkDAO ntdao = new NetworkDAO();
				HttpSession sc = request.getSession(false);
				int userid=0;
			
			try {
			
				userid = (Integer)sc.getAttribute("UserID");
				
				System.out.println("user id of the user is "+ userid);
			    int socialid = ntdao.getSocialNetworkId(request.getParameter("network"));
			    System.out.println("social id of the user is " + socialid );
				Usernetworks onetwork = new Usernetworks(
			    		userid, socialid, "", "", 
			    		sc.getAttribute("access_token").toString());
				
				
				System.out.println("access token size "+ sc.getAttribute("access_token").toString().length());
			  
				int row = new NetworkDAO().setUserSocialNetworkSite(onetwork);
				
				
				System.out.println("row value returned :: " + row);
				/**
				 * Reading Facebook, LinkedIn, Gmail etc... friends for loggedin user and storing into table. 
				 */
				new ScheduleSocialNetwork().startscheduleScoialNetwork(userid, sc.getId(),socialid);
				
				 if(row > 0){
					 //System.out.println("in if case success occurs");
					 
					 try 
					 {
					 	System.out.println("network user name "+sc.getAttribute("network_user").toString());
					 	System.out.println("network " + onetwork.toString());
					 }
					 catch (Exception e)  
					 {
						System.out.println("EXception occured : "+e);
					 }	
					 	
					 if(sc.getAttribute("network_user") == null)
					 {
						 new NetworkDAO().setNetworkUserName(onetwork,""); 
					 }
					 else
					 {
						 new NetworkDAO().setNetworkUserName(onetwork,sc.getAttribute("network_user").toString());
					 }
				 		
				 		return mapping.findForward("success");
					}
			
			} catch (Exception e) {
					System.out.println("Exception  e" + e);
				}
				 //System.out.println("failure");
				 sc.removeAttribute("network_user");
			     return mapping.findForward("failure");
			}

	
	public ActionForward edit(ActionMapping mapping, ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception{
				Usernetworks usernetwork =(Usernetworks)form;
				Usernetworks onetwork = new Usernetworks(usernetwork.getUserId(), 
			    		usernetwork.getSocialNetworkSiteId(), usernetwork.getUsername(), 
			    		usernetwork.getPassword(), "");
				int row = new NetworkDAO().updateUserSocialNetworkSite(onetwork);
				 if(row > 0)
					{
						return mapping.findForward("success");
					}
				 return mapping.findForward("failure");
			}
	
}
