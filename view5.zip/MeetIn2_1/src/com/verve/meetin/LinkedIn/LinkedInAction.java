package com.verve.meetin.LinkedIn;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class LinkedInAction extends DispatchAction{
	public ActionForward linkedinAuthentication(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		//System.out.println("This is the Linked in Authentication .............. !");
		OAuthConsumer consumer;
		OAuthProvider provider;
		consumer = new DefaultOAuthConsumer(
	                "A6G_RTLYXHVski-7-ZNegHakOL6ioBWjtGy6hvgreZDg-HIsG9MqRFTEwyTB7M5U",
	                "2bdx3kCzxRWHVFbf3foTtYszQGf-vW3Tww8cv9XW0kcgsq1pSXNRpxGQqD8V2Uqy"
	                );
	 	provider = new DefaultOAuthProvider(
	        		"https://api.linkedin.com/uas/oauth/requestToken",
	                "https://api.linkedin.com/uas/oauth/accessToken",
	                "https://api.linkedin.com/uas/oauth/authorize");
		if(request.getParameter("oauth_verifier") == null) {
			String authUrl = provider.retrieveRequestToken(
					consumer, 
					"http://meetin.vervesys.com/linkedin.do?action=linkedinAuthentication"); //or   OAuth.OUT_OF_BAND
			
			response.sendRedirect(authUrl);
		}
		else {
			provider.retrieveAccessToken(consumer, request.getParameter("oauth_verifier"));
		}
		return null;
	}
}