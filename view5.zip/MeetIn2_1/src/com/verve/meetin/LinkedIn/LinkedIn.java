package com.verve.meetin.LinkedIn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//import com.google.code.facebookapi.ProfileField;
import com.google.code.linkedinapi.client.LinkedInApiClient;
import com.google.code.linkedinapi.client.LinkedInApiClientFactory;
import com.google.code.linkedinapi.client.enumeration.ProfileField;
import com.google.code.linkedinapi.client.oauth.LinkedInAccessToken;
import com.google.code.linkedinapi.schema.Connections;
import com.google.code.linkedinapi.schema.CurrentShare;
import com.google.code.linkedinapi.schema.DateOfBirth;
import com.google.code.linkedinapi.schema.Network;
import com.google.code.linkedinapi.schema.Person;
import com.google.code.linkedinapi.schema.Update;
import com.google.code.linkedinapi.schema.UpdateContent;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.types.User;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDummy;

public class LinkedIn {
	OAuthConsumer consumer;
	OAuthProvider provider;
	ResourceBundle resource;
	public LinkedIn()
	{
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		consumer = new DefaultOAuthConsumer(
				resource.getString("linkedin.consumer_key"),
        		resource.getString("linkedin.consumer_secret")
                );
 
        provider = new DefaultOAuthProvider(
        		"https://api.linkedin.com/uas/oauth/requestToken",
                "https://api.linkedin.com/uas/oauth/accessToken",
                "https://api.linkedin.com/uas/oauth/authorize");
	}
	
	public Hashtable<String, List<String>> getFriendsInfo(
			String access_token, String current_location) throws Exception
	{
		Hashtable<String, List<String>> friends = 
				new Hashtable<String, List<String>>();
		try {
			LinkedInAccessToken accessToken = 
					new LinkedInAccessToken(access_token.split(",")[0], access_token.split(",")[1]);
			final LinkedInApiClientFactory factory = LinkedInApiClientFactory.newInstance(
					resource.getString("linkedin.consumer_key"),
					resource.getString("linkedin.consumer_secret"));
			
				final LinkedInApiClient client = factory.createLinkedInApiClient(accessToken);
			try {	
				//FacebookClient facebookClient = new DefaultFacebookClient(access_token);
				//User user = client.getProfileByUrl("me", User.class);
				//return user.getEmail();
				Person profile = client.getProfileForCurrentUser();
				System.out.print("CurrentUsers Profile-Name >> "+profile.getFirstName()+" "+profile.getLastName());
				
			}catch (Exception e)
			{
				List<String> msg = new ArrayList<String>();
				msg.add(e.getLocalizedMessage());
				friends.put("ERROR", msg);
				return friends;
			}
			//final Set<ProfileField> connectionFields = EnumSet.of(ProfileField.UID, 
			//ProfileField.FIRST_NAME, ProfileField.LAST_NAME, ProfileField.PROFILE_URL,ProfileField.HOMETOWN_LOCATION);
			//People people = client.searchPeople());
			
			Connections tryconnections = client.getConnectionsForCurrentUser();
			for (Person person : tryconnections.getPersonList()) {
				List<String> friend_info = new ArrayList<String>();
				if(person.getLocation() != null)
				{
					String location = person.getLocation().getName();
					Pattern locationPattern = Pattern.compile("\\s[a-zA-z]*,\\s?[a-zA-Z]+");
			        Matcher locationMatcher = locationPattern.matcher(location);
			        location = locationMatcher.replaceAll("").toLowerCase();
					if(location.toLowerCase().contains(current_location.toLowerCase())) {
						friend_info.add(person.getFirstName() + " " + person.getLastName());
						friend_info.add(""); //getProfile(access_token, person.getId())
						friend_info.add(new NetworkDAO().getSocailNetworkIcon("LinkedIn").toString());
						String latlang = new LocationDAO().getCityLatitudeLongitude(current_location.toLowerCase());
						friend_info.add(latlang.split(":")[0]); // linkedin user's latitude
						friend_info.add(latlang.split(":")[1]); // linkedin user's langitude
						friend_info.add(""); // empty value
						friend_info.add(""); // empty value for linkedin user's image name
						friend_info.add(""); // linkedin user's gender
						friends.put(person.getId(), friend_info);
					}
				}
			}
			
			return friends;
		}catch(Exception e)
		{
			List<String> msg = new ArrayList<String>();
			msg.add("Problem to get LinkedIn Contacts !");
			friends.put("ERROR", msg);
			return friends;
		}
	}
	/** This is overloaded method */
	public Hashtable<String, List<String>> getFriendsInfo(String access_token)
			throws Exception {
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		try {
			LinkedInAccessToken accessToken = new LinkedInAccessToken(
					access_token.split(",")[0], access_token.split(",")[1]);
			
			final LinkedInApiClientFactory factory = LinkedInApiClientFactory
					.newInstance(resource.getString("linkedin.consumer_key"),
							resource.getString("linkedin.consumer_secret"));
			final LinkedInApiClient client = factory
					.createLinkedInApiClient(accessToken);
			Person profile = client.getProfileForCurrentUser();
			
			// ////////////////////////////////////////////////////////////////////////////
			/** This is use for status Update on Linkedin from Add Trip */
			// client.updateCurrentStatus("Hello Linkedin");
			// client.sendInviteByEmail("lokesh.pareek5@gmail.com", "lokesh",
			// "pareek", "VIA linkedin", "This is test message");
		/*	try{
			DateOfBirth dob = 
			
			}catch (Exception e) {
				
			}*/
			// ///////////////////////////////////////////////////////////////////

			Connections tryconnections = client.getConnectionsForCurrentUser();
			for (Person person : tryconnections.getPersonList()) {
				List<String> friend_info = new ArrayList<String>();
				friend_info.add(person.getFirstName() + " "
						+ person.getLastName());
				if(person.getLocation() != null) {
					String location_split = person.getLocation().getName().split(",")[0];
					String user_location = location_split.replace("Area", "").trim();
					friend_info.add(user_location);
				}else{
					friend_info.add("---");
				}
				friend_info.add("");
				friend_info.add(new NetworkDAO().getSocailNetworkIcon("LinkedIn").toString());
				friends.put(person.getId(),friend_info);
			}

			/**
			 * This code use for send a text message on linkedin message(as an
			 * email).
			 */
			/*
			 * Person uprofile =
			 * client.getProfileForCurrentUser(EnumSet.allOf(ProfileField
			 * .class)); Connections c = uprofile.getConnections(); List<Person>
			 * ufriends = c.getPersonList(); List<String> ids = new
			 * ArrayList<String>(); int length = ufriends.size(); for(int i
			 * =0;i<length;i++){ //ids.add(ufriends.get(i).getId());
			 * ids.add("mHYMnFMw5R"); //this is lokesh pareek Id of linkedin }
			 * try{ client.sendMessage(ids,"HI","Hello How r u");
			 * }catch(Exception e){ //System.out.println(e); }
			 * //System.out.println("Hello");
			 */
			/** Code end */

			return friends;
		} catch (Exception e) {
			List<String> msg = new ArrayList<String>();
			msg.add("Problem to get LinkedIn Contacts !");
			friends.put("ERROR", msg);
			return friends;
		}
	}
	public List<SocialNetworkDummy> getLinkedInFriendsDump(String access_Token, int userid, String sessionid, int socialid)
	{
	
		List<SocialNetworkDummy> list = new ArrayList<SocialNetworkDummy>();
		try {
			
			LinkedInAccessToken accessToken = new LinkedInAccessToken(
					access_Token.split(",")[0], access_Token.split(",")[1]);
			
			final LinkedInApiClientFactory factory = LinkedInApiClientFactory
					.newInstance(resource.getString("linkedin.consumer_key"),
							resource.getString("linkedin.consumer_secret"));
			final LinkedInApiClient client = factory
					.createLinkedInApiClient(accessToken);
						
			String city = null;
			Connections tryconnections = client.getConnectionsForCurrentUser();
			for (Person person : tryconnections.getPersonList()) 
			{
				String fullname  = person.getFirstName() + " " + person.getLastName();
				if(person.getLocation() !=null)
				{
					String location_split = person.getLocation().getName().split(",")[0];
					city = location_split.replace("Area", "").trim();	
				}
				
				SocialNetworkDummy s = new SocialNetworkDummy(sessionid, userid, socialid, fullname, null, person.getPictureUrl(), city);
				list.add(s);
				
			}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return list;
	}
	public String getProfile(String access_token, String connectionId) throws Exception{
		
		consumer.setTokenWithSecret(access_token.split(",")[0], access_token.split(",")[1]);
		//URL url = new URL("http://api.linkedin.com/v1/people/~:
		//(id,first-name,last-name,picture-url,headline,location:(name),phone-numbers,main-address,public-profile-url)");
		URL url = new URL("http://api.linkedin.com/v1/people/id="+connectionId+":(id,public-profile-url)");
		//URL url = new URL("https://api.linkedin.com/uas/oauth/invalidateToken");
        HttpURLConnection request1 = (HttpURLConnection) url.openConnection();
 
        try {
			consumer.sign(request1);
		} catch (OAuthMessageSignerException e) {
			e.printStackTrace();
		} catch (OAuthExpectationFailedException e) {
			e.printStackTrace();
		} catch (OAuthCommunicationException e) {
			e.printStackTrace();
		}
 
        request1.connect();
        String profile_url = parseProfile(request1.getInputStream());
        /*String responseBody = convertStreamToString(request1.getInputStream());*/
        /*//System.out.println("Response: " + request1.getResponseCode() + " "
                + request1.getResponseMessage() + "\n\n" + responseBody);*/
        return profile_url;
	}
	public String parseProfile(InputStream xmlDoc) throws Exception
	{
		String Profile_Url="";
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(xmlDoc);
		doc.getDocumentElement().normalize();

		NodeList nodeLst = doc.getElementsByTagName("person");
		
		for (int s = 0; s < nodeLst.getLength(); s++) {
			Node fstNode = nodeLst.item(s);
			if (fstNode.getNodeType() == Node.ELEMENT_NODE) {
				Element fstElmnt = (Element) fstNode;
			    NodeList fstNmElmntLst = fstElmnt.getElementsByTagName("public-profile-url");
			    Element fstNmElmnt = (Element) fstNmElmntLst.item(0);
			    if(fstNmElmnt != null)
			    {
			    	NodeList fstNm = fstNmElmnt.getChildNodes();
				    Profile_Url = (fstNm.item(0)).getNodeValue();
			    }
			}
		}
		return Profile_Url;
		/*for (int s = 0; s < nodeLst.getLength(); s++) {
		    Node fstNode = nodeLst.item(s);
		    if (fstNode.getNodeType() == Node.ELEMENT_NODE) {
			    Element fstElmnt = (Element) fstNode;
			    NodeList fstNmElmntLst = fstElmnt.getElementsByTagName("first-name");
			    Element fstNmElmnt = (Element) fstNmElmntLst.item(0);
			    NodeList fstNm = fstNmElmnt.getChildNodes();
			    //System.out.println("First Name : "  + ((Node) fstNm.item(0)).getNodeValue());
			    NodeList lstNmElmntLst = fstElmnt.getElementsByTagName("last-name");
			    Element lstNmElmnt = (Element) lstNmElmntLst.item(0);
			    NodeList lstNm = lstNmElmnt.getChildNodes();
			    //System.out.println("Last Name : " + ((Node) lstNm.item(0)).getNodeValue());
			    
			    NodeList locationLst = fstElmnt.getElementsByTagName("location");
			    NodeList childnode = locationLst.item(0).getChildNodes();
			    //System.out.println("Locatin : "+childnode.item(0).getNodeValue());
		    }
  	    }*/
	}
	public static String convertStreamToString(InputStream is) {
        /*
         * To convert the InputStream to String we use the BufferedReader.readLine()
         * method. We iterate until the BufferedReader return null which means
         * there's no more data to read. Each line will appended to a StringBuilder
         * and returned as String.
         */
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
 
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
 
        return sb.toString();
    }
	
	public static void main(String[] args) throws Exception
	{
		new LinkedIn().getLinkedInFriendsDump("f824160d-da71-4248-ad92-eaa18678c15d,1d226f70-865e-4b9a-b140-edbf954fae0d", 9, "", 2);
	}
}