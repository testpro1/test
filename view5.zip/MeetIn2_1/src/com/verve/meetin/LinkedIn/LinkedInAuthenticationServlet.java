package com.verve.meetin.LinkedIn;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.quartz.SchedulerException;

import com.google.api.services.*;
import com.google.code.linkedinapi.client.LinkedInApiClient;
import com.google.code.linkedinapi.client.LinkedInApiClientFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInAccessToken;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthService;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthServiceFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInRequestToken;
import com.google.code.linkedinapi.schema.Person;
import com.sun.xml.ws.rm.jaxws.runtime.Session;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.Usernetworks;
import com.verve.meetin.network.peoplefinder.ScheduleSocialNetwork;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;

public class LinkedInAuthenticationServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	OAuthConsumer consumer;
	OAuthProvider provider;
	LinkedInRequestToken requestToken;
	LinkedInOAuthService oauthService;
	String authUrl;
	ResourceBundle resource;
	Logger logger = Logger.getLogger(LinkedInAuthenticationServlet.class);
	@Override
	public void init() throws ServletException {
	
		/*resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		//System.out.println("KEY : "+resource.getString("linkedin.consumer_key"));
		//System.out.println("SECRET : "+resource.getString("linkedin.consumer_secret"));
        oauthService = LinkedInOAuthServiceFactory.getInstance().createLinkedInOAuthService(
        		resource.getString("linkedin.consumer_key"),
        		resource.getString("linkedin.consumer_secret"));
        
        requestToken = oauthService.getOAuthRequestToken(resource.getString("linkedin.redirect_uri"));  
        String token = requestToken.getToken();  
        String tokenSecret = requestToken.getTokenSecret();  
        authUrl = requestToken.getAuthorizationUrl();*/
       
	}
	/**
	 * Destruction of the servlet. <br>
	 */
	@Override
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}
	public void getLinkedInCredentials()
    {
    	resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
    	logger.info("key :" +resource.getString("linkedin.consumer_key"));
    	logger.info("SECRET : "+resource.getString("linkedin.consumer_secret"));
		
        oauthService = LinkedInOAuthServiceFactory.getInstance().createLinkedInOAuthService(
        		resource.getString("linkedin.consumer_key"),
        		resource.getString("linkedin.consumer_secret"));
        
        requestToken = oauthService.getOAuthRequestToken(resource.getString("linkedin.redirect_uri"));
        logger.info("Request Token : "+requestToken);
        
        String token = requestToken.getToken();  
        String tokenSecret = requestToken.getTokenSecret();  
        authUrl = requestToken.getAuthorizationUrl();
        
        logger.info("Auth Url : "+authUrl);
    }
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if(request.getParameter("oauth_verifier") == null) {
		
			getLinkedInCredentials();
			logger.info("OAuth Verifier 1:" +request.getParameter("oauth_verifier"));
			response.sendRedirect(authUrl);
		}
		else {
	
			
			logger.info("OAuth Verifier 2:" +request.getParameter("oauth_verifier"));
			LinkedInAccessToken accessToken = oauthService.getOAuthAccessToken(requestToken, request.getParameter("oauth_verifier"));
			logger.info("Access Token : "+accessToken);
			final LinkedInApiClientFactory factory = LinkedInApiClientFactory.newInstance(resource.getString("linkedin.consumer_key"),
					resource.getString("linkedin.consumer_secret"));
			final LinkedInApiClient client = factory.createLinkedInApiClient(accessToken);
			Person profile = client.getProfileForCurrentUser();
			
			HttpSession userSession = request.getSession();
			userSession.setAttribute("access_token", accessToken.getToken()+","+accessToken.getTokenSecret());
			//userSession.setAttribute("network_user", accessToken.getToken()+","+accessToken.getTokenSecret());
			userSession.setAttribute("network_user", profile.getFirstName()+" "+profile.getLastName());	
			
			if(userSession.getAttribute("phoneurl") !=null && userSession.getAttribute("userid") !=null)
			{
				NetworkDAO ntdao = new NetworkDAO();
				int userid = (Integer)userSession.getAttribute("userid");
			    int socialid = ntdao.getSocialNetworkId("LinkedIn");
				Usernetworks onetwork = new Usernetworks(
			    		userid, socialid, "", "", 
			    		userSession.getAttribute("access_token").toString());
			  
				int row = new NetworkDAO().setUserSocialNetworkSite(onetwork);
				
				if(row > 0)
				{
				 		new NetworkDAO().setNetworkUserName(onetwork, userSession.getAttribute("network_user").toString());
				 	
				}
				/**
				 * Reading Facebook, LinkedIn, Gmail etc... friends for loggedin user and storing into table. 
				 */
				try 
				{
					new ScheduleSocialNetwork().startscheduleScoialNetwork(userid, userSession.getId(),socialid);
					
				} catch (SchedulerException e) {
					e.printStackTrace();
				}
				
				userSession.removeAttribute("network_user");
				userSession.removeAttribute("phoneurl");
				userSession.removeAttribute("userid");
				
				response.sendRedirect(request.getContextPath() + "/setupnetworkmobile.jsp?userid=" + userid);
			}
			
		
	        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
			out.println("<HTML>");
			out.println("<HEAD><TITLE>A Servlet</TITLE>");
			out.println("</HEAD>");
			if(request.getAttribute("LinkedIn_setupnetwork") != null)
			{
				out.println("<BODY onload=\"window.opener.addNetwork(); window.close()\">");
				userSession.removeAttribute("LinkedIn_setupnetwork");
			}
			else
			{
				//request.setAttribute("flag","flag");
				out.println("<BODY onload=\"window.opener.addNetwork_wizard(); window.close()\">");
			}
			out.println("</BODY>");
			out.println("</HTML>");
			out.flush();
			out.close();
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	}
}
