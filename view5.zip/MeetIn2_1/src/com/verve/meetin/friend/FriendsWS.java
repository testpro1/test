package com.verve.meetin.friend;

import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FriendsWS implements java.io.Serializable {

	// Fields

	private Integer relationshipId;
	private Integer userId1;
	private Integer userId2;
	private String status;
	private Date requestDate;
	private Date actionDate;
    private String fullname;
    private Integer userid;
    private Integer resultId;
    private Long pendingrequestCount;
    
    
    // Fields for Invite Friends
	private String friendname;
	private String friendemail;
	private String invitemessage;
	private String mailStatus;
	
	// Constructors

	public String getMailStatus() {
		return mailStatus;
	}

	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}

	/** default constructor */
	public FriendsWS() {
	}

	/** full constructor */
	public FriendsWS(Integer userId1, Integer userId2, String status,
			Date requestDate, Date actionDate) {
		this.userId1 = userId1;
		this.userId2 = userId2;
		this.status = status;
		this.requestDate = requestDate;
		this.actionDate = actionDate;
	}

	/** Constructor to add friend request */
	
	public FriendsWS(Integer userId1, Integer userId2, String status,
			Date requestDate) {
		this.userId1 = userId1;
		this.userId2 = userId2;
		this.status = status;
		this.requestDate = requestDate;
	}
	
	// Property accessors

	public Integer getRelationshipId() {
		return this.relationshipId;
	}

	public void setRelationshipId(Integer relationshipId) {
		this.relationshipId = relationshipId;
	}

	public Integer getUserId1() {
		return this.userId1;
	}

	public void setUserId1(Integer userId1) {
		this.userId1 = userId1;
	}

	public Integer getUserId2() {
		return this.userId2;
	}

	public void setUserId2(Integer userId2) {
		this.userId2 = userId2;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getRequestDate() {
		return this.requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public Date getActionDate() {
		return this.actionDate;
	}

	public void setActionDate(Date actionDate) {
		this.actionDate = actionDate;
	}

	public String getFriendname() {
		return friendname;
	}

	public void setFriendname(String friendname) {
		this.friendname = friendname;
	}

	public String getFriendemail() {
		return friendemail;
	}

	public void setFriendemail(String friendemail) {
		this.friendemail = friendemail;
	}

	public String getInvitemessage() {
		return invitemessage;
	}

	public void setInvitemessage(String invitemessage) {
		this.invitemessage = invitemessage;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public Integer getResultId() {
		return resultId;
	}

	public void setResultId(Integer resultId) {
		this.resultId = resultId;
	}

	public Long getPendingrequestCount() {
		return pendingrequestCount;
	}

	public void setPendingrequestCount(Long pendingrequestCount) {
		this.pendingrequestCount = pendingrequestCount;
	}

	
}
