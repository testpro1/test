package com.verve.meetin.friend;

import java.util.Date;

import org.apache.struts.action.ActionForm;
 
/**
 * MiFriends entity. @author MyEclipse Persistence Tools
 */

public class Friends extends ActionForm implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer relationshipId;
	private Integer userId1;
	private Integer userId2;
	private String status;
	private Date requestDate;
	private Date actionDate;

	// Fields for Invite Friends
	
	private String friendname;
	private String friendemail;
	private String invitemessage;
		
	// Constructors

	/** default constructor */
	public Friends() {
	}

	/** full constructor */
	public Friends(Integer userId1, Integer userId2, String status,
			Date requestDate, Date actionDate) {
		this.userId1 = userId1;
		this.userId2 = userId2;
		this.status = status;
		this.requestDate = requestDate;
		this.actionDate = actionDate;
	}

	/** Constructor to add friend request */
	
	public Friends(Integer userId1, Integer userId2, String status,
			Date requestDate) {
		this.userId1 = userId1;
		this.userId2 = userId2;
		this.status = status;
		this.requestDate = requestDate;
	}
	
	// Property accessors

	public Integer getRelationshipId() {
		return this.relationshipId;
	}

	public void setRelationshipId(Integer relationshipId) {
		this.relationshipId = relationshipId;
	}

	public Integer getUserId1() {
		return this.userId1;
	}

	public void setUserId1(Integer userId1) {
		this.userId1 = userId1;
	}

	public Integer getUserId2() {
		return this.userId2;
	}

	public void setUserId2(Integer userId2) {
		this.userId2 = userId2;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getRequestDate() {
		return this.requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public Date getActionDate() {
		return this.actionDate;
	}

	public void setActionDate(Date actionDate) {
		this.actionDate = actionDate;
	}

	public String getFriendname() {
		return friendname;
	}

	public void setFriendname(String friendname) {
		this.friendname = friendname;
	}

	public String getFriendemail() {
		return friendemail;
	}

	public void setFriendemail(String friendemail) {
		this.friendemail = friendemail;
	}

	public String getInvitemessage() {
		return invitemessage;
	}

	public void setInvitemessage(String invitemessage) {
		this.invitemessage = invitemessage;
	}

}