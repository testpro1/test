package com.verve.meetin.friend;

import java.util.Properties;
import java.util.ResourceBundle;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

public class InviteFriends {

	static Logger log = Logger.getLogger(InviteFriends.class);
	ResourceBundle resource;

	// String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

	public void postMail(String recipient, String subject, String message,
			String from) throws MessagingException {

		resource = ResourceBundle
				.getBundle("com/verve/meetin/struts/ApplicationResources");

		log.info("Sending an invitation to join the MeetIn by an email");
		log.info("Email receiver :" + recipient);
		log.info("Email sender :" + resource.getString("mail.id"));

		String SMTP_HOST_NAME = resource.getString("mail.hostname");
		String SMTP_PORT = resource.getString("mail.port");

		boolean debug = false;
		Properties props = new Properties();
		props.put("mail.smtp.host", SMTP_HOST_NAME);
		props.put("mail.smtp.port", SMTP_PORT);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.socketFactory.port", SMTP_PORT);
		// props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
		props.put("mail.smtp.socketFactory.fallback", "false");

		Authenticator auth = new SMTPAuthenticator();
		Session session = Session.getDefaultInstance(props, auth);

		session.setDebug(debug);

		// create a message
		Message msg = new MimeMessage(session);

		// set the from and to address
		InternetAddress addressFrom = new InternetAddress(resource
				.getString("mail.id"));
		
		try
		{
		msg.setFrom(new InternetAddress(addressFrom.toString(),"mymeetin.com"));
		}
		catch (Exception e) {
				//System.out.println("Exception occured"+e);
		}
		InternetAddress addressTo = new InternetAddress(recipient);
		msg.setRecipient(Message.RecipientType.TO, addressTo);

		// Setting the Subject and Content Type
		msg.setSubject(subject);

		// Setting the Email Message and Content Type
		msg.setContent(message, "text/html");

		/**********************************/

		/*
		 * MimeMessage mail = new MimeMessage(session);
		 * mail.setSubject(subject); MimeBodyPart messageBodyPart = new
		 * MimeBodyPart(); messageBodyPart.setContent(message, "text/html");
		 * Multipart multipart = new MimeMultipart();
		 * multipart.addBodyPart(messageBodyPart); messageBodyPart = new
		 * MimeBodyPart(); DataSource source = new FileDataSource(new
		 * File("/home/verve/Desktop/P1000070.JPG"));
		 * messageBodyPart.setDataHandler(new DataHandler(source));
		 * //messageBodyPart.setFileName(fileAttachment.getName());
		 * messageBodyPart.setDisposition(MimeBodyPart.INLINE);
		 * multipart.addBodyPart(messageBodyPart); mail.setContent(multipart);
		 */
		/*******************************************/

		Transport.send(msg);
		log.info("Email has been sent successfully to the receiver :"
				+ recipient);
	}
	public void postMails(String recipient[], String subject, String message,String from) throws MessagingException 
	{
		String getEmail=null;
		StringBuilder builder=new StringBuilder();
		
		for(int i=0;i<recipient.length;i++){
		
			if(recipient[i]!=null){
				getEmail=builder.append(recipient[i]+",").toString();
			}
		}
		
		resource = ResourceBundle
				.getBundle("com/verve/meetin/struts/ApplicationResources");
		
		log.info("Sending an invitation to join the MeetIn by an email");
		log.info("Email receiver :" + recipient);
		log.info("Email sender :" + resource.getString("mail.id"));
		
		String SMTP_HOST_NAME = resource.getString("mail.hostname");
		String SMTP_PORT = resource.getString("mail.port");
		
		boolean debug = false;
		Properties props = new Properties();
		props.put("mail.smtp.host", SMTP_HOST_NAME);
		props.put("mail.smtp.port", SMTP_PORT);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.socketFactory.port", SMTP_PORT);
		// props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
		props.put("mail.smtp.socketFactory.fallback", "false");
		
		Authenticator auth = new SMTPAuthenticator();
		Session session = Session.getDefaultInstance(props, auth);
		
		session.setDebug(debug);
		
		// create a message
		Message msg = new MimeMessage(session);
		
		// set the from and to address
		InternetAddress addressFrom = new InternetAddress(resource.getString("mail.id"));
		msg.setFrom(addressFrom);
		
		try {
		msg.setFrom(new InternetAddress(addressFrom.toString(),"mymeetin.com"));
		
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		//InternetAddress addressTo = new InternetAddress(getEmail);
		InternetAddress[] addressTo = InternetAddress.parse(getEmail,true);
		
		msg.setRecipients(Message.RecipientType.BCC, addressTo);
		//msg.setRecipients(Message.RecipientType.TO, addressTo);
		
		// Setting the Subject and Content Type
		msg.setSubject(subject);
		
		
		
		
		// Setting the Email Message and Content Type
		msg.setContent(message, "text/html");
		
		/**********************************/

/*
 * MimeMessage mail = new MimeMessage(session);
 * mail.setSubject(subject); MimeBodyPart messageBodyPart = new
 * MimeBodyPart(); messageBodyPart.setContent(message, "text/html");
 * Multipart multipart = new MimeMultipart();
 * multipart.addBodyPart(messageBodyPart); messageBodyPart = new
 * MimeBodyPart(); DataSource source = new FileDataSource(new
 * File("/home/verve/Desktop/P1000070.JPG"));
 * messageBodyPart.setDataHandler(new DataHandler(source));
 * //messageBodyPart.setFileName(fileAttachment.getName());
 * messageBodyPart.setDisposition(MimeBodyPart.INLINE);
 * multipart.addBodyPart(messageBodyPart); mail.setContent(multipart);
 */
/*******************************************/

Transport.send(msg);
log.info("Email has been sent successfully to the receiver :"
		+ recipient);
	}

	public class SMTPAuthenticator extends javax.mail.Authenticator {
		@Override
		public PasswordAuthentication getPasswordAuthentication() {
			String SMTP_AUTH_USER = resource.getString("mail.id");
			String SMTP_AUTH_PWD = resource.getString("mail.password");
			String username = SMTP_AUTH_USER;
			String password = SMTP_AUTH_PWD;
			return new PasswordAuthentication(username, password);
		}
	}

}
