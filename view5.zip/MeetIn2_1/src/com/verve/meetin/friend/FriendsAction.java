
package com.verve.meetin.friend;


import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.sun.xml.ws.rm.jaxws.runtime.Session;
import com.verve.meetin.foursquare.foursquareDemo;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;
import com.verve.meetin.user.User;
import com.verve.meetin.user.UserAccountDAO;

public class FriendsAction extends DispatchAction 
{	
	/** This is action to get the user's pending friend request */
	public ActionForward pendingfriendrequest(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		//System.out.println("FriendsAction.java -------------------  PendingFriendRequest method ");
		
		HttpSession sc = request.getSession();
		Integer userid = (Integer)sc.getAttribute("UserID");
		List friend_pending_request = null;
		if(userid !=null && userid.intValue() !=0){
		
		friend_pending_request = new FriendsDAO().getPendingFriendRequest(userid);
		if(friend_pending_request !=null && friend_pending_request.size() > 0){
			request.setAttribute("PendingFriendRequest", friend_pending_request);
		  }
		
		  /** Showing confirmation message of connecting or rejecting of the user on pending friend request page*/
		  if(request.getParameter("rf")!=null && request.getParameter("fr")!=null)
		  {
			  if(request.getParameter("rf").equals("Approve"))
			  {
				  int fid = Integer.parseInt(request.getParameter("fid"));
				  List<String> list = new FriendsDAO().retrieveEmailId(fid);
			  
				  List<String> list1 =  new FriendsDAO().retrieveEmailId(fid);
			       
				     String femailId ="";
				     for(int j=0;j<list1.size();j++)
				     {
				    	 femailId = list1.get(j);
				    	
				     }
				     
				     List<String> list2 =  new FriendsDAO().retrieveName(fid);
				     String friendname1 ="";
				     for(int j=0;j<list2.size();j++)
				     {
				    	 friendname1 = list2.get(j);
				     }
				
				/*
				 * 	Email Message format				     
				 */
				     	

			   //header imaga
			   String path = request.getContextPath();
    	   		String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
	   		///mailer format 
    	   		String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
    	        HttpSession session = request.getSession();
				     
			
    	  htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
    	  "  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'> </td>" +
    	  "  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><p>"+session.getAttribute("name").toString()+" has accepted your friends request in meetIn. </p>" +
    	  "      <p>Login to your account to see more details.</p>      <p>Keep your trips updated so your friends can also get alerts and contact you.</p>" +
    	  "</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p></p></td>" +
    	  "  </tr>  <tr>" +
    	  "    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
    	  "  </tr></table></td>  </tr>";	      
				     
				 
    		String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
    		String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
    		String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
    		String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
    			
    	  
    	 htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
				     
				     
    	 new InviteFriends().postMail(femailId,"meetIn friend request accepted", htmlmessage,"");		     
				     
				
				  List<String> confirmrequest = new ArrayList<String>();
				  /**This line will store the name of friend whose friend request has been accepted */
				  confirmrequest.add(request.getParameter("fr"));
				  /**This line will store the action (Apprve or Reject) that has been taken  */
				  confirmrequest.add(request.getParameter("rf"));
				  request.setAttribute("confirmrequest", confirmrequest);
				  
			  }
		  }
		  return mapping.findForward("viewrequest");
		}
		
	    return mapping.findForward("login");
	 }
	
	/** This is the action which approve the friend request */
	public ActionForward approverequest(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception {
	
		//System.out.println("FriendsAction.java -------------  approveRequest  method");
		
		HttpSession sc = request.getSession();
		Integer userid = (Integer)sc.getAttribute("UserID");
		
		String friendRequestId = request.getParameter("friendrequestId");
		
		int friend_approve_id = 0;
		FriendsDAO friendDAO = new FriendsDAO();
		String requestStatus = request.getParameter("ref");
		
		if(!requestStatus.equals("") && requestStatus.equals("Approve"))
		{
			/** This line will approve the pending friend request */
			friend_approve_id = friendDAO.approveFriendRequest(Integer.parseInt(friendRequestId));
		}
		else if(!requestStatus.equals("") && requestStatus.equals("Reject"))
		{
			/** This line will reject the pending friend request */
			friend_approve_id = friendDAO.rejectFriendRequest(Integer.parseInt(friendRequestId));
		}
		
		if(friend_approve_id > 0){
			
			/**Code to indicate that user has accepted pending friend request from Search Friend page and It has to be redirect at Friend Search 
			 * result page  when he Accept the reques from friend search page.
			 */
			/**User has accepted friend request from Friend Search Page */
			if(request.getParameter("acceptref") !=null && request.getParameter("acceptref").equals("searchfriend"))
			{
				List result = (ArrayList)sc.getAttribute("searchresult");
				
				Integer useridfrom =(Integer)sc.getAttribute("UserID");
				Integer useridto = Integer.parseInt(request.getParameter("useridto"));
				
				//List<String> requeststatusList = new ArrayList<String>();
				List requeststatusList = new ArrayList();
				Friends f = null;
				String friendname ="";
				for(int i=0; i < result.size();i++){
					   User user = new User();
				       user = (User)result.get(i);
				       f = (Friends) new FriendsDAO().checkFriendRequest(useridto,useridfrom);
				       //requeststatusList.add(f); 
				}
				User user=new User();
				Integer userid1 = (Integer)sc.getAttribute("UserID");
				String name =(String) sc.getAttribute("name1");
				String location = (String) sc.getAttribute("location");
				String company = (String) sc.getAttribute("company");
				String keyword=(String) sc.getAttribute("keyword");
				
				
				
				//int pageNumber = Integer.parseInt(request.getParameter("page"));
				String requestStatus1 ="";
				List search_result = null;
				//List<String> requeststatusList = new ArrayList<String>();
				//List requeststatusList = new ArrayList();
				
				List userID2 = new ArrayList();
				//Friends friend = null;
				//search_result = new FriendsDAO().searchMeetInFriends(name, location, company, keyword);
				
				search_result = new FriendsDAO().searchMeetInFriendsOptimized(userid1,name, location, company, keyword);
				
				//System.out.println("after search result");
				if(search_result !=null && search_result.size() > 0)
				{
				    for(int i=0;i < search_result.size();i++) 
				    {
				    	user = (User)search_result.get(i);
				    	//System.out.println(user.getStatus());
				       /*User user = new User();
				       
				       friend = (Friends) new FriendsDAO().checkFriendRequest(userid, user.getUserId());*/
				    	//System.out.println("statussss  "+request.getParameter("status"));
				       requeststatusList.add(user.getStatus()); 
				       userID2.add(user.getUserId2());
				       
				    }
					sc.setAttribute("searchresult", search_result);
				    sc.setAttribute("start", "0");
					if (search_result.size() < 10)
						sc.setAttribute("end", search_result.size());
					else
						sc.setAttribute("end", 10);
				    sc.setAttribute("checkRequestStatus", requeststatusList);
				    sc.setAttribute("userId2",userID2);
					/** Adding current page number into session */
					//sc.setAttribute("pageNumber", pageNumber +1);
				}
				//request.setAttribute("checkRequestStatus", requeststatusList);
				return mapping.findForward("searchresult");
			}
			else
			{
				/**User has acce[ted friend request from Pending Friend Request Page */
				/**Below line code of redirect user to pending friend request when it accept/reject the friend request */
				pendingfriendrequest(mapping, form, request, response);	
			}
			
		}
		
		/** count a pending friend request of a user */
		/** Star code here */
	    Long countPendingRequest = new FriendsDAO().getUserPendingRequestCount(userid);
	    if(countPendingRequest !=null && countPendingRequest.intValue()!=0)
	    {
	    	sc.setAttribute("CountPendingRequest", countPendingRequest);
	    }
	    else
	    {
	    	sc.setAttribute("CountPendingRequest", null);
	    }
	    
		return mapping.findForward("viewrequest");
  }
	
	/**This is the action which is used to invite the friend to join the MeetIn application*/
	public ActionForward invitefriend(ActionMapping mapping,ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		
		//System.out.println("inviteFriend method called ");
		
		HttpSession sc = request.getSession();
		Integer userId = (Integer)sc.getAttribute("UserID");
		User user = new User();
		Friends friend =(Friends)form;
		String path = request.getContextPath();
		
		String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/profileimage/";
		String imageName="";
		String subject ="Invitation to connect on MeetIn";
		String toEmail = friend.getFriendemail();
		
		
		String fromEmail = (String)sc.getAttribute("Email");
		String friendname = friend.getFriendname();
		String invitemessage = friend.getInvitemessage();
	     user =(User)new UserAccountDAO().getUserProfileDetails((Integer)sc.getAttribute("UserID"));
		String meetinLogo =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/images/meetin_icon.png";
		
		String[] result=toEmail.split(",");
		int i=0;
		for(String r:result){
			result[i]=r;
		    i++;
		}
		
		if(userId !=null && userId.intValue() !=0)
		{
			user = (User) new UserAccountDAO().getUserProfileDetails(userId);
			if(user !=null)
			{
				if(user.getImage() !=null && !user.getImage().equals(""))
				{
					imageName = imagePath + user.getUserId()+ "_" +user.getImage();		
					
				}
			}
		
			//header imaga
			String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
			///mailer format 
			String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
			
			String text =request.getParameter("invitemessage");
			//String text="hello dfsgdfgdgdfgdfg fgdf dfgdg dfgdfgdf gdfgdf dfgdfg dgdfgdfgdfg dfgdfgdfgd dfsgdsf gdsfgdfgdfgdfg  dfgd gfdfgdgf dfgdfgd dfgdfg dfgdfg ";
			//htmlmessage = htmlmessage +"<div style='color: #FFFFFF'>" +text + "</div>";
			htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
			text+"</td>" +
			"  </tr> <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
			"  </tr></table></td>  </tr>";	
			//System.out.println(""+invitemessage);
			
			/*
			htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
		 user.getFullname() +	" would like to invite you to use meetIn (www.mymeetin.com) to keep in touch with your friends, family, colleagues while you or they are traveling.</td>" +
			"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
			"<p><br>meetIn connects to some of the most popular social networking sites and gets you updated information even when you are traveling, " +
			"or at home or when your friends are traveling to tell you when you are at the same place and can meet.</p>" +
			"      <p>meetIn is also available now on iPhone and Android, allowing you to search your network on the move. </p>" +
			"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p>Register now and meet me on meetIn.</p></td>" +
			"  </tr>  <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
			"  </tr></table></td>  </tr>";	 */
		
			String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
			String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
			String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
			String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
				
				
			htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

			new InviteFriends().postMails(result, user.getFullname()+" has invited you to use meetIn", htmlmessage, fromEmail);
		
		}
		return mapping.findForward("email");		
	}
	
	/** This is the action for simple friend search */
	public ActionForward simplefriendsearch(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
	 
		HttpSession sc = request.getSession();
		Integer userid = (Integer)sc.getAttribute("UserID");
		User user=new User();
		if(userid !=null && userid.intValue() !=0)
		{
		 
			String friendname = request.getParameter("friendname");
			sc.setAttribute("searchfriendname", friendname);
			String requestStatus ="";
			//int pageNumber = Integer.parseInt(request.getParameter("page"));
			List search_result = null;
			List<String> requeststatusList = new ArrayList<String>();
			
			//search_result = new FriendsDAO().searchMeetInFriends(friendname);
			search_result = new FriendsDAO().searchMeetInFriendsSimple(userid, friendname);
			Friends friend = null;
			List userID2 = new ArrayList();
			if(search_result !=null && search_result.size() > 0)
			{
			    for(int i=0;i < search_result.size();i++)
			    {
			    	user = (User)search_result.get(i);
			    	//System.out.println(user.getStatus());
			       /*User user = new User();
			       
			       friend = (Friends) new FriendsDAO().checkFriendRequest(userid, user.getUserId());*/
			    	//System.out.println("statussss  "+request.getParameter("status"));
			       requeststatusList.add(user.getStatus()); 
			       userID2.add(user.getUserId2());
			    }
				
			    sc.setAttribute("start", "0");
				if (search_result.size() < 10)
					sc.setAttribute("end", search_result.size());
				else
					sc.setAttribute("end", 10);
			    
			    sc.setAttribute("searchresult", search_result);
			    sc.setAttribute("checkRequestStatus", requeststatusList);
			    sc.setAttribute("userId2",userID2);
			    /** Adding current page number into session */
			    //sc.setAttribute("pageNumber", pageNumber +1);
			    /** flag for simple search page */
			    request.setAttribute("simplesearch", "simplesearch");
			    
			}
			else
			{
				sc.setAttribute("searchresult", null);
			}
			return mapping.findForward("searchresult");
		}
		
	   return mapping.findForward("login");
	}
	
	/** This is the action for advance friend search */
	public ActionForward advancefriendsearch(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		User user=new User();
		Friends friends= new Friends();
		HttpSession sc = request.getSession();
		Integer userid = (Integer)sc.getAttribute("UserID");
		
		if(userid !=null && userid.intValue() !=0)
		{
		 
			String name = request.getParameter("name");
			String location = request.getParameter("location");
			String company = request.getParameter("company");
			String keyword = request.getParameter("keyword");
			sc.setAttribute("name1", name);
			sc.setAttribute("location", location);
			sc.setAttribute("company", company);
			sc.setAttribute("keyword", keyword);
			int pageNumber = Integer.parseInt(request.getParameter("page"));
			String requestStatus ="";
			List search_result = null;
			//List<String> requeststatusList = new ArrayList<String>();
			List requeststatusList = new ArrayList();
			
			List userID2 = new ArrayList();
			Friends friend = null;
			//search_result = new FriendsDAO().searchMeetInFriends(name, location, company, keyword);
			search_result = new FriendsDAO().searchMeetInFriendsOptimized(userid,name, location, company, keyword);
			
			if(search_result !=null && search_result.size() > 0)
			{
			    for(int i=0;i < search_result.size();i++) 
			    {
			    	user = (User)search_result.get(i);
			    	//System.out.println(user.getStatus());
			       /*User user = new User();
			       
			       friend = (Friends) new FriendsDAO().checkFriendRequest(userid, user.getUserId());*/
			    	//System.out.println("statussss  "+request.getParameter("status"));
			       requeststatusList.add(user.getStatus()); 
			       userID2.add(user.getUserId2());
			       
			    }
				//System.out.println("******************after checkFriendRequest");
				
			    sc.setAttribute("searchresult", search_result);
			    sc.setAttribute("start", "0");
				if (search_result.size() < 10)
					sc.setAttribute("end", search_result.size());
				else
					sc.setAttribute("end", 10);
			    sc.setAttribute("checkRequestStatus", requeststatusList);
			    sc.setAttribute("userId2",userID2);
				/** Adding current page number into session */
				//sc.setAttribute("pageNumber", pageNumber +1);
			}
			else
			{
				sc.setAttribute("searchresult", null);
			}
			return mapping.findForward("searchresult");
		}
	   return mapping.findForward("login");
	}
	
	
	public ActionForward navigateMyFriendSearchList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		
		HttpSession session = request.getSession();
		ArrayList friends = (ArrayList) session.getAttribute("searchresult");
		String event = (String) request.getParameter("e");
		int start = Integer.parseInt(session.getAttribute("start").toString());
        int end = Integer.parseInt(session.getAttribute("end").toString());
        
		
		if(event !=null && event.equalsIgnoreCase("Last")){
			end = friends.size();
	    	if(friends.size() < 10)
	    		start = 0;
	    	else
	    	{
	    		start = (friends.size() / 10) * 10;
	    		if(start == friends.size())
					start = start - 10;
	    	}	
		}if(event !=null && event.equalsIgnoreCase("First")){
			start = 0;
			end = (friends.size() < 10) ? friends.size(): 10;
        	
		}if(event !=null && event.equalsIgnoreCase("Next")){
			 start = end;
			 				
             if(friends.size() < 10){
                     end = friends.size();
             }else if((end+10) < friends.size()){ 
                     end = end + 10;
             }else if((end+10) > friends.size()){
                     end = end + (friends.size() - end);
             }else if((end+10) >= friends.size()){
                     end = friends.size();
             }
             
		}if(event != null && event.equalsIgnoreCase("Prev")){
			 
			if(start >= 10){
                     start = start - 10;
             }else if(start < 10){
                     start = start - start;
             }
             end = start + 10;
             
         }if(event !=null && event.equalsIgnoreCase("page_combo")){
        	 
        	String[] s = request.getParameter("paging").split("-");
         	start = Integer.parseInt(s[0]);
         	end = Integer.parseInt(s[1]);
         }
			
    	session.setAttribute("end", end);
    	session.setAttribute("start", start);
    	
    	return mapping.findForward("searchresult");
	}

	public ActionForward addasfriend(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception {
		HttpSession sc= request.getSession();
		Integer useridfrom =(Integer)sc.getAttribute("UserID");
		
		Integer useridto = Integer.parseInt(request.getParameter("id"));
		
		if(useridfrom !=null && useridfrom.intValue() != 0){
		Friends friend = new Friends(useridfrom, useridto,"Pending", new Date());
		Friends f =null;
			int friend_request_id = new FriendsDAO().setFriendRequest(friend);
			if(friend_request_id > 0){
				List result = (ArrayList)sc.getAttribute("searchresult");
				//List<String> requeststatusList = new ArrayList<String>();
				List requeststatusList = new ArrayList();
				String requestStatus="";
				String friendname ="";
				String femailId ="";
				User user = new User();
				
				 List<String> list =  new FriendsDAO().retrieveEmailId(useridto);
				 List<String> list1 =  new FriendsDAO().retrieveName(useridto);
				for(int i=0; i < result.size();i++)
				{
					 user = (User)result.get(i);
					 f = (Friends) new FriendsDAO().checkFriendRequest(useridfrom, user.getUserId());
				     for(int j=0;j<list.size();j++)
				     {
				    	 femailId = list.get(j);
				    	 //System.out.println("email id "+ femailId);
				     }
				     String friendname1 ="";
				     for(int j=0;j<list1.size();j++)
				     {
				    	 friendname1 = list1.get(j);
				     }
				     //requeststatusList.add(f); 
				}	
				Integer userid = (Integer)sc.getAttribute("UserID");
				String name =(String) sc.getAttribute("name1");
				String location = (String) sc.getAttribute("location");
				String company = (String) sc.getAttribute("company");
				String keyword=(String) sc.getAttribute("keyword");
				
				//int pageNumber = Integer.parseInt(request.getParameter("page"));
				String requestStatus1 ="";
				List search_result = null;
				//List<String> requeststatusList = new ArrayList<String>();
				//List requeststatusList = new ArrayList();
				
				List userID2 = new ArrayList();
				//Friends friend = null;
				//search_result = new FriendsDAO().searchMeetInFriends(name, location, company, keyword);
				
				
				if(request.getParameter("ref").toString().equalsIgnoreCase("simplesearch"))
				{
					List list2 = new FriendsDAO().retrieveName(useridto);
					System.out.println(list2.get(0).toString()+"***************  in simple search  ********************");
					search_result = new FriendsDAO().searchMeetInFriendsSimple(userid, sc.getAttribute("searchfriendname").toString());
				}
				else
				{
					search_result = new FriendsDAO().searchMeetInFriendsOptimized(userid,name, location, company, keyword);
				}
			
				if(search_result !=null && search_result.size() > 0)
				{
				    for(int i=0;i < search_result.size();i++) 
				    {
				    	user = (User)search_result.get(i);
				    	//System.out.println(user.getStatus());
				       /*User user = new User();
				       
				       friend = (Friends) new FriendsDAO().checkFriendRequest(userid, user.getUserId());*/
				    	//System.out.println("statussss  "+request.getParameter("status"));
				       requeststatusList.add(user.getStatus()); 
				       userID2.add(user.getUserId2());
				       
				    }
					//System.out.println("******************after checkFriendRequest");
					
				    sc.setAttribute("searchresult", search_result);
				  
				  sc.setAttribute("start",Integer.parseInt(sc.getAttribute("start").toString()));
				  sc.setAttribute("end",Integer.parseInt(sc.getAttribute("end").toString()));
				 
				//    sc.setAttribute("start", "0");
				//	if (search_result.size() < 10)
				//		sc.setAttribute("end", search_result.size());
				//	else
				//		sc.setAttribute("end", 10);
				    sc.setAttribute("checkRequestStatus", requeststatusList);
				    sc.setAttribute("userId2",userID2);
					/** Adding current page number into session */
					//sc.setAttribute("pageNumber", pageNumber +1);
				}
				 HttpSession session=request.getSession();
				 //session.setAttribute("checkRequestStatus", requeststatusList);*/

				//header image
				String path = request.getContextPath();
				String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
				///mailer format 
				String htmlmessage = new Mailer_Header().getMailerHeader(bannar);
				
				
				
				htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
				
				"    <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'><p> "+session.getAttribute("name").toString()+" has sent you friends request in meetIn.</p>" +
				"      <p>Login to your account to see their profile and take further action on this request.</p>      <p>Keep your trips updated so your friends can also get alerts and contact you.</p>" +
				"</td>  </tr>   " +
				"  </table> </td>  </tr>";	 	     
				
				//code for sending mail 
				//new InviteFriends().postMail(femailId,"meetIn Friend Request","meetIn Friend request send ", session.getAttribute("name").toString());
				//new PeopleFinder().sendMeetingInvitation(femailId, "meetIn friend add request,htmlmessage", "", session.getAttribute("name").toString());   
					
				
				String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
				String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
				String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
				String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
				
				htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);
				new InviteFriends().postMail(femailId,"meetIn friend add request", htmlmessage,"");					
				
			   //requestStatus = new FriendsDAO().checkFriendRequest(useridfrom, user.getUserId());
				// requeststatusList.add(requestStatus);
			}
			// If user had reached at his friend request limitation
			else
			{
				List result = (ArrayList)sc.getAttribute("searchresult");
				//List<String> requeststatusList = new ArrayList<String>();
				List requeststatusList = new ArrayList();
				String requestStatus="";
				String friendname ="";
				for(int i=0; i < result.size();i++){
					   User user = new User();
				       user = (User)result.get(i);
				       f = (Friends) new FriendsDAO().checkFriendRequest(useridfrom, user.getUserId());
				       requeststatusList.add(f); 
				       //requestStatus = new FriendsDAO().checkFriendRequest(useridfrom, user.getUserId());
				      // requeststatusList.add(requestStatus);
				}
				
				request.setAttribute("Requestlimitmsg", friend_request_id);
				request.setAttribute("checkRequestStatus", requeststatusList);
			}
			
			return mapping.findForward("searchresult");
			
		}
		
	  return mapping.findForward("login");
	}
	
	
	/** This is the action to fetch the user's social network setup list */
	public ActionForward myfriends(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		//System.out.println("FriendsAction.java ************   myfriends method called --  ");
		
		HttpSession sc = request.getSession();
		Integer userid = (Integer)sc.getAttribute("UserID");
		
		if(userid !=null && userid.intValue() !=0)
		{
			/** The below code is to show the list of social network site that user's has setup */
			List socialnetworklist = null;
			socialnetworklist = new NetworkDAO().getUserSocialNetworkSitesByUserId(userid);
			
			if(socialnetworklist !=null && socialnetworklist.size() > 0)
			{
				request.setAttribute("socialnetworklist", socialnetworklist);
			}
			else
			{
				request.setAttribute("socialnetworklist", null);
			}
			
			/**The below code is to show MeetIn Friend as default when user click on My Friend menu first time */
			/** Start code here */
			
			List meetinfriendList = null; 
			Hashtable<String, List<String>> friendList =new Hashtable<String, List<String>>();
			meetinfriendList = new ArrayList();
			meetinfriendList = new FriendsDAO().viewMeetInFriends(userid);
			String profile_path = "profile_page.jsp";
	       if(meetinfriendList !=null && meetinfriendList.size() >0)
	       {
	    	   for(int i=0;i < meetinfriendList.size();i++)
	    	   {
	    		   Object[] object = (Object[])meetinfriendList.get(i);
	    		   List<String> finalResultList = new ArrayList<String>();
	    		  
	    		   finalResultList.add((String)object[1]);
	    		   finalResultList.add((String)object[2]);
	    		   finalResultList.add(profile_path+"?id=" +(Integer)object[0]);
	    		 //  finalResultList.add("images/meetin_icon.png");
	    		   friendList.put(String.valueOf((Integer)object[0]), finalResultList);
	    	   }
	    	   
	    	   request.setAttribute("friendlist", friendList);
	       }
	       else
	       {
	    	   request.setAttribute("friendlist", null);
	       }
	       
			/** End code here */
			
			
			/** count a pending friend request of a user */
			/** Star code here */
		    Long countPendingRequest = new FriendsDAO().getUserPendingRequestCount(userid);
		    if(countPendingRequest !=null && countPendingRequest.intValue()!=0)
		    {
		    	sc.setAttribute("CountPendingRequest", countPendingRequest);
		    }
		    else
		    {
		    	sc.setAttribute("CountPendingRequest", null);
		    }
		    /** End code here */
		       
			return mapping.findForward("socialnetworklist"); 
		}
		
	  return mapping.findForward("login");
	}
	/** This action to view the Friends */
	public ActionForward viewfriends(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		HttpSession sc = request.getSession();
		Integer userid = (Integer)sc.getAttribute("UserID");
		List meetinfriendList = null;
		List socialfriendList = null;
		List facebookcheckinList =null;
		Hashtable<String, List<String>> friendList =new Hashtable<String, List<String>>();
		NetworkDAO oNetworkDAO = new NetworkDAO();
		
		if(userid !=null && userid.intValue() !=0)
		{
			int socialId = Integer.parseInt(request.getParameter("sid"));
			String profile_path = "profile_page.jsp";
			
			//System.out.println("Social ID ::" +socialId);
			
			switch (socialId) {
			case NetworkConstraint.SOCIAL_NETWORK_MEETIN:
				   meetinfriendList = new FriendsDAO().viewMeetInFriends(userid);
			       if(meetinfriendList !=null && meetinfriendList.size() >0)
			       {
			    	   for(int i=0;i < meetinfriendList.size();i++)
			    	   {
			    		   Object[] object = (Object[])meetinfriendList.get(i);
			    		   List<String> finalResultList = new ArrayList<String>();
			    		   finalResultList.add((String)object[1]);
			    		   finalResultList.add((String)object[2]);
			    		   finalResultList.add(profile_path+"?id=" +(Integer)object[0]);
			    		   finalResultList.add("images/meetin_icon.png");
			    		   
			    		   
			    		   if(object[3] != null && !((String) object[3]).equals(""))
			    		   {
			    			   finalResultList.add("profileimage/"+(String)object[3]);   
			    		   }
			    		   else
			    		   {
			    			   if(((String)object[4]).equalsIgnoreCase("Male"))
			    			   {
			    				   finalResultList.add("images/male.png");   
			    			   }
			    			   else
			    			   {
			    				   finalResultList.add("images/female.png");
			    			   }
			    		   }
			    		   
			    		  
			    			  
			    		   friendList.put(String.valueOf((Integer)object[0]), finalResultList);
			    	   }
			       }
			       break;
			case NetworkConstraint.SOCIAL_NETWORK_ALL:
				int count= 1;
				FriendsDAO oFriendsDAO = new FriendsDAO();
				socialfriendList = oFriendsDAO.getAllSocialNetworkFriends(userid);
				
				System.out.println(socialfriendList.size());
				meetinfriendList = oFriendsDAO.viewMeetInFriends(userid);
		
				System.out.println(""+meetinfriendList.size());
			
				if(meetinfriendList !=null && meetinfriendList.size() >0)
			       {
			    	   for(int i=0;i < meetinfriendList.size();i++)
			    	   {
			    		   Object[] object = (Object[])meetinfriendList.get(i);
			    		   List<String> finalResultList = new ArrayList<String>();
			    		   finalResultList.add((String)object[1]);
			    		   finalResultList.add((String)object[2]);
			    		   finalResultList.add(profile_path+"?id=" +(Integer)object[0]);
			    		   finalResultList.add("images/meetin_icon.png");
			    		   if(object[3] != null && !((String) object[3]).equals(""))
			    		   {
			    			   finalResultList.add("profileimage/"+(String)object[3]);
			    		   }
			    		   else
			    		   {
			    			   if(((String)object[4]).equalsIgnoreCase("Male"))
			    			   {
			    				   finalResultList.add("images/male.png");   
			    			   }
			    			   else
			    			   {
			    				   finalResultList.add("images/female.png");
			    			   }
			    		   }
			    		   
			    		   friendList.put(""+(count++) +"", finalResultList);
			    	   }
			       }
				//System.out.println(friendList.toString());
				//System.out.println("size " +friendList.size());
				if(socialfriendList.size() > 0 && socialfriendList != null)
				{
					//System.out.println("HELLLL:::"+ socialfriendList.toString());
					for(int i=0;i<socialfriendList.size();i++)
					{
						Object[] object = (Object[])socialfriendList.get(i);
						List<String> finalResult = new ArrayList<String>();
						finalResult.add((String)object[1]);
						String city = ((String) object[2] !=null ? (String) object[2] : "");
						finalResult.add(city);
						finalResult.add((String)object[3]);
						finalResult.add((String)object[5]);
						finalResult.add((String)object[6]);
						//System.out.println((Integer)object[4]);
						friendList.put(""+(count++) +"", finalResult);
					}
				}
				
				socialfriendList = new foursquareDemo().getFourSquareCheckInFriends(userid, NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE_CHECKIN);
				
				System.out.println("foursquare checkin size " +socialfriendList.size());
				for(int i=0;i<socialfriendList.size();i++)
				{
					Object[] object = (Object[])socialfriendList.get(i);
					List<String> finalResult = new ArrayList<String>();
					finalResult.add((String)object[1]);
					String city = (object[2] !=null ? (String) object[2] : "");
					finalResult.add(city);
					finalResult.add((String)object[3]);
					finalResult.add((String)object[5]);
					finalResult.add((String)object[6]);
					friendList.put(""+(count++) +"", finalResult);
				}
				
					System.out.println("final friends list szie "+friendList.size());
				/*
				 * facebookcheckinList = oFriendsDAO.getFacebookCheckinFriendList(userid);
				 * if(facebookcheckinList.size() > 0 && facebookcheckinList != null)
				{
					//System.out.println("HELLLL:::"+ socialfriendList.toString());
					for(int i=0;i<facebookcheckinList.size();i++)
					{
						Object[] object = (Object[])facebookcheckinList.get(i);
						List<String> finalResult = new ArrayList<String>();
						finalResult.add((String)object[1]);
						String city = ((String) object[2] !=null ? (String) object[2] : "");
						finalResult.add(city);
						finalResult.add((String)object[3]);
						finalResult.add((String)object[5]);
						finalResult.add((String)object[6]);
						System.out.println((Integer)object[4]);
						friendList.put(String.valueOf((Integer)object[4]), finalResult);
					}
				}*/
				break;
			default:
				System.out.println("View Friends");
				System.out.println(userid);
				System.out.println(socialId);
				
				// 8 id given to foursquare chec
				if(socialId ==NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE_CHECKIN)
				{
					socialfriendList = new foursquareDemo().getFourSquareCheckInFriends(userid, NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE_CHECKIN);
					System.out.println("social friend list " + socialfriendList);
				}else
				{
					socialfriendList = new FriendsDAO().getSocialNetworkFriends(userid, socialId);
					System.out.println("social friend list " + socialfriendList);
				}
				
				System.out.println(socialfriendList.size());
				
				for(int i=0;i<socialfriendList.size();i++)
				{
					Object[] object = (Object[])socialfriendList.get(i);
					List<String> finalResult = new ArrayList<String>();
					finalResult.add((String)object[1]);
					String city = (object[2] !=null ? (String) object[2] : "");
					finalResult.add(city);
					finalResult.add((String)object[3]);
					finalResult.add((String)object[5]);
					finalResult.add((String)object[6]);
					friendList.put(String.valueOf((Integer)object[4]), finalResult);
				}
				break;
			}
			
			ArrayList f = new ArrayList(friendList.values()); 
	    	new UserAccountDAO().sortList(f);
	    	sc.setAttribute("friendlist", f);
	    	sc.setAttribute("start", "0");
		    if(friendList.size() < 10)
	              sc.setAttribute("end", f.size());
		    else
	              sc.setAttribute("end", 10);
		    
		    sc.setAttribute("socialnetworkname", request.getParameter("ref")); 
		    return mapping.findForward("myfriendlist1");
		       
		}
		
		return mapping.findForward("login");
	}
	
	public ActionForward navigateMyFriendList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		
		HttpSession session = request.getSession();
		ArrayList friends = (ArrayList) session.getAttribute("friendlist");
		String event = (String) request.getParameter("e");
		int start = Integer.parseInt(session.getAttribute("start").toString());
        int end = Integer.parseInt(session.getAttribute("end").toString());
        
		
		if(event !=null && event.equalsIgnoreCase("Last")){
			end = friends.size();
	    	if(friends.size() < 10)
	    		start = 0;
	    	else
	    	{
	    		start = (friends.size() / 10) * 10;
	    		if(start == friends.size())
					start = start - 10;
	    	}	
		}if(event !=null && event.equalsIgnoreCase("First")){
			start = 0;
			end = (friends.size() < 10) ? friends.size(): 10;
        	
		}if(event !=null && event.equalsIgnoreCase("Next")){
			 start = end;
			 				
             if(friends.size() < 10){
                     end = friends.size();
             }else if((end+10) < friends.size()){ 
                     end = end + 10;
             }else if((end+10) > friends.size()){
                     end = end + (friends.size() - end);
             }else if((end+10) >= friends.size()){
                     end = friends.size();
             }
             
		}if(event != null && event.equalsIgnoreCase("Prev")){
			 
			if(start >= 10){
                     start = start - 10;
             }else if(start < 10){
                     start = start - start;
             }
             end = start + 10;
             
         }if(event !=null && event.equalsIgnoreCase("page_combo")){
        	 
        	String[] s = request.getParameter("paging").split("-");
         	start = Integer.parseInt(s[0]);
         	end = Integer.parseInt(s[1]);
         }
			
    	session.setAttribute("end", end);
    	session.setAttribute("start", start);
    	
    	return mapping.findForward("myfriendlist1");
	}
	
		
	
}