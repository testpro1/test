package com.verve.meetin.friend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.struts.upload.FormFile;
import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.LinkedIn.LinkedIn;
import com.verve.meetin.facebook.facebookGraphAPI;
import com.verve.meetin.gmail.GmailAPI;
import com.verve.meetin.gmail.GmailFriends;
import com.verve.meetin.googleplus.GooglePlusAPI;
import com.verve.meetin.googleplus.GooglePlusFriends;
import com.verve.meetin.myspace.myspace;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.twitter.twitter;
import com.verve.meetin.user.User;

public class FriendsDAO
{
    static Logger log = Logger.getLogger(FriendsDAO.class);
    ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
    String DriverClass = resource.getString("jdbc.driverClass");
    String connectionValue=resource.getString("jdbc.connectionValue");
    String username=resource.getString("jdbc.database.username");
    String password=resource.getString("jdbc.database.password");
  public int setFriendRequest(Friends friends)
    {
            log.info("Inside user friends details....");
            int friend_request_id = 0;
            Long maxAttempt = null;
            String maxAttemptQuery = "select count(*) from FriendsDummy where userId1=? and userId2=?";
                    
            try
            {
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(maxAttemptQuery);
                query.setParameter(0, friends.getUserId1());
                query.setParameter(1, friends.getUserId2());
                maxAttempt = (Long)query.uniqueResult();
                
                if(maxAttempt !=null && maxAttempt.intValue() >= 3)
                {
                    log.info("Friend request limitation for current user has reached at it's level");      
                }
                else
                {
                    friend_request_id=(Integer)session.save(friends);
                    log.info("Friend request has been submitted successfully");    
                }
                
                session.getTransaction().commit();        
            }
            catch(Exception ex)
            {
                log.error("There is a problem in friend request process");
                log.debug(ex);
                ex.printStackTrace();
            }
            
        return friend_request_id;
    }
  public List getPendingFriendRequest(int userid)
  {
        log.info("Inside user pending friend request");
        List resultList =null;
        String status ="Pending";
        String queryString ="select friends.relationshipId, user.fullname, user.userId from User as user, Friends as friends where user.userId=friends.userId1 and friends.userId2 =? and friends.status=?";
        try
        {
            
            log.info("Trying to fetch user's pending friend request.......");
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
            session.beginTransaction();
            Query query = session.createQuery(queryString);
            query.setParameter(0, userid);
            query.setParameter(1, status);
            resultList = query.list();
            session.getTransaction().commit();
            
            log.info("User's pending friend request returned from DataSource,Size:" +resultList.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in getting pending friend request");
            log.debug(ex);
            ex.printStackTrace();
        }
        
       return resultList;  
  }

 
 
  //method to return friend email id
  public List<String> retrieveEmailId(int fid)
  {
       log.info("Inside retrieveEmailId");
       
       List<String> list = null;
       String queryString ="select email from User where userId = " + fid;
        try
        {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
            session.beginTransaction();
            Query query = session.createQuery(queryString);
            list = query.list();
            session.getTransaction().commit();
            
            return list;
            
        }
        catch(Exception ex)
        {
            log.error("There is a problem in getting pending friend request count");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return null;
            
  }
  public List<String> retrieveName(int fid)
  {
      
        log.info("Inside retrieveName");
        List<String> list = null;
        String queryString ="select fullname from User where userId = " + fid;
        try
        {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
            session.beginTransaction();
            Query query = session.createQuery(queryString);
            list = query.list();
            session.getTransaction().commit();
            
            return list;
            
        }
        catch(Exception ex)
        {
            log.error("There is a problem in getting pending friend request count");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return null;
            
  }
 
 
   public Long getUserPendingRequestCount(int userid)
   {
       
       log.info("Inside user pending request count");
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
           Date date = new Date();
        //System.out.println(" " + dateFormat.format(date));
        
        Long countRequest = null;
        String status ="Pending";
        String queryString ="select count(*) from Friends as friends where friends.userId2 =? and friends.status=?";
        
        try
        {
            
            log.info("Trying to count user's pending friend request.......");
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
            session.beginTransaction();
            Query query = session.createQuery(queryString);
            query.setParameter(0, userid);
            query.setParameter(1, status);
           // System.out.println(" before query" + dateFormat.format(date));
            countRequest = (Long)query.uniqueResult();
           // System.out.println(" after query" + dateFormat.format(date));
            session.getTransaction().commit();
            
            log.info("User's pending friend request count returned from DataSource,Size:" +countRequest.intValue());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in getting pending friend request count");
            log.debug(ex);
            ex.printStackTrace();
        }
        
       return countRequest;
       
   }
   //Added by Rupal Kathiriya to get userid2 from friends to set email in setfriendrequest web service dated on 31 dec 2012
   public List getFriendsIDs(int requestId)
   {
      
        log.info("Inside retrieveFriendIds");
        List<String> list = null;
        String queryString ="select userId2 from Friends where relationshipId = " + requestId;
        try
        {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
            session.beginTransaction();
            Query query = session.createQuery(queryString);
            list = query.list();
            session.getTransaction().commit();
            
            return list;
            
        }
        catch(Exception ex)
        {
            log.error("There is a problem in getting pending friend request count");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return null;
       
       
   }
   //Added by rupal Kathiriya to get userid1 from friends to set username in approverequest web service dated on 31 dec 2012
   public List getUserIds(int requestId)
   {
              
       log.info("Inside retrieveUserId");
       List<String> list = null;
        
        String queryString ="select userId1 from Friends where relationshipId = " + requestId;
        try
        {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
            session.beginTransaction();
            Query query = session.createQuery(queryString);
            list = query.list();
            session.getTransaction().commit();
            
            return list;
            
        }
        catch(Exception ex)
        {
            log.error("There is a problem in getting pending friend request count");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return null;
       
       
   }
   /** This is the method that approve the user's pending friend request */
  public int approveFriendRequest(int friend_reuest_id)
  {
      log.info("Inside approve friend request...");
   
     String requestStatus ="Approve";
     String queryString = "update Friends set status=?,actionDate=? where relationshipId =?";
     int i = 0;
     try{
             log.info("User's friend request is getting approved....");
             Session session = HibernateUtil.getSessionFactory().getCurrentSession();
             Transaction tx = null;
            tx = session.beginTransaction();
            Query query = session.createQuery(queryString);
            
            query.setParameter(0, requestStatus);
            query.setParameter(1, new Date());
            query.setParameter(2, friend_reuest_id);
            i = query.executeUpdate();
            tx.commit();
            
            log.info("User's friend request has been approved successfully");
            
        }
        catch(Exception ex)
        {
            log.error("There is a problem approving friend request");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        
     return i;
      
   }
  /** This is the method that reject the user's pending friend request and add the entry into dummy table */
  public int rejectFriendRequest(int friend_request_id)
  {
      
      log.info("Inside reject friend request...");
      String queryString = "from Friends where relationshipId =?";
      String deleteQuery ="delete from Friends where relationshipId =?";
      int dummyResult =0;
      int i = 0;
         try
             {
                 log.info("Trying to fetch friend request details.....");
                 Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryString);        
                query.setParameter(0, friend_request_id);
                Friends friend = new Friends();
                
                friend =(Friends)query.uniqueResult();
                session.getTransaction().commit();
                
                log.info("Friend Request details have been fetched successfully");
                
                if(friend !=null)
                {
                    FriendsDummy frienddummy = new FriendsDummy(friend.getUserId1(), friend.getUserId2(), friend.getStatus(), friend.getRequestDate(), new Date());
                    // These lines of code will saved the friend request in dummy table
                    
                     log.info("Trying to save friend request entry in dummy table.....");
                    
                     session = HibernateUtil.getSessionFactory().getCurrentSession();
                     Transaction tx = null;
                     tx = session.beginTransaction();
                     dummyResult=(Integer)session.save(frienddummy);
                       tx.commit();

                    log.info("Friend request has been saved in dummy table");
            
                    // These lines of code will delete the friend request entry from original table
                    log.info("Trying to delete the friend request entry from original table...");
                                        
                    session = HibernateUtil.getSessionFactory().getCurrentSession();
                    Transaction t = null;
                    t = session.beginTransaction();
                    
                    Query q = session.createQuery(deleteQuery);
                    q.setParameter(0, friend_request_id);
                    i = q.executeUpdate();
                    t.commit();
                    
                    log.info("Friend request entry has been deleted from original table");
                    
                }
                            
            }
            catch(Exception ex)
            {
                log.error("There is a problem approving friend request");
                log.debug(ex);
                ex.printStackTrace();
            }
                        
         return i;
  }
 
  /**This method will return the total search results based on  only Friend's name parameter */
  private Long getTotalFriends(String queryName,String friendname)
  {
          
        Long resultCount = null;
        try
        {
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryName);
                query.setParameter(0, friendname);
                resultCount =(Long)query.uniqueResult();
                session.getTransaction().commit();
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
        return resultCount;
  }
 
  /**This method will search friends and return the list of friends based on only Friend's Name parameter */
  public List searchMeetInFriends(String friendname,int pageNumber)
  {
      
          log.info("Inside MeetIn Friend Search...");
        List resultList =null;
        List<User> finalList =null;
        int pageSize= 10;
        String queryString ="from User as user where user.fullname like concat(?,'%') order by user.fullname";
        String countQuery ="select count(*) from User as user where user.fullname like concat(?,'%')";
        try
        {
               if(!friendname.trim().equals(""))
               {
                Long totalResult = getTotalFriends(countQuery,friendname);
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                
                log.info("Searching for meetin friends.......");
                Query query = session.createQuery(queryString);
                query = query.setFirstResult(0);
                query.setMaxResults(pageSize * pageNumber);
                query.setString(0, friendname);
                
                resultList = query.list();
                session.getTransaction().commit();
                
                finalList = new ArrayList<User>();
                for(int i=0;i < resultList.size();i++)
                {
                    User user = new User();
                    user =(User)resultList.get(i);
                    User u = new User();
                    u.setFullname(user.getFullname());
                    u.setLocCity(user.getLocCity());
                    u.setUserId(user.getUserId());
                    u.setImage(user.getImage());
                    u.setResultcount(totalResult);
                    u.setGender(user.getGender());
                    finalList.add(u);
                }
                
                log.info("Total Results returned from DataSource, Size: " + totalResult);
                log.info("Display search results size:"  + resultList.size() + " and Page number:"  + pageNumber);
               }
               else
               {
                   log.info("There are no friend's search results found due to empty search query");
               }
                              
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
        return finalList;
  }
 
 
  /**This method will search friends and return the list of friends based on only Friend's Name parameter */
  public List searchMeetInFriends(String friendname)
  {
      
          log.info("Inside MeetIn Friend Search...");
        List resultList =null;
        List<User> finalList =null;
        int pageSize= 10;
        String queryString ="from User as user where user.fullname like concat(?,'%') order by user.fullname";
        try
        {
               if(!friendname.trim().equals(""))
               {
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                
                log.info("Searching for meetin friends.......");
                Query query = session.createQuery(queryString);
                query = query.setFirstResult(0);
                
                query.setString(0, friendname);
                
                resultList = query.list();
                session.getTransaction().commit();
                
                log.info("Display search results size:"  + resultList.size());
               }
               else
               {
                   log.info("There are no friend's search results found due to empty search query");
               }
                              
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
        return resultList;
  }
  public List getStatus(int userId) throws ClassNotFoundException, SQLException{
      log.info("Inside MeetIn Friend Search...");
           List<User> resultListrow =new ArrayList<User>();
          int pageSize =10;
          Connection con=null;    
          Class.forName(DriverClass.trim());
          con = DriverManager.getConnection(connectionValue.trim(), username.trim(), password.trim());
          SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
          log.info("Inside MeetIn Friend Search...");
        
        List resultList =new ArrayList();
            
        
        List<User> finalList =null;
        try
        {
           {
            String queryString="SELECT u.*,f.status,f.relationship_id,f.user_Id2 FROM mi_users AS u LEFT JOIN mi_friends AS f ON (u.user_id = f.user_id1 AND  f.user_id2 = '"+userId+"') OR " +
                "(u.user_id = f.user_id2 AND  f.user_id1 ='"+userId+"')";
            PreparedStatement prest = con.prepareStatement(queryString);
            ResultSet set=prest.executeQuery();
            //ResultSetMetaData rsMetaData = set.getMetaData();
            while(set.next()){
                
                User user = new User();
                user.setUserId(set.getInt(1));
                user.setFullname(set.getString(2));
                user.setEmail(set.getString(3));
                user.setImage(set.getString(7));
                user.setAboutMe(set.getString(8));
                user.setCompany(set.getString(9));
                user.setJobTitle(set.getString(11));
                user.setIndustry(set.getString(13));
                user.setDegreeCollege(set.getString(14));
                user.setLocCountry(set.getString(16));
                user.setLocState(set.getString(17));
                user.setLocStreet(set.getString(18));
                user.setLocCity(set.getString(19));
                user.setLocPin(set.getString(20));
                user.setLocLat(set.getString(21));
                user.setLocLang(set.getString(22));
                user.setOtherSpecify(set.getString(23));
                user.setLastLogin(set.getDate(24));
                user.setGender(set.getString(26));
                user.setResultcount(set.getLong(28));
                user.setGoogleMarkerIcon(set.getString(29));
                user.setStatus(set.getString(31));
                user.setRelationshipId(set.getString(32));
                user.setUserId2(set.getString(33));
                resultListrow.add(user);
            }
            log.info("Display search results size:"  + resultListrow.size() );
        }
        }catch(Exception e){
            e.printStackTrace();
        }
      return resultListrow;
  }
  public List searchMeetInFriendsSimple(int userId,String friendname) throws ClassNotFoundException, SQLException
  {
      
          log.info("Inside MeetIn Friend Search...");
           List<User> resultListrow =new ArrayList<User>();
          int pageSize =10;
          Connection con=null;    
          Class.forName(DriverClass.trim());
          con = DriverManager.getConnection(connectionValue.trim(), username.trim(), password.trim());
          SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
          log.info("Inside MeetIn Friend Search...");
        
        List resultList =new ArrayList();
            
        
        List<User> finalList =null;
        try
        {
        if(!friendname.trim().equals(""))
           {
            String queryString="SELECT u.*,f.status,f.relationship_id,f.user_Id2 FROM mi_users AS u LEFT JOIN mi_friends AS f ON (u.user_id = f.user_id1 AND  f.user_id2 = '"+userId+"') OR " +
                "(u.user_id = f.user_id2 AND  f.user_id1 ='"+userId+"') WHERE u.fullname LIKE CONCAT('"+friendname+"','%') ORDER BY u.fullname";
        //String queryString ="from User as user where user.fullname like concat(?,'%') order by user.fullname";
            PreparedStatement prest = con.prepareStatement(queryString);
            ResultSet set=prest.executeQuery();
            //ResultSetMetaData rsMetaData = set.getMetaData();
            while(set.next()){
                
                User user = new User();
                 
                 
                user.setUserId(set.getInt(1));
                user.setFullname(set.getString(2));
                user.setEmail(set.getString(3));
                user.setImage(set.getString(7));
                user.setAboutMe(set.getString(8));
                user.setCompany(set.getString(9));
                user.setJobTitle(set.getString(11));
                user.setIndustry(set.getString(13));
                user.setDegreeCollege(set.getString(14));
                user.setLocCountry(set.getString(16));
                user.setLocState(set.getString(17));
                user.setLocStreet(set.getString(18));
                user.setLocCity(set.getString(19));
                user.setLocPin(set.getString(20));
                user.setLocLat(set.getString(21));
                user.setLocLang(set.getString(22));
                user.setOtherSpecify(set.getString(23));
                user.setLastLogin(set.getDate(24));
                user.setGender(set.getString(26));
                user.setResultcount(set.getLong(28));
                user.setGoogleMarkerIcon(set.getString(29));
                user.setStatus(set.getString(31));
                user.setRelationshipId(set.getString(32));
                user.setUserId2(set.getString(33));

                resultListrow.add(user);                
                
            }
            log.info("Display search results size:"  + resultListrow.size() );
      }else{
          log.info("There are no friend's search results found due to empty search query");
      }
        
              
              
                              
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
        return resultListrow;
  }
 
  /**This method will return the total search results based on Friend's name, location, company and keyword parameters */
  private Long getTotalFriends(String queryName,Hashtable hashtable)
  {
        Long resultCount = null;
        try
        {
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryName);
                for(int j=0; j<hashtable.size();j++)
                {
                    query.setParameter(j, hashtable.get(j));
                }
            
                resultCount =(Long)query.uniqueResult();
                session.getTransaction().commit();
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
        return resultCount;
  }
 
  /**This method will search friends and return the list of friends based on Friend's Name,Location,Company and Keyword parameter */
  public List searchMeetInFriends(String name, String location, String company, String keyword, int pageNumber)
  {
       
          log.info("Inside MeetIn Friend Search...");
          
        List resultList =null;
        List finalList =null;
        int pageSize =10;
        String queryString ="from User as user where";
        String countQuery = "select count(*) from User as user where";
        int i=0;
        Hashtable queryParam = new Hashtable();
        try
        {
            if(!name.trim().equals("") || !location.trim().equals("") || !company.trim().equals("") || !keyword.trim().equals(""))
            {
                log.info("Searching for meetin friends.......");
                if(!name.trim().equals(""))
                    {
                        queryString +=" user.fullname like concat(?,'%')";
                        countQuery+=" user.fullname like concat(?,'%')";
                        queryParam.put(i++, name);
                    }
                if(!location.trim().equals(""))
                {
                    if(i > 0)
                    {
                     queryString +=" and user.locCity like concat(?,'%')";
                     countQuery+=" and user.locCity like concat(?,'%')";
                    }
                    else
                    {
                     queryString +=" user.locCity like concat(?,'%')";
                     countQuery +=" user.locCity like concat(?,'%')";
                    }
                    queryParam.put(i++, location);
                }
                if(!company.trim().equals(""))
                {
                    if(i > 0)
                    {
                     queryString +=" and user.company like concat(?,'%')";
                     countQuery+=" and user.company like concat(?,'%')";
                    }
                    else
                    {
                     queryString +=" user.company like concat(?,'%')";
                     countQuery+=" user.company like concat(?,'%')";
                    }
                    queryParam.put(i++, company);
                }
                if(!keyword.trim().equals(""))
                {
                    if(i > 0)
                    {
                      queryString +=" and user.aboutMe like concat(?,'%')";
                      countQuery +=" and user.aboutMe like concat(?,'%')";
                    }
                    else
                    {
                      queryString +=" user.aboutMe like concat(?,'%')";
                      countQuery +=" user.aboutMe like concat(?,'%')";
                    }
                    queryParam.put(i++, keyword);
                }
                
                // This is line code will arrange the results in ascending order
                
                queryString +=" order by user.fullname";
                Long totalResult = getTotalFriends(countQuery, queryParam);
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                
                Query query = session.createQuery(queryString);
                query = query.setFirstResult(0);
                query.setMaxResults(pageSize * pageNumber);
                
                for(int j=0; j<queryParam.size();j++)
                {
                    query.setParameter(j, queryParam.get(j));
                }
                
                resultList = query.list();
                session.getTransaction().commit();
                
                finalList = new ArrayList<User>();
                
                for(int k=0;k < resultList.size();k++)
                {
                    User user = new User();
                    user =(User)resultList.get(k);
                    User u = new User();
                    u.setFullname(user.getFullname());
                    u.setLocCity(user.getLocCity());
                    u.setUserId(user.getUserId());
                    u.setImage(user.getImage());
                    u.setResultcount(totalResult);
                    u.setGender(user.getGender());
                    finalList.add(u);
                }
                
                log.info("Total Results returned from DataSource, Size: " + totalResult);
                log.info("Display search results size:"  + resultList.size() + " and Page number:"  + pageNumber);
            }
            else
            {
                log.info("There are no friend's search results found due to empty search query");
            }
        
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
       return finalList;  
  }
 
 
 
  /**This method will search friends and return the list of friends based on Friend's Name,Location,Company and Keyword parameter */
  public List searchMeetInFriends(String name, String location, String company, String keyword)
  {
       
          log.info("Inside MeetIn Friend Search...");
          
        List resultList =null;
        String queryString ="from User as user where";
        
        int i=0;
        Hashtable queryParam = new Hashtable();
        try
        {
            if(!name.trim().equals("") || !location.trim().equals("") || !company.trim().equals("") || !keyword.trim().equals(""))
            {
                log.info("Searching for meetin friends.......");
                if(!name.trim().equals(""))
                    {
                        queryString +=" user.fullname like concat(?,'%')";
                        queryParam.put(i++, name);
                    }
                if(!location.trim().equals(""))
                {
                    if(i > 0)
                    {
                     queryString +=" and user.locCity like concat(?,'%')";
                    }
                    else
                    {
                     queryString +=" user.locCity like concat(?,'%')";
                    }
                    queryParam.put(i++, location);
                }
                if(!company.trim().equals(""))
                {
                    if(i > 0)
                    {
                     queryString +=" and user.company like concat(?,'%')";
                    }
                    else
                    {
                     queryString +=" user.company like concat(?,'%')";
                    }
                    queryParam.put(i++, company);
                }
                if(!keyword.trim().equals(""))
                {
                    if(i > 0)
                    {
                      queryString +=" and user.aboutMe like concat(?,'%')";
                    }
                    else
                    {
                      queryString +=" user.aboutMe like concat(?,'%')";
                    }
                    queryParam.put(i++, keyword);
                }
                
                // This is line code will arrange the results in ascending order
                
                queryString +=" order by user.fullname";
            //    Long totalResult = getTotalFriends(countQuery, queryParam);
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                
                Query query = session.createQuery(queryString);
                query = query.setFirstResult(0);
                //query.setMaxResults(pageSize * pageNumber);
                //System.out.println("query"+query);
                for(int j=0; j<queryParam.size();j++)
                {
                    query.setParameter(j, queryParam.get(j));
                }
                
                resultList = query.list();
                session.getTransaction().commit();
                log.info("Display search results size:"  + resultList.size() );
            }
            else
            {
                log.info("There are no friend's search results found due to empty search query");
            }
        
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
       return resultList;  
  }
 
  public List searchMeetInFriendsOptimized1(int userId,String name, String location, String company, String keyword)
  {
       
          log.info("Inside MeetIn Friend Search...");
          Hashtable queryParam = new Hashtable();
        List resultList =null;
        
        String queryString ="select u.fullname,f.status FROM User AS u LEFT JOIN  Friends AS f ON(u.userId = f.userId1 AND  f.userId2 = ?) OR"+
            "(u.userId = f.userId2 AND  f.userId1 =?) where";
        int i=0;
        try
        {
            if(!name.trim().equals("") || !location.trim().equals("") || !company.trim().equals("") || !keyword.trim().equals(""))
            {
                log.info("Searching for meetin friends.......");
                if(!name.trim().equals(""))
                    {
                        queryString +=" u.fullname like concat(?,'%')";
                        queryParam.put(i++, name);
                    }
                if(!location.trim().equals(""))
                {
                    if(i > 0)
                    {
                        queryString +=" and u.locCity like concat(?,'%')";
                    }
                    else
                    {
                        queryString +=" u.locCity like concat(?,'%')";
                    }
                    queryParam.put(i++, location);
                }
                if(!company.trim().equals(""))
                {
                    if(i > 0)
                    {
                     queryString +=" and u.company like concat(?,'%')";
                    }
                    else
                    {
                     queryString +=" u.company like concat(?,'%')";
                    }
                    queryParam.put(i++, company);
                }
                if(!keyword.trim().equals(""))
                {
                    if(i > 0)
                    {
                      queryString +=" and u.aboutMe like concat(?,'%')";
                    }
                    else
                    {
                      queryString +=" u.aboutMe like concat(?,'%')";
                    }
                    queryParam.put(i++, keyword);
                }
                // This is line code will arrange the results in ascending order
                queryString +=" order by u.fullname";
                //    Long totalResult = getTotalFriends(countQuery, queryParam);
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                
                Query query = session.createQuery(queryString);
                query.setParameter(0, userId);
                query.setParameter(1, userId);
                
                query = query.setFirstResult(0);
                //query.setMaxResults(pageSize * pageNumber);
                //System.out.println("query"+query);
                for(int j=0; j<queryParam.size();j++)
                {
                    query.setParameter(j, queryParam.get(j));
                }
                
                resultList = query.list();
                session.getTransaction().commit();
                log.info("Display search results size:"  + resultList.size() );
            }
            else
            {
                log.info("There are no friend's search results found due to empty search query");
            }
        
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
       return resultList;  
  }
 
  @SuppressWarnings("unchecked")
public List searchMeetInFriendsOptimized(int userId,String name, String location, String company, String keyword) throws ClassNotFoundException, SQLException
  {
      
      List<User> resultListrow =new ArrayList<User>();
      int pageSize =10;
      Connection con=null;    
      Class.forName(DriverClass.trim());
      con = DriverManager.getConnection(connectionValue.trim(), username.trim(), password.trim());
      SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
      log.info("Inside MeetIn Friend Search...");
          Hashtable queryParam = new Hashtable();
        List resultList =new ArrayList();
        
        
        String queryString="select u.*,f.status,f.relationship_id,f.user_id2 from mi_users AS u LEFT JOIN mi_friends AS f ON (u.user_id = f.user_id1 AND  f.user_id2 = '"+userId+"') OR"+
        "(u.user_id = f.user_id2 AND  f.user_id1 ='"+userId+"') where";
        
        /*String queryString ="select u.fullname,f.status FROM User AS u LEFT JOIN  Friends AS f  on(u.userId = f.userId1 AND  f.userId2 = ?) OR"+
            "(u.userId = f.userId2 AND  f.userId1 =?) where u.locCity like concat(?,'%')";*/
        
        int i=0;
        try
        {
            if(!name.trim().equals("") || !location.trim().equals("") || !company.trim().equals("") || !keyword.trim().equals(""))
            {
                log.info("Searching for meetin friends.......");
                if(!name.trim().equals(""))
                {
                    queryString +=" u.fullname like concat('"+name+"','%')";
                    queryParam.put(i++, name);
                }
            if(!location.trim().equals(""))
            {
                if(i > 0)
                {
                    queryString +=" and u.loc_city like concat('"+location+"','%')";
                }
                else
                {
                    queryString +=" u.loc_city like concat('"+location+"','%')";
                }
                queryParam.put(i++, location);
            }
            if(!company.trim().equals(""))
            {
                if(i > 0)
                {
                 queryString +=" and u.company like concat('"+company+"','%')";
                }
                else
                {
                 queryString +=" u.company like concat('"+company+"','%')";
                }
                queryParam.put(i++, company);
            }
            if(!keyword.trim().equals(""))
            {
                if(i > 0)
                {
                  queryString +=" and u.about_me like concat('"+keyword+"','%')";
                }
                else
                {
                  queryString +=" u.about_me like concat('"+keyword+"','%')";
                }
                queryParam.put(i++, keyword);
            }
                queryString +=" order by u.fullname";
                //System.out.println("print query ::::  "+queryString);
                
                PreparedStatement prest = con.prepareStatement(queryString);
                ResultSet set=prest.executeQuery();
                ResultSetMetaData rsMetaData = set.getMetaData();
                int numberOfColumns = rsMetaData.getColumnCount();
               // System.out.println("columns:::: "+numberOfColumns);
                
              
                while(set.next()){
                    
                            User user = new User();
                             
                             
                            user.setUserId(set.getInt(1));
                            user.setFullname(set.getString(2));
                            user.setEmail(set.getString(3));
                            user.setImage(set.getString(7));
                            user.setAboutMe(set.getString(8));
                            user.setCompany(set.getString(9));
                            user.setJobTitle(set.getString(11));
                            user.setIndustry(set.getString(13));
                            user.setDegreeCollege(set.getString(14));
                            user.setLocCountry(set.getString(16));
                            user.setLocState(set.getString(17));
                            user.setLocStreet(set.getString(18));
                            user.setLocCity(set.getString(19));
                            user.setLocPin(set.getString(20));
                            user.setLocLat(set.getString(21));
                            user.setLocLang(set.getString(22));
                            user.setOtherSpecify(set.getString(23));
                            user.setLastLogin(set.getDate(24));
                            user.setGender(set.getString(26));
                            user.setResultcount(set.getLong(28));
                            user.setGoogleMarkerIcon(set.getString(29));
                            user.setStatus(set.getString(31));
                            user.setRelationshipId(set.getString(32));
                            user.setUserId2(set.getString(33));
                            
                            resultListrow.add(user);
                            
                            
                 }
                log.info("Display search results size:"  + resultListrow.size() );
                    
                
                
                
                
            }
            
            else
            {
                log.info("There are no friend's search results found due to empty search query");
            }
                //con.commit();
            
            
        }
        catch(Exception ex)
        {
            log.error("There is a problem in searching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
                
       return resultListrow;  
  }
  public Object checkFriendRequest(int fromUserId, int toUserId)
  {
        String request_status ="";
        Object object = null;
        String queryString ="from Friends as friends where friends.userId1 =? and friends.userId2=? or friends.userId1=? and friends.userId2=?";
        try
        {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
            session.beginTransaction();
            
            Query query = session.createQuery(queryString);
            query.setParameter(0, fromUserId);
            query.setParameter(1, toUserId);
            query.setParameter(2, toUserId);
            query.setParameter(3, fromUserId);
            object =(Object)query.uniqueResult();
            session.getTransaction().commit();
            
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }    
        return object;
      
  }
 
  public List<Integer> getFriendsId(int userid)
  {
      List<Integer> friends_ids = new ArrayList<Integer>();
      String queryString = "select userId1, userId2 from Friends where userId1 = ? or userId2 = ?";
      
      try
      {
          
          Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
          session.beginTransaction();
          
          Query query = session.createQuery(queryString);
          query.setParameter(0, userid);
          query.setParameter(1, userid);
          ScrollableResults sr = query.scroll();
                    
          while(sr.next())
          {
              if(sr.getInteger(0) == userid)
                  friends_ids.add(sr.getInteger(1));
              else if(sr.getInteger(1) == userid)
                  friends_ids.add(sr.getInteger(0));
          }
          sr.close();
          session.getTransaction().commit();
          
          return friends_ids;
      }
      catch(Exception ex)
        {
            log.error("There is a problem fetching friend ");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return friends_ids;
  }
 
  /** This method will return the List of MeetIn Friends for a User */
  public List viewMeetInFriends(int userId)
  {
      
        log.info("Inside MeetIn Friends List...");
        List resultList =null;
        String queryString ="select a.userId,a.fullname,a.locCity,a.image,a.gender from User a,Friends b where a.userId=b.userId1 and b.userId2=? and b.status= 'Approve' or a.userId=b.userId2 and b.userId1=? and b.status ='Approve' order by a.fullname";
        try
        {
                log.info("Fetching the List of meetin friends.......");
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                  
                Query query = session.createQuery(queryString);
                query.setParameter(0, userId);
                query.setParameter(1, userId);
                resultList = query.list();
                session.getTransaction().commit();
                
                log.info("Search results returned from DataSource,Size:" +resultList.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return resultList;
  }
  //Added by rupal Kathiriya to get meetin all users with location wise dated on 23rd jan 2013
  public List viewMeetInFriendsWithLocation(int userId,String location)
  {
          log.info("Inside MeetIn Friends List...");
        List resultList =null;
        String queryString ="SELECT distinct a.userId,a.fullname,a.locCity,a.locLat,a.locLang,a.image,a.gender FROM User a,Friends b, Trips c WHERE a.userId NOT IN " +
                "(SELECT userId FROM Trips WHERE (fromDate <=CURDATE() AND toDate >=CURDATE() OR fromDate >= CURDATE()) AND" +
                "    (fromDate >=CURDATE() AND toDate <=CURDATE() OR fromDate <= CURDATE())) AND ((a.userId=b.userId1 AND b.userId2='"+userId+"' AND" +
                "    b.status='Approve' AND a.locCity LIKE CONCAT('"+location+"', '%')) OR (a.userId=b.userId2 AND b.userId1='"+userId+"' AND b.status= 'Approve'" +
                        "     AND a.locCity LIKE CONCAT('"+location+"','%'))) order by a.fullname";
            try
            {
                log.info("Fetching the List of meetin friends.......");
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryString);
                /*query.setParameter(0, userId);
                query.setParameter(1, userId);
                query.setParameter(2, location);*/
                resultList = query.list();
                session.getTransaction().commit();
                
                log.info("Search results returned from DataSource,Size:" +resultList.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching meetin friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return resultList;
  }
 
  /** This method will return the list of Facebook friends for a user */
  public Hashtable<String, List<String>> viewFacebookFriends(int userId)
  {
      
        log.info("Inside Facebook Friends List...");
        Hashtable<String, List<String>> Facebook_friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for Facebook friends..........");
            facebookGraphAPI fbapi = new facebookGraphAPI();
            String access_token = socialnetwork.getAccessToken(userId, socialnetwork.getSocialNetworkId("Facebook"));
            Facebook_friends = fbapi.getFacebookFriendList(access_token);
            log.info("Facebook friends returned :" +Facebook_friends.size());
        
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching facebook friends");
            log.debug(ex);
        }
        
        return Facebook_friends;
  }
  /** This method will return the list of linked in friends for a user */
  public Hashtable<String, List<String>> viewLinkedInFriends(int userId)
  {
        log.info("Inside Linkedin Friends List...");
        Hashtable<String, List<String>> Linkedin_friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for Linkedin friends.....");
            LinkedIn linkedinapi = new LinkedIn();
            String access_token = socialnetwork.getAccessToken(
                    userId, socialnetwork.getSocialNetworkId("LinkedIn"));
            Linkedin_friends = linkedinapi.getFriendsInfo(access_token);
            log.info("Linkedin friends returned :" +Linkedin_friends.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching Linkedin friends");
            log.debug(ex);
        }
        
        return Linkedin_friends;
  }
 
  /** This method will return the list of gmail friends for a user */
  public Hashtable<String, List<String>> viewGmailFriends(String email, String password)
  {
          log.info("Inside Gmail Friends List...");
        Hashtable<String, List<String>> Gmail_Friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for Gmail friends.....");
            Gmail_Friends = new GmailFriends().getGmailFriends(email, password);
            log.info("Gmail friends returned :" +Gmail_Friends.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching Gmail friends");
            log.debug(ex);
        }
        
        return Gmail_Friends;
  }
  /** This method will return the list of gmail friends for a user (code for web based app) */
  /**overloaded method*/
  public Hashtable<String, List<String>> viewGmailFriends(int userId)
  {
          log.info("Inside Gmail Friends List...");
        Hashtable<String, List<String>> Gmail_Friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for Gmail friends.....");
            String access_token = socialnetwork.getAccessToken(
                    userId, socialnetwork.getSocialNetworkId("Gmail"));
            
            
            Gmail_Friends = new GmailAPI().getFriends(access_token);
            log.info("Gmail friends returned :" +Gmail_Friends.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching Gmail friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        return Gmail_Friends;
  }
  /** This method will return the list of twitter friends for a user */
  public Hashtable<String, List<String>> viewtwitterFriends(int userId)
  {
    
        log.info("Inside twitter Friends List...");
        Hashtable<String, List<String>> twitter_friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for twitter friends.....");
            twitter twitterapi = new twitter();
            String access_token = socialnetwork.getAccessToken(userId, socialnetwork.getSocialNetworkId("Twitter"));
            twitter_friends = twitterapi.getFriendsInfo(access_token);
            log.info("twitter friends returned :" +twitter_friends.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching twitter friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return twitter_friends;
  }
  /** This method will return the list of google plus friends for a user */
  public Hashtable<String, List<String>> viewGooglePlusFriends(String email, String password)
  {
          log.info("Inside Gmail Friends List...");
        Hashtable<String, List<String>> GooglePlus_Friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for Gmail friends.....");
            GooglePlus_Friends = new GooglePlusFriends().getGooglePlusFriends(email, password);
            log.info("Google + friends returned :" +GooglePlus_Friends.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching Google + friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        return GooglePlus_Friends;
  }
  /** This method will return the list of Goole Plus friends for a user */
  public Hashtable<String, List<String>> viewgooglePlusFriends(int userId)
  {
        log.info("Inside Google Plus Friends List...");
        Hashtable<String, List<String>> googlePlus_friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for Google Plus friends.....");
            GooglePlusAPI googleplusapi = new GooglePlusAPI();
            String access_token = socialnetwork.getAccessToken(
                    userId, socialnetwork.getSocialNetworkId("GooglePlus"));
            googlePlus_friends = googleplusapi.getFriends(access_token);
            log.info("Google Plus friends returned :" +googlePlus_friends.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching twitter friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return googlePlus_friends;
  }
 
  public List getSocialNetworkFriends(int userId,int socialid)
  {
      
        log.info("Inside get SocialNetwork Friends List...");
        List resultList =null;
        String queryString ="select s.userId,s.fullname,s.location,s.profileUrl,s.id,u.socialNetworkSiteIcon,s.profileImage from SocialNetworkDummy as s, Networkmaster u" +
                " where s.socialId = u.socialNetworkSiteId and  s.userId = ? and s.socialId = ? order by s.fullname";
        try
        {
                log.info("Fetching the List of friends.......");
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryString);
                query.setParameter(0, userId);
                query.setParameter(1, socialid);
                resultList = query.list();
                session.getTransaction().commit();
                
                log.info("Search results returned from DataSource,Size:" +resultList.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return resultList;
  }
 
  public List getFacebookCheckInFriends(int userId,int socialid)
  {
      
        log.info("Inside get SocialNetwork Friends List...");
        List resultList =null;
        String queryString ="select s.userId,s.fullname,s.location,s.profileUrl,s.id,u.socialNetworkSiteIcon,s.profileImage from Facebook_Checkin as s, Networkmaster u" +
                " where s.socialId = u.socialNetworkSiteId and  s.userId = ? and s.socialId = ? order by s.fullname";
        try
        {
                log.info("Fetching the List of friends.......");
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryString);
                query.setParameter(0, userId);
                query.setParameter(1, socialid);
                resultList = query.list();
                session.getTransaction().commit();
                
                log.info("Search results returned from DataSource,Size:" +resultList.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return resultList;
  }
 
 
  public List getAllSocialNetworkFriends(int userId)
  {
      
        log.info("Inside get All SocialNetwork Friends List...");
        List resultList =null;
        String queryString ="select s.userId,s.fullname,s.location,s.profileUrl,s.id, u.socialNetworkSiteIcon,s.profileImage from SocialNetworkDummy as s, Networkmaster u" +
                " where s.socialId = u.socialNetworkSiteId and s.userId= ? order by s.fullname";
        try
        {
                log.info("Fetching the List of All social friends.......");
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryString);
                query.setParameter(0, userId);
                resultList = query.list();
                session.getTransaction().commit();
                
                log.info("All social network friends for myfriends module found from DataSource,Size:" +resultList.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching all social network friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return resultList;
  }
 
  public List getFacebookCheckinFriendList(int userId)
  {
      
        log.info("Inside get All SocialNetwork Friends List...");
        List resultList =null;
        String queryString ="select s.userId,s.fullname,s.location,s.profileUrl,s.id, u.socialNetworkSiteIcon,s.profileImage from Facebook_Checkin as s, Networkmaster u" +
                " where s.socialId = u.socialNetworkSiteId and s.userId= ? order by s.fullname";
        try
        {
                log.info("Fetching the List of Facebook Checkin friends.......");
                
                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
                session.beginTransaction();
                Query query = session.createQuery(queryString);
                query.setParameter(0, userId);
                resultList = query.list();
                session.getTransaction().commit();
                
                log.info("Facebook Checkin friends for myfriends module found from DataSource,Size:" +resultList.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching all social network friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return resultList;
  }
 
 
 
  /** This method will return the list of myspace friends for a user */
  public Hashtable<String, List<String>> viewmyspaceFriends(int userId)
  {
        log.info("Inside myspace Friends List...");
        Hashtable<String, List<String>> myspace_friends = new Hashtable<String, List<String>>();
        NetworkDAO socialnetwork = new NetworkDAO();
        try
        {
            log.info("Searching for myspace friends.....");
            myspace myspaceapi = new myspace();
            String access_token = socialnetwork.getAccessToken(
                    userId, socialnetwork.getSocialNetworkId("Myspace"));
            myspace_friends = myspaceapi.getFriendsInfo(access_token);
            log.info("myspace friends returned :" +myspace_friends.size());
        }
        catch(Exception ex)
        {
            log.error("There is a problem in fetching myspace friends");
            log.debug(ex);
            ex.printStackTrace();
        }
        
        return myspace_friends;
  }
 
  public static void main(String[] args) throws ClassNotFoundException, SQLException{
      new FriendsDAO().searchMeetInFriendsOptimized(6, "", "Ahmedabad", "", "");
  }
}
