package com.verve.meetin.mailer_template;


import java.util.Date;
import javax.mail.MessagingException;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.user.User;
import com.verve.meetin.user.UserAccountDAO;

public class SendFirstFriendRequestScheduler implements Job 
{

	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		
		JobDataMap data = arg0.getJobDetail().getJobDataMap();
		String receiveremail = (String)data.get("receiveremail");
		String subject = (String)data.get("subject");
		String message = (String)data.get("message");
				
		try 
		{
			new InviteFriends().postMail(receiveremail, subject, message , "");
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
	
	public void SendFirstFriendRequestEmail(int userId, String subject, String header, String footer)
	{
		try 
		{
			
			User user = (User)new UserAccountDAO().getUserProfileDetails(userId);
			
			JobDetail job = new JobDetail();
	    	job.setName("Send First Friend Request Email");
	    	job.setJobClass(SendFirstFriendRequestScheduler.class);
	    	job.getJobDataMap().put("receiveremail", user.getEmail());
	    	job.getJobDataMap().put("subject", subject);
	    	job.getJobDataMap().put("message", generateFirstFriendRequestEmailTemplate(user.getFullname(), header, footer));
	       		    	
	    	SimpleTrigger trigger = new SimpleTrigger();
	    	trigger.setName("Send First Friend Request Email");
	    	trigger.setStartTime(new Date(System.currentTimeMillis() + 1000));
	    	
			Scheduler scheduler = new StdSchedulerFactory().getScheduler();
			scheduler.start();
	    	scheduler.scheduleJob(job, trigger);
	    	
		}catch (SchedulerException e) {
			e.printStackTrace();
		}
	}
	 public String generateFirstFriendRequestEmailTemplate(String name, String header, String footer)
	 {
		 String message = "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"   <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
			"<p> Hey " + name + ",</p>" +
			"      <p>Welcome to meetIn. I hope you're doing great!</p>      <p>I am the Founder & CEO of meetIn and our goal is to help you make the most out of your trips. meetIn will exploit the true power of Social Networking sites. Ever since the arrival of these sites, our social interactions have been very limited and most of it has been on these sites. So the idea of meetIn, to allow an easy way to meet while you travel. We will be coming up with new upgrades and features soon and will keep you updated. I thank you for using meetIn and wanted to share my email (chirendu@mymeetin.com) in case you want to drop in some feedbacks. </p>" +
			"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p>You also got your first friend request from me, which means that once you accept the request you can keep a track of where I am traveling and we can look forward to meet using meetIn.</p><p> We will also encourage you to keep updating your trips and invite your friends to start using meetIn so that you and they can look forward to meet each other someday using meetIn. Thanks again and have a great day. </p> </td>" +
			"</tr>  <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'><p>Chirendu<br/>CEO, meetIn </p> </td>" +
			"  </tr></table></td>  </tr>";
		 
		 StringBuffer sb = new StringBuffer();
		 sb.append(header);
		 sb.append(message);
		 sb.append(footer);
		
		 return sb.toString();

	 }
	
}
