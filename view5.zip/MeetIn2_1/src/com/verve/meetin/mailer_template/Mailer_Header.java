package com.verve.meetin.mailer_template;

public class Mailer_Header {


	public String getMailerHeader (String bannar)
	{
		
	String header ="<table width='600' border='0' cellspacing='0' cellpadding='0' align='center' style='background:#000;'>  <tr>    <td align='left' valign='top' height='113px;'><img src="+bannar+" alt='banner' /></td>" +
			"  </tr>  <tr>    <td align='center' valign='top' style='background:#414346; border-bottom:solid 1px #fff; border-top:solid 1px #fff; padding:14px 0; width:100%;'>" +
			"<table cellpadding='0' cellspacing='0' border='0'>        	<tr>" +
			"          	<td><a href='#' style='color:#FFBC3A; font-size:24px; font-family:Helvetica, Arial, sans-serif; text-decoration:none;'>Who</a></td>" +
			"                <td align='center' width='20' style='color:#fff; font-size:24px; font-family:Helvetica, Arial, sans-serif; text-decoration:none;'>|</td>" +
			"                <td><a href='#' style='color:#FFBC3A; font-size:24px; font-family:Helvetica, Arial, sans-serif; text-decoration:none;'>Where</a></td>" +
			"                <td align='center' width='20' style='color:#fff; font-size:24px; font-family:Helvetica, Arial, sans-serif; text-decoration:none;'>|</td>" +
			"                <td><a href='#' style='color:#FFBC3A; font-size:24px; font-family:Helvetica, Arial, sans-serif; text-decoration:none;'>When</a></td>" +
			"            </tr>        </table>" +
			"</td>" +
			"  </tr>";
		
		return header;
	}
	// last code
	public String getMailerFooter(String facebookimage,String twitterimage,String androidimage,String iphoneimage)
	{

		String footer ="		<tr>		  <td align='left' valign='top'><table cellspacing='0' cellpadding='0' border='0' width='100%' style='background: none repeat scroll 0% 0% rgb(65, 67, 70);'>			      " +
		 "	   <tbody>      <tr> <td align='left' valign='top' style='padding: 12px 0pt 0pt;'><table cellspacing='0' cellpadding='0' border='0' align='center' width='240px' ;=''>" 
		 +
		"<tbody>  <tr><td align='left' width='50%' valign='top' style='font-size: 12px; color: rgb(255, 255, 255); font-family: Helvetica,Arial,sans-serif; text-align: center;'>Follow Us on</td>  "
		 + "<td align='left' width='50%' valign='top' style='font-size: 12px; color: rgb(255, 255, 255); font-family: Helvetica,Arial,sans-serif; text-align: center;'>App Available on</td>"
		 + " </tr>	<tr>  <td align='left' width='50%' valign='top' style='padding: 7px 23px; border-right: 2px solid rgb(255, 255, 255);'><a style='padding-right: 10px; float: left; display:inline-block; border: medium none;' href='https://www.facebook.com/mymeetIn' target='_blank' ><img border='0' alt='facebook' src="+facebookimage+"></a><a href='https://twitter.com/mymeetIn' target='_blank'><img border='0' alt='twitter' src="+twitterimage+
		 "></a></td>  <td align='left' width='50%' valign='top' style='padding: 7px 23px;'><a style='padding-right: 10px; display:inline-block; float: left;' href='https://itunes.apple.com/us/app/meetin/id590629564?ls=1&mt=8' target='_blank'><img border='0' alt='apple' src="+iphoneimage+"></a><a href='https://play.google.com/store/apps/details?id=com.meetin&feature=search_result#?t=W251bGwsMSwyLDEsImNvbS5tZWV0aW4iXQ..' target='_blank'><img border='0' alt='android' src="+androidimage
		 +"></a></td> </tr>	       </tbody>	       </table></td>			        </tr>			        <tr>" +
		"   <td align='left' valign='top' style='padding: 8px 0pt;'><table cellspacing='0' cellpadding='0' border='0' align='center' width='240px'>"
			  +        " <tbody> <tr>    <td align='left' valign='top' style='font-size: 10px; padding: 5px 0pt 0pt; float: left; border-top: 1px solid rgb(255, 255, 255); color: rgb(255, 255, 255); text-align: center; font-family: Helvetica,Arial,sans-serif;'>Copyright @ 2012-13 meetIn. All rights reserved.<a style='font-size: 10px; color: rgb(255, 255, 255); text-align: center; font-family: Helvetica,Arial,sans-serif; text-decoration: none;' href='mymeetin.com' target='_blank'>www.mymeetin.com</a></td>"
			   + " </tr>  </tbody>	 </table></td>          " +			          " </tr>	 </tbody>   </table></td>			</tr>			</tbody>" +
			          "			</table>			</td>			" +
			            "			            </tr>			            </tbody>			            </table>		            "; 
		
		
/*	String footer ="<tr>    <td align='left' valign='top'><table cellspacing='0' cellpadding='0' border='0' width='100%' style='background: none repeat scroll 0% 0% rgb(65, 67, 70);'>" +
			"  <tbody><tr>    <td align='left' valign='top' style='padding: 12px 0pt 0pt;'><table cellspacing='0' cellpadding='0' border='0' align='center' width='240px' ;=''>" +
			"  <tbody><tr>    <td align='left' width='50%' valign='top' style='font-size: 12px; color: rgb(255, 255, 255); font-family: Helvetica,Arial,sans-serif; text-align: center;'>Follow Us on</td>" +
			"    <td align='left' width='50%' valign='top' style='font-size: 12px; color: rgb(255, 255, 255); font-family: Helvetica,Arial,sans-serif; text-align: center;'>App Available on</td>" +
			"  </tr>  <tr>    <td align='left' width='50%' valign='top' style='padding: 7px 23px; border-right: 2px solid rgb(255, 255, 255);'><a style='padding-right: 10px; float: left; border: medium none;' href='#'><img border='0' alt='facebook' src="+facebookimage+"></a><a href='#'><img border='0' alt='twitter' src="+twitterimage+"></a></td>" +
			"    <td align='left' width='50%' valign='top' style='padding: 7px 23px;'><a style='padding-right: 10px; float: left;' href='#'><img border='0' alt='apple' src="+iphoneimage+"></a><a href='#'><img border='0' alt='android' src="+androidimage+"></a></td>" +
			"  </tr></tbody></table></td>  </tr>  <tr>" +
			"  	<td align='left' valign='top' style='padding: 8px 0pt;'><table cellspacing='0' cellpadding='0' border='0' align='center' width='240px'>" +
			"  <tbody><tr>    <td align='left' valign='top' style='font-size: 10px; padding: 5px 0pt 0pt; float: left; border-top: 1px solid rgb(255, 255, 255); color: rgb(255, 255, 255); text-align: center; font-family: Helvetica,Arial,sans-serif;'>Copyright &copy; meetIn All rights reserved.			<a style='font-size: 10px; color: rgb(255, 255, 255); text-align: center; font-family: Helvetica,Arial,sans-serif; text-decoration: none;' href='mymeetin.com' target='_blank'>www.mymeetin.com</a></td>" +
			"    </tr>  </tbody></table></td>" +
			"  </tr> </tbody></table> </td>   </tr> </tbody> </table> </td>" +
			"</tr> </tbody> </table>";
*/		
			return footer;
			
	}

}