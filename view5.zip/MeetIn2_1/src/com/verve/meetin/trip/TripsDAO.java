package com.verve.meetin.trip;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.interest.InterestDAO;
import com.verve.meetin.user.UserAccountDAO;


public class TripsDAO 
{
	
    static Logger log = Logger.getLogger(TripsDAO.class);
	
	public int setUserTrip(Trips trip)
	{
		log.info("Inside user trips details....");
		int last_trip_id = 0;
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			last_trip_id=(Integer)session.save(trip);
			tx.commit();
			
			log.info("User trip details have been submitted successfully");
		}
		catch(Exception ex)
		{
			log.error("There is a problem in user trip details");
			log.debug(ex);
		}
				
		return last_trip_id;
	}

	/*public int setUserTripDetails(Trips_detail trip)
	{
		log.info("Inside user trips details....");
		int last_trip_id = 0;
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			last_trip_id=(Integer)session.save(trip);
			tx.commit();
			
			log.info("User trip details have been submitted successfully");
		}
		catch(Exception ex)
		{
			log.error("There is a problem in user trip details");
			log.debug(ex);
		}
				
		return last_trip_id;
	}*/
	
	// Added by Rupal kathiriya to insert trip details with date range using stored procedure dated on 18th Feb 2013
	
	public int callStoredProc(Trips_detail trip){
		int last_trip_id = 0;
		try{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			Query query = session.createSQLQuery("CALL make_intervals(:tripsDetailId,:tripId,:userId,:fromDate,:toDate,:intval,:unitval,:destination,:destinationLatitude,:destinationLongitude)")
			.addEntity(Trips_detail.class).setProperties(trip);
			query.executeUpdate();
			tx.commit();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return last_trip_id;
	}
	
	// Added by Rupal kathiriya to delete trip details with date range using stored procedure dated on 19th Feb 2013
	public int deleteTripsDetail(int tripId,int userId)
	{
		log.info("Inside user remove trip....");
		int row=0;
		String queryString ="delete from Trips_detail where tripId=? and userId=?";
		try
		{
			log.info("Trying to remove user's trip.....");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, tripId);
		    query.setParameter(1, userId);
		    row = query.executeUpdate();
		    tx.commit();
		    
		    log.info("User's trip has been removed successfully");
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			log.error("There is a problem in user trip deletion");
			log.debug(ex);
		}
		return row;
	}
	public int updateUserTrip(Trips trip)
	{
		log.info("Inside user update trip details....");
		int updated_trip_id = 0;
		String queryString = "update Trips set destination=?,description=?,fromDate=?,toDate=?,destinationLatitude=?,destinationLongitude=? where tripId=?";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
			Query query =session.createQuery(queryString);
			query.setParameter(0, trip.getDestination());
			query.setParameter(1, trip.getDescription());
			query.setParameter(2, trip.getFromDate());
			query.setParameter(3, trip.getToDate());
			query.setParameter(4, trip.getDestinationLatitude());
			query.setParameter(5, trip.getDestinationLongitude());
			query.setParameter(6, trip.getTripId());
			
			updated_trip_id = query.executeUpdate();
			tx.commit();
			
			log.info("User's trip details has been updated successfully");
			
		}
		catch(Exception ex)
		{
			log.error("There is a problem in user trip updation");
			log.debug(ex);
		}
		
		return updated_trip_id;
	}
	
	public int removeUserTrip(int tripId)
	{
		
		log.info("Inside user remove trip....");
		int row=0;
		String queryString ="delete from Trips as trips where trips.tripId=?";
		
		try
		{
			log.info("Trying to remove user's trip.....");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, tripId);
		    row = query.executeUpdate();
		    tx.commit();
		    
		    log.info("User's trip has been removed successfully");
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in user trip deletion");
			log.debug(ex);
		}
		return row;
	}
	@SuppressWarnings("unchecked")
	public List getTripDestination(String destinationKey)
	{
	
		String result ="";
		List resultList =null;
		String queryString ="select citymaster.city,regionmaster.region from Cities as citymaster,States as regionmaster where citymaster.city like concat(?,'%') and citymaster.regionId=regionmaster.regionid order by citymaster.city";
	
		try
		{
			log.info("Trying to fetch Trip Destinations.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, destinationKey);
		    resultList = query.list();
		    session.getTransaction().commit();
		    		    
		    log.info("Trip destinations returned from DataSource,Size:" +resultList.size());
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in cities master");
			log.debug(ex);
		}
		
	   return resultList;	
	}
	
	@SuppressWarnings("unchecked")
	public List getUserUpcomingTrips(int userid)
	{
		
		log.info("Inside user upcoming trips");
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println("in  " + dateFormat.format(date));
		
		List resultList =null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="from Trips as trip where trip.toDate >= ? and userId=? order by trip.fromDate asc";
		try
		{
			
			log.info("Trying to fetch user's upcoming trips.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, userid);
		    System.out.println("before query  " + dateFormat.format(date));
		    resultList = query.list();
		    System.out.println("after query  " + dateFormat.format(date));
		    session.getTransaction().commit();
		    
		    log.info("User's upcoming trips returned from DataSource,Size:" +resultList.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting upcoming trips");
			log.debug(ex);
		}
				
	   return resultList;	
	}
	
	
	public List getTripitUserUpcomingTrips(int userid)
	{
		
		log.info("Inside user upcoming trips");
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println("in  " + dateFormat.format(date));
		
		List resultList =null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="from Tripit_Trips as trip where trip.toDate >= ? and userId=? order by trip.fromDate asc";
		try
		{
			
			log.info("Trying to fetch user's upcoming trips.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, userid);
		    System.out.println("before query  " + dateFormat.format(date));
		    resultList = query.list();
		    System.out.println("after query  " + dateFormat.format(date));
		    session.getTransaction().commit();
		    
		    log.info("User's upcoming trips returned from DataSource,Size:" +resultList.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting upcoming trips");
			log.debug(ex);
		}
				
	   return resultList;	
	}
	
	
	public List getUserPastTrips(int userid)
	{
		log.info("Inside User past trips");
		List resultList =null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="from Trips as trip where  trip.userId= " + userid + "  AND CURDATE() > toDate";
		try
		{
			
			log.info("Trying to fetch user's past trips.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setMaxResults(10);
		    resultList = query.list();
		    session.getTransaction().commit();
		    
		    log.info("User's past trips returned from DataSource,Size:" +resultList.size());
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting past trips");
			log.debug(ex);
		}
		
	   return resultList;	
	}
	
	public List getUserAllTrips(int userid)
	{
		log.info("Inside User all trips for a user");
		List resultList =null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="from Trips as trip where  trip.userId= " + userid ;
		try
		{
			log.info("Trying to fetch user's all trips.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setMaxResults(10);
		    resultList = query.list();
		    session.getTransaction().commit();
		    
		    log.info("User's all trips returned from DataSource,Size:" +resultList.size());
	
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting past trips");
			log.debug(ex);
		}
		
	   return resultList;	
		
	}
	public Trips getTripById(int tripId)
	{
		log.info("Inside Trip find by Id");
		Trips trip = null;
		String queryString ="from Trips as trip where  trip.tripId=?";
		try
		{
			
			log.info("Trying to fetch trip by trip Id......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, tripId);
		    trip = (Trips)query.uniqueResult();
		    session.getTransaction().commit();
		    
		    log.info("User's trip for tripid" +tripId + "returned from DataSource");
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting trip for tripId" + tripId);
			log.debug(ex);
			ex.printStackTrace();
		}
		
	   return trip;
	}
	public List getUserAllTripsforWebservice(int userid)
	{
		
		log.info("Inside User all trips for web service");
		List resultList =null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="from Trips as trip where  trip.userId= " + userid ;
		try
		{
			
			log.info("Trying to fetch user's all trips for webservice......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    resultList = query.list();
		    session.getTransaction().commit();
		    
		    log.info("User's all trips for webservice returned from DataSource,Size:" +resultList.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting all trips for webservice");
			log.debug(ex);
			ex.printStackTrace();
		}
		
	   return resultList;	
		
	}
	/*
	 * Search People for Location, from Date and end Date and interest
	 * @Method searchPeople 
	 * @Param : userIds List of Friends
	 * @Param : from  from date
	 * @Param : end  end date
	 * @Param : location
	 * @Param : interest
	 */
	public Hashtable<String, List<String>> searchPeople(List<Integer> userIds, Date from, Date end, String location, String searchInterest)
	{
		String profile_path = "profile_page.jsp";
		Hashtable<String, List<String>> searchFriend = new Hashtable<String, List<String>>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="select userId, fromDate, toDate from Trips as trip where trip.userId = ? and " +
				"trip.fromDate >= ? and  trip.toDate <= ? and trip.destination = ? order by trip.fromDate desc";  
		try
		{
			log.info("Trying to fetch user's Trips .......!");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			for(int i = 0; i<userIds.size(); i++)
			{
			    Query query = session.createQuery(queryString);
			    query.setParameter(0, userIds.get(i));
			    query.setParameter(1, sdf.parse(sdf.format(from)));
			    query.setParameter(2, sdf.parse(sdf.format(end)));
			    query.setParameter(3, location);
			    ScrollableResults sr  = query.scroll();
			    			    
			    while(sr.next())
			    {
			    	////System.out.println(sr.getInteger(0)+" : "+sr.getDate(1)+" : "+sr.getDate(2));
			    	List<String> interest = new InterestDAO().getInterest(sr.getInteger(0));
			    	if(interest.contains(searchInterest))
			    	{
			    		List<String> friends = new ArrayList<String>();
				    	friends.add(new UserAccountDAO().getFriendNames(sr.getInteger(0)));
			    		friends.add(sr.getDate(1).toString());
			    		friends.add(sr.getDate(2).toString());
			    		friends.add(profile_path+"?path="+sr.getInteger(0));
			    		friends.add("images/meetin_icon.png");
			    		searchFriend.put(sr.getInteger(0).toString(), friends);
			    	}
			    		
			    }
			    
			    sr.close();
			    session.getTransaction().commit();
			}
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting Search People");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return searchFriend;
	}
	/*
	 * Search People for Location, from Date and end Date and interest
	 * @Method searchPeople 
	 * @Param : userIds List of Friends
	 * @Param : from  from date
	 * @Param : end  end date
	 * @Param : location
	 */
	public Hashtable<String, List<String>> searchPeople(List<Integer> userIds, Date from, Date end, String location)
	{
		String profile_path = "profile_page.jsp";
		Hashtable<String, List<String>> searchFriend = new Hashtable<String, List<String>>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="select userId, fromDate, toDate from Trips as trip where trip.userId = ? and " +
				"trip.fromDate >= ? and  trip.toDate <= ? and trip.destination = ? order by trip.fromDate desc";  
		try
		{
			log.info("Trying to fetch user's Trips .......!");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			for(int i = 0; i<userIds.size(); i++)
			{
			    Query query = session.createQuery(queryString);
			    query.setParameter(0, userIds.get(i));
			    query.setParameter(1, sdf.parse(sdf.format(from)));
			    query.setParameter(2, sdf.parse(sdf.format(end)));
			    query.setParameter(3, location);
			    ScrollableResults sr  = query.scroll();
			    			    
			    while(sr.next())
			    {
			    	SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
			    	List<String> friends = new ArrayList<String>();
			    	friends.add(new UserAccountDAO().getFriendNames(sr.getInteger(0)));
		    		friends.add(format.format(sr.getDate(1)).toString());
		    		friends.add(format.format(sr.getDate(2)).toString());
		    		friends.add(profile_path+"?path="+sr.getInteger(0));
		    		friends.add("images/meetin_icon.png");
		    		searchFriend.put(sr.getInteger(0).toString(), friends);
			    }
			    sr.close();
			    session.getTransaction().commit();
			}
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting Search People");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return searchFriend;
	}
	
	public List getCurrentTripLocation(int userid)
	{
		
		
		log.info("Inside user upcoming trips");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   Date date = new Date();
		System.out.println("getcurrenttriplocation method  called " + dateFormat.format(date));
		
		List resultList =null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); //trip.fromDate <= ? and 
		String queryString ="from Trips as trip where " +
								"trip.toDate >= ? and userId = ? order by trip.fromDate asc,trip.destination asc";
		try
		{
	
			log.info("Trying to fetch user's upcoming trips.......");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, sdf.parse(sdf.format(new Date())));
		    //query.setParameter(1, sdf.parse(sdf.format(new Date())));
		    query.setParameter(1, userid);
		    System.out.println("before query called " + dateFormat.format(date));
		    resultList = query.list();
		    System.out.println("after query  called " + dateFormat.format(date));
		    session.getTransaction().commit();
		    
		    /*Trips trip = new Trips();
			for(int i=0;i<resultList.size();i++)
			{
				trip = (Trips)resultList.get(i);
				current_trip_location.add(""+trip.getDestination()+"");
			}*/
		    log.info("User's upcoming trips returned from DataSource,Size:" +resultList.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting upcoming trips");
			log.debug(ex);
			ex.printStackTrace();
		}
	
		return resultList;
	}
	
}
