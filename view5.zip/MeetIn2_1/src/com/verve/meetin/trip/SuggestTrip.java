package com.verve.meetin.trip;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import com.google.code.linkedinapi.client.LinkedInApiClient;
import com.google.code.linkedinapi.client.LinkedInApiClientFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInAccessToken;
import com.google.code.linkedinapi.schema.Connections;
import com.google.code.linkedinapi.schema.Person;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.json.JsonObject;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;


public class SuggestTrip 
{
	static Logger log = Logger.getLogger(SuggestTrip.class);
	
	public List getSuggestTripListBySocialNetwork(int userId, int socialId)
	{
		String queryString = "select count(*) as total, location from SocialNetworkDummy where userId= ? and socialId=?" +
							" and location is not null group by location order by count(*) desc";
		List resultList = null;
				
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, socialId);
		    query.setMaxResults(10);
		    
		    resultList =  query.list();
		    session.getTransaction().commit();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	
		return resultList;
	}

	public List getSuggestTripListByMeetIn(int userId, String fromDate, String toDate)
	{
		
		String queryString ="select count(distinct t.userId) as total, (case when locate(',', t.destination) > 0 then substring(t.destination, 1, locate(',', t.destination) - 1) else t.destination end) FROM Trips t, Friends f " 
				+" where ((t.userId=f.userId1 and f.userId2=? and f.status ='Approve') or (t.userId=f.userId2 and f.userId1=? and f.status ='Approve')) and (t.toDate >= ? and t.toDate <= ?) " 
						+ "group by (case when locate(',', t.destination) > 0 then substring(t.destination, 1, locate(',', t.destination) - 1 ) else t.destination end)" 
						+ " order by count(*) desc";
		
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		List resultList = null;
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, userId);
		    query.setParameter(2, sdf1.parse(sdf1.format(sdf.parse(fromDate))));
		    query.setParameter(3, sdf1.parse(sdf1.format(sdf.parse(toDate))));
		    query.setMaxResults(10);
		    
		    resultList =  query.list();
		    session.getTransaction().commit();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return resultList;
	}
	public List getSuggestTripListByMeetIn(int userId)
	{
		String queryString = "select count(*) as total, (case when locate(',', u.locCity) > 0 then substring(u.locCity, 1, locate(',', u.locCity) - 1) else u.locCity end) FROM User u, Friends f where (u.userId=f.userId1 and f.userId2=? and f.status ='Approve') or (u.userId=f.userId2 and f.userId1=? and f.status ='Approve') group by (case when locate(',', u.locCity) > 0 then substring(u.locCity, 1, locate(',', u.locCity) - 1 ) else u.locCity end)" 
							 + " order by count(*) desc";
		List resultList = null;
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    query.setParameter(1, userId);
		    query.setMaxResults(10);
		    
		    resultList =  query.list();
		    session.getTransaction().commit();
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	
		return resultList;
	}
	
	public Hashtable<String, List<String>> getSuggestSocialFriendList(int userId, int socialId, String location)
	{
		Hashtable<String, List<String>> finalResult = new Hashtable<String, List<String>>();
		List resultList = new SocialNetworkDAO().getSocialFriendsProfile(userId, socialId, location);
		
		if(resultList !=null && resultList.size() > 0)
		{
			 for(int i=0; i< resultList.size();i++)
			    {
			    	Object[] object= (Object[])resultList.get(i);
			    	ArrayList<String> list = new ArrayList<String>();
			    	list.add((String)object[1]);
			    	list.add((String)object[2]);
			    	list.add((String)object[3]);
			    	list.add((String)object[7]);
			    	finalResult.put(Integer.toString((Integer)object[6]), list);
			    }
		}
		
		return finalResult;
	}
	/**
	 * This method find the list of friend at living location.
	 * @param userId User ID
	 * @param location - Trip Location
	 * @return - Object of Hashtable that hold the user details
	 */
	public Hashtable<String, List<String>> getSuggestMeetInFriendList(int userId, String location)
	{
	
		String queryString = "select u.fullname, u.userId, 'images/meetin_icon.png',u.image from User u, Friends f where (case when locate(',', u.locCity) > 0 then substring(u.locCity, 1, locate(',', u.locCity) - 1 ) else u.locCity end) = ?" 
			+ " and ((u.userId=f.userId1 and f.userId2=? and f.status ='Approve') or (u.userId=f.userId2 and f.userId1=? and f.status ='Approve'))";
		Hashtable<String, List<String>> finalResult = new Hashtable<String, List<String>>();
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, location);
		    query.setParameter(1, userId);
		    query.setParameter(2, userId);
		    
		    List resultList =  query.list();
		    session.getTransaction().commit();
		    
		    for(int i=0; i< resultList.size();i++)
		    {
		    	Object[] object= (Object[])resultList.get(i);
		    	ArrayList<String> list = new ArrayList<String>();
		    	list.add((String)object[0]);
		    	list.add(Integer.toString((Integer)object[1]));
		    	list.add((String)object[3]);
		    	list.add((String)object[2]);
		    	finalResult.put(Integer.toString((Integer)object[1]), list);
		    }
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
				
		return finalResult;
	}
	
	/**
	 * This method find the list of friends at traveling location
	 * @param userId - User ID
	 * @param location - Trip location
	 * @param fromDate - Trip start date
	 * @param toDate - Trip end date
	 * @return
	 */
	public Hashtable<String, List<String>> getSuggestMeetInFriendList(int userId, String location, String fromDate, String toDate)
	{
		String queryString = "select distinct u.fullname, u.userId, 'images/meetin_icon.png' from User u, Friends f, Trips t where (case when locate(',', t.destination) > 0 then substring(t.destination, 1, locate(',', t.destination) - 1 ) else t.destination end) = ?"
			+ " and ((t.userId=f.userId1 and f.userId2=? and f.status ='Approve') or (t.userId=f.userId2 and f.userId1=? and f.status ='Approve')) and (t.toDate >= ? and t.toDate <= ?) and(t.userId=u.userId)";
	
	Hashtable<String, List<String>> finalResult = new Hashtable<String, List<String>>();
	
	try
	{
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
	    Query query = session.createQuery(queryString);
	    query.setParameter(0, location);
	    query.setParameter(1, userId);
	    query.setParameter(2, userId);
	    query.setParameter(3, sdf1.parse(sdf1.format(sdf.parse(fromDate))));
	    query.setParameter(4, sdf1.parse(sdf1.format(sdf.parse(toDate))));
	    
	    List resultList =  query.list();
	    session.getTransaction().commit();
	    
	    for(int i=0; i< resultList.size();i++)
	    {
	    	Object[] object= (Object[])resultList.get(i);
	    	ArrayList<String> list = new ArrayList<String>();
	    	list.add((String)object[0]);
	    	list.add(Integer.toString((Integer)object[1]));
	    	list.add((String)object[2]);
	    	finalResult.put(Integer.toString(i), list);
	    	
	    }
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
		
	return finalResult;
		
	}
	
	public List getSuggestFriendsTripDetail(int userId, int friendId, String location, String fromDate, String toDate)
	{
		String queryString = "select t.destination, t.fromDate, t.toDate from User u, Trips t, Friends f " +
				" where t.userId=? and (t.toDate >= ? and t.toDate <=?) and ((case when locate(',', t.destination) > 0 then substring(t.destination, 1, locate(',', t.destination) - 1 ) else t.destination end) = ?) and " +
				" ((t.userId = f.userId1 and f.userId2=? and f.status ='Approve') or (t.userId = f.userId2 and f.userId1=? and f.status ='Approve')) " +
				" and (t.userId = u.userId) order by t.toDate desc";
		List list = null;
		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, friendId);
		    query.setParameter(1, sdf1.parse(sdf1.format(sdf.parse(fromDate))));
		    query.setParameter(2, sdf1.parse(sdf1.format(sdf.parse(toDate))));
		    query.setParameter(3, location);
		    query.setParameter(4, userId);
		    query.setParameter(5, userId);
		    
		    list =  query.list();
		    session.getTransaction().commit();
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
			
		return list;
	}
}
