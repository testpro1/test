package com.verve.meetin.trip;

public class TripConstraint 
{
	public static final int SOCIAL_MEDIA_MEETIN = 0;
	public static final int SOCIAL_MEDIA_FACEBOOK = 1;
	public static final int SOCIAL_MEDIA_LINKEDIN = 2;
	public static final int SOCIAL_MEDIA_GMAIL = 3;
	public static final int SOCIAL_MEDIA_TWITTER = 4;
	
}
