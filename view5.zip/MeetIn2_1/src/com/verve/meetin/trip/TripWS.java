package com.verve.meetin.trip;

import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class TripWS implements java.io.Serializable {


    // Fields    

     private Integer tripId;
     private Integer userId;
     private String destination;
     private String description;
     private Date fromDate;
     private Date toDate;
     private String destinationLatitude;
     private String destinationLongitude;
     private String startDate;
     private String endDate;

    // Field for upcoming trip (find people there)
     private String friendname;
     
    // Field for sending meeting invitation 
     private String friendemail;
     private String inviteResult;
     
     
	/** default constructor */
    public TripWS() {
    }

    
    /** full constructor */
    public TripWS(Integer userId, String destination, String description, Date fromDate, Date toDate) {
        this.userId = userId;
        this.destination = destination;
        this.description = description;
        this.fromDate = fromDate;
        this.toDate = toDate;
       
    }

    /**constructor to set the properties for upcoming trip and past trip details */
    public TripWS(Integer tripId, Integer userId, String destination, String description, String startDate, String endDate,String latitude,String longitude) {
        this.tripId=tripId;
    	this.userId = userId;
        this.destination = destination;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.destinationLatitude = latitude;
        this.destinationLongitude = longitude;
       
    }
   
    // Property accessors

    public Integer getTripId() {
        return this.tripId;
    }
    
    public void setTripId(Integer tripId) {
        this.tripId = tripId;
    }

    public Integer getUserId() {
        return this.userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getDestination() {
        return this.destination;
    }
    
    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public Date getFromDate() {
        return this.fromDate;
    }
    
    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return this.toDate;
    }
    
    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getDestinationLatitude() {
        return this.destinationLatitude;
    }
    
    public void setDestinationLatitude(String destinationLatitude) {
        this.destinationLatitude = destinationLatitude;
    }

    public String getDestinationLongitude() {
        return this.destinationLongitude;
    }
    
    public void setDestinationLongitude(String destinationLongitude) {
        this.destinationLongitude = destinationLongitude;
    }


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public String getFriendname() {
		return friendname;
	}


	public void setFriendname(String friendname) {
		this.friendname = friendname;
	}


	public String getFriendemail() {
		return friendemail;
	}


	public void setFriendemail(String friendemail) {
		this.friendemail = friendemail;
	}


	public String getInviteResult() {
		return inviteResult;
	}


	public void setInviteResult(String inviteResult) {
		this.inviteResult = inviteResult;
	}

}