package com.verve.meetin.trip;

import java.util.Date;

import org.apache.struts.action.ActionForm;
/**
 * 
 * @author Rupal Kathiriya 
 *	to add trips detail with date range 
 */
public class Trips_detail extends ActionForm  implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private  Integer tripsDetailId;
	private Integer tripId;
    private Integer userId;
    private Date fromDate;
    private Date toDate;
    private Integer intval;
    private String unitval;
    private String destination;
    private String destinationLatitude;
    private String destinationLongitude;
    public Trips_detail(){
    	
    }
    public Trips_detail(Integer tripsDetailId,Integer tripId,Integer userId,Date fromDate,Date toDate,Integer intval,String unitval,String destination, String destinationLatitude,String destinationLongitude){
    	this.tripsDetailId=tripsDetailId;
    	this.tripId=tripId;
    	this.userId = userId;
    	this.fromDate = fromDate;
    	this.toDate = toDate;
    	this.intval=intval;
    	this.unitval=unitval;
    	this.destination = destination;
    	this.destinationLatitude = destinationLatitude;
    	this.destinationLongitude= destinationLongitude;
    }
    public Integer getIntval() {
		return intval;
	}
	public void setIntval(Integer intval) {
		this.intval = intval;
	}
	public String getUnitval() {
		return unitval;
	}
	public void setUnitval(String unitval) {
		this.unitval = unitval;
	}
	public Integer getTripsDetailId() {
		return tripsDetailId;
	}
	public void setTripsDetailId(Integer tripsDetailId) {
		this.tripsDetailId = tripsDetailId;
	}
	public Integer getTripId() {
		return tripId;
	}
	public void setTripId(Integer tripId) {
		this.tripId = tripId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDestinationLatitude() {
		return destinationLatitude;
	}
	public void setDestinationLatitude(String destinationLatitude) {
		this.destinationLatitude = destinationLatitude;
	}
	public String getDestinationLongitude() {
		return destinationLongitude;
	}
	public void setDestinationLongitude(String destinationLongitude) {
		this.destinationLongitude = destinationLongitude;
	}
	
      
}
