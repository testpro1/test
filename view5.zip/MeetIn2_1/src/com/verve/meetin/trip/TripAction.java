package com.verve.meetin.trip;


import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.oauth.OAuthConsumer;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import sun.misc.BASE64Decoder;
import twitter4j.IDs;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import com.google.code.linkedinapi.client.LinkedInApiClient;
import com.google.code.linkedinapi.client.LinkedInApiClientFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInAccessToken;
import com.google.code.linkedinapi.schema.Person;
import com.tripit.api.Client;
import com.tripit.api.Response;
import com.tripit.auth.Credential;
import com.tripit.auth.OAuthCredential;
import com.verve.meetin.LinkedIn.LinkedIn;
import com.verve.meetin.facebook.facebookGraphAPI;
import com.verve.meetin.friend.InviteFriends;
import com.verve.meetin.mailer_template.Mailer_Header;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;
import com.verve.meetin.tripit.Tripit_Trips_DAO;
import com.verve.meetin.twitter.twitter;
import com.verve.meetin.user.User;
import com.verve.meetin.user.UserAccountDAO;

public class TripAction extends DispatchAction {

	public ActionForward addtrip(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		System.out.println("Trip Action.java----add trip methdod");
		
		   	Trips trip =(Trips)form;
		   	//Trips_detail tripsDetail=(Trips_detail)form;
			TripsDAO tripDAO= new TripsDAO();
			HttpSession sc = request.getSession(false);
			int userid = (Integer)sc.getAttribute("UserID");
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
			Trips otrip = new Trips(userid, trip.getDestination(), trip.getDescription(), sdf.parse(trip.getStartDate()), sdf.parse(trip.getEndDate()),trip.getDestinationLatitude(),trip.getDestinationLongitude());
			
			int tripid = tripDAO.setUserTrip(otrip);
			Trips_detail tripsDetail=new Trips_detail(1,tripid,userid,sdf.parse(trip.getStartDate()), sdf.parse(trip.getEndDate()),1,"DAY",trip.getDestination(),trip.getDestinationLatitude(),trip.getDestinationLongitude());
			//tripDAO.setUserTripDetails(tripsDetail);
			tripDAO.callStoredProc(tripsDetail);
			if(tripid > 0){
					upcomingtrip(mapping, form, request, response);
			}
		///////////////////////////////////////////code change by lokesh
		/**this code is update current status on add Own Trip infomation on Linkedin.  */
		NetworkDAO socialnetwork = new NetworkDAO();
		User user = (User) new UserAccountDAO().getUserProfileDetails(userid);
		
		
		String startDate = request.getParameter("startDate");
		
		String endDate = request.getParameter("endDate");
		
		try {
		
			
		//code for sending email when adding trip by the user
			
		//return list of friends on base location
		List list =	new UserAccountDAO().getFriendEmailIdsOnBaseLocation(trip.getDestination(),userid,request.getParameter("startDate"),request.getParameter("endDate"));
		
		
		//System.out.println("base location "+list.size());
		
		//return list of friends on trip on that location
		List list1 = new UserAccountDAO().getFriendEmailIdsOnTrip(trip.getDestination(),userid);
		
		//System.out.println("in trip "+list1.size());
		
		
		List list2 = new ArrayList();
		
		if(list.size() != 0)
		{
			Iterator iterator= list.iterator();
			while(iterator.hasNext())
			{
				list2.add(iterator.next());
			}
		}
		
		Response r;
		String accessToken = socialnetwork.getAccessToken(userid,socialnetwork.getSocialNetworkId("Tripit"));
		System.out.println(accessToken);
		System.out.println(accessToken.split(",")[0]);
		System.out.println(accessToken.split(",")[1]);
		Credential cred = new OAuthCredential("391327d54d014e2b1f137e86ff1755cc9f66630b","9653d44f5a1320ba0429773b1c5a84b2a9c1d45d",accessToken.split(",")[0],accessToken.split(",")[1]);
		Client client = new Client(cred);
		Map<String, String> createMap = new HashMap<String, String>();
    	createMap.put("xml", "<Request><Trip><start_date>2013-04-09</start_date><end_date>2013-04-27</end_date><primary_location>Jamnagar, NY</primary_location></Trip></Request>");
    	r = client.create(createMap);
    	System.out.println(r);
		System.out.println("done");

		if(list1.size() != 0)
		{
			Iterator iterator2 = list1.iterator();
			while(iterator2.hasNext())
			{
				list2.add(iterator2.next());
			}
		}
	
		if(list2.size() != 0)
		{
				Iterator<String> iterator = list2.iterator();
				int i=0;
				String arr[] = new String[list2.size()];
				while(iterator.hasNext())
				{
						arr[i]=iterator.next();
						//System.out.println(arr[i]);
						i++;
				}
					HttpSession session = request.getSession();
					
					//header image
					String path = request.getContextPath();
					String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
					///mailer format 
					String htmlmessage = new Mailer_Header().getMailerHeader(bannar);

					
					String gender ="";
					if(user.getGender().equals("Male"))
					{
						gender="he";
					}
					else
					{
						gender="she";
					}
					
			htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'></td>" +
			"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
			"<p>Your meetIn friend " + session.getAttribute("name").toString() + " has added a trip and is traveling to "+trip.getDestination()+" between "+request.getParameter("startDate")+" to "+request.getParameter("endDate")+". </p>" +
			"      <p>We thought you would be interested in meeting up "+session.getAttribute("name").toString()+" while "+gender+" is there.</p>      <p>You can contact "+session.getAttribute("name").toString()+" with your availability on "+user.getEmail()+"</p>" +
			"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p>Keep your trips updated so your friends can also get alerts and contact you.</p></td>" +
			"  </tr>  <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
			"  </tr></table></td>  </tr>";	 
					

			String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
			String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
			String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
			String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
				
				
			htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

		
					/*
	//format for email message 
		String path = request.getContextPath();
		String meetinLogo = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/meetin_icon.png";
		String invitemessage = " "+session.getAttribute("name").toString() + " has added Trip to " + trip.getDestination() + " from " + request.getParameter("startDate") +"  to " + request.getParameter("endDate") + ".";
				     
		String htmlmessage = "<div style=\"width: 500px;\">";
		 htmlmessage += "<div style=\"background-color: rgb(255, 153, 0); padding: 5px 10px; color: rgb(255, 255, 255); font-family: 'Trebuchet MS'; font-size: 18px;\"><img src="
			+ meetinLogo
			+ " align=\"absmiddle\" hspace=\"5\"></img><strong>Meetin Trip Added</strong></div>";
			htmlmessage += "<div style=\"margin-top: 10px; padding: 0px 10px; font-family: 'Trebuchet MS';\"> ";
	//		htmlmessage += "<div style=\"color: rgb(0, 153, 255); font-size: 13px; font-weight: bold;\">Hi "+friendname1 + ",</div> ";
					//htmlmessage += "<div style=\"padding: 10px 10px 10px 0px;float:left;\"><img src="+ imageName + " width=\"75px\" height=\"75px\"></div>";
					htmlmessage += "<div style=\"font-family: 'Trebuchet MS';padding: 10px 0px;float:left;\">"+ invitemessage + "</div>";
					htmlmessage += "<div style=\"font-family: 'Trebuchet MS'; font-size: 13px;clear:both;\">Regards, <br> meetIn Team</div></div></div>";
					*/
			
			//System.out.println("mails");
			//System.out.println(arr.length);
			
			new InviteFriends().postMails(arr, "meetIn friend alert!!!",htmlmessage, session.getAttribute("name").toString());
		
			//System.out.println("mails");
		
		}
			
		} catch (Exception e) {
			//System.out.println("Exception E : " + e);
		}
			
	
		ResourceBundle resource;
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	
		String access_token = socialnetwork.getAccessToken(userid, socialnetwork.getSocialNetworkId("LinkedIn"));
		String access_token1 = socialnetwork.getAccessToken(userid, socialnetwork.getSocialNetworkId("Twitter"));
		
		
		//System.out.println("linked in value *************************************  "+request.getParameter("linkedinchk"));
		
		
		if(request.getParameter("linkedinchk") == null)
		{
			trip.setLinkedinchk(false);
		}
		
		if(request.getParameter("facebookchk") == null)
		{
			trip.setFacebookchk(false);
		}
		
		if(request.getParameter("twitterchk") == null)
		{
			trip.setTwitterchk(false);
		}
		
		try {
		
		if(trip.getLinkedinchk()== true && access_token!=null){
			LinkedIn linkedinapi= new LinkedIn();
			Hashtable<String, List<String>> Linkedin_friends = new Hashtable<String, List<String>>();
		
		
			//String access_token = socialnetwork.getAccessToken(userid, socialnetwork.getSocialNetworkId("LinkedIn"));
		
			Linkedin_friends = linkedinapi.getFriendsInfo(access_token);
		
			LinkedInAccessToken accessToken =new LinkedInAccessToken(access_token.split(",")[0], access_token.split(",")[1]);
			final LinkedInApiClientFactory factory = LinkedInApiClientFactory.newInstance(resource.getString("linkedin.consumer_key"),resource.getString("linkedin.consumer_secret"));
			final LinkedInApiClient client = factory.createLinkedInApiClient(accessToken);
			
			Person profile = client.getProfileForCurrentUser();
 			
			String linkedin_update_status = "I am in "+ trip.getDestination()+ " ["+ trip.getStartDate()+ " - "+ trip.getEndDate()+ "]. Contact "+ user.getEmail()+" (posted via www.mymeetin.com)";
			/**This is use for status Update on Linkedin from Add Trip */
			client.updateCurrentStatus(linkedin_update_status);
		}
		
		/**this code is update current status on add Own Trip infomation on twitter. */
		
		} catch (Exception e) {
			System.out.println("Linked eXception occured " +e);
		}
		
		//System.out.println("get twitter check "+trip.getTwitterchk());
		
		
		try {
			
		
		if(trip.getTwitterchk() == true && access_token1!=null ){
			
			System.out.println(" Twitter in");
			twitter twitterapi = new twitter();
			Hashtable<String, List<String>> twitter_friends = new Hashtable<String, List<String>>();
			String access_token_twitter = socialnetwork.getAccessToken(
					userid, socialnetwork.getSocialNetworkId("Twitter"));
			twitter_friends = twitterapi.getFriendsInfo(access_token_twitter);
			Twitter twitter = new TwitterFactory().getInstance();
			twitter.setOAuthConsumer("EOsMJlIu5ZdRlha1HRxuAA","09VQLBbMqpFTQTmeEKbsHi9qej00c8k6e5LQwmD0M4");
			String accesstoken [] = access_token_twitter.split(",");
			for(int i=0;i<accesstoken.length;i++){
				String token = accesstoken[0];
				String tokenSecret = accesstoken[1];
				twitter.setOAuthAccessToken(token, tokenSecret);
		}
			IDs ids  = twitter.getFriendsIDs();
			
			
			String twitter_update_status = "I am in "+ trip.getDestination()+ " ["+ trip.getStartDate()+ " - "+ trip.getEndDate()+ "]. Contact "+ user.getEmail()+" (posted via www.mymeetin.com)";
			/**This is use for status Update on twitter from Add Trip */
			Status status = twitter.updateStatus(twitter_update_status);
			
			System.out.println("status uploaded ");
			System.out.println("status uploaded ");
			System.out.println("status uploaded ");
		}
		
		} catch (Exception e) {
			System.out.println("Twitter error "  +e);
		}
		
		
		try {
		
		if(trip.getFacebookchk() == true)
		{
			String access_token_facebook = socialnetwork.getAccessToken(
					userid, socialnetwork.getSocialNetworkId("Facebook"));
			String facebook_wall_status = "I am in "+ trip.getDestination()+ " ["+ trip.getStartDate()+ " - "+ trip.getEndDate()+ "]. Contact "+ user.getEmail()+" (posted via www.mymeetin.com)";
			new facebookGraphAPI().postOnFacebookWall(facebook_wall_status, access_token_facebook);
		}
		
		} catch (Exception e) {
			System.out.println("facebook Exception  "  +e);
		}
		
		trip.setLinkedinchk(true);
		trip.setTwitterchk(true);
		trip.setFacebookchk(true);
		
		return mapping.findForward("success");
	}
	public ActionForward getedittrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{

		int tripId = Integer.parseInt(new String(new BASE64Decoder().decodeBuffer(request.getParameter("tp"))));
		String viewref = request.getParameter("ref");
		
		Trips trip = new TripsDAO().getTripById(tripId);
		
		request.setAttribute("trip", trip);
		request.setAttribute("ref", viewref);
		return mapping.findForward("edittrip");
		
	}
	public ActionForward updatetrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		//System.out.println("Trip Action.java -------------- updatetrip");
		
		
		Trips trip =(Trips)form;
		TripsDAO tripDAO= new TripsDAO();
		HttpSession sc = request.getSession(false);
		int userid = (Integer)sc.getAttribute("UserID");
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
		int tripID = Integer.parseInt(request.getParameter("tripId").trim());
		System.out.println("trip id value is "+tripID);
		Trips otrip = new Trips(tripID,userid,trip.getDestination(), trip.getDescription(), sdf.parse(trip.getStartDate()), sdf.parse(trip.getEndDate()),trip.getDestinationLatitude(),trip.getDestinationLongitude());
		int tripid = tripDAO.updateUserTrip(otrip); 
		tripDAO.deleteTripsDetail(tripID,userid);
		Trips_detail tripsDetail=new Trips_detail(1,tripID,userid,sdf.parse(trip.getStartDate()), sdf.parse(trip.getEndDate()),1,"DAY",trip.getDestination(),trip.getDestinationLatitude(),trip.getDestinationLongitude());
		//tripDAO.setUserTripDetails(tripsDetail);
		tripDAO.callStoredProc(tripsDetail);
		if(tripid > 0){
				upcomingtrip(mapping, form, request, response);
		}return mapping.findForward("upcomingtrip");
	}
	
	/** This is the action servlet to delete the user's trip details */
	public ActionForward removetrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		HttpSession sc = request.getSession();
		int userid = (Integer)sc.getAttribute("UserID");
		int tripID = Integer.parseInt(request.getParameter("tripId"));	
		int returnId = new TripsDAO().removeUserTrip(tripID);
		new TripsDAO().deleteTripsDetail(tripID,userid);
		
		return null;
	}
	public ActionForward upcomingtrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		System.out.println("Trip Action .java ------------------   upcomingtrip");
		
		HttpSession sc = request.getSession(false);
		int userid = (Integer)sc.getAttribute("UserID");
		
		
		List finalList = new ArrayList();
		
		
		
		List upcomingTrip = new ArrayList();
		upcomingTrip = new TripsDAO().getUserUpcomingTrips(userid);
		
		System.out.println("upcoming trip size "+upcomingTrip.size() );
		if(upcomingTrip.size() > 0 && upcomingTrip != null)
		{
			finalList.addAll(upcomingTrip);
			//finalList.add(upcomingTrip);
		}
	
		
		List TripitUserUpcomingTrip = new Tripit_Trips_DAO().getUserUpcomingTrips(userid);
		System.out.println(TripitUserUpcomingTrip.size());
		System.out.println(TripitUserUpcomingTrip.toString());
		if(TripitUserUpcomingTrip.size() > 0 && TripitUserUpcomingTrip != null)
		{
			finalList.addAll(TripitUserUpcomingTrip);
		}
		
		System.out.println("final list size "+finalList.size());
		
		if(upcomingTrip !=null && upcomingTrip.size() > 0)
		{
			request.setAttribute("upcomingtrip", upcomingTrip);
		}
		else
		{
			request.setAttribute("upcomingtrip", null);
		}
		
		if(TripitUserUpcomingTrip != null && TripitUserUpcomingTrip.size() >0)
		{
			request.setAttribute("TripitUserUpcomingTrip",TripitUserUpcomingTrip);
		}
		else
		{
			request.setAttribute("TripitUserUpcomingTrip",null);
		}
		
		
		if(request.getParameter("peoplefinder") != null)
			request.setAttribute("headerfooter", "false");
		else
			request.setAttribute("headerfooter", "true");
		request.setAttribute("content", "true");
		
		return mapping.findForward("upcomingtrip");

	}
	public ActionForward pasttrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession sc = request.getSession(false);
		int userid = (Integer)sc.getAttribute("UserID");
		List pastTrip = new ArrayList();
		pastTrip = new TripsDAO().getUserPastTrips(userid);
		
		if(pastTrip !=null && pastTrip.size() >0)
		{
			request.setAttribute("pasttrip", pastTrip);
		
		}
		else
		{
			request.setAttribute("pasttrip", null);	
		}
		
	    return mapping.findForward("pasttrip");
	}
	public ActionForward suggesttrip(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession sc = request.getSession(false);
		int userId = (Integer)sc.getAttribute("UserID");
		SuggestTripDTO f = (SuggestTripDTO)form;
		List suggestionList = new ArrayList();
		
		switch (f.getSocialMedia()) {
		case TripConstraint.SOCIAL_MEDIA_MEETIN:
			
			SuggestTrip oSuggesetTrip = new SuggestTrip();
			suggestionList = oSuggesetTrip.getSuggestTripListByMeetIn(userId);
			if(!f.getStartDate().equals("") && !f.getEndDate().equals(""))
			{
				suggestionList = oSuggesetTrip.getSuggestTripListByMeetIn(userId, f.getStartDate(), f.getEndDate());
			}
			
			break;
			
		default:
			suggestionList = new SuggestTrip().getSuggestTripListBySocialNetwork(userId, f.getSocialMedia());
			break;
		}
		
		request.setAttribute("suggestTrip", suggestionList);
		
		return mapping.findForward("success");
	}
	
	public ActionForward suggesttripfriends(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession sc = request.getSession();
		int userId = (Integer)sc.getAttribute("UserID");
		int socialId = Integer.parseInt(request.getParameter("socialParam"));
		String cityName = request.getParameter("cityName");
		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		ArrayList friends = null;
		
		switch (socialId) {
		case TripConstraint.SOCIAL_MEDIA_MEETIN:
			
			SuggestTrip oSuggesetTrip = new SuggestTrip();
			friends = new ArrayList(oSuggesetTrip.getSuggestMeetInFriendList(userId, cityName).values());
			
			if(!fromDate.equals("") && !toDate.equals(""))
			{
				friends = new ArrayList(oSuggesetTrip.getSuggestMeetInFriendList(userId, cityName, fromDate, toDate).values());
				request.setAttribute("tripFriend", true);
			}
			
			break;

		default:
			friends = new ArrayList(new SuggestTrip().getSuggestSocialFriendList(userId, socialId, cityName).values());
			break;
		}
			
		sortList(friends);
		
		sc.setAttribute("start", 0);
		sc.setAttribute("end", (friends.size() > 10 ? 10 : friends.size()));
		sc.setAttribute("cityName", cityName);	
		sc.setAttribute("friends", friends);
		
		return mapping.findForward("suggesttripfriends");
	}
	
	public ActionForward navigateFriendList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession session = request.getSession();
		ArrayList friends = (ArrayList) session.getAttribute("friends");
		String event = (String) request.getParameter("e");
		int start = Integer.parseInt(session.getAttribute("start").toString());
        int end = Integer.parseInt(session.getAttribute("end").toString());
        
		if(event !=null && event.equalsIgnoreCase("Last")){
			end = friends.size();
	    	if(friends.size() < 10)
	    		start = 0;
	    	else
	    	{
	    		start = (friends.size() / 10) * 10;
	    		if(start == friends.size())
					start = start - 10;
	    	}	
		}if(event !=null && event.equalsIgnoreCase("First")){
			start = 0;
			end = (friends.size() < 10) ? friends.size(): 10;
        	
		}if(event !=null && event.equalsIgnoreCase("Next")){
			 start = end;
			 				
             if(friends.size() < 10){
                     end = friends.size();
             }else if((end+10) < friends.size()){ 
                     end = end + 10;
             }else if((end+10) > friends.size()){
                     end = end + (friends.size() - end);
             }else if((end+10) >= friends.size()){
                     end = friends.size();
             }
             
             
		}if(event != null && event.equalsIgnoreCase("Prev")){
			 
			if(start >= 10){
                     start = start - 10;
             }else if(start < 10){
                     start = start - start;
             }
             end = start + 10;
             
         }if(event !=null && event.equalsIgnoreCase("page_combo")){
        	 
        	String[] s = request.getParameter("paging").split("-");
         	start = Integer.parseInt(s[0]);
         	end = Integer.parseInt(s[1]);
         }
			
    	session.setAttribute("end", end);
    	session.setAttribute("start", start);
    	
    	
    	System.out.println(" *** "+start);
    	System.out.println(" --- "+end);
    	return mapping.findForward("suggesttripfriends");
	}
	
	public ActionForward suggesttripfriendsTripDetail(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		HttpSession sc = request.getSession(false);
		Integer myuserId = (Integer)sc.getAttribute("UserID");
		Integer friendId = Integer.parseInt(request.getParameter("friendId"));
		String cityName = request.getParameter("cityName");
		String fromDate = request.getParameter("startDate");
		String toDate = request.getParameter("endDate");
		
		if (myuserId != null && myuserId.intValue() != 0) 
		{

			List tripdetailsList = new SuggestTrip().getSuggestFriendsTripDetail(myuserId, friendId, cityName, fromDate, toDate);

			if (tripdetailsList != null && tripdetailsList.size() > 0){
				request.setAttribute("ViewPeopleTripDetail", tripdetailsList);
			}else{
				request.setAttribute("ViewPeopleTripDetail", null);
			}

			return mapping.findForward("viewuserupcomingtrips");
		}
		
		return null;
	}
	
	public ActionForward addtripwizard(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request,HttpServletResponse response) throws Exception{
				System.out.println("Trip Action.java----add trip methdod");
		
		   	
			TripsDAO tripDAO= new TripsDAO();
			Trips trip = new Trips();
			HttpSession sc = request.getSession(false);
			int userid = (Integer)sc.getAttribute("UserID");
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
			String tripDestination = request.getParameter("destination");
			String tripDescription = request.getParameter("description");
			String tripstartDate = request.getParameter("startDate");
			String tripendDate = request.getParameter("endDate");
			String destinationLatitude = request.getParameter("destinationLatitude");
			String destinationLongitude = request.getParameter("destinationLongitude");
			
			Trips otrip = new Trips(userid, tripDestination, tripDescription, sdf.parse(tripstartDate), sdf.parse(tripendDate),destinationLatitude, destinationLongitude);
			
			int tripid = tripDAO.setUserTrip(otrip); 
			if(tripid > 0){
					upcomingtrip(mapping, form, request, response);
			}
		///////////////////////////////////////////code change by lokesh
		/**this code is update current status on add Own Trip infomation on Linkedin.  */
		NetworkDAO socialnetwork = new NetworkDAO();
		User user = (User) new UserAccountDAO().getUserProfileDetails(userid);
				
		try {
		
			
		//code for sending email when adding trip by the user
			
		//return list of friends on base location
		List list =	new UserAccountDAO().getFriendEmailIdsOnBaseLocation(tripDestination,userid, tripstartDate,tripendDate);
		
		
		//System.out.println("base location "+list.size());
		
		//return list of friends on trip on that location
		List list1 = new UserAccountDAO().getFriendEmailIdsOnTrip(tripDestination,userid);
		
		//System.out.println("in trip "+list1.size());
		
		
		List list2 = new ArrayList();
		
		if(list.size() != 0)
		{
			Iterator iterator= list.iterator();
			while(iterator.hasNext())
			{
				list2.add(iterator.next());
			}
		}
		
		
		if(list1.size() != 0)
		{
			Iterator iterator2 = list1.iterator();
			while(iterator2.hasNext())
			{
				list2.add(iterator2.next());
			}
		}
	
		if(list2.size() != 0)
		{
				Iterator<String> iterator = list2.iterator();
				int i=0;
				String arr[] = new String[list2.size()];
				while(iterator.hasNext())
				{
						arr[i]=iterator.next();
						//System.out.println(arr[i]);
						i++;
				}
					HttpSession session = request.getSession();
					
					//header image
					String path = request.getContextPath();
					String bannar = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/banner.jpg";
					///mailer format 
					String htmlmessage = new Mailer_Header().getMailerHeader(bannar);

					
					String gender ="";
					if(user.getGender().equals("Male"))
					{
						gender="he";
					}
					else
					{
						gender="she";
					}
					
			htmlmessage = htmlmessage + "  <tr>    <td align='left' valign='top'><table width='100%' border='0' cellspacing='0' cellpadding='0' style='background:#000; border-bottom:solid 1px #ff8c19; padding:25px;'>" +
			"  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'></td>" +
			"  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif;'>" +
			"<p>Your meetIn friend " + session.getAttribute("name").toString() + " has added a trip and is traveling to "+tripDestination+" between "+tripstartDate+" to "+tripendDate+". </p>" +
			"      <p>We thought you would be interested in meeting up "+session.getAttribute("name").toString()+" while "+gender+" is there.</p>      <p>You can contact "+session.getAttribute("name").toString()+" with your availability on "+user.getEmail()+"</p>" +
			"</td>  </tr>  <tr>    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#fff; font-family: Helvetica, Arial, sans-serif; margin:0;'><p>Keep your trips updated so your friends can also get alerts and contact you.</p></td>" +
			"  </tr>  <tr>" +
			"    <td align='left' valign='top' style='font-size:14px; font-weight:normal; color:#ff8c19; font-family: Helvetica, Arial, sans-serif; margin:0;'></td>" +
			"  </tr></table></td>  </tr>";	 
					

			String facebookimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/fb_icon.png";
			String twitterimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/tw_icon.png";
			String androidimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/android_icon.png";
			String iphoneimage = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/images/iphone-icon.png";
				
				
			htmlmessage = htmlmessage + new Mailer_Header().getMailerFooter(facebookimage,twitterimage,androidimage,iphoneimage);

		
			
			new InviteFriends().postMails(arr, "meetIn friend alert!!!",htmlmessage, session.getAttribute("name").toString());
		
		
		}
			
		} catch (Exception e) {
			
		}
			
	
		ResourceBundle resource;
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	
		String access_token = socialnetwork.getAccessToken(userid, socialnetwork.getSocialNetworkId("LinkedIn"));
		String access_token1 = socialnetwork.getAccessToken(userid, socialnetwork.getSocialNetworkId("Twitter"));
		
		Boolean linkedInCheckbox = Boolean.parseBoolean(request.getParameter("linkedinchk"));
		Boolean facebookCheckbox = Boolean.parseBoolean(request.getParameter("facebookchk"));
		Boolean twitterCheckbox = Boolean.parseBoolean(request.getParameter("twitterchk"));

		
		try {
		
			if(linkedInCheckbox && access_token!=null){
			LinkedIn linkedinapi= new LinkedIn();
			Hashtable<String, List<String>> Linkedin_friends = new Hashtable<String, List<String>>();
		
		
			//String access_token = socialnetwork.getAccessToken(userid, socialnetwork.getSocialNetworkId("LinkedIn"));
		
			Linkedin_friends = linkedinapi.getFriendsInfo(access_token);
		
			LinkedInAccessToken accessToken =new LinkedInAccessToken(access_token.split(",")[0], access_token.split(",")[1]);
			final LinkedInApiClientFactory factory = LinkedInApiClientFactory.newInstance(resource.getString("linkedin.consumer_key"),resource.getString("linkedin.consumer_secret"));
			final LinkedInApiClient client = factory.createLinkedInApiClient(accessToken);
			
			Person profile = client.getProfileForCurrentUser();
 			
			String linkedin_update_status = "I am in "+ tripDestination + " ["+ tripstartDate + " - "+ tripendDate + "]. Contact "+ user.getEmail()+" (posted via www.mymeetin.com)";
			/**This is use for status Update on Linkedin from Add Trip */
			client.updateCurrentStatus(linkedin_update_status);
		}
		
		} catch (Exception e) {
			System.out.println("Linked Exception" +e);
		}		
			
			
		try {
			
		
		/** This code is update current status on add Own Trip infomation on twitter. */
				
		if(twitterCheckbox && access_token1!=null ){
			
			twitter twitterapi = new twitter();
			Hashtable<String, List<String>> twitter_friends = new Hashtable<String, List<String>>();
			String access_token_twitter = socialnetwork.getAccessToken(
					userid, socialnetwork.getSocialNetworkId("Twitter"));
			twitter_friends = twitterapi.getFriendsInfo(access_token_twitter);
			Twitter twitter = new TwitterFactory().getInstance();
			twitter.setOAuthConsumer("EOsMJlIu5ZdRlha1HRxuAA","09VQLBbMqpFTQTmeEKbsHi9qej00c8k6e5LQwmD0M4");
			String accesstoken [] = access_token_twitter.split(",");
			for(int i=0;i<accesstoken.length;i++){
				String token = accesstoken[0];
				String tokenSecret = accesstoken[1];
				twitter.setOAuthAccessToken(token, tokenSecret);
		}
			IDs ids  = twitter.getFriendsIDs();
			
			
			String twitter_update_status = "I am in "+ tripDestination + " ["+ tripstartDate + " - "+ tripendDate + "]. Contact "+ user.getEmail()+" (posted via www.mymeetin.com)";
			/**This is use for status Update on twitter from Add Trip */
			Status status = twitter.updateStatus(twitter_update_status);
		}
		
		} catch (Exception e) {
			System.out.println("Twitter Exception " +e);
		}

		try {
		if(facebookCheckbox)
		{
			String access_token_facebook = socialnetwork.getAccessToken(
					userid, socialnetwork.getSocialNetworkId("Facebook"));
			String facebook_wall_status = "I am in "+ tripDestination + " ["+ tripstartDate + " - "+ tripendDate + "]. Contact "+ user.getEmail()+" (posted via www.mymeetin.com)";
			new facebookGraphAPI().postOnFacebookWall(facebook_wall_status, access_token_facebook);
		}
		
		} catch (Exception e) {
			System.out.println("Facebook Exception  " +e);
		}
		
		return null;
	}
	
	public void sortList(ArrayList myArrayList)
	{
		Collections.sort(myArrayList, new Comparator() {
			public int compare(Object o1, Object o2) {
				
				int result=0;
				String value1 = (String)((List<String>) o1).get(0);
				String value2 = (String)((List<String>) o2).get(0);
				
				result=value1.compareToIgnoreCase(value2);

				return result;
			}
		});
	}

}
