package com.verve.meetin.trip;

import org.apache.struts.action.ActionForm;

import com.restfb.Facebook;
import com.restfb.json.JsonObject;

public class SuggestTripDTO extends ActionForm 
{

	private int socialMedia;
	private String startDate;
	private String endDate;
		
	@Facebook
	private JsonObject current_location;
	
	@Override
	public String toString() {
	
		if(current_location !=null)
		{
			return current_location.getString("city");
		}
		
		return "";
	}
	
	public JsonObject getCurrent_location() {
		return current_location;
	}

	public void setCurrent_location(JsonObject currentLocation) {
		current_location = currentLocation;
	}	
	
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}


	public int getSocialMedia() {
		return socialMedia;
	}

	public void setSocialMedia(int socialMedia) {
		this.socialMedia = socialMedia;
	}

}
