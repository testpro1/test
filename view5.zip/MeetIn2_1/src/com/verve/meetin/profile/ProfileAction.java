package com.verve.meetin.profile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.sun.xml.ws.rm.jaxws.runtime.Session;
import com.verve.meetin.friend.Friends;
import com.verve.meetin.friend.FriendsDAO;
import com.verve.meetin.interest.Interest;
import com.verve.meetin.interest.InterestDAO;
import com.verve.meetin.user.User;
import com.verve.meetin.user.UserAccountDAO;
import com.verve.meetin.visitor.VisitorsDAO;

public class ProfileAction extends DispatchAction {

	public ActionForward aboutme(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		//System.out.println("profileaction.java *------------------------------**  aboutme method called ");
		
		UserAccountDAO userAccount = new UserAccountDAO();
		HttpSession userSession = request.getSession(false);
		
		request.setAttribute("userinfo",userAccount.getPostLoginDetails(Integer.parseInt(userSession.getAttribute("UserID").toString())));
		
		return mapping.findForward("aboutme");
	}
	// This action indicate the user is on about me page as post login part
	public ActionForward aboutmeAspostlogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		UserAccountDAO userAccount = new UserAccountDAO();
		HttpSession userSession = request.getSession(false);
		request.setAttribute("userinfo", 
				userAccount.getPostLoginDetails(
						Integer.parseInt(userSession.getAttribute("UserID").toString())));
		return mapping.findForward("aboutmeAspostlogin");
	}
	
	// This action indicate the user is on set up network page as post login part
	public ActionForward setupnetworkAspostlogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		return mapping.findForward("setupnetworkAspostlogin");
	}
	
	public ActionForward setupnetwork(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		return mapping.findForward("setupnetwork");
	}
	
	public ActionForward privacysetting(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		return mapping.findForward("privacysetting");
	}
	
	public ActionForward privacysettingAspostlogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		return mapping.findForward("privacysettingAspostlogin");
	}
	
    /**Action servlet to get the list of Profile visitors for a user */
	public ActionForward profilevisitors(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		//System.out.println("ProfileAction.java === ///  profilevisitors action");
		
		VisitorsDAO visitors = new VisitorsDAO();
		HttpSession userSession = request.getSession(false);
		Integer userid = (Integer)userSession.getAttribute("UserID");
		List requeststatusList = new ArrayList();
		Friends friend = null;
		
		if(userid !=null && userid.intValue() > 0)
		{
			List visitorList = new VisitorsDAO().getProfileVisitorList(userid);
			
			
			if(visitorList !=null && visitorList.size() >0)
			{
				for(int i=0;i < visitorList.size();i++)
			    {
				   Object[] object= (Object[])visitorList.get(i);
				   /**Code to check out the status of profile visitor to the current user (Ex. connected,request pending...)*/
			       friend = (Friends) new FriendsDAO().checkFriendRequest(userid,(Integer)object[1]);
			       /**Store the visitor's connection status with the visitee in to list*/
			       requeststatusList.add(friend);
			       
			    }
				  
			    request.setAttribute("visitors_info", visitorList);
			    request.setAttribute("checkRequestStatus", requeststatusList);
			}
			
			return mapping.findForward("profilevisitors");
		}
		
		return null;
	}
	 /**Action servlet to accept friend request from Profile visitors view */
	public ActionForward acceptrequest(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		HttpSession sc = request.getSession();
		Integer userid = (Integer)sc.getAttribute("UserID");
		
		String friendRequestId = request.getParameter("friendrequestId");
		
		int friend_approve_id = 0;
		friend_approve_id = new FriendsDAO().approveFriendRequest(Integer.parseInt(friendRequestId));
		if(friend_approve_id >0)
		{
			profilevisitors(mapping, form, request, response);
		}
		return null;
	}
	/**Action servlet to add friend from Profile visitors view */
	public ActionForward addasfriend(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		//System.out.println("ProfileAction.java -------------   addasfriend method called ");
		
		
		HttpSession sc= request.getSession();
		Integer useridfrom =(Integer)sc.getAttribute("UserID");
		Integer useridto = Integer.parseInt(request.getParameter("id"));
		if(useridfrom !=null && useridfrom.intValue() != 0)
		{
			Friends friend = new Friends(useridfrom, useridto,"Pending", new Date());
			int friend_request_id = new FriendsDAO().setFriendRequest(friend);
			
			if(friend_request_id >0 )
			{
				profilevisitors(mapping, form, request, response);
			}
		}
		
		return null;
	}
	
	public ActionForward interest(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		HttpSession sc= request.getSession();
		List<Integer> userinterestId =null;
		Integer userid =(Integer)sc.getAttribute("UserID");
		
	    
		if(userid !=null && userid.intValue() !=0)
		{
			List interestList = new InterestDAO().getInterest();
			
			if(interestList !=null && interestList.size() > 0)
			{
				List userinterestList = new InterestDAO().getUserInterest(userid);
				userinterestId = new ArrayList<Integer>();
				
				for(int i =0;i < userinterestList.size();i++)
				{
					Object[] object =(Object[])userinterestList.get(i);
					userinterestId.add((Integer)object[0]);
				}
				
			}
			
			request.setAttribute("Interest", interestList);
			request.setAttribute("UserInterest", userinterestId);
			return mapping.findForward("interest");
		}
		
		return null;
	}
	
	public ActionForward updateinterest(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		
		String[] interestArray = request.getParameter("interestid").split("_");
		
		InterestDAO interestDAO = new InterestDAO();
		HttpSession sc= request.getSession();
		Integer userid =(Integer)sc.getAttribute("UserID");	
		Integer countResult = 0;
		if(interestArray !=null && interestArray.length > 0){
			
			countResult = new InterestDAO().removeUserInterest(userid);
			//if(countResult > 0){
				for(int i=0; i < interestArray.length;i++){
					Interest interest = new Interest(userid, Integer.parseInt(interestArray[i]));
			   		interestDAO.setUserInterest(interest);
		   		}
			//}
		}
		
		interest(mapping, form, request, response);
		//return mapping.findForward("interest");
		return mapping.findForward("setupnetwork");
	}
	public ActionForward setuplocation(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		return mapping.findForward("setuplocation");
	}
	
	/*Action servlet to change the user default location **/
	public ActionForward location_edit(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		//System.out.println("ProfileAction.java ----------  location edit method called ");
		
		HttpSession sc = request.getSession();
		
		Integer userId =(Integer)sc.getAttribute("UserID");
		
		if(userId !=null && userId.intValue() !=0)
		{
			
			User user = new UserAccountDAO().getUserLocationDetails(userId);
			
			//HttpSession session = request.getSession();
			//session.setAttribute("UserLocation", user);
			
			request.setAttribute("UserLocation", user);
			return mapping.findForward("success");
		}
		
		return null;
	}
	
	/*Action servlet to change the user password**/
	public ActionForward changepassword(ActionMapping mapping,ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		HttpSession sc = request.getSession();
		Integer userId = (Integer)sc.getAttribute("UserID");
		
		if(userId !=null && userId.intValue() !=0)
		{
			String oldpassword = request.getParameter("oldpassword");
			String newpassword = request.getParameter("newpassword");
			int changeResult = new UserAccountDAO().changeUserPassword(userId, oldpassword, newpassword);
			request.setAttribute("ChangePasswordResult", changeResult);
			return mapping.findForward("changepassword");	
		}
		
		return mapping.findForward("login");
	}
	
	public ActionForward changepasswordAdmin(ActionMapping mapping,ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		
		HttpSession sc = request.getSession();
		
		String username = sc.getAttribute("username").toString();
		
		if(username !=null)
		{
			String oldpassword = request.getParameter("oldpassword");	
			String newpassword = request.getParameter("newpassword");
			
			HttpSession session =request.getSession();
			System.out.println("username ::  "+		session.getAttribute("username"));
			
			int changeResult = new UserAccountDAO().changeUserPasswordAdmin(session.getAttribute("username").toString(),oldpassword, newpassword);
			request.setAttribute("ChangePasswordResult", changeResult);
			return mapping.findForward("changepasswordAdmin");	
		}
		
		return mapping.findForward("login");
	}		
	
	
	
}
