package com.verve.meetin.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
 
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
public class SessionFilter implements Filter {
	
	private ArrayList<String> urlList;
	
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req=null;
        HttpServletResponse res = null; 
		
		try
		{
			req = (HttpServletRequest) request;
	        res = (HttpServletResponse) response;
	        HttpSession session = req.getSession();
	        String url = req.getServletPath();
	        
	        boolean allowedRequest = false;
	   
	        if(urlList.contains(url)) {
	            allowedRequest = true;
	        }
	 
	        if (!allowedRequest) {
	            
	            if (session.getAttribute("UserID") == null) {
	                res.sendRedirect("mymeetin.jsp");
	            }
	        }
	        else if(url.equals("/accessToken.jsp")) {
	        	
	        }
	 
	        chain.doFilter(req, res);    
		}
		catch(Exception ex)
		{
			res.sendRedirect("mymeetin.jsp");
		}
		
		
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		String urls = filterConfig.getInitParameter("avoid-urls");
        StringTokenizer token = new StringTokenizer(urls, ",");
 
        urlList = new ArrayList<String>();
 
        while (token.hasMoreTokens()) {
            urlList.add(token.nextToken());
 
        }
	}

}
