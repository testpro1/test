package com.verve.meetin.common;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CommonUtil 
{
	private String webserviceurl;
	private String weburl;
	private String privacyurl;
	private String setupnetworkurl;
	
	public CommonUtil()
	{
		
	}
	
	
	public String getWebserviceurl() {
		return webserviceurl;
	}

	public String getWeburl() {
		return weburl;
	}

	public void setWebserviceurl(String webserviceurl) {
		this.webserviceurl = webserviceurl;
	}

	public void setWeburl(String weburl) {
		this.weburl = weburl;
	}
	public String getPrivacyurl() {
		return privacyurl;
	}
	public void setPrivacyurl(String privacyurl) {
		this.privacyurl = privacyurl;
	}
	public String getSetupnetworkurl() {
		return setupnetworkurl;
	}
	public void setSetupnetworkurl(String setupnetworkurl) {
		this.setupnetworkurl = setupnetworkurl;
	}

	

}
