package com.verve.meetin.foursquare;

import java.io.BufferedReader; 
import java.io.IOException; 
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.json.JSONArray;
import org.json.JSONObject;
import org.quartz.SimpleTrigger;

import com.google.code.facebookapi.schema.Group;
import com.restfb.json.JsonObject;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.network.peoplefinder.SocialNetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDummy;
import com.verve.meetin.tripit.Tripit_Trips;



import fi.foyt.foursquare.api.FoursquareApi;
import fi.foyt.foursquare.api.FoursquareApiException;
import fi.foyt.foursquare.api.FoursquareEntity;
import fi.foyt.foursquare.api.Result;
import fi.foyt.foursquare.api.entities.Checkin;
import fi.foyt.foursquare.api.entities.CompactUser;
import fi.foyt.foursquare.api.entities.CompactVenue;
import fi.foyt.foursquare.api.entities.UserGroup;
import fi.foyt.foursquare.api.entities.VenueGroup;
import fi.foyt.foursquare.api.entities.VenuesSearchResult;
 

/***
 * @author dharam
 *	
 *This Class As a Foursquare DAO class and contains method for Database rElated	
 *
 */

public class foursquareDemo 
{
	
	/**
	 *  @param list
	 *  This method is used to save Foursquare Checkin List to Database
	 *  
	 *  Paramter contains list of foursquare checkin object
	 */
	public void saveFourSquareData(List<FourSquareCheckin> list)
	{
		System.out.println("in "+list.size());
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			tx = session.beginTransaction();
						
			if(list !=null && list.size() > 0)
			{
				Iterator itr = list.iterator();
				while(itr.hasNext())
				{
					FourSquareCheckin s = (FourSquareCheckin)itr.next();
					session.save(s);
				}
				tx.commit();
			}
		}
		catch(Exception ex)
		{
			tx.rollback();
			ex.printStackTrace();
		}
	}
	
	/**
	 * This method return Foursquare checkin object in the form of List
	 * and contains userId and socialId as parameter
	 * 
	 *    socialId means network id provided to network 
	 */
	
	public List getFourSquareCheckInFriends(int userId,int socialid)
	  {
	        List resultList =null;
	        String queryString ="select s.userId,s.fullname,s.location,s.profileUrl,s.id,u.socialNetworkSiteIcon,s.profileImage,s.date from FourSquareCheckin as s, Networkmaster u" +
	                " where s.socialId = u.socialNetworkSiteId and  s.userId = ? and s.socialId = ? order by s.fullname";
	         
	        List finalList = null;
	        try
	        {
	                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
	                session.beginTransaction();
	                Query query = session.createQuery(queryString);
	                query.setParameter(0, userId);
	                query.setParameter(1, socialid);
	                resultList = query.list();
	                session.getTransaction().commit();
	        }
	        catch(Exception ex)
	        {
	            ex.printStackTrace();
	        }
	        SimpleDateFormat sFormat = new SimpleDateFormat("dd-MMM-yyyy");
	        for (int i = 0; i <resultList.size() ; i++) 
	        {
	        	Object object[] = (Object[]) resultList.get(i);
				object[1] = object[1] + " (" + sFormat.format((Date)object[7]).toString() + ")";
				String nameDate =(String) object[1] ;
				//System.out.println("Date Given  "+nameDate);
	       }
	       
	       return resultList;
	  }
	
	/*
	 * created By Dharam	
	 * used to get FoursquareCheckinByfriends stored in database
	 *
	 * userId is passed as parameter
	 * for myfriends 
	 */
	public List getFourSquareCheckInFriends(int userId)
	  {
	      
	        
	        List resultList =null;
	        String queryString ="select s.userId,s.fullname,s.location,s.profileUrl,s.id,u.socialNetworkSiteIcon,s.profileImage from FourSquareCheckin as s, Networkmaster u" +
	                " where s.socialId = u.socialNetworkSiteId and  s.userId = ? order by s.fullname";
	        try
	        {
	                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
	                session.beginTransaction();
	                Query query = session.createQuery(queryString);
	                query.setParameter(0, userId);
	                resultList = query.list();
	                session.getTransaction().commit();
	        }
	        catch(Exception ex)
	        {
	            ex.printStackTrace();
	        }
	        
	        return resultList;
	  }
	
	/*
	 * created By Dharam	
	 * used to get FoursquareCheckinByfriends stored in database
	 * 
	 * userId is passed as parameter
	 * location is passed as parameter to filter based on location
	 * for peoplefinder 
	 */
	
	public List getFourSquareCheckInFriends(int userId,String location)
	  {
	        List resultList =null;
	        String queryString ="select s.userId,s.fullname,s.location,s.profileUrl,s.id,u.socialNetworkSiteIcon,s.profileImage from FourSquareCheckin as s, Networkmaster u" +
	                " where s.socialId = u.socialNetworkSiteId and  s.userId = ? and s.location = ? order by s.fullname";
	        try
	        {
	                Session session = HibernateUtil.getSessionFactory().getCurrentSession();    
	                session.beginTransaction();
	                Query query = session.createQuery(queryString);
	                query.setParameter(0, userId);
	                query.setParameter(1, location);
	                resultList = query.list();
	                session.getTransaction().commit();
	        }
	        catch(Exception ex)
	        {
	            ex.printStackTrace();
	        }
	        
	        return resultList;
	  }
	
	
	
/*
	public static void main(String args[])
	{
	
		try {
					
		FoursquareApi foursquareApi = new FoursquareApi("NTNIEQBZFTGUDTHV2ASQQMVBOAKRH2KOYSD3SC2QLUJKHOJZ", "MTXKTKSDMOD1L04LOSHT4VE4020AHZRJL3AND5A5YKBSR4VB", "http://localhost:8080/MeetIn2/servlet/foursquareAuthenticate");
    	
    // After client has been initialized we can make queries.
    Result<VenuesSearchResult> result = foursquareApi.venuesSearch("23.039567,72.566004", null, null, null, null, null, null, null, null, null, null);
    
    
    System.out.println("venye length"+	result.getResult().getVenues().length);
    
    
    
    
    if (result.getMeta().getCode() == 200)
    {
    	
    	
    	// if query was ok we can finally we do something with the data
      for (CompactVenue venue : result.getResult().getVenues())
      {
        // TODO: Do something we the data
        System.out.println(venue.getName());
        	
      }
    } 
    else
    {
      // TODO: Proper error handling
      System.out.println("Error occured: ");
      System.out.println("  code: " + result.getMeta().getCode());
      System.out.println("  type: " + result.getMeta().getErrorType());
      System.out.println("  detail: " + result.getMeta().getErrorDetail()); 
    }

    
		} catch (Exception e) {
			// TODO: handle exception
		}
    
	}*/
	
	
	/*public void getfoursquareDump(String accessToken,int userId,String sessionId ,int socialId)
	{
		System.out.println("Method called ");
		try {
				
			FoursquareApi foursquareApi =  new FoursquareApi("NTNIEQBZFTGUDTHV2ASQQMVBOAKRH2KOYSD3SC2QLUJKHOJZ", "MTXKTKSDMOD1L04LOSHT4VE4020AHZRJL3AND5A5YKBSR4VB", "http://localhost:8080/MeetIn2/foursquareAuthentication.jsp");
			//foursquareApi.authenticateCode(accessToken);
			Result<UserGroup>  result = foursquareApi.usersFriends("self");
			CompactUser compactUser[]  = result.getResult().getItems();
			
			System.out.println("number of friends are "+	compactUser.length);
		} catch (Exception e) {
			System.out.println("EXception occured " +e);
		} 
	}*/
	
	/*public void call() 
	{
		String responseString = "";
		String outputString = "";
		try {
		 String wsURL = "https://api.foursquare.com/v2/checkins/recent?oauth_token=BLQE0VR0VLX2ZC1KUVXYLHUNVGQ53XSEGUJAHJMQCPDPP2AD";
		 URL url = new URL(wsURL);
		 URLConnection connection;
		
		connection = url.openConnection();
		
		 HttpURLConnection httpConn = (HttpURLConnection)connection;
		
		// OutputStream out = httpConn.getOutputStream();
		 
		 System.out.println("Content length"+	httpConn.getContentLength()); 
		 
		 InputStreamReader isr =     new InputStreamReader(httpConn.getInputStream());
		 
		 BufferedReader in = new BufferedReader(isr);
		 
		 while ((responseString = in.readLine()) != null) {
		        outputString = outputString + responseString;
		    }
		 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	public void getFourSquareDump(String accessToken) throws Exception
	{
		ResourceBundle resource;
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		String client_id = resource.getString("foursquare.Client_id");
		String client_secret = resource.getString("foursquare.Client_secret");
		String redirect_uri =resource.getString("foursquare.Redirect_URI");
		FoursquareApi foursquareApi =  new FoursquareApi(client_id, client_secret,redirect_uri); 
		try {
			
			Checkin[] checkins = foursquareApi.checkinsRecent(null, null,null).getResult();
			System.out.println("checkins length: *******   " +checkins.length);	
		}
		catch (Exception e) {
			System.out.println("in catch");
			System.out.println("Exception occred " +e);
		}
		
	/*	String url ="https://foursquare.com/oauth2/authenticate?client_id="+client_id+"&response_type=code&redirect_uri="+URLEncoder.encode(redirect_uri.toString(),"UTF-8");
		     
		 
		URL u = new URL(url);
		BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
		while ((inputLine = in.readLine()) != null)
		{
			
			MY_ACCESS_TOKEN = inputLine;
		
		}
		
	    MY_ACCESS_TOKEN = MY_ACCESS_TOKEN.replace("access_token=","");
	    
	    if(MY_ACCESS_TOKEN.contains("&expires=")) {
	    	MY_ACCESS_TOKEN = MY_ACCESS_TOKEN.substring(0, MY_ACCESS_TOKEN.length()-16);
	    }
	    in.close();
	*/	
		
		
	}
	
	
	public String getFourSquareAccessToken(String code)
	{
		ResourceBundle resource;
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		
		String MY_ACCESS_TOKEN="";
		  String inputLine ="";
			String Client_Id = resource.getString("foursquare.Client_id");
			String Client_Secret = resource.getString("foursquare.Client_secret");
			String redirect_Uri = resource.getString("foursquare.Redirect_URI");

		try 
		{
	
		 String url ="https://foursquare.com/oauth2/access_token?client_id="+Client_Id+"&client_secret="+Client_Secret+
		 "&grant_type=authorization_code&redirect_uri="+URLEncoder.encode(redirect_Uri,"UTF-8")+"&code="+code;
		  
			
			
		  URL u = new URL(url);
		  BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			
			
			while ((inputLine = in.readLine()) != null)
			{	
				MY_ACCESS_TOKEN = inputLine;
			}
			    MY_ACCESS_TOKEN = MY_ACCESS_TOKEN.replace("access_token=","");
			    if(MY_ACCESS_TOKEN.contains("&expires=")) {
			    	MY_ACCESS_TOKEN = MY_ACCESS_TOKEN.substring(0, MY_ACCESS_TOKEN.length()-16);
			    }
			    in.close();
		 
		} catch (Exception e) {
			System.out.println("Exception occured : " + e);
		}
		
		MY_ACCESS_TOKEN = MY_ACCESS_TOKEN.substring(17, MY_ACCESS_TOKEN.length()-2);
	    return MY_ACCESS_TOKEN;
		
	}
	
	
	
	public void getFoursquareFriendsDump(String accessToken)
	{
		  String MY_ACCESS_TOKEN="";
		  String inputLine ="";
		
		try {
	
String url ="https://api.foursquare.com/v2/users/self?oauth_token=GYYNY1EPEHWXL0ISHXCYBNH13VYNB01WN1X1LJWKDFBAGJJM&v=20130516";
			
		
		 URL u = new URL(url);
		  BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			
			while ((inputLine = in.readLine()) != null)
			{	
				MY_ACCESS_TOKEN = inputLine;
				//System.out.println(" " + inputLine);
			}
		
			JSONObject object = new JSONObject(MY_ACCESS_TOKEN);
			
			JSONArray friends = object.getJSONObject("response").getJSONObject("user").getJSONObject("friends").getJSONArray("groups").getJSONObject(1).getJSONArray("items");
			

			for (int i = 0; i < friends.length(); i++) {
				
				JSONObject friendDetails = friends.getJSONObject(i);
				System.out.println(friendDetails);
			
				String prefix = friendDetails.getJSONObject("photo").getString("prefix");
					
				String suffix =	friendDetails.getJSONObject("photo").getString("suffix");
				
				String imagepath = prefix+suffix.substring(1,suffix.length());
				
			SocialNetworkDummy socialNetworkDummy = new SocialNetworkDummy("10", 8, 7, friendDetails.getString("firstName") + " " + friendDetails.getString("lastName"), "",imagepath, friendDetails.getString("homeCity"));
				
			}
			
			System.out.println(friends);
			
		
			in.close();
		
		} catch (Exception e) {
			System.out.println("Exception occured " + e);
		
		}
	}
		
	
	public List<SocialNetworkDummy> getFoursquareFriendsDump(String access_Token, int userId, String sessionId, int socialId)
	{
		System.out.println("in foursquare friends dummy");
		List<SocialNetworkDummy> friends = new ArrayList<SocialNetworkDummy>();
		  String MY_ACCESS_TOKEN="";
		  String inputLine ="";
		
		  
		  
		try {
	
String url ="https://api.foursquare.com/v2/users/self?oauth_token=GYYNY1EPEHWXL0ISHXCYBNH13VYNB01WN1X1LJWKDFBAGJJM&v=20130516";
			
		
		 URL u = new URL(url);
		  BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			
			while ((inputLine = in.readLine()) != null)
			{	
				MY_ACCESS_TOKEN = inputLine;
			}
				System.out.println("json object :  "+MY_ACCESS_TOKEN);
				JSONObject object = new JSONObject(MY_ACCESS_TOKEN);
			
			JSONArray group = object.getJSONObject("response").getJSONObject("user").getJSONObject("friends").getJSONArray("groups").getJSONObject(1).getJSONArray("items");
			

			for (int i = 0; i < group.length(); i++) {
				
				JSONObject friendDetails = group.getJSONObject(i);
				System.out.println(friendDetails);
			
				String prefix = "https://is1.4sqi.net/userpix_thumbs"; 
				//friendDetails.getJSONObject("photo").getString("prefix");
					
				String suffix =	friendDetails.getJSONObject("photo").getString("suffix");
				
				String imagepath = prefix+suffix;
				
			SocialNetworkDummy socialNetworkDummy = new SocialNetworkDummy(sessionId, userId, socialId, friendDetails.getString("firstName") + "" + friendDetails.getString("lastName"), "",imagepath, friendDetails.getString("homeCity"));
			
			friends.add(socialNetworkDummy);	
			}
		
			in.close();
		
		} catch (Exception e) {
			System.out.println("Exception occured " + e);
		
		}
		return friends;
	}
	
	public int removeFoursquareCheckinDump(int userId, int socialId)
	{
		System.out.println("inside remove Foursquare Checkin Dump");
		int row=0;
		String queryString ="delete from FourSquareCheckin as f where f.userId=?";
		
		try
		{
			System.out.println("trying to remove foursqure checkin dump");
			
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    row = query.executeUpdate();
		    tx.commit();
		    
		System.out.println("foursquare checkin dump removed successfully");
		    
		}
		catch(Exception ex)
		{
			System.out.println("There is a problem in foursquarecheckin deletion");
			System.out.println(""+ex);	
		}
		return row;
	}
	
	
	
	public void getFoursquareCheckinDump(String accessToken, int userId, String sessionId, int socialId)
	{
		System.out.println("foursquareCheckinDump");
		
		removeFoursquareCheckinDump(userId, socialId);
		
		  String MY_ACCESS_TOKEN="";
		  String inputLine ="";
		
		  SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		  Date date = new Date();
		  
		  System.out.println("Date is :: "+simpleDateFormat.format(date));
		try {
			String url ="https://api.foursquare.com/v2/checkins/recent?oauth_token="+accessToken+"&v="+simpleDateFormat.format(date);
			URL u = new URL(url);
			BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			while ((inputLine = in.readLine()) != null)
			{	
				MY_ACCESS_TOKEN = inputLine;
				System.out.println(" " + inputLine);
			}
			
			System.out.println("json object :  **  " + MY_ACCESS_TOKEN);
			JSONObject object = new JSONObject(MY_ACCESS_TOKEN);
			JSONArray checkins =	object.getJSONObject("response").getJSONArray("recent");
			List <FourSquareCheckin> friendsCheckin = new ArrayList<FourSquareCheckin>();
			
			
			for (int i = 0; i < checkins.length(); i++) 
			{
				try
				{
				JSONObject checkin = checkins.getJSONObject(i);
				
				/*System.out.println(checkin.getJSONObject("user").getString("firstName") +"name = " + checkin.getJSONObject("user").getString("lastName") );
				
				System.out.println(checkin.getJSONObject("venue").getJSONObject("location").getString("lat"));
				System.out.println(checkin.getJSONObject("venue").getJSONObject("location").getString("lng"));
				System.out.println(checkin.getJSONObject("venue").getJSONObject("location").getString("city"));
			*/
				
				JSONObject location = checkin.getJSONObject("venue").getJSONObject("location");
				
				String createdAt =checkin.getString("createdAt");
				Date  createdDate = new Date((Long.parseLong(createdAt))*1000);
			
				
				String friendname =checkin.getJSONObject("user").getString("firstName")+" "+checkin.getJSONObject("user").getString("lastName");
				String city =location.getString("city");
				
				String gender =checkin.getJSONObject("user").getString("gender");
				
				String prefix = "https://is1.4sqi.net/userpix_thumbs";
				String photoSuffix = checkin.getJSONObject("user").getJSONObject("photo").getString("suffix");
				String imagePath = prefix+photoSuffix;
				
				
				FourSquareCheckin fourSquareCheckin = new FourSquareCheckin(sessionId,userId, socialId+1,friendname,"",imagePath,city,gender,createdDate);
		    	friendsCheckin.add(fourSquareCheckin);
				
				System.out.println(checkin.getString("createdAt"));
				}
				catch (Exception e) {
						System.out.println("Exception occured " +e);
						continue;
				} 
			}
			
			new foursquareDemo().saveFourSquareData(friendsCheckin);
			
			in.close();
		
		} catch (Exception e) {
			System.out.println("Exception occured " + e);
		}
	}
	
	
	
	public static void main(String args[]) throws Exception
	{
		//List<SocialNetworkDummy>friends	=new foursquareDemo().getFoursquareFriendsDump("4GEPA3OS1KFHD40U1TWUI31OXDCHTBTE2G1VNW4GCR5QWVCX",8,"10",7);
		
		new foursquareDemo().getFoursquareCheckinDump("4GEPA3OS1KFHD40U1TWUI31OXDCHTBTE2G1VNW4GCR5QWVCX", 8, "", 7);
		//new  SocialNetworkDAO().saveSocialDummyData(friends);
	//   new foursquareDemo().getFoursquareCheckinDump("4GEPA3OS1KFHD40U1TWUI31OXDCHTBTE2G1VNW4GCR5QWVCX",8,"10",7);	
	}
	
}
