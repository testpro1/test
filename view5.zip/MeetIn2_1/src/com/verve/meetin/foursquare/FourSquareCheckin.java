package com.verve.meetin.foursquare;

import java.io.Serializable;
import java.util.Date;

public class FourSquareCheckin implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
    private String sessionId;
    private Integer userId;
    private Integer socialId;
    private String fullname;
    private String profileUrl;
    private String profileImage;
    private String location;
    private String gender;
    private Date date;
    
    public FourSquareCheckin(){
    	
    }
    
    public FourSquareCheckin(String sessionId, Integer userId, Integer socialId, String fullname,
    						String profileUrl, String profileImage, String location,String gender,Date date) {
     
    	this.sessionId = sessionId;
        this.userId = userId;
        this.socialId = socialId;
        this.fullname = fullname;
        this.profileUrl = profileUrl;
        this.profileImage = profileImage;
        this.location = location;
        this.gender = gender;
        this.date = date;
    }
    

    
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getSocialId() {
		return socialId;
	}
	public void setSocialId(Integer socialId) {
		this.socialId = socialId;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getProfileUrl() {
		return profileUrl;
	}
	public void setProfileUrl(String profileUrl) {
		this.profileUrl = profileUrl;
	}
	public String getProfileImage() {
		return profileImage;
	}
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date dateOn) {
		this.date = dateOn;
	}
    
    
    
}
