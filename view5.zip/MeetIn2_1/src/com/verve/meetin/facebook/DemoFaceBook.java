package com.verve.meetin.facebook;

import java.io.IOException;
import java.util.*;
import com.google.code.facebookapi.*;
import com.google.code.facebookapi.schema.*;

public class DemoFaceBook {
		  //public static String API_KEY = "174878165954799";
		  public static String API_KEY="308044212608087";
		  //public static String SECRET = "deabada699c380aaa6877f7cb1b4d566";
		  public static String SECRET="fff91a402d0e282afac69a7e67de32f3";
		  public static void main(String args[]) {
			  // Create the client instance

		    FacebookJaxbRestClient client =new FacebookJaxbRestClient(API_KEY, SECRET);

//		    client.setIsDesktop(true); // is this a desktop app

		    try {
		      String token = client.auth_createToken();
		      // Build the authentication URL for the user to fill out

		      String url = "http://www.facebook.com/login.php?api_key="

		                + API_KEY + "&v=1.0" 

		                + "&auth_token=" + token;
		      // Open an external browser to login to your application

		      Runtime.getRuntime().exec("open " + url); // OS X only!

		      // Wait until the login process is completed

		      System.in.read();

		      // fetch session key

		      String sessionKey = client.auth_getSession(token,true ); 

		      // obtain temp secret

		      String tempSecret = client.getCacheSessionSecret();

		      // new facebook client object
		      client = new FacebookJaxbRestClient(API_KEY, tempSecret, sessionKey);
		      
		      // keep track of the logged in user id

		      Long userId = client.users_getLoggedInUser(); 

		      // Get friends list

		      client.friends_get();

		      FriendsGetResponse response = (FriendsGetResponse) client.getResponsePOJO();

		      List<Long> friends = response.getUid();

		      // Go fetch the information for the user list of user ids

		     client.users_getInfo(friends, EnumSet.of(ProfileField.NAME));


		     UsersGetInfoResponse userResponse = (UsersGetInfoResponse) client.getResponsePOJO();

		      // Print out the user information

		      List<User> users = userResponse.getUser();

		      for (User user : users) {

		      }

		    } catch (FacebookException e) {

		      // TODO Auto-generated catch block

		      e.printStackTrace();

		    } catch (IOException e) {

		      // TODO Auto-generated catch block

		      e.printStackTrace();

		    }

		  }

		}

