package com.verve.meetin.facebook;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import org.apache.log4j.Logger;

import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.json.JsonArray;
import com.restfb.json.JsonObject;
import com.restfb.types.User;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.user.UserWS;

@Produces("application/xml")
@Path("facebook")
public class FacebookGraphAPIWS {
	
	static Logger log = Logger.getLogger(FacebookGraphAPIWS.class);
	@GET
	@Path("userinfo")
	public UserWS getUserInfo(@QueryParam("access_token") String access_token) throws ParseException {
		UserWS userws =new UserWS();
		FacebookClient facebookClient = new DefaultFacebookClient(access_token);
		User user = facebookClient.fetchObject("me", User.class);
		userws.setFullname(user.getName());
		userws.setEmail(user.getEmail());
		SimpleDateFormat facebook_format = new SimpleDateFormat("mm/dd/yyyy");
		SimpleDateFormat required_format = new SimpleDateFormat("MMM dd,yyyy");
		Date date= new Date();
		date = facebook_format.parse(user.getBirthday());
		
		userws.setBirthdate(required_format.format(date));
		return userws;
	}
	
	@GET
	@Path("friends")
	public List<Friends> getFacebookFriendList(@QueryParam("access_token") String access_token, 
			@QueryParam("current_location") String current_location) {
		try {
			List<Friends> friends = new ArrayList<Friends>();
			FacebookClient facebookClient = 
				new DefaultFacebookClient(access_token); //"165885353460625|3513cb20fe0c938607c19c90-698109171|P3B2Zc44XNyX6MOczb9gsOzDpUs"
			JsonObject json_friend = facebookClient.fetchObject("me/friends", JsonObject.class, 
					Parameter.with("fields", "id, first_name, last_name, name, location, gender,link"));
			JsonArray jarray_friend = (JsonArray)json_friend.get("data");
			int i=0;
			JsonObject friend=null;
			JsonObject location = new JsonObject();
			while(i<jarray_friend.length())
			{
				friend = (JsonObject)jarray_friend.get(i++);
				if(friend.has("location"))
				{
					location = (JsonObject)friend.get("location");
					Pattern locationPattern = Pattern.compile(",\\s?[a-zA-Z]+");
			        Matcher locationMatcher = locationPattern.matcher(location.get("name").toString());
			        String location_city = locationMatcher.replaceAll("");
					if(current_location.toLowerCase().equals(location_city.toLowerCase())) 
					{
						Friends friend_info = new Friends();
						friend_info.setName(friend.get("name").toString());
						friend_info.setLink(friend.get("link").toString());
						friend_info.setIcon(new NetworkDAO().getSocailNetworkIcon("Facebook").toString());
						friends.add(friend_info);
					}
				}
			}
			return friends;
		}catch (Exception e) {
			log.info("Facebook API Problem");
			return null;
		}
	}
}
