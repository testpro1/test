package com.verve.meetin.facebook;

import com.restfb.Facebook;

public class Properties1 {
	 @Facebook
	    ActionLink category;

	    @Facebook
	    String ratings;
	   
}
