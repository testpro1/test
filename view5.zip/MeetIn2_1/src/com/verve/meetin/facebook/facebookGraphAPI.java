package com.verve.meetin.facebook;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.google.api.client.json.Json;
import com.restfb.Connection;
import com.restfb.DefaultLegacyFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.DefaultFacebookClient;
import com.restfb.LegacyFacebookClient;
import com.restfb.Parameter;
import com.restfb.json.JsonArray;
import com.restfb.json.JsonObject;
import com.restfb.types.FacebookType;
import com.restfb.types.User;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.network.NetworkConstraint;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDummy;
import com.verve.meetin.trip.SuggestTrip;
import com.verve.meetin.user.UserAccountDAO;
//import com.verve.meetin.user.User;

/**
* The Facebook Graph API
*  getting the all the facebook user information.
* 
* @author Sunil Patel
*/
public class facebookGraphAPI {
	/*
	 * @param access_token
	 */
	static Logger log = Logger.getLogger(UserAccountDAO.class);
	public com.verve.meetin.user.User getUserInfo(String access_token) throws ParseException {
		try
		{
			FacebookClient facebookClient = new DefaultFacebookClient(access_token);
			User user = facebookClient.fetchObject("me", User.class);
			
			com.verve.meetin.user.User ouser = new com.verve.meetin.user.User();
			
			ouser.setFullname(user.getName());
			
			System.out.println("*****************************************************");
			System.out.println("user name is ***   "+user.getName());
			System.out.println("*****************************************************");
			
			//ouser.setEmail(user.getEmail());
			ouser.setEmail("");
			ouser.setGender(user.getGender());
			SimpleDateFormat facebook_format = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat required_format = new SimpleDateFormat("MMM dd,yyyy");
			Date date= new Date();
			date = facebook_format.parse(user.getBirthday());
			ouser.setBirthdate(required_format.format(date));
			
			if(user.getLocation() != null)
			{
				if(user.getLocation().getName().split(",").length == 3)
				{
					ouser.setLocCity(user.getLocation().getName().split(", ")[0]);
					ouser.setLocState(user.getLocation().getName().split(", ")[1]);
					ouser.setLocCountry(user.getLocation().getName().split(", ")[2]);
				}
				else if(user.getLocation().getName().split(",").length == 2)
				{
					ouser.setLocCity(user.getLocation().getName().split(", ")[0]);
					ouser.setLocCountry(user.getLocation().getName().split(", ")[1]);
				}
				else if(user.getLocation().getName().split(",").length == 1)
				{
					ouser.setLocCity(user.getLocation().getName());
				}
			}
			return ouser;
		}catch(Exception e)
		{
			return null; 
		}
	}
	public Hashtable<String, List<String>> getFacebookFriendList(String access_token, String current_location) {
		
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		
		try {
		
			log.info("Trying to get facebook friends for location :" + current_location);
			
			String query  = "select uid, name, current_location.city, sex, profile_url,pic,email from user where uid IN (select uid2 from friend where uid1 = me()) and "+
							" current_location.city = '" + current_location.toLowerCase() + "'";
			
			FacebookClient facebookClient = new DefaultFacebookClient(access_token); 
			
			List<JsonObject> list = facebookClient.executeQuery(query, JsonObject.class);
			
			//System.out.println(list.toString());
			
			JsonObject location = null;
			JsonObject friend = null;
			String faceBookIcon = new NetworkDAO().getSocailNetworkIcon("Facebook").toString();
			String latlang = new LocationDAO().getCityLatitudeLongitude(current_location.toLowerCase());
			String latitude = "";
			String langitude = "";
			
			for(int i=0; i < list.size(); i++)
			{
				friend = (JsonObject)list.get(i);
				
				if(friend.get("current_location") !=null && friend.get("current_location") != JsonObject.NULL)
				{
					location  = (JsonObject)friend.get("current_location");
					List<String> friend_info = new ArrayList<String>();
					friend_info.add(friend.getString("name"));
					friend_info.add(friend.getString("profile_url"));
					friend_info.add(faceBookIcon);
					
					if (!latlang.equals(""))
					{
						latitude = latlang.split(":")[0];
						langitude = latlang.split(":")[1];
					}
					
					friend_info.add(latitude); // facebok user's latitude
					friend_info.add(langitude); // facebook user's langitude
					friend_info.add(""); // empty value
					friend_info.add(friend.getString("pic"));
					friend_info.add(friend.getString("sex")); // facebook user's gender
					
					friends.put(String.valueOf(friend.get("uid")), friend_info);
						
				}
			}
			
			log.info("Total Facebook friends for location :" + current_location + " found : " + friends.size());
			return friends;
			
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		
	}
	
	/** This method will return the list of facebook friends */
	public Hashtable<String, List<String>> getFacebookFriendList(String access_token) {
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		try {
			FacebookClient facebookClient = new DefaultFacebookClient(access_token); 
			
			JsonObject json_friend = facebookClient.fetchObject("me/friends", JsonObject.class, 
					Parameter.with("fields", "id, first_name, last_name, name, location, gender,link, hometown"));
			JsonArray jarray_friend = (JsonArray)json_friend.get("data");
			int i=0;
			JsonObject friend=null;
			JsonObject location = new JsonObject();
			
			while(i<jarray_friend.length())
			{
				friend = (JsonObject)jarray_friend.get(i++);
				if(friend.has("location"))
				{
					location =(JsonObject)friend.get("location");	
				}
				else if(friend.has("hometown"))
				{
					location =(JsonObject)friend.get("hometown");
				}
				else
				{
					location = null;
				}
				List<String> friend_info = new ArrayList<String>();
				friend_info.add(friend.get("name").toString());
				
				if(location != null && location.length() > 0 && !location.get("name").toString().equals("null")) 
					friend_info.add(location.get("name").toString().split(",")[0]);
				else
					friend_info.add("---");
				friend_info.add(friend.get("link").toString());
				friend_info.add(new NetworkDAO().getSocailNetworkIcon("Facebook").toString());
			
				friends.put((String)friend.get("id"), friend_info);
			}
			
			return friends;
			
		}catch (Exception e) {
			log.info("Facebook API Problem : "+ e.getMessage());
			List<String> msg = new ArrayList<String>();
			msg.add(e.getMessage());
			friends.put("ERROR", msg);
			return friends;
		}
	}
	public void getfriendsInterest(String access_token) 
	{
		FacebookClient facebookClient = 
		new DefaultFacebookClient(access_token); 
		User user = facebookClient.fetchObject("me", User.class);
		String id = user.getId();
		////System.out.println("User ID: " + id);
		/*
		/////////////////////////////////////////////////////////////////////////////
		*//**this code is use for update status on Facebook via meetin application  *//*
		try{
			FacebookType publishMessageResponse = facebookClient.publish("me/feed", FacebookType.class, Parameter.with("message", "This is only for Testing status!"));
			//System.out.println("Published message ID: " + publishMessageResponse.getId());
			
		}catch (Exception e) {
			// TODO: handle exception
			
		}
		*//**Code End here *//*
		//////////////////////////////////////////////////////////////////
		
		*/
		////////////////////////////////////////////////////////////////////////////////////////
		/**this code is use for update status on Facebook via meetin application as a templet */
		LegacyFacebookClient LegacyfbClient = new DefaultLegacyFacebookClient(access_token);
		/*ActionLink category = new ActionLink();
		category.href = "http://localhost:8080/MeetIn2/";
		category.text = "humor";

		Properties1 properties = new Properties1();
		properties.category = category;
		properties.ratings = "5 stars";
	
		Attachment attachment = new Attachment();
		attachment.properties = properties;
		attachment.name = "i'm bursting with joy";
	    attachment.href = "http://localhost:8080/MeetIn2/";
	    attachment.caption = "{*actor*} rated the lolcat 5 stars";
	    attachment.description = "a funny looking cat";
		// Send the request to Facebook.
		// We specify the session key to use to make the call, the fact that we're
		// expecting a String response, and the attachment (defined above).

		String postId = LegacyfbClient.execute("stream.publish", String.class,Parameter.with("attachment", attachment));
		*/
	}
	public String getUserName(String access_token)
	{
		FacebookClient facebookClient = new DefaultFacebookClient(access_token);
		User user = facebookClient.fetchObject("me", User.class);
		return user.getEmail();
	}
	
	public void postOnFacebookWall(String message, String accessToken)
	{
		log.info("Trying to post on facebook wall.....");
        FacebookClient facebookClient = new DefaultFacebookClient(accessToken);       
        User user = facebookClient.fetchObject("me", User.class);

        String connection = "me/feed";
        FacebookType publishMessageResponse =  facebookClient.publish(connection, FacebookType.class,
        									Parameter.with("message", message));
        log.info("Message successfully posted on facebook wall");
	}

	public List<SocialNetworkDummy> getFacebookFriendsDump(String access_Token, int userid, String sessionid, int socialid)
	{
		
		try {
				log.info("Trying to get facebook friends.......");
				String query  = "select uid, name, current_location.city, sex, profile_url,pic from user where uid IN (select uid2 from friend where uid1 = me())";
				List<SocialNetworkDummy> friends = new ArrayList<SocialNetworkDummy>();
				FacebookClient facebookClient = new DefaultFacebookClient(access_Token); 
				
				List<JsonObject> list = facebookClient.executeQuery(query, JsonObject.class);
				JsonObject location = null;
				JsonObject friend = null;
				
				for(int i=0; i < list.size(); i++)
				{
					friend = (JsonObject)list.get(i);
					
					if(friend.get("current_location") !=null && friend.get("current_location") != JsonObject.NULL)
					{
						location  = (JsonObject)friend.get("current_location");
						SocialNetworkDummy s = new SocialNetworkDummy(sessionid, userid, socialid,
					       		friend.getString("name"), friend.getString("profile_url"), friend.getString("pic"), location.getString("city"));
						friends.add(s);	
					}
				}
				
				log.info("Total Facebook friends found : " + friends.size());
				return friends;
				
			}catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}
	
	public static void main(String[] args)
	{
		String token = "CAAJIrzj4ZBJ0BAKVzvHlnmYZCgWLX7ZCFMh4zEm3Tgq3r3qinDfd4PCt4MzhsmEOHWoUGnzkj2ZBckb9RSlyd0xRIh5aN5gEVmgQok3hr1EYsIZBZAOsPZA5ZALMhsmSFEIs0CwZAYZBgMOicIoZC7cMoG9";
		//new facebookGraphAPI().getFacebookFriendsDump(token, 9, "FDSFDS", 1);
		Hashtable<String , List<String>> h = new facebookGraphAPI().getFacebookFriendList(token, "Pune");
		System.out.println(h.toString());
		
	}
	
}
