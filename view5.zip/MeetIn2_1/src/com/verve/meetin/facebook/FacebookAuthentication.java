package com.verve.meetin.facebook;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.google.code.facebookapi.FacebookJaxbRestClient;
import com.google.code.facebookapi.FacebookParam;
/*
import org.json.JSONException;
import org.json.JSONObject;
import com.google.code.facebookapi.FacebookException;
import com.google.code.facebookapi.FacebookJsonRestClient;
import com.google.code.facebookapi.FacebookWebappHelper;
import com.google.code.facebookapi.FacebookXmlRestClient;
import com.google.code.facebookapi.IFacebookRestClient;
import com.google.code.facebookapi.schema.User;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
*/
import com.verve.meetin.user.User;

/**
* The Facebook User Filter ensures that a Facebook client that pertains to the
* logged in user is available in the session object named
* "facebook.user.client".
* 
* The session ID is stored as "facebook.user.session". It's important to get
* the session ID only when the application actually needs it. The user has to
* authorise to give the application a session key.
* 
* @author Sunil Patel
*/

public class FacebookAuthentication implements Filter{

	private String api_key;
	private String secret;
	private String redirect_uri;
	private ArrayList<String> urlList;
	ResourceBundle resource;
	public void init(FilterConfig filterConfig) throws ServletException {
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");

		api_key = resource.getString("facebook.api_key");
		secret = resource.getString("facebook.secret");
		
		
		redirect_uri = resource.getString("facebook.redirect_uri");
		if (api_key == null || secret == null) { 
			throw new ServletException(
					"Cannot initialise Facebook User Filter because the "
					+ "facebook_api_key or facebook_secret context init "
					+ "params have not been set. Check that they're there "
					+ "in your servlet context descriptor.");
		} 
		String urls = filterConfig.getInitParameter("authenticate-urls");

         StringTokenizer token = new StringTokenizer(urls, ",");
 
        urlList = new ArrayList<String>();
 
        while (token.hasMoreTokens()) {
            urlList.add(token.nextToken());
         }
	}
	/*
	 * (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, 
	 * javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 * 
	 */
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		HttpSession userSession = request.getSession(true);
		String url = request.getServletPath();
		
		boolean allowedRequest= false;
		if(urlList.contains(url)) {       // Authenticate the URL to filter the redirect the execution flow
			
            allowedRequest = true;
        }
		if(request.getParameter("fbtoken") != null) {
			com.verve.meetin.user.User user=null;
			user = (User) userSession.getAttribute("FBUserInfo");
			
			if(user !=null)
			{
								
				request.setAttribute("fullname", user.getFullname());
				request.setAttribute("email", user.getEmail());
				request.setAttribute("birthdate", user.getBirthdate());
				request.setAttribute("country", user.getLocCountry());
				request.setAttribute("state", user.getLocState());
				request.setAttribute("city", user.getLocCity());
				request.setAttribute("gender", user.getGender());
				
				userSession.setAttribute("network_user", user.getFullname());
			}
		}
		if(allowedRequest && request.getParameter("fbtoken") == null && request.getParameter("code") != null)
		{
			facebookGraphAPI fbgAPI = new facebookGraphAPI();
			String access_token = getAccessToken(request.getParameter("code").toString());
			
			try {
					User user =(User) new facebookGraphAPI().getUserInfo(access_token);
					userSession.setAttribute("network_user", user.getFullname());
					userSession.setAttribute("access_token", access_token);
			} catch (Exception e) {
				System.out.println("Exception e "+e);
			}
			
			try 
			{
				com.verve.meetin.user.User u = new facebookGraphAPI().getUserInfo(access_token);
				userSession.setAttribute("FBUserInfo", u);			
				
			//	System.out.println(u.toString());
			//	System.out.println("in done");
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		chain.doFilter(request, response);
	}
	
	public void destroy() {
	}
	/*
	 * Function getAccessToken
	 * 
	 * @param code : Oauth_token which is fetch from redirected url
	 * @return MY_ACCESS_TOKEN
	 * 
	 * The task of the function is to generate the Access Token by passing 
	 * api key, secret key, code and redirect URL of application.
	 */
	public String getAccessToken(String code) {
		
		
		String inputLine="";
		String MY_ACCESS_TOKEN="";
		try {
			String token_url="https://graph.facebook.com/oauth/access_token?client_id="+api_key+"&redirect_uri="
				+URLEncoder.encode(redirect_uri.toString(),"UTF-8")
				+"&client_secret="+secret+"&code="+code;
			/*String token_url="s://graph.facebook.com/oauth/access_token?client_id="+api_key+"&redirect_uri="
			+redirect_uri+
			"&client_secret="+secret+"&code="+code;*/
		
			URL u = new URL(token_url);
			BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			while ((inputLine = in.readLine()) != null)
			MY_ACCESS_TOKEN = inputLine;
		    MY_ACCESS_TOKEN = MY_ACCESS_TOKEN.replace("access_token=","");
		    
		    if(MY_ACCESS_TOKEN.contains("&expires=")) {
		    	MY_ACCESS_TOKEN = MY_ACCESS_TOKEN.substring(0, MY_ACCESS_TOKEN.length()-16);
		    	
		    }
		    in.close();
		   
			return MY_ACCESS_TOKEN;
		}catch(Exception e){
			return null;
		}
	}
	
	public static void main(String args[])
	{
		
	}
}