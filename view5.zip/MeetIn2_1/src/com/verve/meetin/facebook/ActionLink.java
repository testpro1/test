package com.verve.meetin.facebook;

import com.restfb.Facebook;

public class ActionLink {
	 @Facebook
	    String text;

	    @Facebook
	    String href;
}
