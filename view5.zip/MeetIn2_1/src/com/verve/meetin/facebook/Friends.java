package com.verve.meetin.facebook;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.*;

@XmlRootElement
public class Friends 
{
	private String name;
	private String link;
	private String icon;
	private String onupcomingPeople;
	private String imagePath;
	
	
	// user latitude / langitude
	private String latitude;
	private String langitude;
	private String loggedinuserlatlong;
	
	private String resultString;
	private String relationId;
	private String updateOn;
	
	
	
	public String getUpdateOn() {
		return updateOn;
	}
	public void setUpdateOn(String updateOn) {
		this.updateOn = updateOn;
	}
	public String getRelationId() {
		return relationId;
	}
	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}
	public String getResultString() {
		return resultString;
	}
	public void setResultString(String resultString) {
		this.resultString = resultString;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getLatitude() {
		return latitude;
	}
	public String getLangitude() {
		return langitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public void setLangitude(String langitude) {
		this.langitude = langitude;
	}
	public String getOnupcomingPeople() {
		return onupcomingPeople;
	}
	public void setOnupcomingPeople(String onupcomingPeople) {
		this.onupcomingPeople = onupcomingPeople;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getLoggedinuserlatlong() {
		return loggedinuserlatlong;
	}
	public void setLoggedinuserlatlong(String loggedinuserlatlong) {
		this.loggedinuserlatlong = loggedinuserlatlong;
	}
}