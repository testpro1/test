package com.verve.meetin.facebook;

import com.restfb.Facebook;

public class Attachment {
	 @Facebook
	    String name;

	    @Facebook
	    String href;

	    @Facebook
	    String caption;

	    @Facebook
	    String description;

	    @Facebook
	    Properties1 properties;

	
}
