package com.verve.meetin.facebook;

import com.restfb.Facebook;

public class Privacy {
	 @Facebook 
	  String value; 
	  @Facebook 
	  String friends; 
	  @Facebook 
	  String allow; 
}
