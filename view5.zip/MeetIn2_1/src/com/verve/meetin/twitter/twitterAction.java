package com.verve.meetin.twitter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;


import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class twitterAction extends DispatchAction{
	public ActionForward twitterAuthentication(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		//System.out.println("This is the Twitter Authentication .............. !");
		OAuthConsumer consumer = new DefaultOAuthConsumer("EOsMJlIu5ZdRlha1HRxuAA","09VQLBbMqpFTQTmeEKbsHi9qej00c8k6e5LQwmD0M4");

	    OAuthProvider provider = new DefaultOAuthProvider("http://twitter.com/oauth/request_token",
	            "http://twitter.com/oauth/access_token",
	            "http://twitter.com/oauth/authorize");

	    if(request.getParameter("oauth_verifier") == null) {
			String authUrl = provider.retrieveRequestToken(
					consumer, //consumer, 
					"http://192.168.1.193:8080/MeetIn2/twitter.do?action=twitterAuthentication"); //or   OAuth.OUT_OF_BAND
			//System.out.println(authUrl);
			response.sendRedirect(authUrl);
		}
		else {
			provider.retrieveAccessToken(
					consumer, //consumer,
					request.getParameter("oauth_verifier"));
		}
		return null;
	}
}
