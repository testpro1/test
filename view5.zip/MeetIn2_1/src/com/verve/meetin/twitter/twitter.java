package com.verve.meetin.twitter;

import java.net.URL;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;
import twitter4j.IDs;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;

import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDummy;

public class twitter {

	/**
	 * @param args
	 */
	OAuthConsumer consumer;
	OAuthProvider provider;
	ResourceBundle resource;
	
	public twitter()
	{
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		consumer = new DefaultOAuthConsumer(
				resource.getString("twitter.consumer_key"),
        		resource.getString("twitter.consumer_secret")
                );
 
		provider = new DefaultOAuthProvider("https://api.twitter.com/oauth/request_token",
	            "https://api.twitter.com/oauth/access_token",
	            "https://api.twitter.com/oauth/authorize");
	}
	
	public Hashtable<String, List<String>> getFriendsInfo(String access_token,
			String current_location) throws Exception
			{
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		
		String acctoken = access_token;
		String accesstoken [] = acctoken.split(",");
		Twitter twitter = new TwitterFactory().getInstance();
		twitter.setOAuthConsumer("EOsMJlIu5ZdRlha1HRxuAA","09VQLBbMqpFTQTmeEKbsHi9qej00c8k6e5LQwmD0M4");
		for(int i=0;i<accesstoken.length;i++){
			
			String token = accesstoken[0];
			String tokenSecret = accesstoken[1];
			twitter.setOAuthAccessToken(token, tokenSecret);
		}
		IDs ids  = twitter.getFriendsIDs();
		User user = twitter.verifyCredentials();
		for (int id : ids.getIDs()) 
		{
			List<String> friend_info = new ArrayList<String>();
			String idval = Integer.toString(id);
			
			
			 String location = twitter.showUser(id).getLocation();
			 
	 
			 if(location != null)
			 {
				 URL friendimg = twitter.showUser(id).getProfileImageURL();
				if(location.toLowerCase().contains(current_location.toLowerCase())) 
				{
					friend_info.add(twitter.showUser(id).getName());
		
					friend_info.add(""); //getProfile(access_token, person.getId())
					friend_info.add(new NetworkDAO().getSocailNetworkIcon("Twitter").toString());
					String latlang = new LocationDAO().getCityLatitudeLongitude(current_location.toLowerCase());
					friend_info.add(latlang.split(":")[0]); //  user's latitude
					friend_info.add(latlang.split(":")[1]); //  user's langitude
					friend_info.add(""); // empty value
					friend_info.add(friendimg.toString()); // value for twitter user's image name
					friend_info.add(""); //  user's gender
					friends.put( idval, friend_info);
					
				}
			}
			
		}
		return friends;
	}
	
	
	//Get Screen name for the twitter user
	public String getTwitterScreenName(String access_token)
	{
		String acctoken = access_token;
		String accesstoken [] = acctoken.split(",");
		
		Twitter twitter = new TwitterFactory().getInstance();
		
		twitter.setOAuthConsumer("EOsMJlIu5ZdRlha1HRxuAA","09VQLBbMqpFTQTmeEKbsHi9qej00c8k6e5LQwmD0M4");
		
		for(int i=0;i<accesstoken.length;i++){
			String token = accesstoken[0];
			String tokenSecret = accesstoken[1];
			twitter.setOAuthAccessToken(token, tokenSecret);
		}
		try
		{
				IDs ids  = twitter.getFriendsIDs();
				User user = twitter.verifyCredentials();
			
				return user.getScreenName();
		}
		catch (Exception e) {
			//System.out.println("Exception occured");
		}
		return null;
		
	}
	
	
	/** This is overloaded method */
	public Hashtable<String, List<String>> getFriendsInfo(
			String access_token) throws Exception
			{
				Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
				
				String acctoken = access_token;
				String accesstoken [] = acctoken.split(",");
				Twitter twitter = new TwitterFactory().getInstance();
				twitter.setOAuthConsumer("EOsMJlIu5ZdRlha1HRxuAA","09VQLBbMqpFTQTmeEKbsHi9qej00c8k6e5LQwmD0M4");
				for(int i=0;i<accesstoken.length;i++){
					
					String token = accesstoken[0];
					String tokenSecret = accesstoken[1];
					twitter.setOAuthAccessToken(token, tokenSecret);
				}
				IDs ids  = twitter.getFriendsIDs();
				User user = twitter.verifyCredentials();
			
			
				for (int id : ids.getIDs()) 
				{
					List<String> friend_info = new ArrayList<String>();
					String idval = Integer.toString(id);
				    String location = twitter.showUser(id).getLocation();
					
				    
				    
					friend_info.add(twitter.showUser(id).getName());
					if(location != null)
					{
					
						String location_split = location.split(",")[0];
						String user_location = location_split.replace("Area", "").trim();
						friend_info.add(user_location);
						
					}
					else
					{
						//System.out.println("location null--");
						friend_info.add("---");
					}
					friend_info.add(""); 
					friend_info.add(new NetworkDAO().getSocailNetworkIcon("Twitter").toString());
					friends.put(idval, friend_info);
				}
				return friends;
			}

	public List<SocialNetworkDummy> getTwitterFriendsDump(String access_Token, int userId, String sessionId, int socialId) 
	{
		
		try
		{
			List<SocialNetworkDummy> friends = new ArrayList<SocialNetworkDummy>();
			String accesstoken [] = access_Token.split(",");
			Twitter twitter = new TwitterFactory().getInstance();
			twitter.setOAuthConsumer(resource.getString("twitter.consumer_key"), resource.getString("twitter.consumer_secret"));
			
			for(int i=0;i<accesstoken.length;i++){
				
				String token = accesstoken[0];
				String tokenSecret = accesstoken[1];
				twitter.setOAuthAccessToken(token, tokenSecret);
			}
			
			IDs ids  = twitter.getFriendsIDs();
			User user = twitter.verifyCredentials();
			String city = null;
			String profileImageUrl = null;
			
			for (int id : ids.getIDs()) 
			{
				
				String idval = Integer.toString(id);
			    String location = twitter.showUser(id).getLocation();

				if(location != null)
				{
				
					String location_split = location.split(",")[0];
					city = location_split.replace("Area", "").trim();
				}
				
				String path = "http://" + twitter.showUser(id).getProfileImageURL().getHost();
				String filename = twitter.showUser(id).getProfileImageURL().getFile();
				profileImageUrl = path + filename;

				SocialNetworkDummy s = new SocialNetworkDummy(sessionId, userId, socialId, twitter.showUser(id).getName(), null, profileImageUrl, city);
				friends.add(s);
			}
			
			return friends;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}

	}
}
