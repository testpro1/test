package com.verve.meetin.twitter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.quartz.SchedulerException;

import com.sun.jersey.spi.dispatch.RequestDispatcher;
import com.sun.xml.ws.rm.jaxws.runtime.Session;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.Usernetworks;
import com.verve.meetin.network.peoplefinder.ScheduleSocialNetwork;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;
import oauth.signpost.exception.OAuthNotAuthorizedException;



import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
//import twitter4j.http.AccessToken;
//import twitter4j.http.RequestToken;
/*import twitter4j.auth.AccessToken;
import twitter4j.auth.OAuthSupport;
import twitter4j.auth.RequestToken;*/
import twitter4j.http.AccessToken;


public class twitterAuthenticationServlet extends HttpServlet {

	private static final long serialVersionUID = -1486360080128882436L;
	//RequestToken requestToken;
	String authUrl;
	ResourceBundle resource;
	HttpServletRequest request;
	AccessToken accessToken;
	OAuthConsumer consumer = new DefaultOAuthConsumer("EOsMJlIu5ZdRlha1HRxuAA","09VQLBbMqpFTQTmeEKbsHi9qej00c8k6e5LQwmD0M4");

    OAuthProvider provider = new DefaultOAuthProvider(
            "https://api.twitter.com/oauth/request_token",
            "https://api.twitter.com/oauth/access_token",
            "https://api.twitter.com/oauth/authorize");
	@Override
	public void init() throws ServletException {

	}
	/**
	 * Destruction of the servlet. <br>
	 */
	@Override
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
		
	}
	public void gettwitterCredentials() 
    {
    	
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
       System.out.println(resource.getString("twitter.redirect_uri"));
       System.out.println(consumer);
		try {
			authUrl = provider.retrieveRequestToken(consumer, resource.getString("twitter.redirect_uri"));
			System.out.println("authurl:::: "+authUrl);
		} catch (OAuthMessageSignerException e) {
			// TODO Auto-generated catch block
			//System.out.println("Exception is "+e.getMessage());
		} catch (OAuthNotAuthorizedException e) {
			// TODO Auto-generated catch block
			//System.out.println("Exception is "+e.getMessage());
		} catch (OAuthExpectationFailedException e) {
			// TODO Auto-generated catch block
			//System.out.println("Exception is "+e.getMessage());
		} catch (OAuthCommunicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//System.out.println("Exception is "+e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
		}
    }
	
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		if(request.getParameter("oauth_verifier") == null) {
			
			gettwitterCredentials();
			response.sendRedirect(authUrl);
		}
		else {
			/*Twitter twitter = new TwitterFactory().getInstance();
			twitter.setOAuthConsumer(resource.getString("twitter.consumer_key"),resource.getString("twitter.consumer_secret"));*/
			try {
				
				
				provider.retrieveAccessToken(consumer, request.getParameter("oauth_verifier"));
			}  catch (OAuthMessageSignerException e) {
				// TODO Auto-generated catch block
				System.out.println("Exception is "+e.getMessage());
			} catch (OAuthNotAuthorizedException e) {
				// TODO Auto-generated catch block
				System.out.println("Exception is "+e.getMessage());
			} catch (OAuthExpectationFailedException e) {
				// TODO Auto-generated catch block
				System.out.println("Exception is "+e.getMessage());
			} catch (OAuthCommunicationException e) {
				// TODO Auto-generated catch block
				System.out.println("Exception is "+e.getMessage());
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println("Exception e "+e);
			}
			
		      //twitter.setOAuthAccessToken(consumer.getToken().toString(), consumer.getTokenSecret().toString());
		   
			HttpSession userSession = request.getSession();
			userSession.setAttribute("access_token", consumer.getToken()+","+consumer.getTokenSecret());
			
			
			String username = new twitter().getTwitterScreenName(consumer.getToken()+","+consumer.getTokenSecret());
			userSession.setAttribute("network_user",username);
			
			//userSession.setAttribute("network_user", consumer.getToken()+","+consumer.getTokenSecret());
			if(userSession.getAttribute("phoneurl") !=null && userSession.getAttribute("userid") !=null)
			{
				NetworkDAO ntdao = new NetworkDAO();
				int userid = (Integer)userSession.getAttribute("userid");
			    int socialid = ntdao.getSocialNetworkId("Twitter");
				
			    Usernetworks onetwork = new Usernetworks(
			    		userid, socialid, "", "", 
			    		userSession.getAttribute("access_token").toString());
				
				int row = new NetworkDAO().setUserSocialNetworkSite(onetwork);
				
				 if(row > 0)
				 {
				 		new NetworkDAO().setNetworkUserName(onetwork, userSession.getAttribute("network_user").toString());
				 }
				 	/**
					 * Reading Facebook, LinkedIn, Gmail etc... friends for loggedin user and storing into table. 
					 */
					try 
					{
						new ScheduleSocialNetwork().startscheduleScoialNetwork(userid, userSession.getId(),socialid);
						
					} catch (SchedulerException e) {
						e.printStackTrace();
					}
					
				userSession.removeAttribute("network_user");
				userSession.removeAttribute("userid");
				userSession.removeAttribute("phoneurl");
				
				response.sendRedirect(request.getContextPath() + "/setupnetworkmobile.jsp?userid=" + userid);
				
			}
			else
			{

		        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
				out.println("<HTML>");
				out.println("<HEAD><TITLE>A Servlet</TITLE>");
				out.println("</HEAD>");
				
				if(request.getAttribute("twitter_setupnetwork") != null)
				{
					out.println("<BODY onload=\"window.opener.addtwitterNetwork(); window.close()\">");
				}
				else
				{
					userSession.setAttribute("flag","flag");
					out.println("<BODY onload=\"window.opener.addtwitterNetwork_wizard(); window.close()\">");
				}
				
				out.println("</BODY>");
				out.println("</HTML>");
				out.flush();
				out.close();
			}
		}
	}
}