package com.verve.meetin.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.verve.meetin.user.User;

public class UserProfile extends HttpServlet {
	
	
		/**
		 * Database configuration
		 */
	 	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	 	String url = resource.getString("jdbc.connectionValue").trim();
	 	String driver = resource.getString("jdbc.driverClass").trim();
		String userName = resource.getString("jdbc.database.username").trim();
		String password = resource.getString("jdbc.database.password").trim();

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException{
		
		HttpSession session = request.getSession();
		String id =request.getParameter("id");
	
		  try {
			  	Class.forName(driver).newInstance();
			  	Connection con = null;		 
	
			  	con = DriverManager.getConnection(url,userName,password);
			  	String query="select fullname, dob, email, loc_country, loc_city, about_me, company, job_title, " +
			  		"industry, degree_college,image,gender from mi_users where user_id=? ";
			  	PreparedStatement st = con.prepareStatement(query);
			  	st.setString(1, id);
			 
			  	ResultSet rs =st.executeQuery();
			  	User u = new User();
			  	while(rs.next()){
					  u.setFullname(rs.getString("fullname"));
					  u.setEmail(rs.getString("email"));
					  u.setDob(rs.getDate("dob"));
					  u.setLocCountry(rs.getString("loc_country"));
					  u.setLocCity(rs.getString("loc_city"));
					  u.setAboutMe(rs.getString("about_me"));
					  u.setCompany(rs.getString("company"));
					  u.setDegreeCollege(rs.getString("degree_college"));
					  u.setJobTitle(rs.getString("job_title"));
					  u.setIndustry(rs.getString("industry"));
					  u.setImage(rs.getString("image"));
					  u.setGender(rs.getString("gender"));
			  	}
			  		  session.setAttribute("user", u);
					  st.close();
				  
					  String query1="select a.name from mi_interestmaster a, mi_userinterests b where a.interest_id =b.interest_id and b.user_id=?";
					  PreparedStatement st1 = con.prepareStatement(query1);
					  st1.setString(1, id);
					  List<String> interestList= new ArrayList<String>();
					  ResultSet rs1=st1.executeQuery();
					  while(rs1.next()){
						  interestList.add(rs1.getString(1));
					  }
					  session.setAttribute("userInterest", interestList);
					  st1.close();
					  con.close();			  
					  getServletConfig().getServletContext().getRequestDispatcher("/profileadmin.jsp").forward(request, response);			
			}catch( Exception e ) {
				  getServletConfig().getServletContext().getRequestDispatcher("/loginadmin.jsp").forward(request, response);			
		}
			
	}
}
