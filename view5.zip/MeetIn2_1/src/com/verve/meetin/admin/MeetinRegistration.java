package com.verve.meetin.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MeetinRegistration extends HttpServlet {
	

		/**
		 * Database configuration
		 */
	
 		ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
 		String url = resource.getString("jdbc.connectionValue").trim();
 		String driver = resource.getString("jdbc.driverClass").trim();
 		String userName = resource.getString("jdbc.database.username").trim();
 		String password = resource.getString("jdbc.database.password").trim();
		
	 	String meetinCount;
	  	String fbCount;
	  	String linkedInCount;
	  	String gmailCount;
	  	String twitterCount;
	  	
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException{
		HttpSession session = request.getSession(); 
		String email=request.getParameter("email");
		String pword=request.getParameter("pword");
		
		System.out.println(email);
		System.out.println(pword);
		boolean value = validateUser(email,pword);
		
		
		if(value){
		  try {
			  session.setAttribute("username",email);
			  
			  Class.forName(driver).newInstance();
			  Connection con = null;	
			  con = DriverManager.getConnection(url,userName,password);
			  String query="select user_id, fullname, loc_city,image,gender from mi_users";
			  PreparedStatement st = con.prepareStatement(query);		
			  ResultSet rs =st.executeQuery();
			  List<User> userList= new ArrayList<User>();
			  DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			  while(rs.next()){
				  User u = new User();
				  u.setUser_id(rs.getInt("user_id"));
				  u.setFullname(rs.getString("fullname"));
				  u.setCity(rs.getString("loc_city"));
				  if(rs.getString("loc_city").length()>=22){
					  u.setCity(rs.getString("loc_city").substring(0,22));
				  }
				  if(rs.getString("fullname").length()>=20){
					  u.setFullname(rs.getString("fullname").substring(0,20));
				  }
				  u.setImage(rs.getString("image"));
				  u.setGender(rs.getString("gender"));					  
				  userList.add(u);
			  }
			  	rs.close();
			  	st.close();
			  	con.close();
			  	
				for(User u:userList){
					u.setMeetinCount(new MeetinRegistration().getMeetinCount(u.getUser_id()));				
					HashMap<String,String> hm =new MeetinRegistration().getCount(u.getUser_id());
					Set set = hm.entrySet();
					// Get an iterator
					Iterator i = set.iterator(); 
					while(i.hasNext()){
						Map.Entry<String, String> me =(Map.Entry<String, String>)i.next();
					
						if(me.getKey().equals("1"))
							u.setFbCount(me.getValue());						
						else if(me.getKey().equals("2"))
							u.setLinkedInCount(me.getValue());
						else if(me.getKey().equals("3"))
							u.setGmailCount(me.getValue());
						else if(me.getKey().equals("4"))
							u.setTwitterCount(me.getValue());
					}
				  }
			  	request.setAttribute("users", userList);
				getServletConfig().getServletContext().getRequestDispatcher("/mymeetinadmin.jsp").forward(request, response);			
			}catch( Exception e ) {
				getServletConfig().getServletContext().getRequestDispatcher("/loginadmin.jsp").forward(request, response);
			}	
		}			
		else {
			request.setAttribute("emailRegistered", "emailRegistered");
			getServletConfig().getServletContext().getRequestDispatcher("/loginadmin.jsp").forward(request, response);
		}
	}
	
	
	public boolean validateUser(String email,String pword)
	{
		try {
			Class.forName(driver).newInstance();
			Connection con = null;		
			con = DriverManager.getConnection(url,userName,password);
			String query ="select username,password from admin";
			PreparedStatement statement = con.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery(query);
		
			while(resultSet.next())
			{
				if(resultSet.getString(1).equals(email) && resultSet.getString(2).equals(pword))
				{
					return true;
				}
			}
		
		} catch (Exception e) {
			System.out.println("Exception occured " +e);
		}
		return false;
	}
	
	
	public static void main(String args[])
	{
		 System.out.println( new MeetinRegistration().validateUser("admin@vervesys.com", "admin"));
	}
	
	public String getMeetinCount(int userid){
		try{		
			Connection con = null;		
			con = DriverManager.getConnection(url,userName,password);
			String query1="select COUNT(*) from mi_friends where user_id1 =? and status ='Approve'";
			PreparedStatement st1 = con.prepareStatement(query1);		
			st1.setInt(1, userid);
			ResultSet rs1 =st1.executeQuery();
	  		while(rs1.next()){
	  			meetinCount=rs1.getString("COUNT(*)");
	  		}
		  	rs1.close();
		  	st1.close();
		  	con.close();
			}catch( Exception e ) {
				 e.printStackTrace();
			}
			if(meetinCount=="") return "-";
			else
				return meetinCount;
	}
	public HashMap<String, String> getCount(int userid){
		HashMap<String, String> hm = new HashMap<String, String>(); 
		try{	
				Connection con = null;
			  	con = DriverManager.getConnection(url,userName,password);
				String query2="select COUNT(*),socialId from socialnetwork_dummy where userId=? group by socialId;";
				PreparedStatement st2 = con.prepareStatement(query2);	
				st2.setInt(1, userid);
				ResultSet rs2 =st2.executeQuery();
				while(rs2.next()){			
					hm.put(rs2.getString("socialId"),rs2.getString("COUNT(*)"));
				}
				
				rs2.close();
				st2.close();
			  	con.close();

		}catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}	
	
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException{
		HttpSession session = request.getSession(); 
		  try {
				Class.forName(driver).newInstance();
				Connection con = null;
				con = DriverManager.getConnection(url,userName,password);			
				String searchBy =request.getParameter("search");
				String searchText=request.getParameter("searchtxt");
				PreparedStatement st=null;
				if(!searchBy.equals("0")){
					if(searchBy.equals("register_on")){
						String fromDate=request.getParameter("fromdate");
						String toDate=request.getParameter("todate");
						String query="select user_id, fullname, loc_city,image,gender " +
					  		"FROM mi_users WHERE DATE(register_on) between ? and ?";
						st = con.prepareStatement(query);
						Date from =new Date(fromDate);
						Date to=new Date(toDate);							  
						st.setDate(1, new java.sql.Date(from.getTime()));
						st.setDate(2, new java.sql.Date(to.getTime()));
						}
					else //if (searchBy.equals("fullname")) 
						{
						String query="select user_id, fullname, loc_city,image,gender from mi_users where "+ searchBy +" like concat(?,'%')";
						st = con.prepareStatement(query);
  					    st.setString(1, searchText);					
  					}
				}
				else {
					 String query="select user_id, fullname, loc_city,image,gender from mi_users";
					 st = con.prepareStatement(query);	
				}
				
				  ResultSet rs =st.executeQuery();
				  List<User> userList= new ArrayList<User>();
				  while(rs.next()){
					  User u = new User();
					  u.setUser_id(rs.getInt("user_id"));
					  u.setFullname(rs.getString("fullname"));
					  u.setCity(rs.getString("loc_city"));
					  if(rs.getString("loc_city").length()>=22){
						  u.setCity(rs.getString("loc_city").substring(0,22));
					  }
					  if(rs.getString("fullname").length()>=20){
						  u.setFullname(rs.getString("fullname").substring(0,20));
					  }
					  u.setImage(rs.getString("image"));
					  u.setGender(rs.getString("gender"));	
					  userList.add(u);
				  }
				  	rs.close();
				  	st.close();
				  	con.close();
				  	
					for(User u:userList){
						u.setMeetinCount(new MeetinRegistration().getMeetinCount(u.getUser_id()));
						HashMap<String,String> hm =new MeetinRegistration().getCount(u.getUser_id());
						Set set = hm.entrySet();
						// Get an iterator
						Iterator i = set.iterator(); 
						while(i.hasNext()){
							Map.Entry<String, String> me =(Map.Entry<String, String>)i.next();
						
							if(me.getKey().equals("1"))
								u.setFbCount(me.getValue());						
							else if(me.getKey().equals("2"))
								u.setLinkedInCount(me.getValue());
							else if(me.getKey().equals("3"))
								u.setGmailCount(me.getValue());
							else if(me.getKey().equals("4"))
								u.setTwitterCount(me.getValue());
						}					  
					  }
				  	request.setAttribute("users", userList);
					getServletConfig().getServletContext().getRequestDispatcher("/mymeetinadmin.jsp").forward(request, response);			
			
		  }catch(Exception e){
			  //e.printStackTrace();
			  getServletConfig().getServletContext().getRequestDispatcher("/loginadmin.jsp").forward(request, response);
		  }
	}
}