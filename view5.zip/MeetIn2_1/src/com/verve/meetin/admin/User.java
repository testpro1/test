package com.verve.meetin.admin;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

//about_me, company, job_title, industry, degree_college
	
public class User implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int user_id;
	private Date register_on;
	private String city;
	private String state;
	private String country;
	private String count;
	private String fullname;
	private String email;
	private Date dob;
	private String company;
	private String about_me;
	private String job_title;
	private String industry;
	private String degree_college;
	private String image;
	private String gender;
	private String meetinCount;
	private String fbCount;
	private String linkedInCount;
	private String gmailCount;
	private String twitterCount;
	
	public Date getRegister_on() {
		return register_on;
	}
	public void setRegister_on(Date registerOn) {
		register_on = registerOn;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getAbout_me() {
		return about_me;
	}
	public void setAbout_me(String aboutMe) {
		about_me = aboutMe;
	}
	public String getJob_title() {
		return job_title;
	}
	public void setJob_title(String jobTitle) {
		job_title = jobTitle;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getDegree_college() {
		return degree_college;
	}
	public void setDegree_college(String degreeCollege) {
		degree_college = degreeCollege;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getImage() {
		return image;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGender() {
		return gender;
	}
	public void setMeetinCount(String meetinCount) {
		this.meetinCount = meetinCount;
	}
	public String getMeetinCount() {
		return meetinCount;
	}
	public String getFbCount() {
		return fbCount;
	}
	public void setFbCount(String fbCount) {
		this.fbCount = fbCount;
	}
	public String getLinkedInCount() {
		return linkedInCount;
	}
	public void setLinkedInCount(String linkedInCount) {
		this.linkedInCount = linkedInCount;
	}
	public String getGmailCount() {
		return gmailCount;
	}
	public void setGmailCount(String gmailCount) {
		this.gmailCount = gmailCount;
	}
	public String getTwitterCount() {
		return twitterCount;
	}
	public void setTwitterCount(String twitterCount) {
		this.twitterCount = twitterCount;
	}
}
