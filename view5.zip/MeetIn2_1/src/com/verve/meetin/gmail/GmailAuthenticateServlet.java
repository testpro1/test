package com.verve.meetin.gmail;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.quartz.SchedulerException;

import com.google.api.client.auth.oauth2.draft10.AccessTokenResponse;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessProtectedResource;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessTokenRequest.GoogleAuthorizationCodeGrant;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;

import com.verve.meetin.gmail.GmailAPI;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.Usernetworks;
import com.verve.meetin.network.peoplefinder.ScheduleSocialNetwork;

public class GmailAuthenticateServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	private String SCOPE = "";
	private String CALLBACK_URL = "";
	private HttpTransport TRANSPORT = new NetHttpTransport();
	private JsonFactory JSON_FACTORY = new JacksonFactory();
	
	// FILL THESE IN WITH YOUR VALUES FROM THE API CONSOLE
	private String CLIENT_ID = "";
	private String CLIENT_SECRET = "";
	public GmailAuthenticateServlet() {
		super();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	@Override
	public void init() throws ServletException {
		// Reading parameter for gmail authentication 
		SCOPE =resource.getString("gmail.scope.url");
		CALLBACK_URL = resource.getString("gmail.callback.url");
		CLIENT_ID = resource.getString("gmail.client.id");
		CLIENT_SECRET = resource.getString("gmail.client.secret");
	}
	
	/**
	 * Destruction of the servlet. <br>
	 */
	@Override
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession userSession = request.getSession();
		String authorizationCode = userSession.getAttribute("code").toString();
		
		GoogleAuthorizationCodeGrant authRequest = new GoogleAuthorizationCodeGrant(TRANSPORT,
		        JSON_FACTORY, CLIENT_ID, CLIENT_SECRET, authorizationCode, CALLBACK_URL);
		
		authRequest.useBasicAuthorization = false;
		AccessTokenResponse authResponse = authRequest.execute();
	    String accessToken = authResponse.accessToken;
	    String refreshToken = authResponse.refreshToken;
	    userSession.setAttribute("access_token",accessToken+","+refreshToken);
	    out.println("accessToken : "+accessToken);
	    out.println("refreshToken : "+refreshToken);
	    
	    GoogleAccessProtectedResource access 
	    		= new GoogleAccessProtectedResource(accessToken);
	 	       								//		TRANSPORT, 
	 	       									//	JSON_FACTORY, 
	 	       										//CLIENT_ID, 
	 	       										//CLIENT_SECRET, 
	 	       										//refreshToken);
		HttpRequestFactory rf = TRANSPORT.createRequestFactory(access);
		 
		 
		GenericUrl shortenEndpoint = new GenericUrl("https://www.google.com/m8/feeds/contacts/default/full");
		shortenEndpoint.set("startIndex", 1);
		shortenEndpoint.set("max-results", 2000);
		HttpRequest request1 = rf.buildGetRequest(shortenEndpoint);
		//request.headers.contentType = "application/json";//"application/atom+xml";
		
		HttpResponse shortUrl = request1.execute();
		GmailAPI gapi = new GmailAPI();
		
		userSession.setAttribute("network_user", gapi.getUserName(shortUrl.getContent()));
		
		if(userSession.getAttribute("phoneurl") !=null && userSession.getAttribute("userid") !=null)
		{
			NetworkDAO ntdao = new NetworkDAO();
			int userid = (Integer)userSession.getAttribute("userid");
		    int socialid = ntdao.getSocialNetworkId("Gmail");
			Usernetworks onetwork = new Usernetworks(
		    		userid, socialid, "", "", 
		    		userSession.getAttribute("access_token").toString());
		  
			int row = new NetworkDAO().setUserSocialNetworkSite(onetwork);
			
			 if(row > 0)
			 {
			 		new NetworkDAO().setNetworkUserName(onetwork, userSession.getAttribute("network_user").toString());
			 }
			 
			 	/**
				 * Reading Facebook, LinkedIn, Gmail etc... friends for loggedin user and storing into table. 
				 */
				try 
				{
					new ScheduleSocialNetwork().startscheduleScoialNetwork(userid, userSession.getId(),socialid);
					
				} catch (SchedulerException e) {
					e.printStackTrace();
				}
			userSession.removeAttribute("network_user");
			userSession.removeAttribute("phoneurl");
			
			response.sendRedirect("setupnetworkmobile.jsp?userid=" + userid);
		}
		
			out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
			out.println("<HTML>");
			out.println("<HEAD><TITLE>A Servlet</TITLE>");
			out.println("</HEAD>");
			
			if(request.getAttribute("gmail_setupnetwork") != null)
			{
				out.println("<BODY onload=\"window.opener.addGmailNetwork(); window.close()\">");
			}
			else
			{
					out.println("<BODY onload=\"window.opener.addGmailNetwork_wizard(); window.close()\">");
			}
			
			out.println("</BODY>");
			out.println("</HTML>");
		
		
	    /*GoogleAccessProtectedResource access = new GoogleAccessProtectedResource(accessToken,
	            TRANSPORT, JSON_FACTORY, CLIENT_ID, CLIENT_SECRET, refreshToken);
	    
	    HttpRequestFactory rf = TRANSPORT.createRequestFactory(access);
	    
	    GenericUrl shortenEndpoint = new GenericUrl("https://www.google.com/m8/feeds/contacts/default/full");
	    shortenEndpoint.set("startIndex", 1);
	    shortenEndpoint.set("max-results", 2000);
	    HttpRequest grequest = rf.buildGetRequest(shortenEndpoint);
	    HttpResponse shortUrl = grequest.execute();
	    ParseData(shortUrl.getContent());*/
		
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
