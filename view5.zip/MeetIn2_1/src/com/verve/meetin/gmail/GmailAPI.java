package com.verve.meetin.gmail;
 
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessProtectedResource;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessTokenRequest.GoogleRefreshTokenGrant;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDummy;

public class GmailAPI {
	
	
	private static final HttpTransport TRANSPORT = new NetHttpTransport();
	private static final JsonFactory JSON_FACTORY = new JacksonFactory();
	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	static Logger log = Logger.getLogger(GmailAPI.class);
	//Default constructor
	public GmailAPI()
	{
		
	}
	
	public Hashtable<String, List<String>> getFriends(String access_token, String location)
	{
		
		String CLIENT_ID = resource.getString("gmail.client.id");
		String CLIENT_SECRET = resource.getString("gmail.client.secret");
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		String accessToken = access_token.split(",")[0];
		String refreshToken = access_token.split(",")[1];
		HttpRequestFactory rf = null;
		GenericUrl shortenEndpoint = null;
		try{
			
			String token  = requestAccessToken(refreshToken);
			GoogleAccessProtectedResource access = new GoogleAccessProtectedResource(token);
			rf = TRANSPORT.createRequestFactory(access);
				
			shortenEndpoint = new GenericUrl("https://www.google.com/m8/feeds/contacts/default/full");
		    shortenEndpoint.set("startIndex", 1);
		    shortenEndpoint.set("max-results", 2000);
		
	    	HttpRequest request = rf.buildGetRequest(shortenEndpoint);
	    	HttpResponse shortUrl = request.execute();
	    	
	    	friends = ParseData(shortUrl.getContent(), location);
	    	
	    } catch (Exception e) {
	    	e.printStackTrace();
	    	//return getFriends(requestAccessToken(refreshToken) + "," + refreshToken , location);
		}
	 
		return friends;
	}
	public List<SocialNetworkDummy> getGmailFriendsDump(String access_Token, int userId, String sessionId, int socialId)
	{
		try {
				log.info("Trying to get Gmail friends for local dump");
				List<SocialNetworkDummy> friends = new ArrayList<SocialNetworkDummy>();
				
				DocumentBuilderFactory factory = 	DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				
				String CLIENT_ID = resource.getString("gmail.client.id");
				String CLIENT_SECRET = resource.getString("gmail.client.secret");
				
				String accessToken = access_Token.split(",")[0];
				String refreshToken = access_Token.split(",")[1];
				HttpRequestFactory rf = null;
				GenericUrl shortenEndpoint = null;
				
				String token  = requestAccessToken(refreshToken);
				GoogleAccessProtectedResource access = new GoogleAccessProtectedResource(token);
				rf = TRANSPORT.createRequestFactory(access);
					
				shortenEndpoint = new GenericUrl("https://www.google.com/m8/feeds/contacts/default/full");
				shortenEndpoint.set("startIndex", 1);
				shortenEndpoint.set("max-results", 2000);
				
			    HttpRequest request = rf.buildGetRequest(shortenEndpoint);
			    HttpResponse shortUrl = request.execute();
			    
				Document doc = builder.parse(shortUrl.getContent());
				Element e = doc.getDocumentElement();
				
				for(int i =1; i<e.getChildNodes().getLength();i++)
				{
					String location = null;
					String name = "";		
					if(e.getChildNodes().item(i).getNodeName().equals("entry"))
					{
						NodeList ndList = e.getChildNodes().item(i).getChildNodes();
					
						for (int j=1; j<ndList.getLength(); j++)
						{
							if(ndList.item(j).getNodeName().equals("title") && !ndList.item(j).getTextContent().equals(""))
								name = ndList.item(j).getTextContent();
							if(ndList.item(j).getNodeName().equals("gd:postalAddress"))
							{
								location = ndList.item(j).getTextContent();
								Pattern p = Pattern.compile(",\\s?[a-zA-Z]+");
								Matcher m = p.matcher(location);
								location = m.replaceAll("");
							}
						}
						
						if(!name.equals(""))
						{
							SocialNetworkDummy s = new SocialNetworkDummy(sessionId, userId, socialId, name, null, null, location);
							friends.add(s);
						}
					
					}
				}	
				
				log.info("Total Gmail friends found : " + friends.size());
			    return friends;
			    	
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Hashtable<String, List<String>> getFriends(String access_token) {
		String CLIENT_ID = resource.getString("gmail.client.id");
		String CLIENT_SECRET = resource.getString("gmail.client.secret");
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		String accessToken = access_token.split(",")[0];
		String refreshToken = access_token.split(",")[1];
				
		HttpRequestFactory rf = null;
		GenericUrl shortenEndpoint = null;
		 				
		try {
			
			String token  = requestAccessToken(refreshToken);
			GoogleAccessProtectedResource access = new GoogleAccessProtectedResource(token);			
			rf = TRANSPORT.createRequestFactory(access);
			shortenEndpoint = new GenericUrl(
					"https://www.google.com/m8/feeds/contacts/default/full");			
			shortenEndpoint.set("startIndex", 1);
			shortenEndpoint.set("max-results", 2000);	
			
			HttpRequest request = rf.buildGetRequest(shortenEndpoint);
			HttpResponse shortUrl = request.execute();
			friends = ParseData(shortUrl.getContent());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return friends;
	}
	
	public Hashtable<String, List<String>> ParseData(InputStream output)
	{
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		try
		{
			String location = "";
			String name = "";
			DocumentBuilderFactory factory = 
			DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(output);
		
			Element e = doc.getDocumentElement();
			String username = e.getChildNodes().item(0).getTextContent();
			
			for(int i =1; i<e.getChildNodes().getLength();i++)
			{
				if(e.getChildNodes().item(i).getNodeName().equals("entry"))
				{
					System.out.println("child node of the gmail content-"+e.getChildNodes().item(i).getTextContent());
					NodeList ndList = e.getChildNodes().item(i).getChildNodes();
				for (int j=1; j<ndList.getLength(); j++)
				{
					if(ndList.item(j).getNodeName().equals("title") && !ndList.item(j).getTextContent().equals(""))
						name = ndList.item(j).getTextContent();
					if(ndList.item(j).getNodeName().equals("gd:postalAddress"))
					{
						location = ndList.item(j).getTextContent();
						Pattern p = Pattern.compile(",\\s?[a-zA-Z]+");
						Matcher m = p.matcher(location);
						location = m.replaceAll("");
					}
					///////////////////////this code get contacts email address its use send mails/messages
					/*if(ndList.item(j).getNodeName().equals("gd:email"))
					{
						String mail_address = ndList.item(j).getAttributes().getNamedItem("address").toString();
						System.out.println("mail_address------"+mail_address);
						String subject ="Test Mail";
						String toEmail = "lokesh.pareek5@gmail.com";
						String message = "This is test mail";
						String fromEmail ="info@mymeetin.com";
						new InviteFriends().postMail(toEmail, subject, message, fromEmail);						
					}*/
					////////////////////////////
					//else
						//location = "---";
					if(!name.equals(""))
					{
						System.out.println(name);
						List<String> friend_info = new ArrayList<String>();
						friend_info.add(name);
						friend_info.add(location);
						friend_info.add("");
						friend_info.add(new NetworkDAO().getSocailNetworkIcon("Gmail").toString());
						//friend_info.add(ndList.item(j).getTextContent());
						friends.put("gmail-"+i, friend_info);

					}
				}
				name = "";
				location = "";
				
				}
			}
		}
		catch (Exception e)
		{
			System.err.println(e);
			System.exit(0);
		}
		return friends;
	}
	
	public Hashtable<String, List<String>> ParseData(InputStream output, String location)
	{
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		try
		{
			String name = "";
			DocumentBuilderFactory factory = 
			DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(output);
			Element e = doc.getDocumentElement();
			for(int i =1; i<e.getChildNodes().getLength();i++)
			{
				NodeList ndList = e.getChildNodes().item(i).getChildNodes();
				for (int j=1; j<ndList.getLength(); j++)
				{
					if(ndList.item(j).getNodeName().equals("title") && !ndList.item(j).getTextContent().equals(""))
						name = ndList.item(j).getTextContent();
					if(ndList.item(j).getNodeName().equals("gd:postalAddress"))
					{
						if(ndList.item(j).getTextContent().toLowerCase().contains(location.toLowerCase()))
						{
							List<String> friend_info = new ArrayList<String>();
							friend_info.add(name);
							friend_info.add("");
							friend_info.add(new NetworkDAO().getSocailNetworkIcon("Gmail").toString());
							String latlang = new LocationDAO().getCityLatitudeLongitude(location.toLowerCase());
							friend_info.add(latlang.split(":")[0]); // facebok user's latitude
							friend_info.add(latlang.split(":")[1]); // facebook user's langitude
							friend_info.add(""); // empty value
							friend_info.add(""); // empty value for profile Image
							friend_info.add(""); // gmail user's gender
							//friend_info.add(ndList.item(j).getTextContent());
							friends.put("gmail-"+i, friend_info);
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			System.err.println(e);
			System.exit(0);
		}
		return friends;
	}
	
	/* get Gmail UserName */
	public String getUserName(InputStream output)
	  {
		  try
		  {
			  String name="";
			  
			  DocumentBuilderFactory factory =  DocumentBuilderFactory.newInstance();
			  DocumentBuilder builder = factory.newDocumentBuilder();
			  Document doc = builder.parse(output);
			  Element e = doc.getDocumentElement();
			  return e.getChildNodes().item(0).getTextContent();  
		  }
		  
		  catch (Exception e)
		  {
			  System.err.println(e);
			  System.exit(0);
			  return null;
		  }  
	  }
	
	private String requestAccessToken(String refreshToken)
	{
		String token = "";
		
		try {
			
	        GoogleRefreshTokenGrant request = new GoogleRefreshTokenGrant(new NetHttpTransport(),
	            new JacksonFactory(),
	            resource.getString("gmail.client.id"),
	            resource.getString("gmail.client.secret"),
	            refreshToken);
	        
	        com.google.api.client.auth.oauth2.draft10.AccessTokenResponse response = request.execute();
	        token = response.accessToken;
	        
	      } catch (Exception e) {
	    	  System.out.println(e.getMessage());
	      }
	      
		return token;
	}
	
	public static void main(String[] args)
	{
		String accesst = "ya29.AHES6ZTc0AmyGGNWpO9oySeXvhYkY9cVovbBFDri8erd6Ro,1/TPUKmZC5ifunOu0QvjOMGZsea15eKrpf_Gj7S1i46B0";
		List<SocialNetworkDummy> l = new GmailAPI().getGmailFriendsDump(accesst, 4, "DSFDSF", 3);
		for(int i=0; i < l.size();i++)
		{
			SocialNetworkDummy s = (SocialNetworkDummy)l.get(i);
			System.out.println("Name : " +s.getFullname());
			System.out.println("Location : " +s.getLocation());
			System.out.println("Profile URL : " +s.getProfileUrl());
			System.out.println("----------------------------------------");
		}
	}
}
