package com.verve.meetin.tripit;

import java.util.Iterator; 
import java.util.List;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.trip.Trips;

public class Tripit {

	OAuthConsumer consumer;
	OAuthProvider provider;
	
	public Tripit()
	{
		System.out.println("in tripit:::");
		try {
		/*consumer = new DefaultOAuthConsumer("391327d54d014e2b1f137e86ff1755cc9f66630b",
        		"9653d44f5a1320ba0429773b1c5a84b2a9c1d45d"
                );
		
		provider = new DefaultOAuthProvider("https://api.tripit.com/oauth/request_token",
	            "https://api.tripit.com/oauth/access_token",
	            "https://www.tripit.com/oauth/authorize");*/
		
		} catch (Exception e) {
			System.out.println("Exception "+ e); 
		}
		System.out.println("ended");
	}
	
	
	public void saveTripitData(List<Tripit_Trips> list)
	{
		System.out.println("in "+list.size());
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			tx = session.beginTransaction();
						
			if(list !=null && list.size() > 0)
			{
				Iterator itr = list.iterator();
				while(itr.hasNext())
				{
					Tripit_Trips s = (Tripit_Trips)itr.next();
					session.save(s);
				}
				
				tx.commit();
			
			}
		}
		catch(Exception ex)
		{
			tx.rollback();
			ex.printStackTrace();
		}

	}
	
	public int deleteTripit_Trips(int userId)
	{
		int row=0;
		String queryString ="delete from Tripit_Trips as s where s.userId=?";
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = null;
		try
		{
			
			tx = session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    row = query.executeUpdate();
		    tx.commit();
		
		}
		catch(Exception ex)
		{
			tx.rollback();
			ex.printStackTrace();
		}
		return row;
	}
}
