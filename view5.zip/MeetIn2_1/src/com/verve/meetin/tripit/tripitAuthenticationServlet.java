package com.verve.meetin.tripit;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;
import oauth.signpost.exception.OAuthNotAuthorizedException;
import oauth.signpost.signature.HmacSha1MessageSigner;

import org.apache.http.Header;
import org.apache.http.client.methods.HttpPost;
import org.json.JSONArray;
import org.json.JSONObject;

import twitter4j.http.AccessToken;

import com.tripit.api.Client;
import com.tripit.api.Response;
import com.tripit.api.Type;
import com.tripit.auth.Credential;
import com.tripit.auth.OAuthCredential;

public class tripitAuthenticationServlet extends HttpServlet {

	
	String authUrl;
	ResourceBundle resource;
	HttpServletRequest request;
	AccessToken accessToken;
	
	 OAuthConsumer consumer = new DefaultOAuthConsumer("391327d54d014e2b1f137e86ff1755cc9f66630b","9653d44f5a1320ba0429773b1c5a84b2a9c1d45d");
	 OAuthProvider provider = new DefaultOAuthProvider(
	            "https://api.tripit.com/oauth/request_token",
	            "https://api.tripit.com/oauth/access_token",
	            "https://www.tripit.com/oauth/authorize");
	 
	/**
	 * Constructor of the object.
	 */
	public tripitAuthenticationServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	
	public void gettripitCredentials() 
    {
		
	
		 consumer.setMessageSigner(new HmacSha1MessageSigner());
		
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
       System.out.println(resource.getString("tripit.redirect_uri"));
       System.out.println(consumer);
		try {
			//OAuth.OUT_OF_BAND
			authUrl = provider.retrieveRequestToken(consumer, resource.getString("tripit.redirect_uri"));
			System.out.println("authurl:::: "+authUrl);
		} catch (OAuthMessageSignerException e) {
			// TODO Auto-generated catch block
			//System.out.println("Exception is "+e.getMessage());
		} catch (OAuthNotAuthorizedException e) {
			// TODO Auto-generated catch block
			//System.out.println("Exception is "+e.getMessage());
		} catch (OAuthExpectationFailedException e) {
			// TODO Auto-generated catch block
			//System.out.println("Exception is "+e.getMessage());
		} catch (OAuthCommunicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//System.out.println("Exception is "+e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
		}
    }
	
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		if(request.getParameter("oauth_token") == null) {
			gettripitCredentials();
//			System.out.println("auth url "+authUrl);
			response.sendRedirect(authUrl);
		}
		else {

		//	System.out.println("consumer get token "+consumer.getToken());
		//	System.out.println("consumer get secret token "+consumer.getTokenSecret());

			HttpSession userSession = request.getSession();
			userSession.setAttribute("access_token", consumer.getToken()+","+consumer.getTokenSecret());

			try {
				
				provider.retrieveAccessToken(consumer, request.getParameter("oauth_token"));

				
			} catch (Exception e) {
				System.out.println("Exception occured " + e);
			}
			
			
			out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
			out.println("<HTML>");
			out.println("<HEAD><TITLE>A Servlet</TITLE>");
			out.println("</HEAD>");
			
			if(request.getAttribute("twitter_setupnetwork") != null)
			{
				out.println("<BODY onload=\"window.opener.addtwitterNetwork(); window.close()\">");
			}
			else
			{
				userSession.setAttribute("flag","flag");
				try
			  	{
			  		Credential cred = new OAuthCredential("391327d54d014e2b1f137e86ff1755cc9f66630b","9653d44f5a1320ba0429773b1c5a84b2a9c1d45d",consumer.getToken(),consumer.getTokenSecret());
			  		Client client = new Client(cred);
			        Map<String, String> listMap = new HashMap<String, String>();
			    	listMap.put("upcoming","true");
			    	listMap.put("format", "json");
			
			    	Response r;
			    	
			    	Type t = null;
			    	t = Type.TRIP;
			    	r = client.list(t, listMap);
			    	String str = r.toString();
			    	int i =	str.indexOf("{");
			    	String jobject = str.substring(i,str.length());
			    	JSONObject  jsonObject = new JSONObject(jobject.toString());
			    	System.out.println("json object value ******  " + jsonObject);
			    	
			    
			    	
			    	List <Tripit_Trips> list =new ArrayList<Tripit_Trips>();
			    	
			    	try
			    	{
			    		JSONObject profile = jsonObject.getJSONObject("Profile");
			    		userSession.setAttribute("network_user",profile.get("public_display_name").toString());	
			    		JSONObject jsonObject2 = jsonObject.getJSONObject("Trip");
			    	//System.out.println("End Date   "+	jsonObject2.getString("end_date"));		    		System.out.println("End Date   "+	jsonObject2.getString("start_date"));			    		System.out.println("End Date   "+	jsonObject2.getString("primary_location"));			    		System.out.println("Description "+jsonObject2.get("display_name"));
			    		
			    		JSONObject jsonObject3 = jsonObject2.getJSONObject("PrimaryLocationAddress");
			    		
			    	//	System.out.println("longitude "+jsonObject3.get("longitude"));						System.out.println("latitude  "+jsonObject3.get("latitude"));

						DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						Date start_date = (Date) formatter.parse(jsonObject2.get("start_date").toString());
						Date end_date = (Date) formatter.parse(jsonObject2.get("end_date").toString());
Tripit_Trips trips = new Tripit_Trips(8, jsonObject2.get("primary_location").toString(), jsonObject2.get("display_name").toString(), start_date, end_date ,jsonObject3.get("latitude").toString() ,jsonObject3.get("longitude").toString());
						list.add(trips);
						new Tripit().saveTripitData(list);
						
			    	}
			    	catch (Exception e)
			    	{
						try 
						{
					//		JSONObject jsonObject = new JSONObject(jsonString);
						JSONArray jsonArray =	jsonObject.getJSONArray("Trip");		
						for (i = 0; i < jsonArray.length(); i++) 
						{
							Tripit_Trips trips =null;
							JSONObject jsonObject1 = jsonArray.getJSONObject(i);
						//	System.out.println("location "+jsonObject1.get("primary_location"));				System.out.println("Description "+jsonObject1.get("display_name"));						System.out.println("Start date " +jsonObject1.get("start_date"));						System.out.println("end date"+jsonObject1.get("end_date"));
							JSONObject jsonObject2 = jsonObject1.getJSONObject("PrimaryLocationAddress");
						//	System.out.println("longitude "+jsonObject2.get("longitude"));							System.out.println("latitude  "+jsonObject2.get("latitude"));
							
							DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
							Date start_date = (Date) formatter.parse(	jsonObject1.get("start_date").toString());
							Date end_date = (Date) formatter.parse(	jsonObject1.get("end_date").toString());
							
							trips = new Tripit_Trips(8, jsonObject1.get("primary_location").toString(), jsonObject1.get("display_name").toString(), start_date, end_date ,jsonObject2.get("latitude").toString() ,jsonObject2.get("longitude").toString());
							//System.out.println(trips.getDescription());
							list.add(trips);
						}
						new Tripit().saveTripitData(list);
							
						}
						catch (Exception e2) 
						{
							System.out.println("EXception catched " +e );
						}
						
					}
			    	
			    	//here we are 
			    	/*
			    	Map<String, String> listMap1 = new HashMap<String, String>();
			    	listMap1.put("start_date","2009-13-09");
			    	listMap1.put("end_date","2009-13-19");
			    	listMap1.put("primary_location", "New York, NY");
			    	Request request2 = new Request("https://api.tripit.com/v1/create?format=json", true, listMap);*/
			    	
			  /*
			    	System.out.println("in 11111111111111111111111111111111111111111111111111111");
			    	
			    	HttpClient httpclient = new DefaultHttpClient();
			    	HttpPost httppost = new HttpPost("https://api.tripit.com/v1/create?format=json");
			    	
			    	StringEntity obj =new StringEntity(" {\"Trip\": {\"start_date\":\"2009-12-09\",  \"end_date\":\"2009-12-27\",  \"primary_location\":\"New York, NY\"   }}");
			    	//httppost.addHeader("content-type", "application/x-www-form-urlencoded");
			    	httppost.addHeader("content-type", "application/json");
			    	httppost.setEntity(obj);
			    	
			    	HttpResponse response2 = httpclient.execute(httppost);
			    	System.out.println(response2);
			    
			    	
			    	
			    	System.out.println("in 2222222222222222222222222222222222222222222222222222222");
			    	*/
			    	//List<NameValuePair> params = new ArrayList<NameValuePair>(2);
			    	/*params.add(new BasicNameValuePair("start_date", "2009-13-09"));
			    	params.add(new BasicNameValuePair("end_date", "2009-13-19"));*/
			    				    	
			    	} catch (Exception e) {
			    			e.printStackTrace();
					}
			
			    	//start herr
						    	
/*					String obj = " {\"Trip\": {\"start_date\":\"2009-12-09\",  \"end_date\":\"2009-12-27\",  \"primary_location\":\"New York, NY\"   }}";

					String contentType = "application/json";
					HttpPost httpPost = new HttpPost("https://api.tripit.com/v1/create");
					List<NameValuePair> postParams = new ArrayList<NameValuePair>();
					postParams.add(new BasicNameValuePair("json", obj.toString()));

					HttpGet httpGet = null;
					try {
						System.out.println("/////// 111111 ");
					    UrlEncodedFormEntity entity = new UrlEncodedFormEntity(postParams);
					    entity.setContentEncoding(HTTP.UTF_8);
					    entity.setContentType("application/json");
					    httpPost.setEntity(entity);
						System.out.println("/////// 222222 ");
					    httpPost.setHeader("Content-Type", contentType);
					    httpPost.setHeader("Accept", contentType);
					} catch (UnsupportedEncodingException e) {
						System.out.println("Exception occured " +e);
						
					}
					try {
						HttpClient httpclient = new DefaultHttpClient();
					    HttpResponse httpResponse = httpclient.execute(httpPost);
					    HttpEntity httpEntity = httpResponse.getEntity();

					    System.out.println("in 3333333333333");
					    if (httpEntity != null) {
					        InputStream is = httpEntity.getContent();
					        StringWriter writer = new StringWriter();
					        IOUtils.copy(is, writer, "UTF-8");
					        String theString = writer.toString();
					        System.out.println("Data "+theString);
					        System.out.println("4444444444444 ");
					        //result = StringUtils.convertStreamToString(is);
					       // Log.i(TAG, "Result: " + result);
					    }
					} catch (Exception e) {
						System.out.println("Exception occured " +e);
					}
					

*/			    	
			    	
				out.println("<BODY onload=\"window.opener.addtripitNetwork_wizard(); window.close()\">");
			}
			
			out.println("</BODY>");
			out.println("</HTML>");
			out.flush();
			out.close();
			
			
		}
		
	
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
