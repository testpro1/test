package com.verve.meetin.tripit;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.json.JSONArray;
import org.json.JSONObject;

import com.tripit.api.Client;
import com.tripit.api.Response;
import com.tripit.api.Type;
import com.tripit.auth.Credential;
import com.tripit.auth.OAuthCredential;
import com.verve.hibernate.utils.HibernateUtil;

public class Tripit_Trips_DAO {

	public List getUserUpcomingTrips(int userid)
	{
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println("in  " + dateFormat.format(date));
		
		List resultList =null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String queryString ="from Tripit_Trips as trip where userId=? order by trip.fromDate asc";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    
		    query.setParameter(0, userid);
		    System.out.println("before query  " + dateFormat.format(date));
		    resultList = query.list();
		    System.out.println("after query  " + dateFormat.format(date));
		    session.getTransaction().commit();
		}
		catch(Exception ex)
		{
			System.out.println("EXception " +ex);
		}
				
	   return resultList;	
	}
	
	
	public void getTripitTrips(int userid,String access_token)
	{
			
		try 
		{
			try
		  	{
		  		Credential cred = new OAuthCredential("391327d54d014e2b1f137e86ff1755cc9f66630b","9653d44f5a1320ba0429773b1c5a84b2a9c1d45d",access_token.split(",")[0],access_token.split(",")[1]);
		  		
		  		Client client = new Client(cred);
		        Map<String, String> listMap = new HashMap<String, String>();
		    	listMap.put("upcoming","true");
		    	listMap.put("format", "json");
		
		    	Response r;
		    	
		    	Type t = null;
		    	t = Type.TRIP;
		    	r = client.list(t, listMap);
		    	String str = r.toString();
		    	int i =	str.indexOf("{");
		    	String jobject = str.substring(i,str.length());
		    	JSONObject  jsonObject = new JSONObject(jobject.toString());
		    	System.out.println("json object value ******  " + jsonObject);
		    	
		    
		    	
		    	List <Tripit_Trips> list =new ArrayList<Tripit_Trips>();
		    	
		    	try
		    	{
		    		JSONObject profile = jsonObject.getJSONObject("Profile");
		    			
		    		JSONObject jsonObject2 = jsonObject.getJSONObject("Trip");
		    	//System.out.println("End Date   "+	jsonObject2.getString("end_date"));		    		System.out.println("End Date   "+	jsonObject2.getString("start_date"));			    		System.out.println("End Date   "+	jsonObject2.getString("primary_location"));			    		System.out.println("Description "+jsonObject2.get("display_name"));
		    		
		    		JSONObject jsonObject3 = jsonObject2.getJSONObject("PrimaryLocationAddress");
		    		
		    	//	System.out.println("longitude "+jsonObject3.get("longitude"));						System.out.println("latitude  "+jsonObject3.get("latitude"));

					DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					Date start_date = (Date) formatter.parse(jsonObject2.get("start_date").toString());
					Date end_date = (Date) formatter.parse(jsonObject2.get("end_date").toString());
Tripit_Trips trips = new Tripit_Trips(userid, jsonObject2.get("primary_location").toString(), jsonObject2.get("display_name").toString(), start_date, end_date ,jsonObject3.get("latitude").toString() ,jsonObject3.get("longitude").toString());
					list.add(trips);
					new Tripit().saveTripitData(list);
					
		    	}
		    	catch (Exception e)
		    	{
					try 
					{
						
						JSONArray profile = jsonObject.getJSONArray("Profile");
                        JSONObject object = profile.getJSONObject(0);
                        
                        System.out.println(object.getString("public_display_name").toString());
                        
					JSONArray jsonArray =	jsonObject.getJSONArray("Trip");		
					for (i = 0; i < jsonArray.length(); i++) 
					{
						Tripit_Trips trips =null;
						JSONObject jsonObject1 = jsonArray.getJSONObject(i);
					//	System.out.println("location "+jsonObject1.get("primary_location"));				System.out.println("Description "+jsonObject1.get("display_name"));						System.out.println("Start date " +jsonObject1.get("start_date"));						System.out.println("end date"+jsonObject1.get("end_date"));
						JSONObject jsonObject2 = jsonObject1.getJSONObject("PrimaryLocationAddress");
					//	System.out.println("longitude "+jsonObject2.get("longitude"));							System.out.println("latitude  "+jsonObject2.get("latitude"));
						
						DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						Date start_date = (Date) formatter.parse(	jsonObject1.get("start_date").toString());
						Date end_date = (Date) formatter.parse(	jsonObject1.get("end_date").toString());
						
						trips = new Tripit_Trips(userid, jsonObject1.get("primary_location").toString(), jsonObject1.get("display_name").toString(), start_date, end_date ,jsonObject2.get("latitude").toString() ,jsonObject2.get("longitude").toString());
						//System.out.println(trips.getDescription());
						list.add(trips);
					}
					new Tripit().saveTripitData(list);
						
					}
					catch (Exception e2) 
					{
						System.out.println("EXception catched " +e );
					}
					
				}

		    	} catch (Exception e) {
		    			e.printStackTrace();
				}
		
		
		} catch (Exception e) {
				System.out.println("EXception occured " +e);
		}	
		
	}
	
	public static void main(String args[])
	{
		//new Tripit_Trips_DAO().getTripitTrips();
	}
	
}
