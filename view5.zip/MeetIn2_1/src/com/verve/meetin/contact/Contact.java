package com.verve.meetin.contact;

import org.apache.struts.action.ActionForm;

public class Contact extends ActionForm implements java.io.Serializable{

	private Integer contactId;
	private String name;
	private String email;
	private String contactNo;
	private String purpose;
	
	
	
	/**
	 * 
	 */
	public Contact() {
		
		// TODO Auto-generated constructor stub
	}



	/**
	 * @param contactId
	 * @param name
	 * @param email
	 * @param contactno
	 * @param purpose
	 */
	public Contact(Integer contactId, String name, String email, String contactNo, String purpose) {
		
		this.contactId = contactId;
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.purpose = purpose;
	}
	
	
	
	/**
	 * @param name
	 * @param email
	 * @param contactno
	 * @param purpose
	 */
	public Contact(String name, String email, String contactNo, String purpose) {
		
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.purpose = purpose;
	}



	public Integer getContactId() {
		return contactId;
	}
	public void setContactId(Integer contactId) {
		this.contactId = contactId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	
	
	
	
	
}
