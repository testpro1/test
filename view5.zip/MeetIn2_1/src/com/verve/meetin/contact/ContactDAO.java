package com.verve.meetin.contact;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;

public class ContactDAO 
{

	static Logger log = Logger.getLogger(ContactDAO.class);
	
	public int addContactUser(Contact contact)
	{
		log.info("Inside Create ContactInfo....");
		int last_contact_id = 0;
		
		try
		{
				Session session = HibernateUtil.getSessionFactory().getCurrentSession();
				Transaction tx = null;
				tx = session.beginTransaction();
				last_contact_id = (Integer)session.save(contact);
				tx.commit();
				log.info("Basic information has been added successfully");	
		}
		catch(Exception ex)
		{
			log.error("There is a problem adding basic information");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return last_contact_id;
	}
	public String retrieveEmailId (int userid)
	{
		String result = ""; 
		ArrayList< String> arrayList = new ArrayList<String>();
		String queryString = "SELECT email FROM User WHERE userId = ?";
		
		try 
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			query.setParameter(0, userid);
			arrayList = (ArrayList<String>) query.list();
			session.getTransaction().commit();
			
			int count = arrayList.size();
			int i=0;
			while(i<count)
			{
				result = arrayList.get(i);
				i++;
			}
				
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return result;
	}
}
