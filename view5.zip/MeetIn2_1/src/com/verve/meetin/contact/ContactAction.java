package com.verve.meetin.contact;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class ContactAction extends DispatchAction{
	
	public ActionForward addContact(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
	
		Contact ocontact = (Contact) form;
		ContactDAO contactDAO = new ContactDAO();
		Contact contact = new Contact(ocontact.getName(), ocontact.getEmail(), ocontact.getContactNo(), ocontact.getPurpose());
		
		HttpSession session = request.getSession();
		session.setAttribute("emailID",ocontact.getEmail());
		
		
		/* This code line save the contact details */
		int last_contact_id = contactDAO.addContactUser(contact);
		ContactAction action=new ContactAction();
		//action.sendToAdmin(mapping, form, request, response);
		//action.sendToContact(mapping, form, request, response);	
		return mapping.findForward("success");
	}
	
	public ActionForward sendToAdmin(ActionMapping mapping,ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		HttpSession sc = request.getSession();
		
		Contact contact=new Contact();
		Contact con = (Contact)form;
		String path = request.getContextPath();
		String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/profileimage/";
		String imageName="";
		String subject ="Request to contact";
		String toEmail = "info@mymeetin.com";
		String contactEmail = con.getEmail();
		String contactName = con.getName();
		String contactNo=con.getContactNo();
		String contactPurpose = con.getPurpose();
	     //user =(User)new UserAccountDAO().getUserProfileDetails((Integer)sc.getAttribute("UserID"));
		String meetinLogo =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/images/meetin_icon.png";
		
		/*if(userId !=null && userId.intValue() !=0)
		{
			user = (User) new UserAccountDAO().getUserProfileDetails(userId);
			if(user !=null)
			{
				if(user.getImage() !=null && !user.getImage().equals(""))
				{
					imageName = imagePath + user.getUserId()+ "_" +user.getImage();		
					
				}
			}*/
		
		
		String htmlmessage  = "<div style=\"width: 500px;\">";
		htmlmessage +="<div style=\"background-color: rgb(255, 153, 0); padding: 5px 10px; color: rgb(255, 255, 255); font-family: 'Trebuchet MS'; font-size: 18px;\"><img src="+ meetinLogo +" align=\"absmiddle\" hspace=\"5\"></img><strong>Request to contact</strong></div>";
		htmlmessage +="<div style=\"margin-top: 10px; padding: 0px 10px; font-family: 'Trebuchet MS';font-size: 14px;\">The user below is trying to contact. It's information is given below, <br/><br/> ";
		htmlmessage +="<div style=\"font-size: 14px; font-family: 'Trebuchet MS'; \">Name:" + contactName + "</div> <br/> ";
		htmlmessage +="<div style=\"font-size: 14px; font-family: 'Trebuchet MS'; \">Email:" + contactEmail + "</div> <br/> ";
		htmlmessage +="<div style=\"font-size: 14px; font-family: 'Trebuchet MS';\">Contact NO:" + contactNo + "</div> <br/> ";
		htmlmessage +="<div style=\"font-size: 14px; font-family: 'Trebuchet MS';\">Purpose:" + contactPurpose + "</div> ";
		//htmlmessage +="<div style=\"padding: 10px 10px 10px 0px;float:left;\"><img src="+ imageName +" width=\"75px\" height=\"75px\"></div>";
		htmlmessage +="<div style=\"float:left;\"></div>";
		//htmlmessage += "<div style=\"font-size: 14px; \"><p><strong>" + con.getName() + "</strong> has shared a link with you</p></div> ";		
/*		htmlmessage += "<p>Subject :" + subject + "</p> ";
		htmlmessage += "<p>Hi "  + friendname +", <br/><br/>";
		htmlmessage += invitemessage +"</p> ";
		htmlmessage +="<p><a href=\"http://meetin.vervesys.com/signup.jsp\" style=\"color:#FF9900; font-size:16px; text-decoration:none\"><strong>Join MeetIn</strong></a></p></div>";*/

		new InviteContact().postMail(toEmail, subject, htmlmessage, contactEmail);
		

		return mapping.findForward("success");		
	}
	
	public ActionForward sendToContact(ActionMapping mapping,ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		HttpSession sc = request.getSession();
		
		Contact contact=new Contact();
		Contact con = (Contact)form;
		String path = request.getContextPath();
		String imagePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/profileimage/";
		String imageName="";
		String subject ="Request to contact";
		String toEmail = "lokesh.pareek5@gmail.com";
		String contactEmail = con.getEmail();
		String contactName = con.getName();
		String contactNo=con.getContactNo();
		String contactPurpose = con.getPurpose();
	     //user =(User)new UserAccountDAO().getUserProfileDetails((Integer)sc.getAttribute("UserID"));
		String meetinLogo =request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/images/meetin_icon.png";

		String htmlmessage  = "<div style=\"width: 500px;\">";
		htmlmessage +="<div style=\"background-color: rgb(255, 153, 0); padding: 5px 10px; color: rgb(255, 255, 255); font-family: 'Trebuchet MS'; font-size: 18px;\"><img src="+ meetinLogo +" align=\"absmiddle\" hspace=\"5\"></img><strong>Request to contact</strong></div><br/><br/>";		
		htmlmessage +="<div style=\"font-size: 14px; font-family: 'Trebuchet MS'; \">Hello,</div> <br/>";
		htmlmessage +="<div style=\"font-size: 14px; font-family: 'Trebuchet MS';\">Thanks for contacting us,we will contact you soon. </div> <br/>";
		htmlmessage +="<div style=\"font-size: 14px; font-family: 'Trebuchet MS'; \">Regards,<br/>MeetIn Team</div>";		
		//htmlmessage +="<div style=\"padding: 10px 10px 10px 0px;float:left;\"><img src="+ imageName +" width=\"75px\" height=\"75px\"></div>";
		htmlmessage +="<div style=\"float:left;\"></div>";
		//htmlmessage += "<div style=\"font-size: 14px; \"><p><strong>" + con.getName() + "</strong> has shared a link with you</p></div> ";		
		
		

		new InviteContact().postMail(contactEmail, subject, htmlmessage, toEmail);
		

		return mapping.findForward("success");		
	}
}
