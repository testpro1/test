package com.verve.meetin.contact;

import java.util.Properties;
import java.util.ResourceBundle;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

public class InviteContact {

	static Logger log = Logger.getLogger(InviteContact.class);
	ResourceBundle resource;
	//String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
     
public void postMail(String recipient, String subject,
                          String message , String from) throws MessagingException    
 {
	
	resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	
    log.info("Sending Email to contact User");
    log.info("Email receiver :" + recipient);
    log.info("Email sender :" + resource.getString("mailAdmin.id"));       
   
    String SMTP_HOST_NAME = resource.getString("mailAdmin.hostname");
    String SMTP_PORT= resource.getString("mailAdmin.port");
   
    boolean debug = false;
    Properties props = new Properties();
    props.put("mail.smtp.host",SMTP_HOST_NAME);
    props.put("mail.smtp.port",SMTP_PORT);
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.socketFactory.port", SMTP_PORT);
  // props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
    props.put("mail.smtp.socketFactory.fallback", "false");
  
    Authenticator auth = new SMTPAuthenticator();
    Session session = Session.getDefaultInstance(props, auth);
  
    session.setDebug(debug);

  // create a message
    Message msg = new MimeMessage(session);
 
  // set the from and to address
    InternetAddress addressFrom = new InternetAddress(resource.getString("mailAdmin.id"));
    msg.setFrom(addressFrom);
    
    InternetAddress addressTo = new InternetAddress(recipient);
    msg.setRecipient(Message.RecipientType.TO, addressTo);

  // Setting the Subject and Content Type
    msg.setSubject(subject);
 
  // Setting the Email Message and Content Type
    msg.setContent(message, "text/html");

    Transport.send(msg);
    log.info("Email has been sent successfully to:" +recipient);
    
 }
 
public class SMTPAuthenticator extends javax.mail.Authenticator{
   @Override
   public PasswordAuthentication getPasswordAuthentication()
    {
	   String SMTP_AUTH_USER = resource.getString("mailAdmin.id");
	   String SMTP_AUTH_PWD  = resource.getString("mailAdmin.password");
       String username = SMTP_AUTH_USER;
       String password = SMTP_AUTH_PWD;
       return new PasswordAuthentication(username, password);
    }
  }


}
