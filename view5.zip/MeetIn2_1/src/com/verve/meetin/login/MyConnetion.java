package com.verve.meetin.login;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyConnetion {
	
	
public static Connection getMyConnection(){
		
		Connection cn= null;
		
		try{
			 
			Class.forName("com.mysql.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://192.168.1.102:3306/meetin", "meetin","meetin");
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return cn;
	}

}
