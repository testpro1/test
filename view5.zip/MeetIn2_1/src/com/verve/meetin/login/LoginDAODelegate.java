package com.verve.meetin.login;

@javax.jws.WebService(targetNamespace = "http://login.meetin.verve.com/", serviceName = "LoginDAOService", portName = "LoginDAOPort", wsdlLocation = "WEB-INF/wsdl/LoginDAOService.wsdl")
public class LoginDAODelegate {

	com.verve.meetin.login.LoginDAO loginDAO = new com.verve.meetin.login.LoginDAO();

	/*public Login isUserValid(String username,String password) {
		return loginDAO.isUserValid(username,password);
	}*/

	public void main(String[] args) {
		LoginDAO.main(args);
	}

}