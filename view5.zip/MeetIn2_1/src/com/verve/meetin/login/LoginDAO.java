package com.verve.meetin.login;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import org.apache.log4j.Logger;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("Login")
public class LoginDAO
{
	
	Connection cn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	Logger log = Logger.getLogger(LoginDAO.class);
		
	@Consumes("application/xml")
	@Produces("application/xml")
	@POST
	@Path("login")
	
	/*public Login isUserValid(@HeaderParam("username") String username, @HeaderParam("password") String password)
	{ 
	    	
        log.info("Username :" +username);
        log.info("Password :" +password);
        
        Login l = null;
		String loginResult = null;
		try{
			
			cn = MyConnetion.getMyConnection();
			ps= cn.prepareStatement("select * from mi_users where email = ? and password = ?");
			ps.setString(1, username);
			ps.setString(2, password);
			
			rs = ps.executeQuery();
			 
			if(rs !=null && rs.next())
			{
				  l = new Login();
				  loginResult = "valid";
	 		      l.setLoginResult(loginResult);
	 		      return l;
			}
						
		
		}catch(Exception ex){
		   ex.printStackTrace();	
		}
		
		return l;
	}*/
	
	public static void main(String args[]){

		Login l = new Login();
	//	l = new LoginDAO().isUserValid("vasim","vasim");
		
		
				
		if(l !=null)
		{
			
			
		}
		
	}
	
}
	
