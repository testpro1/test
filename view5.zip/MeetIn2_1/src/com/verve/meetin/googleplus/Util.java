package com.verve.meetin.googleplus;


import com.google.api.client.googleapis.json.GoogleJsonError;
import com.google.api.client.http.HttpResponseException;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.Json;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.Strings;

import java.io.IOException;

/**
 * @author Jennifer Murphy
 */
public class Util {
  public static final JsonFactory JSON_FACTORY = new GsonFactory();
  public static final HttpTransport TRANSPORT = new NetHttpTransport();

  /**
   * A simple HTML tag stripper to prepare HTML for rendering. This is a
   * quick and dirty solution so please do not depend on it to prevent XSS
   * attacks.
   *
   * @return The same string with all xml/html tags stripped.
   */
  public static String stripTags(String input) {
    return input.replaceAll("\\<[^>]*>","");
  }

  /**
   * Extract the request error details from a HttpResponseException
   * @param e An HttpResponseException that contains error details
   * @return The String representation of all errors that caused the
   *     HttpResponseException
   * @throws java.io.IOException when the response cannot be parsed or stringified
   */
  public static String extractError(HttpResponseException e) throws IOException {
    if (!Json.CONTENT_TYPE.equals(e.response.contentType)) {
      return e.response.parseAsString();
    }

    GoogleJsonError errorResponse =
            GoogleJsonError.parse(JSON_FACTORY, e.response);
    StringBuilder errorReportBuilder = new StringBuilder();

    errorReportBuilder.append(errorResponse.code);
    errorReportBuilder.append(" Error: ");
    errorReportBuilder.append(errorResponse.message);

    for (GoogleJsonError.ErrorInfo error : errorResponse.errors) {
      errorReportBuilder.append(JSON_FACTORY.toString(error));
      errorReportBuilder.append(Strings.LINE_SEPARATOR);
    }
    return errorReportBuilder.toString();
  }
}
