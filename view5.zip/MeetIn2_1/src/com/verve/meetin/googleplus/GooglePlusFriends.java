package com.verve.meetin.googleplus;

import com.google.gdata.client.*;
import com.google.gdata.client.contacts.*;
import com.google.gdata.data.contacts.ContactEntry;
import com.google.gdata.data.contacts.ContactFeed;
import com.google.gdata.data.extensions.*;
import com.google.gdata.util.ServiceException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class GooglePlusFriends 
{
		
    public Hashtable<String, List<String>> getGooglePlusFriends(String email,String password) throws IOException, ServiceException
	{
    	
    	Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
    	
    	try
    	{
    		
    		//String sessionToken = AuthSubUtil.exchangeForSessionToken(access_token, null);
    		ContactsService myService = new ContactsService("verve-meetin-2.0");
    		//myService.setAuthSubToken(sessionToken,null);
    		myService.setUserCredentials(email,password);
    		URL feedUrl = new URL("http://www.google.com/m8/feeds/contacts/default/full");	 
    	    Query myQuery = new Query(feedUrl);
    	    myQuery.setStartIndex(1);
    	    myQuery.setMaxResults(200);
    	    
    	    ContactFeed resultFeed = myService.query(myQuery, ContactFeed.class);
    	    
    	    for (int i = 0; i < resultFeed.getEntries().size(); i++) {
 				ContactEntry entry = resultFeed.getEntries().get(i);
 				List<String> friend_info = new ArrayList<String>();
 				if (entry.getTitle() != null && !entry.getTitle().getPlainText().equals("") && !entry.getTitle().getPlainText().equals("null"))
 					{
 					    friend_info.add(entry.getTitle().getPlainText());
 					   // code for user address 
 					    List l = entry.getStructuredPostalAddresses();
 					    
 					    if(l !=null && l.size() > 0)
 					    {
 					    	
 					    	StructuredPostalAddress address = (StructuredPostalAddress)l.get(0);
 					    	if(address.hasCity())
 					    	{
 					    		friend_info.add(address.getCity().getValue());
 					    	}
 					    	else if(address.hasCountry())
 					    	{
 					    		friend_info.add(address.getCountry().getValue());
 					    	}
 					    	else if(address.hasStreet())
 					    	{
 					    		friend_info.add(address.getStreet().getValue());
 					    	}
 					    	else
 	 					    {
 	 							friend_info.add("---");
 	 					    }
 					    	/*if(address.getCity().getValue() !=null && !address.getCity().getValue().equals(""))
 					    		{
 					    			friend_info.add(address.getCity().getValue());			
 					    		}*/
 					    
 					    }
 					    else
 					    {
 							friend_info.add("---");
 					    }
 					    
 		 				 friend_info.add("");
 		 				// friend_info.add(new NetworkDAO().getSocailNetworkIcon("GooglePlus").toString());
 		 				
 		 				 friends.put(Integer.toString(i), friend_info);
 					}			
    	    }
    	}
    	catch(Exception ex)
    	{
    		//System.out.println("Error :" +ex.getMessage());
    		ex.printStackTrace();
    	}
    	
    	return friends;
	}
    public String getGmailUserAuthenticate(String email, String password)  
    {
    	try
    	{
    		ContactsService myService = new ContactsService("verve-meetin-2.0");
    		myService.setUserCredentials(email,password);
    		
    	}
    	catch(Exception ex)
    	{
    	   return ex.getMessage();	
    	}
    	
    	return "valid";
    }
    public static void main(String args[]) throws IOException, ServiceException{
    	new GooglePlusFriends().getGooglePlusFriends("", "");
    }
}

