package com.verve.meetin.googleplus;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessProtectedResource;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;
import com.verve.meetin.location.LocationDAO;
import com.verve.meetin.network.NetworkDAO;

public class GooglePlusAPI {
	
	private static final HttpTransport TRANSPORT = new NetHttpTransport();
	private static final JsonFactory JSON_FACTORY = new JacksonFactory();
	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");

	//Default constructor
	public GooglePlusAPI() {
		// TODO Auto-generated constructor stub
	}
	public Hashtable<String, List<String>> getFriends(String access_token, String location)
	{
		String CLIENT_ID = resource.getString("googleplus.client.id");
		String CLIENT_SECRET = resource.getString("googleplus.client.secret");
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		String accessToken = access_token;
		
		
		HttpRequestFactory rf = null;
		GenericUrl shortenEndpoint = null;
		try{
			
			/*GoogleAccessProtectedResource access = new GoogleAccessProtectedResource(accessToken,
								TRANSPORT, JSON_FACTORY, CLIENT_ID, CLIENT_SECRET, refreshToken);*/
			GoogleAccessProtectedResource requestInitializer = new GoogleAccessProtectedResource(accessToken);
			rf = TRANSPORT.createRequestFactory(requestInitializer);
			//shortenEndpoint = new GenericUrl("https://www.google.com/m8/feeds/contacts/default/full");
			shortenEndpoint = new GenericUrl("http://www.google.com/calendar/feeds/default/allcalendars/full");
		    shortenEndpoint.set("startIndex", 1);
		    shortenEndpoint.set("max-results", 2000);
		    
		}catch(Exception e)
		{
			List<String> msg = new ArrayList<String>();
			msg.add(e.getMessage());
			friends.put("ERROR", msg);
			return friends;
		}
		
	    try {
	    	
	    	HttpRequest request = rf.buildGetRequest(shortenEndpoint);
	    	HttpResponse shortUrl = request.execute();
	    	friends = ParseData(shortUrl.getContent(), location);

	    } catch (IOException e) {
	    	List<String> msg = new ArrayList<String>();
			msg.add(e.getMessage());
			friends.put("ERROR", msg);
			return friends;
		}
		return friends;
	}
	
	public Hashtable<String, List<String>> getFriends(String access_token)
	{
		String CLIENT_ID = resource.getString("googleplus.client.id");
		String CLIENT_SECRET = resource.getString("googleplus.client.secret");
	
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		String accessToken = access_token;
		HttpRequestFactory rf = null;
		GenericUrl shortenEndpoint = null;
		try{
			
			/*GoogleAccessProtectedResource access = new GoogleAccessProtectedResource(accessToken,
								TRANSPORT, JSON_FACTORY, CLIENT_ID, CLIENT_SECRET, refreshToken);*/
			GoogleAccessProtectedResource access = new GoogleAccessProtectedResource(accessToken,
					TRANSPORT, JSON_FACTORY, CLIENT_ID, CLIENT_SECRET,"");
			rf = TRANSPORT.createRequestFactory(access);
			/*GoogleAccessProtectedResource requestInitializer = new GoogleAccessProtectedResource(accessToken);
			rf = TRANSPORT.createRequestFactory(requestInitializer);*/
			
			/*Plus plus = new Plus(TRANSPORT,requestInitializer,JSON_FACTORY);
			
			Person profile = null ; 
			plus.people.get("me").execute();
			    
			    shortenEndpoint = new GenericUrl("https://www.googleapis.com/plus/v1/people/me");
				//shortenEndpoint = new GenericUrl("http://www.google.com/calendar/feeds/default/allcalendars/full");
			
				shortenEndpoint.set("startIndex", 1);
				shortenEndpoint.set("max-results", 2000);
		    
		}catch(Exception e)
	    {
			List<String> msg = new ArrayList<String>();
			msg.add("Problem to get Gppgle +  Contacts");
			friends.put("ERROR", msg);
			
			return friends;
	    }
	    try {
	    	
	    	HttpRequest request = rf.buildGetRequest(shortenEndpoint);
	    	
	    	HttpResponse shortUrl = request.execute();
	    	
	    	friends = ParseData(shortUrl.getContent());
	    	/*BufferedInputStream bin = new BufferedInputStream(shortUrl.getContent());
	    	 int b;
	    	 while ( ( b = bin.read() ) != -1 )
	    	 {

	    	     char c = (char)b;         

	    	     System.out.print(""+(char)b); //This prints out content that is unreadable.
	    	                                   //Isn't it supposed to print out html tag?
	    	 }*/

			
		} catch (Exception e) {
			List<String> msg = new ArrayList<String>();
			msg.add("Problem to get Google + Contacts");
			friends.put("ERROR", msg);
			return friends;
		}
		
		return friends;
	}
	
	
	public Hashtable<String, List<String>> ParseData(InputStream output)
	{
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		try
		{
			
			String location = "";
			String name = "";
			DocumentBuilderFactory factory = 
			DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			Document doc = builder.parse(output);
			
			Element e = doc.getDocumentElement();
			String username = e.getChildNodes().item(0).getTextContent();
			for(int i =1; i<e.getChildNodes().getLength();i++)
			{
				if(e.getChildNodes().item(i).getNodeName().equals("entry"))
				{
				NodeList ndList = e.getChildNodes().item(i).getChildNodes();
				for (int j=1; j<ndList.getLength(); j++)
				{
					if(ndList.item(j).getNodeName().equals("title") && !ndList.item(j).getTextContent().equals(""))
						name = ndList.item(j).getTextContent();
					if(ndList.item(j).getNodeName().equals("gd:postalAddress"))
					{
						location = ndList.item(j).getTextContent();
						Pattern p = Pattern.compile(",\\s?[a-zA-Z]+");
						Matcher m = p.matcher(location);
						location = m.replaceAll("");
						
					}
					
					//else
						//location = "---";
					if(!name.equals(""))
					{
						List<String> friend_info = new ArrayList<String>();
						friend_info.add(name);
						friend_info.add(location);
						friend_info.add("");
						friend_info.add(new NetworkDAO().getSocailNetworkIcon("GooglePlus").toString());
						//friend_info.add(ndList.item(j).getTextContent());
						friends.put("googleplus-"+i, friend_info);

					}
				}
				name = "";
				location = "";
				}
			}
		}
		catch (Exception e)
		{
			System.err.println(e);
			System.exit(0);
		}
		return friends;
	}
	
	public Hashtable<String, List<String>> ParseData(InputStream output, String location)
	{
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		try
		{
			String name = "";
			DocumentBuilderFactory factory = 
			DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(output);
			Element e = doc.getDocumentElement();
			for(int i =1; i<e.getChildNodes().getLength();i++)
			{
				NodeList ndList = e.getChildNodes().item(i).getChildNodes();
				for (int j=1; j<ndList.getLength(); j++)
				{
					if(ndList.item(j).getNodeName().equals("title") && !ndList.item(j).getTextContent().equals(""))
						name = ndList.item(j).getTextContent();
					if(ndList.item(j).getNodeName().equals("gd:postalAddress"))
					{
						if(ndList.item(j).getTextContent().toLowerCase().contains(location.toLowerCase()))
						{
							List<String> friend_info = new ArrayList<String>();
							friend_info.add(name);
							friend_info.add("");
							friend_info.add(new NetworkDAO().getSocailNetworkIcon("GooglePlus").toString());
							String latlang = new LocationDAO().getCityLatitudeLongitude(location.toLowerCase());
							friend_info.add(latlang.split(":")[0]); // facebok user's latitude
							friend_info.add(latlang.split(":")[1]); // facebook user's langitude
							friend_info.add(""); // empty value
							friend_info.add(""); // empty value for profile Image
							friend_info.add(""); // gmail user's gender
							//friend_info.add(ndList.item(j).getTextContent());
							friends.put("googleplus-"+i, friend_info);
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			System.err.println(e);
			System.exit(0);
		}
		return friends;
	}
	
	
	
	public String getUserName(InputStream output)
	  {
		  try
		  {
			  String name="";
			  
			  DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			  DocumentBuilder builder = factory.newDocumentBuilder();
			  Document doc = builder.parse(output);
			  Element e = doc.getDocumentElement();
			  return e.getChildNodes().item(0).getTextContent();  
		  }
		  
		  catch (Exception e)
		  {
			  System.err.println(e);
			  System.exit(0);
			  return null;
		  }  
	  }
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		new GooglePlusAPI().getFriends("ya29.AHES6ZShPtuHTeLuWFTnI-u-ufBE6CGt5-RLMEC2L8bgxAfsbA");
	}
}
