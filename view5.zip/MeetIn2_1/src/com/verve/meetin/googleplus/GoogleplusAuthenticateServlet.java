package com.verve.meetin.googleplus;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.google.api.client.auth.oauth2.draft10.AccessTokenResponse;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessProtectedResource;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAccessTokenRequest.GoogleAuthorizationCodeGrant;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;
import com.verve.meetin.googleplus.GooglePlusAPI;

public class GoogleplusAuthenticateServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Constructor of the object.
	 */
	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	private String SCOPE = "";
	private String CALLBACK_URL = "";
	 HttpTransport TRANSPORT = new NetHttpTransport();
	 JsonFactory JSON_FACTORY = new JacksonFactory();
	// Set up the HTTP transport and JSON factory

	
	// FILL THESE IN WITH YOUR VALUES FROM THE API CONSOLE
	private String CLIENT_ID = "";
	private String CLIENT_SECRET = "";
	public GoogleplusAuthenticateServlet() {
		super();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	@Override
	public void init() throws ServletException {
		// Reading parameter for googleplus authentication 
		SCOPE =resource.getString("googleplus.scope.url");
		CALLBACK_URL = resource.getString("googleplus.callback.url");
		CLIENT_ID = resource.getString("googleplus.client.id");
		CLIENT_SECRET = resource.getString("googleplus.client.secret");
		
	}
	
	/**
	 * Destruction of the servlet. <br>
	 */
	@Override
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession userSession = request.getSession();
		String authorizationCode = userSession.getAttribute("code").toString();
		
		GoogleAuthorizationCodeGrant authRequest = new GoogleAuthorizationCodeGrant(TRANSPORT,
		        JSON_FACTORY, CLIENT_ID, CLIENT_SECRET, authorizationCode, CALLBACK_URL);
		authRequest.useBasicAuthorization = false;
		AccessTokenResponse authResponse = authRequest.execute();
	    String accessToken = authResponse.accessToken;
	    String refreshToken = authResponse.refreshToken;
	    userSession.setAttribute("access_token",accessToken);
		
	    
	    GoogleAccessProtectedResource requestInitializer = new GoogleAccessProtectedResource(accessToken);
	 // Set up the main Google+ class
	 /*   Plus plus = new Plus(TRANSPORT, JSON_FACTORY);
	    Person profile = null ; 
	    plus.people.get("me").execute();
	      
	    */

	    // Make a request to access your profile and display it to console
	    /*Person profile = plus.people().get("me").execute();
	    										
	    //Plus plus = new Plus(Util.TRANSPORT, access, Util.JSON_FACTORY);
	 // Set up the main Google+ class
	    //Plus plus = Plus.builder(TRANSPORT, JSON_FACTORY).setHttpRequestInitializer(requestInitializer).build();
	    // Make a request to access your profile and display it to console
	   /* Person profile = plus.people().get("me").execute();
	    */
	    
	    /*       
	        /* //fetch your profile object
	         Person profile = null;
	         try {
	           profile = plus.people.get("me").execute();
	         } catch (HttpResponseException e) {
	           System.err.println(Util.extractError(e));
	           return;
	         }
	         
	         String profileUrl = profile.getUrl();
	         String profileimgUrl = profile.getImage().getUrl();
	         String profileId = profile.getId();
	         StringEscapeUtils.escapeHtml(profile.getDisplayName());
	          
	         Plus.Activities.List listActivities = plus.activities.list("me", "public");
	         listActivities.setMaxResults(5L);

	         // Pro tip: Use partial responses to improve response time considerably
	         listActivities.setFields("nextPageToken,items(id,url,object/content)");

	         ActivityFeed activityFeed = null;
	         try {
	           activityFeed = listActivities.execute();
	         } catch (HttpResponseException e) {
	     
	           return;
	         }

	         List<Activity> activities = activityFeed.getItems();

	         listActivities.setPageToken(activityFeed.getNextPageToken());

	         int currentPageNumber = 0;
	           while (activities != null && currentPageNumber < 5) {
	             currentPageNumber++;

	             if (activityFeed.getItems() != null) {
	               for (Activity activity : activities) {
	            	   String activityUrl = activity.getUrl(); 
	            	   String activityId = activity.getId();
	            	   StringEscapeUtils.escapeHtml4(Util.stripTags(activity.getPlusObject().getContent())); 
	                 }
	                 // We will know we are on the last page when the next page token is null.
	                 // If this is the case, break.
	                 if (activityFeed.getNextPageToken() == null) {
	                   break;
	                 }
	                 // Prepare the next page of results
	                 listActivities.setPageToken(activityFeed.getNextPageToken());
	                 // Execute and process the next page request
	                 try {
	                   activityFeed = listActivities.execute();
	                 } catch (HttpResponseException e) {
	                   log.severe(Util.extractError(e));
	                   return;
	                 }

	                 activities = activityFeed.getItems();
	               }
	             }
	           }*/

	    
		HttpRequestFactory rf = TRANSPORT.createRequestFactory(requestInitializer);
		
		 
		//GenericUrl shortenEndpoint = new GenericUrl("https://www.googleapis.com/oauth2/v1/userinfo");
		
		/*shortenEndpoint.set("startIndex", 1);
		shortenEndpoint.set("max-results", 2000);
		HttpRequest request1 = rf.buildGetRequest(shortenEndpoint);
		HttpResponse shortUrl = request1.execute();*/
		/*GenericUrl shortenEndpoint = new GenericUrl("https://www.google.com/m8/feeds/contacts/default/full");
		shortenEndpoint.set("startIndex", 1);
		shortenEndpoint.set("max-results", 2000);
		HttpRequest request1 = rf.buildGetRequest(shortenEndpoint);
		HttpResponse shortUrl = request1.execute();*/
		
		GooglePlusAPI gapi = new GooglePlusAPI();
			
			//userSession.setAttribute("network_user", gapi.getUserName(shortUrl.getContent()));
			userSession.setAttribute("network_user",accessToken);
		    out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
			out.println("<HTML>");
			out.println("<HEAD><TITLE>A Servlet</TITLE>");
			out.println("</HEAD>");
			out.println("<BODY onload=\"window.opener.addGooglePlusNetwork(); window.close()\">");
			out.println("</BODY>");
			out.println("</HTML>");
		out.close();
	}

}
