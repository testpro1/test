package com.verve.meetin.feedback;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;
import com.verve.meetin.contact.Contact;
import com.verve.meetin.contact.ContactDAO;

public class FeedbackDAO 
{

	static Logger log = Logger.getLogger(FeedbackDAO.class);
	public int addFeedback(Feedback feedback)
	{
		log.info("Inside Create ContactInfo....");
		int last_feedback_id = 0;
		
		try
		{
				Session session = HibernateUtil.getSessionFactory().getCurrentSession();		
				Transaction tx = null;
				tx = session.beginTransaction();
				last_feedback_id = (Integer) session.save(feedback);
				tx.commit();
				log.info("Basic information has been added successfully");	
		}
		catch(Exception ex)
		{
			log.error("There is a problem adding basic information");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return last_feedback_id;
	}
	
	public int deleteFeedback(int userId)
	{
		int row=0;
		String queryString ="delete from Feedback as f where f.fuser_id = ?";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    row = query.executeUpdate();
		    tx.commit();
		    return row;
		}
		catch(Exception ex)
		{
			log.debug(ex);
			ex.printStackTrace();
		}
		return 0;
	}
	
	
	public List getFeedback() {
		
		List list=null;
		String queryString = "select f.fid,f.fname, f.femail,f.frating,f.fcomment,f.fdate,u.image,u.gender from Feedback as f ,User as u where f.fuser_id = u.userId and f.fvisible="+1+" order by  f.fid desc";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			list = query.list();
			session.getTransaction().commit();
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}
	
	public List getFeedback(int fuid) {
		
		List list=null;
		String queryString = "select f.fid,f.fname, f.femail,f.frating,f.fcomment,f.fdate,u.image from Feedback as f ,User as u where f.fuser_id = "+fuid+" and f.fvisible="+1+" order by  f.fid desc";
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			list = query.list();
			session.getTransaction().commit();
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}
	
	
	
	
	
	public int checkFeedback(int userId)
	{
		List list=null;
		String queryString = "select f.fid from Feedback as f where f.fuser_id = "+userId;
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			Query query = session.createQuery(queryString);
			list = query.list();
			session.getTransaction().commit();
			
			if(list.size() > 0 )
			{
				return 1;
			}
			else{
				return 0;
			}
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		return 0;
	}
		
}
