package com.verve.meetin.feedback;

import org.apache.struts.action.ActionForm;

public class Feedback extends ActionForm{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int fid;
	private int fuser_id;
	public int getFuser_id() {
		return fuser_id;
	}

	public void setFuser_id(int fuserId) {
		fuser_id = fuserId;
	}

	public String getFdate() {
		return fdate;
	}

	public void setFdate(String fdate) {
		this.fdate = fdate;
	}
	private String fname;
	private String femail;
	private String frating;
	private String fcomment;
	private boolean fvisible=true;
	private String fdate;
	
	public Feedback()
	{
		
	}

	public Feedback(String fname,int fuser_id, String femail,String frating ,String fcomment,String fdate) 
	{
		this.fuser_id = fuser_id;
		this.fname = fname;
		this.femail = femail;
		this.frating = frating;
		this.fcomment = fcomment;
		this.fdate = fdate;
	}
	
	
	
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getFemail() {
		return femail;
	}
	public void setFemail(String femail) {
		this.femail = femail;
	}
	public String getFrating() {
		return frating;
	}
	public void setFrating(String frating) {
		this.frating = frating;
	}
	public String getFcomment() {
		return fcomment;
	}
	public void setFcomment(String fcomment) {
		this.fcomment = fcomment;
	}
	public boolean getFvisible() {
		return fvisible;
	}
	public void setFvisible(boolean fvisible) {
		this.fvisible = fvisible;
	}
	
	
}
