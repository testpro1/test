package com.verve.meetin.feedback;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class FeedbackAction extends DispatchAction{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		Feedback feedback =(Feedback) form;
		feedback.setFrating(request.getParameter("frating"));
		
		
		//System.out.println(feedback.getFname());
		//System.out.println(feedback.getFemail());
		//System.out.println(feedback.getFrating());
		//System.out.println(feedback.getFcomment());
		//System.out.println(feedback.getFvisible());
		
		DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy 'at' hh:mm 'Hrs' zzz");  
		Date date = new Date();

		
		String s = dateFormat.format(date);
		
		//System.out.println("+"+s);
		
		HttpSession session = request.getSession();
		
		
		////System.out.println(session.getAttribute("UserID"));
		
		int user_id = Integer.parseInt(session.getAttribute("UserID").toString()); 
		
		feedback.setFuser_id(user_id);
		feedback.setFdate(s);
		
		Feedback f = new Feedback(feedback.getFname(),user_id,feedback.getFemail(), feedback.getFrating(), feedback.getFcomment(),s);
		
		FeedbackDAO feedbackDAO = new FeedbackDAO();
		
		
		int check = feedbackDAO.checkFeedback(user_id);
		
		if(check==0)
		{
			int last_feed_id = feedbackDAO.addFeedback(feedback); 
		}
		else
		{
			feedbackDAO.deleteFeedback(user_id);
			int last_feed_id = feedbackDAO.addFeedback(feedback);
		}
		
		
		return mapping.findForward("success"); 
	}
	
	
}
