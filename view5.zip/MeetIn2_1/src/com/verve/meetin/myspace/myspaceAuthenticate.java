package com.verve.meetin.myspace;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.myspace.myspaceid.MySpaceException;
import com.myspace.myspaceid.OffsiteContext;
import com.myspace.myspaceid.RestV1;
import com.myspace.myspaceid.oauth.OAuthToken;
import com.verve.meetin.network.peoplefinder.SocialNetworkDummy;

@SuppressWarnings("serial")
public class myspaceAuthenticate extends HttpServlet {

		String authUrl;
		ResourceBundle resource;
		HttpServletRequest request;
		String consumerKey = "c630a0bd0a9a460aa93328b5de1c3c64";
		String consumerSecret = "fdb2c16b1b674389877db0635057e111b4ebbd3ae6c54377b16cfde0a59011b1";
		String id = null;
	    OffsiteContext c1 = null;
	    OffsiteContext c2 = null;
	    RestV1 r = null;
     /* OAuthConsumer consumer = new DefaultOAuthConsumer("c630a0bd0a9a460aa93328b5de1c3c64","fdb2c16b1b674389877db0635057e111b4ebbd3ae6c54377b16cfde0a59011b1");

	    OAuthProvider provider = new DefaultOAuthProvider(
	            "http://api.myspace.com/request_token",
	            "http://api.myspace.com/access_token",
	            "http://api.myspace.com/authorize");
	*/
	@Override
	public void init() throws ServletException {

	}
	/**
	 * Destruction of the servlet. <br>
	 */
	@Override
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
		
	}
	public void getmyspaceCredentials() 
    {
    	
		 resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		 c1 = new OffsiteContext(consumerKey, consumerSecret);
		
		 OAuthToken requestToken = c1.getRequestToken(resource.getString("myspace.redirect_uri"));

		 authUrl = c1.getAuthorizationURL(requestToken);
   
		 //System.out.println("\nAuthorization URL " + authUrl);
		// System.out.print("\nEnter oauth_verifier parameter in callback: ");
		 //System.out.println( requestToken.getKey()+"key --REQUEST TOKEN secret--"+ requestToken.getSecret());
		 c2 = new OffsiteContext(consumerKey, consumerSecret, requestToken.getKey(), requestToken.getSecret());
		 //System.out.println(c2.getAuthorizationURL(requestToken));
		
		///////////////////////////////////////////////////////////////////
			/*resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
			MySpace myspace = new MySpace( "c630a0bd0a9a460aa93328b5de1c3c64", "fdb2c16b1b674389877db0635057e111b4ebbd3ae6c54377b16cfde0a59011b1",ApplicationType.OFF_SITE );
			//System.out.println("HI---"+myspace.getRequestToken());
		    OAuthToken requestToken = myspace.getRequestToken();
		    authUrl = myspace.getAuthorizationURL( requestToken,resource.getString("myspace.redirect_uri")); 
		    //System.out.println("###################################"+authUrl);*/
    }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException,MySpaceException {
		 
		
		//System.out.println("servlet called ");
		
		// If callback parameter not supplied, redirect to go do login.
		
		
		/*
		resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		
	    try {
			authUrl = provider.retrieveRequestToken(consumer, resource.getString("myspace.redirect_uri"));
			provider.retrieveAccessToken(consumer, request.getParameter("oauth_verifier"));
			//System.out.println("Request token: " + consumer.getToken());
		    //System.out.println("Token secret: " + consumer.getTokenSecret());
		} catch (OAuthMessageSignerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OAuthNotAuthorizedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OAuthExpectationFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OAuthCommunicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		//////////////////////////////////////////////////////////////////////
		response.setContentType("text/html");
		if(request.getParameter("oauth_token") == null) {
			getmyspaceCredentials();
			response.sendRedirect(authUrl);
		}
		else{
	
		/**This code is working perfectly get access token and friends deatails */
		
				System.out.println("Auth Verfier :   "+request.getParameter("oauth_verifier"));
			
				OAuthToken Token = c2.getAccessToken(request.getParameter("oauth_verifier"));
				 
				String key = Token.getKey();
				String secret = Token.getSecret();			
				HttpSession userSession = request.getSession();
				userSession.setAttribute("access_token", key+","+secret);
				System.out.println(key);
				System.out.println(secret);
				
							
				try 
				{
					JSONObject jsonObject = new JSONObject(c2.getUser());
					userSession.setAttribute("network_user",jsonObject.get("name").toString());
				} catch (Exception e) {
					System.out.println("Exception " +e);
				}
				
				request.setAttribute("oauth_verifier", request.getParameter("oauth_verifier"));
				id = c2.getUserId();
				
				System.out.println(">>> User id = " + id);
		        r = new RestV1(c2);
		        System.out.println("Friends are -"+r.getFriends(id));
		       
		        
		       try {
			    
		    	   JSONObject jsonObject =	new JSONObject(r.getFriends(id).toString()) ;
		        
		    	   System.out.println(jsonObject); 
		    	   System.out.println(jsonObject.get("count"));
		       
		    	   int countFriends = Integer.parseInt(jsonObject.get("count").toString());
		        
		       
		    	   if(countFriends > 0)
		    	   {
		    		   HttpSession sc = request.getSession(false);
		    		   int userid = (Integer)sc.getAttribute("UserID");
		    		   
		    		   
		    		   JSONArray jsonArray =	jsonObject.getJSONArray("Friends");
		    		   for (int i = 0; i < jsonArray.length(); i++) 
						{
		    			   JSONObject jsonObject1 = jsonArray.getJSONObject(i);
		    			   
		    			   String username =jsonObject1.get("name").toString();
		    			   String image =jsonObject1.get("image").toString(); 
		    			   String profileUrl = jsonObject1.get("webUri").toString();
		    			  
		    			   System.out.println(jsonObject1.get("image"));
		    			   System.out.println(jsonObject1.get("webUri"));
		    			   
		    		//	  SocialNetworkDummy s = new SocialNetworkDummy(sc.getId(), userid, "", username, null,profileUrl, "");
		    			   
		    			   
						}
		    	   }
		    	   
		    	   
		       	} catch (Exception e) {
		       		System.out.println("Exceptin occured " +e);
			}     
			///////////////////////////////////////////////////////////////////////////////////////
		        
  	      /*  //System.out.println("oauth_token is -"+request.getParameter("oauth_token"));
		        try{
		        String oauth_token = request.getParameter("oauth_token");//get oauth_token parameter somehow after login		        
		        OAuthToken recievedToken = new OAuthToken(oauth_token);
		        //System.out.println("Recived Token is -"+recievedToken);
		        MySpace my = null;
		        OAuthToken accessToken = my.getAccessToken(recievedToken);
		        //System.out.println("(((((((((((((((("+accessToken);
		        }catch (Exception e) {
		        	//System.out.println("Exception is --"+e);// TODO: handle exception
				}
       */

		        	PrintWriter out = response.getWriter();
			        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
					out.println("<HTML>");
					out.println("<HEAD><TITLE>A Servlet</TITLE>");
					out.println("</HEAD>");
					out.println("<BODY onload=\"window.opener.addmyspaceNetwork(); window.close()\">");
					out.println("</BODY>");
					out.println("</HTML>");
					out.flush();
					out.close();
	}
	}
	
}
