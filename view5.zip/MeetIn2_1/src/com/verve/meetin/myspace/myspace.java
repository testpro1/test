package com.verve.meetin.myspace;

import java.util.ArrayList; 	
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.myspace.myspaceid.ApplicationType;
import com.myspace.myspaceid.MySpace;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.peoplefinder.SocialNetworkDummy;

public class myspace {
	
	HttpServletRequest request;
	ResourceBundle resource;
	String authUrl;
	 String id = null;
   /*  OffsiteContext c1 = null;
     OffsiteContext c2 = null;
     RestV1 r = null;*/
	 String consumerKey = "c630a0bd0a9a460aa93328b5de1c3c64";
 	String consumerSecret = "fdb2c16b1b674389877db0635057e111b4ebbd3ae6c54377b16cfde0a59011b1";
	/** This is overloaded method */
	public Hashtable<String, List<String>> getFriendsInfo(
			String access_token) throws Exception
			{
				System.out.println("myspace friends");
				Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
			
				String acctoken = access_token;
				String accesstoken [] = acctoken.split(",");
			
				/*try{
				 resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
				 c1 = new OffsiteContext(consumerKey, consumerSecret);
				
				 OAuthToken requestToken = c1.getRequestToken(resource.getString("myspace.redirect_uri"));
				 //System.out.println("!!!!!!!!!!!!!!!!!!!!!!!"+requestToken);
				 authUrl = c1.getAuthorizationURL(requestToken);
				   
				 //System.out.println("\nAuthorization URL " + authUrl);
				 HttpServletResponse response = null;
			//	response.sendRedirect(authUrl);
				 //System.out.println("----------------"+requestToken.getKey());
				 //System.out.println("------------------"+requestToken.getSecret());
				 c2 = new OffsiteContext(consumerKey, consumerSecret, requestToken.getKey(), requestToken.getSecret());
				 				 //	String oauth_verifier = (String) request.getAttribute("oauth_verifier");
				 //response.sendRedirect(authUrl);
				//c2.getAccessToken(request.getParameter("oauth_verifier"));
				////System.out.println(oauth_verifier);
		         r = new RestV1(c2);
		         id = c2.getUserId();
		       
		         //System.out.println(">>> User id = " + id);
		         //System.out.println("Friends are -"+r.getFriends(id));
				}
				catch (Exception e) {
					// TODO: handle exception
					//System.out.println("Exception is "+e);
				}*/
				
				
				///////////////////////////////////////////////////////////////////////////////////
				try{
				MySpace m = new MySpace(consumerKey, consumerSecret,ApplicationType.OFF_SITE, accesstoken[0], accesstoken[1]);
				 //MySpace m = new MySpace(consumerKey, consumerSecret,ApplicationType.OFF_SITE );
				
					
				
				String userId = m.getUserId();
				JSONObject friends1 = m.getFriends(userId);
				JSONObject profile_me = m.getProfile(userId);
				if(friends1.containsKey("count"))
				{
					List<String> friend_info = new ArrayList<String>();
					JSONArray obj = (JSONArray) friends1.get("Friends");
					int i = 0;
					String location = null;
					while(i < obj.size())
					{
						JSONObject n = (JSONObject) obj.get(i);
						friend_info.add((String) n.get("name"));
						//System.out.println(n.get("name"));
						if(location != null)
						{
							String location_split = location.split(",")[0];
							String user_location = location_split.replace("Area", "").trim();
							friend_info.add(user_location);
							
						}
						else
						{
							friend_info.add("---");
						}
						friend_info.add(""); 
						friend_info.add(new NetworkDAO().getSocailNetworkIcon("Myspace").toString());
						String friendId =    (String) n.get("userId");
						friends.put(friendId, friend_info);
						i = i + 1;
					}
						////System.out.println(n.get("name"));
						//Object friendId =   (Object) n.get("userId");
						////System.out.println(n.get("userId")+","+friendId);
						//i = i + 1;
					}
				//}
				}
				catch (Exception e) {
					// TODO: handle exception
					//System.out.println("Exception is --"+e);
				}
				System.out.println("Friends are ="+friends);
				return friends;
			}
	
	
	public List<SocialNetworkDummy> getMyspaceFriendsDump(String access_Token, int user_Id, String sessionId, int socialId)
	{
		System.out.println("myspace friends");
		List<SocialNetworkDummy> friends = new ArrayList<SocialNetworkDummy>();
	
		try {
			
			 
			
			

			
		} catch (Exception e) {
			System.out.println("EXcepion occured " +e);
		}
		
		
		return null;
	}
	
	
		
	public static void main(String[] args) throws Exception {
	// TODO Auto-generated method stub
	new myspace().getFriendsInfo("J0JuXBftuZwJvbR6FoMnyrPYS%2BkMMufDrg6HVxfQpaR2bliKgHEBA11C6kOF1Z6B2szCrO9rfrlluZVKeD9pi2HGOHH%2FhmQnNpAHeYsXDuM%3D,2bc69d8504554aad9c278a80899dc50dbe3fb30541794b539a3a6698f9680f5f");
}
}
