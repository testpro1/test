/*package com.verve.meetin.myspace;


import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;


import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.myspace.myspaceid.OffsiteContext;
import com.myspace.myspaceid.RestV1;
import com.myspace.myspaceid.oauth.OAuthToken;

public class myspaceAction extends DispatchAction{
	public ActionForward myspaceAuthentication(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response) throws Exception{
		//System.out.println("This is the Myspace Authentication .............. !");
		String authUrl;
		ResourceBundle resource;
		
		String consumerKey = "c630a0bd0a9a460aa93328b5de1c3c64";
		String consumerSecret = "bee6dc99f44748dfbc5667ef430e2e3f6cf665e477c645b382108c7f9120285e";
	    String id = null;
	    OffsiteContext c1 = null;
	    OffsiteContext c2 = null;
	    RestV1 r = null;
	    if(request.getParameter("oauth_verifier") == null) {
	    resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
		 c1 = new OffsiteContext(consumerKey, consumerSecret);
		
		 OAuthToken requestToken = c1.getRequestToken(resource.getString("myspace.redirect_uri"));
		 //System.out.println(requestToken);
		 authUrl = c1.getAuthorizationURL(requestToken);
  
		 //System.out.println("\nAuthorization URL " + authUrl);
		 System.out.print("\nEnter oauth_verifier parameter in callback: ");
		 c2 = new OffsiteContext(consumerKey, consumerSecret, requestToken.getKey(), requestToken.getSecret());
			//System.out.println(authUrl);
			response.sendRedirect(authUrl);
		}
		else {
			OAuthToken Token = c2.getAccessToken(request.getParameter("oauth_verifier"));
		}
		return null;
	}
}
*/