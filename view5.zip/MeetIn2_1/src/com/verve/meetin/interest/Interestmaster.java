package com.verve.meetin.interest;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * MiInterestmaster entity. @author MyEclipse Persistence Tools
 */

@XmlRootElement
public class Interestmaster implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer interestId;
	private String name;
	private String description;

	// Constructors

	/** default constructor */
	public Interestmaster() {
	}

	/** full constructor */
	public Interestmaster(String name, String description) {
		this.name = name;
		this.description = description;
	}
	
	public Interestmaster(Integer interestid, String name,String description) {
		this.interestId = interestid;
		this.name = name;
		this.description=description;
		
	}

	// Property accessors

	public Integer getInterestId() {
		return this.interestId;
	}

	public void setInterestId(Integer interestId) {
		this.interestId = interestId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}