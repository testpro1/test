package com.verve.meetin.interest;

import org.apache.log4j.Logger;
import org.hibernate.*;

import java.util.*;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;


public class InterestDAO  
{
	
	static Logger log = Logger.getLogger(InterestDAO.class);
	
	public void setUserInterest(Interest interest)
	{
	
		log.info("Inside Interest Details....");
		
		try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			session.save(interest);
			tx.commit();
			
			log.info("User interest details have been created successfully");

		}
		catch(Exception ex)
		{
			log.error("There is a problem in user interest details");
			log.debug(ex);
			ex.printStackTrace();
		}
				
	}
	
	/** This method will return the list of all interest from interest master table */
	public List getInterest()
	{
		
		List result =null;
		String queryString ="from Interestmaster as interest order by interest.name";
		try
		{
			log.info("Trying to fetch interests.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
		    Query query = session.createQuery(queryString);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    log.info("Interest data returned form DataSource,Size:" +result.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in interest master");
			log.debug(ex);
			ex.printStackTrace();
		}
		
	   return result;	
	}
	
	/** Author Vasim Saiyad */
	
	/** This method will return the Interest List for a current user */
	public List getUserInterest(int userId)
	{
		
		List resultList =null;
		String queryString = "select a.interestId, a.name from Interestmaster a, Interest b where a.interestId =b.interestId and b.userId=?";
		try
		{
			log.info("Fetching Interest details for current user......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
			query.setParameter(0, userId);
			resultList = query.list();
			session.getTransaction().commit();
			
			log.info("Interest details for current user return from datasource, Size :" + resultList.size());
			
		}
		catch(Exception ex)
		{
			log.error("There is a problem in interest master");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return resultList;
	}
	
	/** This method will remove the user's interest before updating new interests into user account */
	public int removeUserInterest(int userid)
	{
		String deleteQuery ="delete from Interest where userId=?";
		int resultId =0;
		try
		{
			log.info("Trying to remove user's previous interest.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = null;
			tx = session.beginTransaction();
			
			Query q = session.createQuery(deleteQuery);
			q.setParameter(0, userid);
		    resultId=q.executeUpdate();
		    tx.commit();
		    
		    log.info("User's previous interest have been removed successfully");
		    
		}
		catch(Exception ex)
		{
			log.info("There is a problem removing previous user's interest details");
			log.debug(ex);
		}
			
		return resultId;
		
	}
	
	public List<String> getInterest(int userId)
	{
		
		List result =null;
		List<String> interest = new ArrayList<String>();
		String queryString ="select interestId from Interest as interest where userId = ?";
		try
		{
			log.info("Trying to fetch interests.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
			Query query = session.createQuery(queryString);
		    query.setParameter(0, userId);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    log.info("Interest data returned form DataSource,Size:" +result.size());
		    
		    queryString ="select name from Interestmaster as interest where interestId = ?";
		    for(int i=0; i<result.size(); i++)
		    {
		    	Query query1 = session.createQuery(queryString);
		    	session.beginTransaction();
			    query1.setParameter(0, result.get(i));
			    interest = query1.list();
			    session.getTransaction().commit();
		    }
		    
		}
		catch(Exception ex)
		{
			log.error("There is a problem in interest master");
			log.debug(ex);
		}
		
		return interest;
	}
		
}
