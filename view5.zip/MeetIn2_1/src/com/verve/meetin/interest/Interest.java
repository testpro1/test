package com.verve.meetin.interest;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * MiUserinterests entity. @author MyEclipse Persistence Tools
 */

@XmlRootElement
public class Interest implements java.io.Serializable {

	// Fields

	private Integer userInterestId;
	private Integer userId;
	private Integer interestId;

	// Constructors

	/** default constructor */
	public Interest() {
	}

	/** full constructor */
	public Interest(Integer userId, Integer interestId) {
		this.userId = userId;
		this.interestId = interestId;
	}

	// Property accessors

	public Integer getUserInterestId() {
		return this.userInterestId;
	}

	public void setUserInterestId(Integer userInterestId) {
		this.userInterestId = userInterestId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getInterestId() {
		return this.interestId;
	}

	public void setInterestId(Integer interestId) {
		this.interestId = interestId;
	}

}