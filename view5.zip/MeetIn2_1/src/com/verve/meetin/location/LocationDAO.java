package com.verve.meetin.location;


import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.*;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;

public class LocationDAO  
{
		
	static Logger log = Logger.getLogger(LocationDAO.class);
	
  public List getCountriesByKey(String countryKey)
	{
		List result =null;
		String queryString ="select countrymaster.country from Country as countrymaster where countrymaster.country like concat(?,'%') order by countrymaster.country";
		try
		{
			log.info("Trying to fetch countries.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, countryKey);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    log.info("Countries returned from DataSource,Size:" +result.size() + " for country key: " + countryKey);
		}
		catch(Exception ex)
		{
			log.error("There is a problem in country master");
			log.debug(ex);
			ex.printStackTrace();
		}
		
	   return result;	
	}
  
  public List getStatesByKey(String stateKey)
	{
		List result =null;
		String queryString ="select statemaster.region from States as statemaster where statemaster.region like concat(?,'%') order by statemaster.region";
		try
		{
			log.info("Trying to fetch states.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, stateKey);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    log.info("States returned form DataSource,Size:" +result.size() + " for state key: " + stateKey);
		}
		catch(Exception ex)
		{
			log.error("There is a problem in states master");
			log.debug(ex);
			ex.printStackTrace();
		}
				
	   return result;	
	}
  
  public List getCitiesByKey(String cityKey)
	{
	  	
		List result =null;
		String queryString ="select citymaster.city, regionmaster.region from Cities as citymaster,States as regionmaster where citymaster.city like concat(?,'%') and citymaster.regionId=regionmaster.regionid order by citymaster.city";
		//queryString ="select citymaster.city from Cities as citymaster where citymaster.city like concat(?,'%') order by citymaster.city";
		String resultString ="";
		try
		{
			
			log.info("Trying to fetch cities.......");
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(queryString);
		    query.setParameter(0, cityKey);
		    result = query.list();
		    session.getTransaction().commit();
		    
		    List finalList = new ArrayList<String>();
		    for(int i=0; i< result.size();i++){
		    	Object[] object= (Object[])result.get(i);
		    	String city = (String)object[0];
		    	String state =(String)object[1];
		    	resultString = city + ", " + state;
		    	finalList.add(resultString);
		    }

		    log.info("Cities returned form DataSource,Size:" +result.size() + " for city key: " + cityKey);
		}
		catch(Exception ex)
		{
			log.error("There is a problem in cities master");
			log.debug(ex);
			ex.printStackTrace();
		}
				
	   return result;	
	}
  
 
  public String getCityLatitudeLongitude(String cityName){
	  
	  String result ="";
	  List resultList =null;
	  ArrayList<String> finalList =null;
	  String cityQuery = "select citymaster.latitude, citymaster.longitude from Cities as citymaster where city=?";
	 // String cityQuery = "select citymaster.city,regionmaster.region from Cities as citymaster,States as regionmaster where citymaster.city like concat(?,'%') and citymaster.regionId=regionmaster.regionid order by citymaster.city";
	  try
		{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			session.beginTransaction();
			
		    Query query = session.createQuery(cityQuery);
		    query.setParameter(0,cityName);
		    resultList = query.list();
		    session.getTransaction().commit();
		    
		    if(resultList !=null && resultList.size() > 0)
		    {
		    	Object[] object = (Object[])resultList.get(0);
		    	String latitude = (String)object[0];
		    	String longitude =(String)object[1];
		    	result = latitude + ":" + longitude;
		    }
		    
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return result;  
  }
 
}
