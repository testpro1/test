package com.verve.meetin.location;

/**
 * MiCountry entity. @author MyEclipse Persistence Tools
 */

public class Country implements java.io.Serializable {

	private String countryid;
	private String country;
	private String fips104;
	private String iso2;
	private String iso3;
	private String ison;
	private String internet;
	private String capital;
	private String mapreference;
	private String nationalitysingular;
	private String nationalityplural;
	private String currency;
	private String currencycode;
	private String population;
	private String title;
	private String comment;
	
	
	public String getCountryid() {
		return countryid;
	}
	public void setCountryid(String countryid) {
		this.countryid = countryid;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getFips104() {
		return fips104;
	}
	public void setFips104(String fips104) {
		this.fips104 = fips104;
	}
	public String getIso2() {
		return iso2;
	}
	public void setIso2(String iso2) {
		this.iso2 = iso2;
	}
	public String getIso3() {
		return iso3;
	}
	public void setIso3(String iso3) {
		this.iso3 = iso3;
	}
	public String getIson() {
		return ison;
	}
	public void setIson(String ison) {
		this.ison = ison;
	}
	public String getInternet() {
		return internet;
	}
	public void setInternet(String internet) {
		this.internet = internet;
	}
	public String getCapital() {
		return capital;
	}
	public void setCapital(String capital) {
		this.capital = capital;
	}
	public String getMapreference() {
		return mapreference;
	}
	public void setMapreference(String mapreference) {
		this.mapreference = mapreference;
	}
	public String getNationalitysingular() {
		return nationalitysingular;
	}
	public void setNationalitysingular(String nationalitysingular) {
		this.nationalitysingular = nationalitysingular;
	}
	public String getNationalityplural() {
		return nationalityplural;
	}
	public void setNationalityplural(String nationalityplural) {
		this.nationalityplural = nationalityplural;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCurrencycode() {
		return currencycode;
	}
	public void setCurrencycode(String currencycode) {
		this.currencycode = currencycode;
	}
	public String getPopulation() {
		return population;
	}
	public void setPopulation(String population) {
		this.population = population;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

}