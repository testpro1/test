package com.verve.meetin.location;

/**
 * MiStatesId entity. @author MyEclipse Persistence Tools
 */

public class States implements java.io.Serializable {

	// Fields

	private String regionid;
	private String countryid;
	private String region;
	private String code;
	private String adm1code;
	public String getRegionid() {
		return regionid;
	}
	public void setRegionid(String regionid) {
		this.regionid = regionid;
	}
	public String getCountryid() {
		return countryid;
	}
	public void setCountryid(String countryid) {
		this.countryid = countryid;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getAdm1code() {
		return adm1code;
	}
	public void setAdm1code(String adm1code) {
		this.adm1code = adm1code;
	}

	

}