package com.verve.meetin.location;

import org.apache.struts.action.ActionForm;

public class location extends ActionForm implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int location_id;
	private String location_state;
	private String location_street;
	private String location_city;
	private String location_postal_code;
	public int getLocation_id() {
		return location_id;
	}
	public void setLocation_id(int locationId) {
		location_id = locationId;
	}
	public String getLocation_state() {
		return location_state;
	}
	public void setLocation_state(String locationState) {
		location_state = locationState;
	}
	public String getLocation_street() {
		return location_street;
	}
	public void setLocation_street(String locationStreet) {
		location_street = locationStreet;
	}
	public String getLocation_city() {
		return location_city;
	}
	public void setLocation_city(String locationCity) {
		location_city = locationCity;
	}
	public String getLocation_postal_code() {
		return location_postal_code;
	}
	public void setLocation_postal_code(String locationPostalCode) {
		location_postal_code = locationPostalCode;
	}
}
