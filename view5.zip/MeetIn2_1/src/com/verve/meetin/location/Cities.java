package com.verve.meetin.location;

/**
 * MiCitiesId entity. @author MyEclipse Persistence Tools
 */

public class Cities implements java.io.Serializable {

	// Fields

	private String cityid;
	private String countryId;
	private String regionId;
	private String city;
	private String latitude;
	private String longitude;
	private String timeZone;
	private String dmaId;
	private String code;
	
	
	public String getCityid() {
		return cityid;
	}
	public void setCityid(String cityid) {
		this.cityid = cityid;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getDmaId() {
		return dmaId;
	}
	public void setDmaId(String dmaId) {
		this.dmaId = dmaId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}

	

}