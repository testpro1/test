package com.verve.meetin.foursquaredemo;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import fi.foyt.foursquare.api.FoursquareApi;

public class TestUtils {

  public static FoursquareApi getAnonymousFoursquareApi() {
    FoursquareApi foursquareApi = new FoursquareApi(CLIENT_ID, CLIENT_SECRET, REDIRECT_URL, new TestIO());
    foursquareApi.setSkipNonExistingFields(false);
    return foursquareApi;
  }
  
  public static FoursquareApi getAuthenticatedFoursquareApi() {
    FoursquareApi foursquareApi = new FoursquareApi(CLIENT_ID, CLIENT_SECRET, REDIRECT_URL, OAUTH, new TestIO());
    foursquareApi.setSkipNonExistingFields(false);
    return foursquareApi;
  }
  
  public static byte[] getFileData(String path) throws IOException {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    
    byte[] buf = new byte[1024];
    int l = 0;
    InputStream in = TestUtils.class.getResourceAsStream(path);
   
    while ((l = in.read(buf)) > 0) {
      bos.write(buf, 0, l);
    }
    
    return bos.toByteArray();
  }
  
  private final static String CLIENT_ID = "NTNIEQBZFTGUDTHV2ASQQMVBOAKRH2KOYSD3SC2QLUJKHOJZ";
  private final static String CLIENT_SECRET = "MTXKTKSDMOD1L04LOSHT4VE4020AHZRJL3AND5A5YKBSR4VB";
  private final static String REDIRECT_URL = "http://localhost:8080/MeetIn2/foursquareAuthentication.jsp";
  private final static String OAUTH = "4GEPA3OS1KFHD40U1TWUI31OXDCHTBTE2G1VNW4GCR5QWVCX";
}