package com.verve.meetin.orkut;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.oauth.OAuthAccessor;
import net.oauth.OAuthConsumer;
import net.oauth.OAuthServiceProvider;
import net.oauth.client.OAuthClient;
import net.oauth.client.httpclient4.HttpClient4;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;
import com.google.orkut.client.api.ActivityTxFactory;
import com.google.orkut.client.api.AlbumsTxFactory;
import com.google.orkut.client.api.CaptchaTxFactory;
import com.google.orkut.client.api.CommentsTxFactory;
import com.google.orkut.client.api.DefaultOrkutAdapter;
import com.google.orkut.client.api.FriendTxFactory;
import com.google.orkut.client.api.OrkutAdapter;
import com.google.orkut.client.api.OrkutAdapterDebugListener;
import com.google.orkut.client.api.OrkutAdapterException;
import com.google.orkut.client.api.PhotosTxFactory;
import com.google.orkut.client.api.ProfileTxFactory;
import com.google.orkut.client.api.ScrapTxFactory;
import com.google.orkut.client.api.VideoTxFactory;

public class CopyOfOrkutAuthenticateServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
	
	
	
	public CopyOfOrkutAuthenticateServlet() {
		super();
	}
	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	@Override
	public void init() throws ServletException {
		
	}
		
	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		   String consumerKey = resource.getString("orkut.consumer_key");
		   String consumerSecret = resource.getString("orkut.consumer_secret");
		   String callbackURL = resource.getString("orkut.redirect_uri");
		   final String CALLBACK_URL = "http://orkut-os-client-test.appspot.com/debugcallback";
		   String OAUTH_REQUEST_URL =
               "https://www.google.com/accounts/OAuthGetRequestToken";
		   String OAUTH_AUTHORIZATION_URL =
               "https://www.google.com/accounts/OAuthAuthorizeToken";
		   String OAUTH_ACCESS_URL = 
               "https://www.google.com/accounts/OAuthGetAccessToken";
		   String OAUTH_SCOPE = 
               "http://orkut.gmodules.com/social";
		   String SERVER_URL_SANDBOX =
               "http://sandbox.orkut.com/social/rpc";
		   String SERVER_URL_PROD =
               "http://www.orkut.com/social/rpc";
		   
		   OrkutAdapter orkad = new DefaultOrkutAdapter(consumerKey,
	                consumerSecret, CALLBACK_URL, false,
	                new OrkutAdapterDebugListener() {
	                   public void printOrkutAdapterMessage(String s) {
	                      System.err.println(s);
	                   }
	      });
		   
		   String authURL = orkad.requestAuthURL();
		   response.sendRedirect(authURL);
		   String oauth_verifier = request.getParameter("oauth_verifier");
		   //System.out.println("Authorization oauth_verifier : " + authURL);
		   //System.out.println("Authorization oauth_verifier : " + oauth_verifier);
		   
		   //orkad.authenticate(authURL);
	       //System.out.println("Got access pass: " + orkad.getAccessPass());
	       
	      /* OAuthConsumer consumer = null;
	       OAuthAccessor accessor = null;
	       OAuthClient client = null;
	       try {
	           //System.out.println("Setting up oauth consumer.");
	           consumer = new OAuthConsumer(null,
	                     "550201537377.apps.googleusercontent.com", 
	                     "Uw0Nja6FhOsF78yH1iWR9nf3",
	                     new OAuthServiceProvider(
	                     OAUTH_REQUEST_URL, OAUTH_AUTHORIZATION_URL, 
	                     OAUTH_ACCESS_URL));
	           consumer.setProperty(OAuthClient.PARAMETER_STYLE,
	                     net.oauth.ParameterStyle.QUERY_STRING);
	           
	           //System.out.println("Setting up oauth accessor and client.");
	           accessor = new OAuthAccessor(consumer);
	           client = new OAuthClient(new HttpClient4());
	           //System.out.println("+++++++++++++++++++++++++"+accessor.accessToken+"AND "+accessor.requestToken);
	        }
	        catch (Exception ex) {
	           throw new OrkutAdapterException(
	                  "OrkutAdapter: Failed to initialize OAuth.", ex);
	        }*/
	     
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	

}
