package com.verve.meetin.visitor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.verve.hibernate.utils.BaseHibernateDAO;
import com.verve.hibernate.utils.HibernateUtil;

public class VisitorsDAO extends BaseHibernateDAO {
	
	static Logger log = Logger.getLogger(VisitorsDAO.class);
	
	/** This method will save the visitor details for current user*/
	public void setProfileVisitor(Visitors visitor)
	{
		
		log.info("Inside Profile visitor Details....");
		String queryString = "select count(*) from Visitors as visitor where visitor.userid1=? and visitor.userid2=?";
		
		try
		{
			Session session  = HibernateUtil.getSessionFactory().getCurrentSession();
			if(visitor.getUserid1() != visitor.getUserid2())
			{
				log.info("Checking the previous visit for the current visitor");
				
				session.beginTransaction();
				Query query = session.createQuery(queryString);
				query.setParameter(0, visitor.getUserid1());
				query.setParameter(1, visitor.getUserid2());
				Long result = (Long)query.uniqueResult();
								
				if(result !=null && result.intValue() > 0)
				{
					log.info("visit found for current visitor");
					log.info("Trying to update the current profile visitor's details...");
					String updateQuery ="update Visitors set visitdate= ? where userid1=? and userid2=?";
					
					Transaction tx = null;
				    tx = session.beginTransaction();
					Query query_update = session.createQuery(updateQuery);
					query_update.setParameter(0, visitor.getVisitdate());
					query_update.setParameter(1, visitor.getUserid1());
					query_update.setParameter(2, visitor.getUserid2());
					query_update.executeUpdate();	
										
					log.info("Current profile visitor's details have been updated successfully");
				}
				else
				{
					log.info("visit not found for current visitor");
					log.info("Trying to add visit details for current visitor...");
					
					Transaction tx = null;
					tx = session.beginTransaction();
					session.save(visitor);
										
					log.info("Current profile visitor's details have been saved successfully");
				}
				
				session.getTransaction().commit();
			}
			else
			{
				log.info("Current profile visitor has visited own profile");
			}
		}
		catch(Exception ex)
		{
			log.error("There is a problem in user profile visitor details");
			log.debug(ex);
		}
		
	}
	
	/** This method will return the list of visitor for current user*/
	public List getProfileVisitorList(int userid)
	{
				
	    log.info("Inside get profile visitors list....");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List visitors = new ArrayList();
		Calendar now = Calendar.getInstance();
		String queryString = "select visitors.visitdate,user.userId, user.fullname, user.image, user.gender from Visitors as visitors,User as user where visitors.userid2 = ? and visitors.userid1=user.userId and visitors.visitdate between ? and ? order by visitors.visitdate desc ";
		try
		{
			String currentDate = now.get(Calendar.YEAR) + "-" + (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.DATE) + " " +now.get(Calendar.HOUR_OF_DAY) + ":" +now.get(Calendar.MINUTE) + ":" +now.get(Calendar.SECOND); 
			now.add(Calendar.DATE, -6);
			String pastDate = now.get(Calendar.YEAR) + "-" + (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.DATE) +" " +now.get(Calendar.HOUR_OF_DAY) + ":" +now.get(Calendar.MINUTE)  + ":" +now.get(Calendar.SECOND);
			
			Session session  = HibernateUtil.getSessionFactory().getCurrentSession();
		    session.beginTransaction();
		    
			Query query = session.createQuery(queryString);
			query.setParameter(0, userid);
			query.setParameter(1, sdf.parse(sdf.format(sdf.parse(pastDate))));
			query.setParameter(2, sdf.parse(sdf.format(sdf.parse(currentDate))));
			visitors = query.list();
			session.getTransaction().commit();
			
			log.info("Profile visitors return from datasource for current user,Size :" + visitors.size());
		}
		catch(Exception ex)
		{
			log.error("There is a problem in getting profile visitor list");
			log.debug(ex);
			ex.printStackTrace();
		}
		
		return visitors;
	}
	
}
