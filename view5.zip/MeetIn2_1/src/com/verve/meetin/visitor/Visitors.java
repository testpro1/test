package com.verve.meetin.visitor;

import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Visitors implements java.io.Serializable {
	
	
	// Fields
	private int visitorid;
	private int userid1;// profile visitor id
	private int userid2;// profile visitee id
	private Date visitdate;
	private String resultString;
	
	// Fields for visitor list web service
	private String fullname;
	private int userId;
	private String visitDate;
	private int relationId;
	
	/** Default constructior */
	
	public Visitors(){
		
	}
	/** Constructor to set profile visitors */
	
	public Visitors(int userid1,int userid2,Date visitdate)
	{
		
		this.userid1 =userid1;
		this.userid2=userid2;
		this.visitdate=visitdate;
	}
	
	// Property accessors
	
	public int getVisitorid() {
		return visitorid;
	}
	public void setVisitorid(int visitorid) {
		this.visitorid = visitorid;
	}
	public int getUserid1() {
		return userid1;
	}
	public void setUserid1(int userid1) {
		this.userid1 = userid1;
	}
	public int getUserid2() {
		return userid2;
	}
	public void setUserid2(int userid2) {
		this.userid2 = userid2;
	}
	public Date getVisitdate() {
		return visitdate;
	}
	public void setVisitdate(Date visitdate) {
		this.visitdate = visitdate;
	}
	
	// Property accessors for visitor list web service
	public String getFullname() {
		return fullname;
	}
	public int getUserId() {
		return userId;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}
	public String getResultString() {
		return resultString;
	}
	public void setResultString(String resultString) {
		this.resultString = resultString;
	}
	public int getRelationId() {
		return relationId;
	}
	public void setRelationId(int relationId) {
		this.relationId = relationId;
	}
	
	
}
