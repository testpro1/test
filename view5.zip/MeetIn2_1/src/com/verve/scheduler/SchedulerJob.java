package com.verve.scheduler;


import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.verve.meetin.user.UserAccountDAO;
 
public class SchedulerJob implements Job
{
	public void execute(JobExecutionContext context)
	throws JobExecutionException {
 
	   //System.out.println("job schedule started ");
 	   
	    new UserAccountDAO().getUsers();
	 
	}
}