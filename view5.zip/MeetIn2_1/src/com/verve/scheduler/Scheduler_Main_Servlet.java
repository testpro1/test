package com.verve.scheduler;

import java.util.Date;
import javax.servlet.ServletException;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;
 
public class Scheduler_Main_Servlet implements PlugIn {
 
	
	public void destroy() {
		// null
	}
 
	
	public void init(ActionServlet servlet, ModuleConfig config)
			throws ServletException {
 
		//System.out.println("init method called");
		
		try{
		
		  SchedulerFactory sf=new StdSchedulerFactory();
		  Scheduler sched=sf.getScheduler();
		  sched.start();
		  JobDetail jd=new JobDetail("myjob",sched.DEFAULT_GROUP,SchedulerJob.class);
		  SimpleTrigger st=new SimpleTrigger("mytrigger",sched.DEFAULT_GROUP,new Date(),
		  null,SimpleTrigger.REPEAT_INDEFINITELY,60L*60L*1000L*24L);
		  sched.scheduleJob(jd, st);
		}catch (Exception e) {
			
			//System.out.println("Exception:**   "+ e);
			
		}
		
	}
 
}