package com.contentmgmt.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ContentMenu")
@Table(name="contentMenu")
@Entity

public class ContentMenu implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private int menuId;
	private String menuName;
	private String pageTitle;
	private String pageAlias;
	private String metaDes;
	private String metaKey;
	
	@Id
	@GeneratedValue
	@Column(name="menuId")	
	public int getMenuId() {
		return menuId;
	}
	
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	
	@Column(name="menuName")
	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}	
	
	@Column(name="pageTitle")
	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	
	@Column(name="pageAlias")
	public String getPageAlias() {
		return pageAlias;
	}

	public void setPageAlias(String pageAlias) {
		this.pageAlias = pageAlias;
	}

	@Column(name="metaDes")
	public String getMetaDes() {
		return metaDes;
	}

	public void setMetaDes(String metaDes) {
		this.metaDes = metaDes;
	}

	@Column(name="metaKey")
	public String getMetaKey() {
		return metaKey;
	}

	public void setMetaKey(String metaKey) {
		this.metaKey = metaKey;
	}

}