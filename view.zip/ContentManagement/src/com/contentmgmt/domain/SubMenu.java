package com.contentmgmt.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "SubMenu")
@Table(name="subMenu")
@Entity

public class SubMenu implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private int subMenuId;
	private String subMenuName;
	private String subPageTitle;
	private String subPageAlias;
	private String subMetaDes;
	private String subMetaKey;
	private ContentMenu contentMenu;
	private int contentMenu_parentId;
	private int contentMenu_childId;
	
	@Id
	@GeneratedValue
	@Column(name="subMenuId")
	public int getSubMenuId() {
		return subMenuId;
	}

	public void setSubMenuId(int subMenuId) {
		this.subMenuId = subMenuId;
	}
	
	@Column(name="subMenuName")
	public String getSubMenuName() {
		return subMenuName;
	}

	public void setSubMenuName(String subMenuName) {
		this.subMenuName = subMenuName;
	}

	@Column(name="subPageTitle")
	public String getSubPageTitle() {
		return subPageTitle;
	}

	public void setSubPageTitle(String subPageTitle) {
		this.subPageTitle = subPageTitle;
	}

	@Column(name="subPageAlias")
	public String getSubPageAlias() {
		return subPageAlias;
	}

	public void setSubPageAlias(String subPageAlias) {
		this.subPageAlias = subPageAlias;
	}

	@Column(name="subMetaDes")
	public String getSubMetaDes() {
		return subMetaDes;
	}

	public void setSubMetaDes(String subMetaDes) {
		this.subMetaDes = subMetaDes;
	}

	@Column(name="subMetaKey")
	public String getSubMetaKey() {
		return subMetaKey;
	}

	public void setSubMetaKey(String subMetaKey) {
		this.subMetaKey = subMetaKey;
	}

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "menuId")
	public ContentMenu getContentMenu() {
		return contentMenu;
	}

	public void setContentMenu(ContentMenu contentMenu) {
		this.contentMenu = contentMenu;
	}
	
	@Column(name="contentMenu_parentId")
	public int getContentMenu_parentId() {
		return contentMenu_parentId;
	}

	public void setContentMenu_parentId(int contentMenuParentId) {
		contentMenu_parentId = contentMenuParentId;
	}
	
	@Column(name="contentMenu_childId")	
	public int getContentMenu_childId() {
		return contentMenu_childId;
	}

	public void setContentMenu_childId(int contentMenuChildId) {
		contentMenu_childId = contentMenuChildId;
	}
}