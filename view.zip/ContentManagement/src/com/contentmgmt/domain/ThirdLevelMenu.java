package com.contentmgmt.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ThirdLevelMenu")
@Table(name="thirdLevelMenu")
@Entity

public class ThirdLevelMenu implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int thirdLevelId;
	private String thirdLevelName;
	private String thirdLevelPageTitle;
	private String thirdLevelPageAlias;
	private String thirdLevelMetaDes;
	private String thirdLevelMetaKey;
	private SubMenu subMenu;
	private int subMenuId;
	
	@Id
	@GeneratedValue
	@Column(name="thirdLevelId")
	public int getThirdLevelId() {
		return thirdLevelId;
	}

	public void setThirdLevelId(int thirdLevelId) {
		this.thirdLevelId = thirdLevelId;
	}

	@Column(name="thirdLeveName")
	public String getThirdLevelName() {
		return thirdLevelName;
	}

	public void setThirdLevelName(String thirdLevelName) {
		this.thirdLevelName = thirdLevelName;
	}

	@Column(name="thirdLevelPageTitle")
	public String getThirdLevelPageTitle() {
		return thirdLevelPageTitle;
	}

	public void setThirdLevelPageTitle(String thirdLevelPageTitle) {
		this.thirdLevelPageTitle = thirdLevelPageTitle;
	}

	@Column(name="thirdLevelPageAlias")
	public String getThirdLevelPageAlias() {
		return thirdLevelPageAlias;
	}

	public void setThirdLevelPageAlias(String thirdLevelPageAlias) {
		this.thirdLevelPageAlias = thirdLevelPageAlias;
	}

	@Column(name="thirdLevelMetaDes")
	public String getThirdLevelMetaDes() {
		return thirdLevelMetaDes;
	}

	public void setThirdLevelMetaDes(String thirdLevelMetaDes) {
		this.thirdLevelMetaDes = thirdLevelMetaDes;
	}

	@Column(name="thirdLevelMetaKey")
	public String getThirdLevelMetaKey() {
		return thirdLevelMetaKey;
	}

	public void setThirdLevelMetaKey(String thirdLevelMetaKey) {
		this.thirdLevelMetaKey = thirdLevelMetaKey;
	}

	

	@Column(name="subMenuId")
	public int getSubMenuId() {
		return subMenuId;
	}

	public void setSubMenuId(int subMenuId) {
		this.subMenuId = subMenuId;
	}
}