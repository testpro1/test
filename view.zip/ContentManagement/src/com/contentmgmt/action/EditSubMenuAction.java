package com.contentmgmt.action;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.contentmgmt.dao.ContentMenuDao;
import com.contentmgmt.domain.ContentMenu;
import com.contentmgmt.domain.SubMenu;

public class EditSubMenuAction extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
	
	int subMenuId=Integer.parseInt(request.getParameter("subMenuId"));
	ContentMenuDao contentMenuDao=new ContentMenuDao();	
	
	List<SubMenu> editSubMenuList=contentMenuDao.editSubMenu(subMenuId);
	request.setAttribute("editSubMenuList",editSubMenuList);
  	
	//List<ContentMenu> editMenuList=contentMenuDao.editMenu(menuId);
	//request.setAttribute("editSubMenuList",editSubMenuList);
	
	List<ContentMenu> menuList=contentMenuDao.viewMenus();
	request.setAttribute("MenuList",menuList);
	
	List<SubMenu> subMenuList=contentMenuDao.viewSubMenu();
	request.setAttribute("subMenuList",subMenuList);
	
	
  	RequestDispatcher rd=request.getRequestDispatcher("EditSubMenu.jsp");
  	rd.forward(request, response);
	}
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}


}
