package com.contentmgmt.action;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.contentmgmt.dao.ContentMenuDao;


public class EditChildPageContentAction extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
	
		int subMenuId=Integer.parseInt(request.getParameter("subMenuId"));
		String parentInt=request.getParameter("contentMenu_parentId");
		String[] parentStr=parentInt.split("-child");
		int contentMenu_parentId=Integer.parseInt(parentStr[0]);
		String subMenuName=request.getParameter("subMenuName");
		String subPageTitle=request.getParameter("subPageTitle");
		String subPageAlias=request.getParameter("subPageAlias");
		String subMetaDes=request.getParameter("subMetaDes");
		String subMetaKey=request.getParameter("subMetaKey");
		
		ContentMenuDao contentMenuDao=new ContentMenuDao();	
		contentMenuDao.updateChildPageContentMenu(subMenuId, contentMenu_parentId,subMenuName,subPageTitle, subPageAlias, subMetaDes, subMetaKey);
		RequestDispatcher rd=request.getRequestDispatcher("ViewSubMenuAction");
	  	rd.forward(request, response);
  	}
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}


}
