package com.contentmgmt.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.contentmgmt.domain.ContentMenu;
import com.contentmgmt.domain.SubMenu;
import com.contentmgmt.domain.ThirdLevelMenu;
import com.contentmgmt.util.HibernateSessionFactory;
	
public class ContentMenuDao {
	SessionFactory sf = null;
    Session ses = null;
    Transaction tra = null;
    Query query = null;
    
	public ContentMenuDao() {
		sf = HibernateSessionFactory.getSessionFactory();
	    ses = sf.openSession();
	    tra = ses.beginTransaction();
	}
    public List<ContentMenu> viewMenus(){
		query = ses.createQuery("FROM ContentMenu");
		return query.list();
	}
    public List<ContentMenu> editMenu(int menuId){
		query = ses.createQuery("FROM ContentMenu where menuId=?");
		query.setParameter(0, menuId);
		return query.list();
    }
    public List<SubMenu> editSubMenu(int subMenuId){
		query = ses.createQuery("FROM SubMenu where subMenuId=?");
		query.setParameter(0, subMenuId);
		return query.list();
    }
    public List<SubMenu> viewSubMenu(){
		query = ses.createQuery("FROM SubMenu");
		return query.list();
    }
    public List<ThirdLevelMenu> viewThirdLevelMenu(){
		query = ses.createQuery("FROM ThirdLevelMenu");
		return query.list();
    }
    public void updateMenu(int menuId,String menuName,String pageTitle,String pageAlias,String metaDes,String metaKey){
		query = ses.createQuery("update ContentMenu set menuName=:menuName,pageTitle=:pageTitle,pageAlias=:pageAlias,metaDes=:metaDes,metaKey=:metaKey where menuId=:menuId");
		
		query.setString("menuName",menuName);
		query.setString("pageTitle", pageTitle);
		query.setString("pageAlias", pageAlias);
		query.setString("metaDes", metaDes);
		query.setString("metaKey", metaKey);
		query.setInteger("menuId", menuId);
		query.executeUpdate();
		
		//return query.list();
	}
    public void updateChildPageContentMenu(int subMenuId,int contentMenu_parentId,String subMenuName,String subPageTitle,String subPageAlias,String subMetaDes,String subMetaKey){
		query = ses.createQuery("update SubMenu set contentMenu_parentId=:contentMenu_parentId,subMenuName=:subMenuName,subPageTitle=:subPageTitle,subPageAlias=:subPageAlias,subMetaDes=:subMetaDes,subMetaKey=:subMetaKey where subMenuId=:subMenuId");
		
		query.setString("subMenuName",subMenuName);
		query.setInteger("contentMenu_parentId", contentMenu_parentId);
		query.setString("subPageTitle", subPageTitle);
		query.setString("subPageAlias", subPageAlias);
		query.setString("subMetaDes", subMetaDes);
		query.setString("subMetaKey", subMetaKey);
		query.setInteger("subMenuId", subMenuId);
		int result = query.executeUpdate();
		
		//return query.list();
	}
    public void InsertRecord(SubMenu log) {
        
    	try {
        	//deleteMenu(log.getMenuId());
            ses.save(log);
            tra.commit();
            
        } catch (Exception e) {
            tra.rollback();
         
            e.printStackTrace();
            
        }
    }
    public List<SubMenu> viewSubMenus(){
		query = ses.createQuery("FROM SubMenu");
		return query.list();
    }
}
