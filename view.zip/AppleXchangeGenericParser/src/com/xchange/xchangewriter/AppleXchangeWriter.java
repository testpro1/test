package com.xchange.xchangewriter;

import java.io.*;
import java.util.*;
import org.apache.commons.logging.*;
import javax.xml.bind.*;
import com.camstar.xchangeparser.unitreport.*;
import com.camstar.xchangeparser.xchangelog.XchangeParserLog.Footer;
import com.camstar.xchangeparser.xchangelog.XchangeParserLog.Footer.Summary;
import com.camstar.xchangeparser.xchangelog.XchangeParserLog.Footer.Summary.Files;
import com.camstar.xchangeparser.xchangelog.XchangeParserLog.Footer.Summary.Lines;
import com.xchange.Exceptions.*;
import com.camstar.xchangeparser.xchangelog.XchangeParserLog;
import com.camstar.xchangeparser.xchangelog.XchangeParserLogFactory;
import com.camstar.xchangeparser.xchangelog.XchangeParserLog.Header;
import com.camstar.xchangeparser.xchangelog.XchangeParserLog.Log.FileSummary;
import com.xchange.genericparser.engine.*;
import com.xchange.genericparser.engine.ParserConfig.*;

public class AppleXchangeWriter extends URWriter {
	private static Log log = LogFactory.getLog(AppleXchangeWriter.class);
	private final String MODE = "true";
	private final String VERSION = "2.0.0.1";
	private final long QUANTITY = 1l;
	private final String PROPERTY_NAME = "Log";
	private final String PROPERTY_TYPE = "text/plain";
	private final boolean ATTACHMENT = true;
	private final String ACTUAL_VALUE = "ACTUAL_VALUE";
	private final String UPPER_VALUE = "UPPER_VALUE";
	private final String LOWER_VALUE = "LOWER_VALUE";
	private final boolean IS_CORRECTIVE = false;
	private final boolean IS_COMPLETED = true;
	private final String PASS_GREADE = "PASS";
	private final String FAIL_GREADE = "FAIL";
	private final String ERROR_GRADE = "ERROR";
	private final String HEADER_NAME = "Apple Xchange Parser";
	private String[] _sourceValueArray;
	private String _stationConfigLocation;
	private List<FileException> _exceptions = new ArrayList<FileException>();
	private int _lineFailure = 0;
	private int _lineSuccess = 0;
	private int _fileFailure=0;
	private int _fileSuccess=0;
	private Hashtable<String, Integer> _exceptionSummary = new Hashtable<String, Integer>();
	private ArrayList<String> _errorLineRecords = new ArrayList<String>();

	public AppleXchangeWriter(DataConverter dataConverter) {
		super(dataConverter);
		if (log.isInfoEnabled()) {
			log.info("IN");
		}
		if (log.isInfoEnabled()) {
			log.info("OUT");
		}
	}

	private void testInit() throws DependecyNotFoundException,
			InvalidConfigurationSchemaException {
		if (log.isDebugEnabled()) {
			log.debug("IN");
		}
		File file = new File(_dataConverter.getMappingFilePath());
		if (File.class.isInstance(file)) {
			try {
				AppleXchangeMap.setContext(_dataConverter.getMappingFilePath());
			} catch (java.lang.Exception e) {
				throw new InvalidConfigurationSchemaException(_dataConverter
						.getMappingFilePath(), Map.class.toString(), e);
			}
		} else {
			log.error("Map File : " + _dataConverter.getMappingFilePath()
					+ " is not available.");
		}
		if (log.isDebugEnabled()) {
			log.debug("OUT");
		}
	}

	@Override
	public void convert(String fileName) {
		if (log.isDebugEnabled())
			log.debug("IN");
		if (log.isDebugEnabled())
			log.debug("TESTINIT");
		try {
			testInit();
		} catch (DependecyNotFoundException e) {
			System.out.println(e + "" + e.get_dependencyName());
		} catch (InvalidConfigurationSchemaException e) {
			System.out.println(e + "" + e.get_serializableClassName() + "-"
					+ e.get_xmlFilePath());
		}
		if (log.isDebugEnabled())
			log.debug("Reading File: " + fileName);

		try {
			readFile(fileName);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		if (log.isDebugEnabled())
			log.debug("SUBMIT!");
		if (log.isDebugEnabled())
			log.debug("OUT");
	}

	private void processLine(String line, int lineNo) {
		boolean isExceptionArrived = false;
		_sourceValueArray = line.split(",");
		XchangeUnitReport unitReport = new XchangeUnitReport();
		unitReport.setAttachments(ATTACHMENT);
		unitReport.setMode(MODE);
		unitReport.setQuantity(QUANTITY);
		unitReport.setSoftwareVersion(VERSION);

		_stationConfigLocation = _dataConverter.getConfigLocation();
		File file = new File(_stationConfigLocation);
		try {
			if (!file.exists()) {
				throw new StationConfigNotFoundException(file.getPath());
			} else {
				unitReport.setConfigLocation(file.getPath());
			}
		} catch (StationConfigNotFoundException e) {
			System.out.println(e.getMessage() + " "
					+ e.get_stationConfigLocation());
		}
		unitReport._queueLocation = XchangeParserProperties.getUnitFolderPath();
		XchangeStation station = unitReport.getStationInstance();
		unitReport.setStationInstance(station);

		XchangeOperator operator = unitReport.getOperator();
		operator.setName(_sourceValueArray[AppleXchangeMap.getOperatorIndex()]);
		unitReport.setOperator(operator);

		XchangeCategory category = unitReport.getCategory();
		category.setName(_sourceValueArray[AppleXchangeMap
				.getAppleProductFamilyIndex()]);

		XchangeProduct product = unitReport.getProduct();
		product.setPartNo(_sourceValueArray[AppleXchangeMap.getPartNoIndex()]);
		product.setSerialNo(_sourceValueArray[AppleXchangeMap
				.getSerialNoIndex()]);
		category.addProducts(product);

		unitReport.setCategory(category);

		XchangeTestRun testRun = unitReport.getTestRun();
		testRun.setStartTime(Calendar.getInstance());
		testRun.setName(_sourceValueArray[AppleXchangeMap.getTestNameIndex()]);
		testRun.setGrade(_sourceValueArray[AppleXchangeMap.getTestGradeIndex()]);

		XchangeProperty property = unitReport.getProperty();
		XchangeValueAttachment attachment = unitReport.getXchangeValueAttachment();
		attachment.setFqn(XchangeParserProperties.getlogFolderPath());
		attachment.setName(PROPERTY_NAME);
		attachment.setType(PROPERTY_TYPE);
		property.addValueAttachment(attachment);
		testRun.addXchangeProperty(property);
		// type checking
		for (int i = AppleXchangeMap.getCTQNameIndex(); i < _sourceValueArray.length; i++) {
			// set the sub-test CTQ-Name
			XchangeTestRun testRun1 = unitReport.getTestRun();
			testRun1.setStartTime(Calendar.getInstance());
			testRun1.setName(_sourceValueArray[i]);
			// Set the Sub-test CTQ-Value
			XchangeProperty property1 = unitReport.getProperty();
			property1.setValueInteger("LoopIndex", 1);
			testRun1.addXchangeProperty(property1);
			try {
				double lowerMeasurement = getValidatedValue(_sourceValueArray[i
						+ AppleXchangeMap.getIndex(LOWER_VALUE)], lineNo, i
						+ AppleXchangeMap.getIndex(LOWER_VALUE));
				double upperMeasurement = getValidatedValue(_sourceValueArray[i
						+ AppleXchangeMap.getIndex(UPPER_VALUE)], lineNo, i
						+ AppleXchangeMap.getIndex(UPPER_VALUE));
				double actualMeasurement = getValidatedValue(
						_sourceValueArray[i
								+ AppleXchangeMap.getIndex(ACTUAL_VALUE)],
						lineNo, i + AppleXchangeMap.getIndex(ACTUAL_VALUE));
				if ((lowerMeasurement < actualMeasurement)
						&& (actualMeasurement < upperMeasurement)) {
					testRun1.setGrade(PASS_GREADE);
				} else {
					testRun1.setGrade(FAIL_GREADE);
				}
			} catch (FileException e) {
				_exceptions.add(e);
				testRun1.setGrade(ERROR_GRADE);
				isExceptionArrived = true;
			}
			i += 3;
			testRun1.getXchangeProperties().add(property1);
			testRun1.setEndTime(Calendar.getInstance());
			testRun.addXchangeSubTestrun(testRun1);
		}
		testRun.setEndTime(Calendar.getInstance());
		unitReport.setTestrun(testRun);
		unitReport.setEndTime(Calendar.getInstance());
		if (isExceptionArrived) {
			unitReport.write();
			_errorLineRecords.add(line);
			_lineFailure++;
			_fileFailure=1;

		} else {
			_lineSuccess++;
			_fileSuccess=1;
		}
	}
	public void writeCSVFile(String line, String fileName) {
		File file = new File(fileName);
		StringBuilder builder = new StringBuilder();
		for (int j = 0; j < file.getName().length(); j++) {
			builder.append(file.getName().charAt(j));
		}
		int deleteEx = builder.lastIndexOf(".csv");
		builder.delete(deleteEx, builder.length());
		String newFileName = XchangeParserProperties.getErrorFolderPath() + "/"
				+ builder + "-records_with_errors.csv";
		try {
			FileWriter writer = new FileWriter(newFileName);
			BufferedWriter out = new BufferedWriter(writer);
			for (int i = 0; i < _errorLineRecords.size(); i++) {
				out.write(_errorLineRecords.get(i));

				if (i < -1) {
					out.write(',');
				} else {
					out.write('\n');
				}
			}
			out.close();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}
	private double getValidatedValue(String value, int lineNo, int columnNo)
			throws ValueNotAvailableException, TypeNotValidException {
		if (value.isEmpty())
			throw new ValueNotAvailableException(lineNo, columnNo);
		try {
			return Double.valueOf(value);
		} catch (java.lang.Exception e) {
			throw new TypeNotValidException(lineNo, columnNo);
		}
	}
	private void writeLogFile(String fileName) throws JAXBException,
			FileNotFoundException {
		{
			// writing Header
			XchangeParserLog xchangeParserLog = new XchangeParserLog();
			Header header = new Header();
			header.setName(HEADER_NAME);
			header.setName(VERSION);
			header.markStartTime();
			xchangeParserLog.setHeader(header);
			com.camstar.xchangeparser.xchangelog.XchangeParserLog.Log log = null;
			XchangeParserLog.Log.Exception exception = null;
			for (FileException ex : _exceptions) {
				log = new com.camstar.xchangeparser.xchangelog.XchangeParserLog.Log();
				exception = new XchangeParserLog.Log.Exception();
				exception.setFileName(new File(fileName).getName());
				exception.setLineNo(ex.get_lineNo());
				exception.setName(ex.get_Name());
				log.setException(exception);
				xchangeParserLog.getLog().add(log);
			}
			log = new com.camstar.xchangeparser.xchangelog.XchangeParserLog.Log();
			for (FileException ex : _exceptions) {
				increseException(ex.get_Name());
			}
			FileSummary fileSummary = new FileSummary();
			fileSummary.setFileName(new File(fileName).getName());
			fileSummary.setIsCompleted(IS_COMPLETED);
			fileSummary.setIsCorrective(IS_CORRECTIVE);
			fileSummary.setLineFailures(_lineFailure);
			fileSummary.setLineSuccesses(_lineSuccess);
			XchangeParserLog.Log.FileSummary.Exceptions logExceptions = new XchangeParserLog.Log.FileSummary.Exceptions();
			for (String key : _exceptionSummary.keySet()) {
				XchangeParserLog.Log.FileSummary.Exceptions.Exception logException = new XchangeParserLog.Log.FileSummary.Exceptions.Exception();
				logException = new XchangeParserLog.Log.FileSummary.Exceptions.Exception();
				logException.setName(key);
				logException.setQuantity(_exceptionSummary.get(key));
				logExceptions.getException().add(logException);
			}
			fileSummary.setExceptions(logExceptions);
			log.setFileSummary(fileSummary);
			xchangeParserLog.getLog().add(log);

			// writing footer
			Footer footer = new Footer();
			footer.markStartTime();
			XchangeParserLog.Footer.Summary.Exceptions footerExceptions = new XchangeParserLog.Footer.Summary.Exceptions();
			Summary summary = new Summary();
			Files files = new Files();
			files.setFailures(_fileFailure);
			files.setSuccesses(_fileSuccess);
			summary.setFiles(files);
			Lines lines = new Lines();
			lines.setFailures(_lineFailure);
			lines.setSuccesses(_lineSuccess);
			summary.setLines(lines);
			for (String key : _exceptionSummary.keySet()) {
				XchangeParserLog.Footer.Summary.Exceptions.Exception footerException = new XchangeParserLog.Footer.Summary.Exceptions.Exception();
				footerException.setName(key);
				footerException.setQuantity(_exceptionSummary.get(key));
				footerExceptions.getException().add(footerException);
			}
			summary.setExceptions(footerExceptions);
			footer.setSummary(summary);
			xchangeParserLog.setFooter(footer);
			XchangeParserLogFactory.Write(xchangeParserLog,	XchangeParserProperties.getlogFolderPath()+"/XchangeParserLog_"+(new Date()).getTime()+".xml");
		}
	}
	private void increseException(String exceptionName) {
		if (_exceptionSummary.containsKey(exceptionName)) {
			int value = _exceptionSummary.get(exceptionName);
			_exceptionSummary.put(exceptionName, value + 1);
		} else {
			_exceptionSummary.put(exceptionName, 1);
		}
	}
	private void readFile(String fileName) throws JAXBException {
		if (log.isDebugEnabled()) {
			log.debug("IN");
		}
		try {
			int lineNo = 0;
			FileInputStream fstream = new FileInputStream(fileName);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader bufferedReader = new BufferedReader(
					new InputStreamReader(in));
			// processing header
			String lineValue = bufferedReader.readLine();
			_errorLineRecords.add(lineValue);
			while ((lineValue = bufferedReader.readLine()) != null) {
				lineNo++;
				processLine(lineValue, lineNo);
			}
			lineNo = 0;
			in.close();
			fstream.close();
			bufferedReader.close();
			writeLogFile(fileName);
			if (_lineFailure != 0) {
				writeCSVFile(lineValue, fileName);
			}
			_lineFailure = 0;
			_lineSuccess = 0;
			_fileFailure=0;
			_fileSuccess=0;
			_errorLineRecords.clear();
			_exceptions.clear();
			_exceptionSummary.clear();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}