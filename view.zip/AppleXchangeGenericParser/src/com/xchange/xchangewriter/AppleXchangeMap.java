package com.xchange.xchangewriter;

import java.io.*;
import java.util.*;
import javax.xml.bind.*;
import com.xchange.Exceptions.*;
import com.xchange.xchangewriter.Map.Element;

public class AppleXchangeMap {	
	final static String OPERATOR_TEXT = "Operator";
	final static String APPLE_PRODUCT_FAMILY="Category";
	final static String PART_NO="PartNo";
	final static String SERIAL_NO="SerialNo";
	final static String TEST_NAME="TestName";
	final static String TEST_GRADE="TestGrade";
	final static int CTQ_INDEX=14;
	private static ArrayList<Element> _elementList=null;
	private enum ValueOrder
	{
		ACTUAL_VALUE,
		UPPER_VALUE,
		LOWER_VALUE
	}
	public static void setContext(String mapFileLocation) throws IOException,InvalidConfigurationSchemaException, DependecyNotFoundException
	{
		JAXBContext context;
		Map map=null;
		File file=new File(mapFileLocation);
		if(!file.exists())
		{
			try {
				throw new SourceNotFoundException(mapFileLocation);
			} catch (SourceNotFoundException e) {
				System.out.println(e+""+e.get_sourceFile());
			}
		}
		else
		{
			try
			{
				context = JAXBContext.newInstance(Map.class);
				Unmarshaller unmarshaller = context.createUnmarshaller();
				unmarshaller.setSchema(null);
				map= (Map)(unmarshaller).unmarshal(file);
			}
			catch (JAXBException e) 
			{
				throw new DependecyNotFoundException(JAXBContext.class.toString(),e);
			}
			catch(Exception ex)
			{
				throw new InvalidConfigurationSchemaException(mapFileLocation,Map.class.toString(), ex);
			}
		}
		_elementList=map.getElement();
	}
	public static int getOperatorIndex()
	{
		return getKeyword(OPERATOR_TEXT)-1;
	}
	public static int getAppleProductFamilyIndex()
	{
		return getKeyword(APPLE_PRODUCT_FAMILY)-1;
	}
	public static int getPartNoIndex()
	{
		return getKeyword(PART_NO)-1;
	}
	public static int getSerialNoIndex()
	{
		return getKeyword(SERIAL_NO)-1;
	}
	public static int getTestNameIndex()
	{
		return getKeyword(TEST_NAME)-1;
	}
	public static int getTestGradeIndex()
	{
		return getKeyword(TEST_GRADE)-1;
	}
	public static int getCTQNameIndex()
	{
		return getKeywordIndex(CTQ_INDEX)-1;
	}
	private static int getKeyword(String keyword)
	{
		for(Element element: _elementList)
		{
			if(element.getName().equals(keyword))
			{
				return element.getIndex();
			}
		}
		return -1;
	}
	private static int getKeywordIndex(int keyword)
	{
		for(Element element: _elementList)
		{
			if(element.getIndex().equals(keyword))
			{
				return element.getIndex();
			}
		}
		return -1;
	}
	public static int getIndex(String arg)
	{
		return ValueOrder.valueOf(arg).ordinal()+1;
	}
}
