package com.xchange.genericparser.engine;


public enum DataConverterStationslookupstrategy {
	file,
    url,
    hybrid,
}
