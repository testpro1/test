package com.xchange.genericparser.engine;

import java.io.File;

public class ParseEvents {

	public File file = null;
	public Long fileProcessed = null;
	public Long fileTotal = null;
	
	public ParseEvents(File file,Long fileProcessed,Long fileTotal){
		this.file=file;
		this.fileProcessed=fileProcessed;
		this.fileTotal=fileTotal;
		
	}
} //end of class ParseEvents
