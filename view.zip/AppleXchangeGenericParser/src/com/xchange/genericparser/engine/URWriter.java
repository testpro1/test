package com.xchange.genericparser.engine;

import java.util.Calendar;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.camstar.xchangeparser.unitreport.*;
import com.xchange.genericparser.conversion.IURWriter;
import com.xchange.genericparser.engine.ParserConfig.DataConverter;

public abstract class URWriter implements IURWriter
{
	private static Log log = LogFactory.getLog(URWriter.class);
	protected XchangeUnitReport xchangeUnitReport;
	protected XchangeTestRun xchangeTestRun;
	protected XchangeCategory xchangeCategory;
	protected XchangeProduct xchangeProduct;
	protected XchangeOperator xchangeOperator;
	protected XchangeStation xchangeStation;
	protected String _filename;
	public static  DataConverter _dataConverter;
	public Calendar timeStamp;
	@SuppressWarnings("static-access")
	public URWriter(DataConverter dataConverter)
	{
	    if (log.isDebugEnabled()) 
	    {
	    	log.debug("IN");	
	    }
	  this._dataConverter = dataConverter;
	    this.timeStamp = Calendar.getInstance();
	    if (_dataConverter.getStationsLookupStrategy().toString().equals(DataConverterStationslookupstrategy.file.toString())) 
	    {
	    	this._filename = _dataConverter.getStationsConfigFile();
	    	if (log.isDebugEnabled()) 
	    	{
	    		log.debug("File! = " + dataConverter.getStationsConfigFile());
	    		System.out.println("In If loop"+ dataConverter.getStationsConfigFile());
	    	}
		}
	    else if(_dataConverter.getStationsLookupStrategy().equals(DataConverterStationslookupstrategy.url)) 
	    {
	    	if (log.isDebugEnabled()) {
	    		log.debug("URL! = " + dataConverter.getStationsLookupUrl());
           }
	    }else if (_dataConverter.getStationsLookupStrategy().equals(DataConverterStationslookupstrategy.hybrid)) 
	    {
	    	if (log.isDebugEnabled()) 
	    	{
	    		log.debug("HYBRID!");
	    	}
		}
	}	
	public abstract void convert(String fileName);
	@SuppressWarnings("unused")
	private Object getPropertyValue(String element, String dataType)
	{
		Object propertyValue = null;
		return _dataConverter;
	}	
}