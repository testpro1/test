package com.xchange.Exceptions;

public class FoundBlankValueException {

}
