package com.xchange.Exceptions;

public abstract class FileException extends Exception {
	public static final long serialVersionUID = 43L;
	private int _lineNo=0;
	private int _columnNo=0;
	
	public FileException(String message, int lineNo, int columnNo) {
		super(message);
		_lineNo=lineNo;
		_columnNo = columnNo;
	}
	public int get_lineNo() {
		return _lineNo;
	}
	public int get_columnNo()
	{
		return _columnNo;
	}
	public String get_Name()
	{
		String className=this.getClass().getSimpleName();
		StringBuilder builder=new StringBuilder();
		for(int j=0;j<className.length();j++){
			builder.append(className.charAt(j));
		}
		int end=builder.lastIndexOf(".");
		int deleteException=builder.lastIndexOf("Exception");
		builder.delete(deleteException, builder.length());
		className=builder.substring(end+1,builder.length());
		return className;
	}	
}