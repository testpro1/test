package com.xchange.Exceptions;


public class InvalidFileListException extends Exception 
{
	public static final long serialVersionUID = 43L;
	private static final String _message = "Minimum one file should be exist for parse in specified directory";
	private static String _parseDirectory; 
	private static String _parseFileFilter;
	
	
public InvalidFileListException(String parseDirectory,String fileFilter) 
	{
	super(_message);
	_parseDirectory=parseDirectory;
	_parseFileFilter=fileFilter;
			
	}
public String get_parseDirectory() {
	return _parseDirectory;
}
public static String get_parseFileFilter() {
	return _parseFileFilter;
}

}
