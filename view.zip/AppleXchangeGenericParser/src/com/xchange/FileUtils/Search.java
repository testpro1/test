package com.xchange.FileUtils;

import java.io.*;
import java.util.*;
import javax.naming.spi.DirectoryManager;
import javax.swing.text.StringContent;
import com.xchange.Exceptions.*;

public class Search
{
	private static final String _fileEx = ".csv";
	public ArrayList<DirectoryManager> Directories;
	public ArrayList<File> Files;  
	public StringContent directoryMask;
	public StringContent fileMask;
	 
	public Search()
	{
		Directories = new ArrayList<DirectoryManager>();
		Files = new ArrayList<File>();
		directoryMask=new StringContent();
		fileMask=new StringContent();
		
	}
    public Search(File initialDirectory){	
    }
    public Search(String baseDirectory){
	}
    public void DoSearch() {
	}
    public void DoSearch(String initialDirectory) {
	}
    public void DoSearch(String initialDirectory, String fileMask) {
	}
    public void DoSearch(String initialDirectory, String fileMask, String directoryMask) {
	}
   
	public void DoSearch(String initialDirectory, String fileMask, String directoryMask, int level)
    {
    	try
    	{  		
    		File[] files1=finder(initialDirectory);
    		if(files1==null)
    		{
    			throw new ExchangeClassNotFoundException(initialDirectory,fileMask,level);
    		}
    		else
    		{
				if(fileMask.toString().endsWith(_fileEx))
    			{
					if(files1.length!=0)
    				{
    					for(int i=0;i<files1.length;i++)
    					{
	    					Files.add(files1[i]);
    					}
    				}
    				else
    				{
    					throw new InvalidFileListException(initialDirectory,fileMask);
    				}
    			}
				else
				{
					throw new InValidExchangeCastException(initialDirectory,fileMask);
				}
			}	
	    }
    	catch(ExchangeClassNotFoundException e)
    	{
    		System.out.println(e.getMessage()+e.get_parseDirectory()+"	"+e.get_parseFileFilter()+"	"+e.get_parseLevel());
    	}
    	catch (InvalidFileListException e) {
			
			System.out.println(e.getMessage()+"-"+e.get_parseDirectory());
		}
    	catch(InValidExchangeCastException e)
    	{
    		System.out.println(e.getMessage()+"	"+e.get_parseDirectory()+"	"+e.get_parseFileFilter());
    	}
    }
   		public File[] finder(String dirName)
   		{
   	        File dir = new File(dirName);
   	        return dir.listFiles(new FilenameFilter() 
   	        { 
   	                 public boolean accept(File dir, String filename)
   	                    { 
   	                	 	boolean fileEx=filename.endsWith(_fileEx);
   	                	 	return fileEx; 
   	                	}
   	        } );

   	    }
   	
public ArrayList<DirectoryManager> getDirectories() {
		return Directories;
	}

    public ArrayList<File> getFiles() {
		return Files;
	}

	public StringContent getDirectoryMask() {
		return directoryMask;
	}

	public void setDirectoryMask(StringContent directoryMask) {
		this.directoryMask = directoryMask;
	}

	public StringContent getFileMask() 
	{
		return fileMask;
	}

	public void setFileMask(StringContent fileMask) {
		this.fileMask = fileMask;
	}
	
}