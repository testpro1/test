package com.xchange.FileUtils;

public class FileSystemMonitor 
{
	private int consolidationInterval; 
	private boolean enableRaisingEvents;
	private String filter; 
	private boolean includeSubdirectories;
	private int internalBufferSize;
	private String path;
	private NotifyFilters NotifyFilter;
	
    public FileSystemMonitor(){
		
	}
    
    public FileSystemMonitor(String path){
    	
    }
    
    public FileSystemMonitor(String path, String filter){
    	
    }

	public void setConsolidationInterval(int consolidationInterval) {
		this.consolidationInterval = consolidationInterval;
	}

	public int getConsolidationInterval() {
		return consolidationInterval;
	}

	public void setEnableRaisingEvents(boolean enableRaisingEvents) {
		this.enableRaisingEvents = enableRaisingEvents;
	}

	public boolean isEnableRaisingEvents() {
		return enableRaisingEvents;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getFilter() {
		return filter;
	}

	public void setIncludeSubdirectories(boolean includeSubdirectories) {
		this.includeSubdirectories = includeSubdirectories;
	}

	public boolean isIncludeSubdirectories() {
		return includeSubdirectories;
	}

	public void setInternalBufferSize(int internalBufferSize) {
		this.internalBufferSize = internalBufferSize;
	}

	public int getInternalBufferSize() {
		return internalBufferSize;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getPath() {
		return path;
	}

	public void setNotifyFilter(NotifyFilters notifyFilter) {
		NotifyFilter = notifyFilter;
	}

	public NotifyFilters getNotifyFilter() {
		return NotifyFilter;
	}
}
