package com.xchange.FileUtils;

public enum NotifyFilters {

	FileName,    
	DirectoryName, //     The name of the directory.
	Attributes,    //     The attributes of the file or folder.
	Size,    //     The size of the file or folder.
	LastWrite,    //     The date the file or folder last had anything written to it.
	LastAccess,    //     The date the file or folder was last opened.
	CreationTime,    //     The time the file or folder was created.
	Security,    //     The security settings of the file or folder.
    
}
