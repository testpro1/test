/*
 * author Rupal Kathiriya
 */
package com.clinical_trials.retrieve;
/*configuration with mysql database.
 * 
 * author Rupal Kathiriya
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import com.clinical_trials.retrieve.ClinicalStudy.ArmGroup;
import com.clinical_trials.retrieve.ClinicalStudy.Intervention;
import com.clinical_trials.retrieve.ClinicalStudy.Location;
import com.clinical_trials.retrieve.ClinicalStudy.OverallContactBackup;
import com.clinical_trials.retrieve.ClinicalStudy.PrimaryOutcome;
import com.clinical_trials.retrieve.ClinicalStudy.Reference;
import com.clinical_trials.retrieve.ClinicalStudy.SecondaryOutcome;
import com.clinical_trials.retrieve.ClinicalStudy.Location.Investigator;

public class DataConnection {
	 Connection con = null;
	 //String url = "jdbc:mysql://23.21.195.200:3306/";
	 //String db = "millipore";
	 String url = "jdbc:mysql://localhost:3306/";
	 String db = "millipore";
	 String driver = "com.mysql.jdbc.Driver";
	 String username = "root";
	 String password = "root";
	
	 public Connection getMyconnection()
	  {
		  try{
			   Class.forName(driver);
		  	   con = DriverManager.getConnection(url+db,username, password);
			 }
		  	catch (Exception e){
		  		e.printStackTrace();
		  	}
		return con;  
	  }
	
	@SuppressWarnings("unchecked")
	public void save(ClinicalStudy clinicalStudy) throws SQLException
	{
		
		System.out.println("in Method");
		PreparedStatement ps = null;
		String startDate = null;
		String verificationDate=null;
		String lastchangedDate=null;
		String firstreceivedDate=null;
		String primary_completionDate=null;
		String completionDate=null;
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMM yyyy");
			
			SimpleDateFormat changedDate=new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat changedDate1=new SimpleDateFormat("MMMM d, yyyy");
			//String rg = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";
			
			String sqlString = "insert into clinical_trials(id_info_nct_id,id_info_org_study_id,required_header_url,brief_title,official_title,sponsors_lead_sponsor_agency,sponsors_lead_sponsor_agency_class,source,brief_summary_textblock,detailed_description_textblock,collaborator_agency,collaborator_agency_class,overall_status,oversight_info_authority,start_date,study_type,study_design,oversight_info_has_dmc,phase,primary_outcome_measure,primary_outcome_time_frame,primary_outcome_safety_issue,primary_outcome_description,eligibility_criteria_textblock,number_of_arms,enrollment_count,condition1,study_pop,sampling_method,Inclusion_criteria,gender,minimum_age,maximum_age,healthy_volunteers,overall_official_last_name,overall_official_role,overall_official_affiliation,overall_contact_location_facility,overall_contact_location_facility_address_city,overall_contact_location_facility_address_state,overall_contact_location_facility_address_zip,overall_contact_location_facility_address_country,overall_contact_last_name,overall_contact_phone,overall_contact_email,overall_contact_backup_last_name,overall_contact_backup_phone,overall_contact_backup_email,facility_name,facility_city,facility_state,facility_zip,facility_country,facility_status,facility_name_2,facility_city_2,facility_state_2,facility_zip_2,facility_contact_2_last_name,facility_contact_2_phone,facility_contact_2_email,contact_investigator_last_name,contact_investigator_role,location_countries,verification_date,lastchanged_date,firstreceived_date,responsible_party_type,is_fda_regulated,has_expanded_access,status,study_results,conditions,interventions,link_url,link_description,age_groups,enrollment,funded_bys,other_ids,first_received,completion_date,last_updated,last_verified,acronym,primary_completion_date,outcome_measures,url,criteria_gender,criteria_minimum_age,criteria_maximum_age,keyword,reference_PMID,mesh_trerms,arm_group_label,arm_group_type,secondary_outcome_measure,secondary_outcome_time_frame,secondary_outcome_safety_issue) values(?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?,?," +
					"?,?,?,?,?,?,?,?,?)";
			
			
			ps = getMyconnection().prepareStatement(sqlString);
			System.out.println("Parsing started.......");
			
				String NctId=clinicalStudy.getIdInfo().getNctId();
				String studyId=clinicalStudy.getIdInfo().getOrgStudyId();
				String url=clinicalStudy.getRequiredHeader().getUrl();
				String briefTitle=clinicalStudy.getBriefTitle();
	        	String officialTitle=clinicalStudy.getOfficialTitle();
				String SpoLeadAgency=null;
				String spoLeadAgencyclass=null;
				if(clinicalStudy.getSponsors()!=null){
					SpoLeadAgency=clinicalStudy.getSponsors().getLeadSponsor().getAgency();
					spoLeadAgencyclass=clinicalStudy.getSponsors().getLeadSponsor().getAgencyClass();
				}
				String source=null;
	        	if(clinicalStudy.getSource()!=null){
	        		source=clinicalStudy.getSource();
	        	}
	        	String briefSumTextBox=null;
	        	if(clinicalStudy.getBriefSummary()!=null){
	        		briefSumTextBox=clinicalStudy.getBriefSummary().getTextblock();
	        	}
	        	String detailedDescTextBox=null;
	        	if(clinicalStudy.getDetailedDescription()!=null){
	        		detailedDescTextBox=clinicalStudy.getDetailedDescription().getTextblock();
	        	}
	        	String overAllStatus=null;
	        	if(clinicalStudy.getOverallStatus()!=null){
	        		overAllStatus=clinicalStudy.getOverallStatus();
	        	}
	        	String collaborator_agency=null;
	        	String collaborator_agency_class=null;
	        	if(clinicalStudy.getSponsors().getCollaborator()!=null){
	        		collaborator_agency=clinicalStudy.getSponsors().getCollaborator().getAgency();
		        	collaborator_agency_class=clinicalStudy.getSponsors().getCollaborator().getAgencyClass();
	        	}
	        	
	        	String oversightInfoAuthority=null;
	        	if(clinicalStudy.getOversightInfo()!=null){
	        		oversightInfoAuthority=clinicalStudy.getOversightInfo().getAuthority();
	        	}
	        	String start_date=clinicalStudy.getStartDate();
	        	//if(start_date.matches(rg)){
	        	if(start_date!=null){
	        	 	Date s_date = (Date)sdf1.parse(1+" "+start_date);
					startDate = sdf.format(s_date);
	        	}else{
					  start_date = null;
				}
	        	String studyType=clinicalStudy.getStudyType();
	        	String studyDesign=clinicalStudy.getStudyDesign();
	        	String oversight_info_has_dmc=clinicalStudy.getOversightInfo().getHasDmc();
				String phase=clinicalStudy.getPhase();
				
				String primary_outcome_measure="";
				String primary_outcome_time_frame="";
				String primary_outcome_safety_issue="";
				String primary_outcome_description="";
				if(clinicalStudy.getPrimaryOutcome()!=null){
				  	List list=clinicalStudy.getPrimaryOutcome();
				  	for(int i=0;i<list.size();i++){
				  		PrimaryOutcome primaryOutcome=(PrimaryOutcome) list.get(i);
				  		primary_outcome_measure+=primaryOutcome.getMeasure()+"-";
				  		primary_outcome_safety_issue+=primaryOutcome.getSafetyIssue()+"-";
				  		primary_outcome_time_frame+=primaryOutcome.getTimeFrame()+"-";
				  		primary_outcome_description+=primaryOutcome.getDescription()+"-";
				  	}
			  	}else{
			  		 primary_outcome_measure=null;
			  		 primary_outcome_time_frame=null;
			  		 primary_outcome_safety_issue=null;
			  		 primary_outcome_description=null;
			  	}
				String eligibility_criteria_textblock=clinicalStudy.getEligibility().getCriteria().getTextblock();
				int number_of_arms=clinicalStudy.getNumberOfArms();
				String enrollment_count=null;
				if(clinicalStudy.getEnrollment()!=null){
				 enrollment_count=clinicalStudy.getEnrollment().getType();
				}
				String condition=clinicalStudy.getCondition().toString();
				
				String study_pop=null;
				String sampling_method=null;
				if(clinicalStudy.getEligibility().getStudyPop()!=null){
					study_pop=clinicalStudy.getEligibility().getStudyPop().getTextblock();
					sampling_method=clinicalStudy.getEligibility().getSamplingMethod();
				}
				
				String Inclusion_criteria=null;//required
				String gender=null;
				if(clinicalStudy.getEligibility().getGender()!=null){
					gender=clinicalStudy.getEligibility().getGender();
				}
				String minimum_age=null;
				String maximum_age=null;
				if(clinicalStudy.getEligibility().getMaximumAge()!=null){
					maximum_age=clinicalStudy.getEligibility().getMaximumAge();
				}
				if(clinicalStudy.getEligibility().getMinimumAge()!=null){
					minimum_age=clinicalStudy.getEligibility().getMinimumAge();
				}
				String healthy_volunteers=clinicalStudy.getEligibility().getHealthyVolunteers();
				
				String overall_official_last_name=null;
				String overall_official_role=null;
				String overall_official_affiliation=null;
				if(clinicalStudy.getOverallOfficial()!=null){
					overall_official_last_name=clinicalStudy.getOverallOfficial().getLastName();
					overall_official_role=clinicalStudy.getOverallOfficial().getRole();
					overall_official_affiliation=clinicalStudy.getOverallOfficial().getAffiliation(); 
				}
				 
				String overall_contact_location_facility="";
				String overall_contact_location_facility_address_city="";
				String overall_contact_location_facility_address_state="";
				String overall_contact_location_facility_address_zip="";
				String overall_contact_location_facility_address_country="";
				if(clinicalStudy.getLocation()!=null){
					List list=clinicalStudy.getLocation();
				  	for(int i=0;i<list.size();i++){
				  	Location location=(Location)list.get(i);
					overall_contact_location_facility+=location.getFacility().getName()+"-";         
					
					overall_contact_location_facility_address_city+=location.getFacility().getAddress().getCity()+"-";         
					overall_contact_location_facility_address_state+=location.getFacility().getAddress().getState()+"-";
					
					overall_contact_location_facility_address_zip+=location.getFacility().getAddress().getZip()+"-";           
					overall_contact_location_facility_address_country+=location.getFacility().getAddress().getCountry()+"-";      
				}}
				else
				{
					overall_contact_location_facility=null;
					overall_contact_location_facility_address_city=null;
					overall_contact_location_facility_address_state=null;
					overall_contact_location_facility_address_zip=null;
					overall_contact_location_facility_address_country=null;
				}
				String overall_contact_last_name=null;                              
				String overall_contact_phone=null;                                     
				String overall_contact_email=null;
				if(clinicalStudy.getOverallContact()!=null){
					overall_contact_last_name=clinicalStudy.getOverallContact().getLastName();                              
					overall_contact_phone=clinicalStudy.getOverallContact().getPhone();                                     
					overall_contact_email=clinicalStudy.getOverallContact().getEmail(); 
				}            
				String overall_contact_backup_last_name="";                
				String overall_contact_backup_phone="";                    
				String overall_contact_backup_email="";                   
				
				OverallContactBackup contactBackup=new OverallContactBackup();
			  	List listback=clinicalStudy.getOverallContactBackup();
			  	if(clinicalStudy.getOverallContactBackup()!=null){
				  	for(int i=0;i<listback.size();i++){
				  		contactBackup=(OverallContactBackup) listback.get(i);
				  		overall_contact_backup_last_name+=contactBackup.getLastName()+"-";
				  		overall_contact_backup_phone+=contactBackup.getPhone()+"-";
				  		overall_contact_backup_email+=contactBackup.getEmail()+"-";
				  	}
			  	}else{
			  		overall_contact_backup_last_name=null;                
					overall_contact_backup_phone=null;                    
					overall_contact_backup_email=null;        
			  	}
				String facility_name=null;                                  
				String facility_city=null;                                      
				String facility_state=null;                                     
				String facility_zip=null;                                        
				
				String facility_country=null;                                
				String facility_status=null;                               
				
				String facility_name_2=null;                              
				String facility_city_2=null;                                 
				String facility_state_2=null;                                     
				String facility_zip_2=null;     
				
				String facility_contact_2_last_name="";                         
				String facility_contact_2_phone="";                             
				String facility_contact_2_email="";      
			
			  	List listcon=clinicalStudy.getLocation();
			  	for(int i=0;i<listcon.size();i++){
			  		Location location=clinicalStudy.location.get(i);
			  		if(location.getContact()!=null){
			  			facility_contact_2_last_name+=location.contact.getLastName()+"-";
			  			facility_contact_2_phone+=location.contact.getPhone()+"-";
			  			facility_contact_2_email+=location.contact.getEmail()+"-";
			  		}else{
			  			facility_contact_2_last_name=null;                         
						facility_contact_2_phone=null;                             
						facility_contact_2_email=null; 
			  		}
			  	}
				String contact_investigator_last_name="";                    
				String contact_investigator_role="";
				List listInvest=clinicalStudy.getLocation();
					for(int i=0;i<listInvest.size();i++){
						Location list=clinicalStudy.location.get(i);
						try{
						if(clinicalStudy.location.get(i)!=null || !list.getInvestigator().isEmpty()){
			  				contact_investigator_last_name+=list.investigator.get(i).getLastName().toString()+"-";
			  				contact_investigator_role+=list.investigator.get(i).getRole().toString()+"-";
			  			}else{
			  				contact_investigator_last_name=null;                    
			  				contact_investigator_role=null;
			  			}
						}
						catch(Exception e){
							
							break;
						}	
			  	}
			  		
				String location_countries=null;
				if(clinicalStudy.getLocationCountries()!=null){
					location_countries=clinicalStudy.getLocationCountries().getCountry();       
				}
				String verification_date=clinicalStudy.getVerificationDate();
				if(verification_date!=null){
	        	 	Date s_date = (Date)sdf1.parse(1+" "+verification_date);
	        	 	verificationDate = sdf.format(s_date);
	        	}else{
	        		verification_date = null;
				}
				String lastchanged_date=clinicalStudy.getLastchangedDate();
				
				if(lastchanged_date!=null){
	        	 	Date s_date = (Date)changedDate1.parse(lastchanged_date);
	        	 	lastchangedDate = changedDate.format(s_date);
	        	}else{
	        		lastchanged_date = null;
				}
				String firstreceived_date=clinicalStudy.getFirstreceivedDate();      
				if(firstreceived_date!=null){
	        	 	Date s_date = (Date)changedDate1.parse(firstreceived_date);
	        	 	firstreceivedDate = changedDate.format(s_date);
	        	}else{
	        		firstreceived_date = null;
				}
				String responsible_party_type=null;
				if(clinicalStudy.getResponsibleParty()!=null){
					responsible_party_type=clinicalStudy.getResponsibleParty().getNameTitle();
				}
				String is_fda_regulated=null;
				if(clinicalStudy.getIsFdaRegulated()!=null){
					is_fda_regulated=clinicalStudy.getIsFdaRegulated();  
				}
				                                   
				String has_expanded_access=clinicalStudy.getHasExpandedAccess();                                  
				String STATUS=null;                                               
				String study_results=null;                                       
				String conditions=clinicalStudy.getCondition().toString();                                           
				String interventions="";                              
				if(clinicalStudy.getIntervention()!=null){
				  	List list=clinicalStudy.getIntervention();
				  	for(int i=0;i<list.size();i++){
				  		Intervention intervention=(Intervention) list.get(i);
				  		interventions+=intervention.getInterventionName()+"-";
				  	}
			  	}else{
			  		interventions=null;
			  	}
				String link_url=null;
				String link_description=null;
				if(clinicalStudy.getLink()!=null){
					link_url=clinicalStudy.getLink().getUrl();                                             
					link_description=clinicalStudy.getLink().getDescription();                                     
				}
				String age_groups=null;
				String enrollment=null;
				if(clinicalStudy.getEnrollment()!=null){
					enrollment=clinicalStudy.getEnrollment().getType(); 
				}
				String funded_bys=null;                                           
				String other_ids=null;                                           
				String first_received=null;//clinicalStudy.getFirstreceivedDate();                                      
				
				String completion_date=null;//clinicalStudy.getCompletionDate();  
				if(completion_date!=null){
	        	 	Date s_date = (Date)sdf1.parse(1+" "+completion_date);
	        	 	completionDate = sdf.format(s_date);
	        	}else{
	        		completion_date = null;
				}
				
				String last_updated=null;                                         
				String last_verified=null;                                        
				String acronym=clinicalStudy.getAcronym();                                              
				
				String primary_completion_date=clinicalStudy.getPrimaryCompletionDate();                              
				if(primary_completion_date!=null){
	        	 	Date s_date = (Date)sdf1.parse(1+" "+primary_completion_date);
	        	 	primary_completionDate = sdf.format(s_date);
	        	}else{
	        		primary_completion_date = null;
				}
				String outcome_measures=null;                                     
				String url1=null;                                                  
				String criteria_gender=null;                                      
				String criteria_minimum_age=null;                           
				String criteria_maximum_age=null;                                 
				
				String keyword=clinicalStudy.getKeyword().toString();                                              
				
				String reference_PMID=""; 
				if(clinicalStudy.getReference()!=null){
					List PMID=clinicalStudy.getReference();
				  		for(int i=0;i<PMID.size();i++){
				  			Reference reference=(Reference) PMID.get(i);
				  			reference_PMID+=reference.getPMID()+"-";
				  		}
				  	
				}else{
			  		reference_PMID=null;
			  	}
				String mesh_trerms=null;
				if(clinicalStudy.getConditionBrowse()!=null){
					mesh_trerms=clinicalStudy.getConditionBrowse().getMeshTerm().toString();
				}
				String arm_group_label="";                                      
				String arm_group_type="";                  
				String secondary_outcome_measure = "";                  
				String secondary_outcome_time_frame="";                
				String secondary_outcome_safety_issue="";
				
			ps.setObject(1,NctId);
		  	ps.setObject(2,studyId);
		  	ps.setObject(3,url);
		  	ps.setObject(4,briefTitle);
		  	ps.setObject(5,officialTitle);
		  	ps.setObject(6,SpoLeadAgency);
		  	ps.setObject(7,spoLeadAgencyclass);
		  	ps.setObject(8,source);
		  	ps.setObject(9,briefSumTextBox);
		  	ps.setObject(10,detailedDescTextBox);
		  	ps.setObject(11,collaborator_agency);
		  	ps.setObject(12,collaborator_agency_class);
		  	ps.setObject(13,overAllStatus);
		  	ps.setObject(14,oversightInfoAuthority);
		  	ps.setObject(15,startDate);
		  	ps.setObject(16,studyType);
		  	ps.setObject(17,studyDesign);
		  	ps.setObject(18,oversight_info_has_dmc);
		  	ps.setObject(19,phase);
		  	ps.setObject(20,primary_outcome_measure);
		  	ps.setObject(21,primary_outcome_time_frame);
		  	ps.setObject(22,primary_outcome_safety_issue);
		  	ps.setObject(23,primary_outcome_description);
		  	ps.setObject(24,eligibility_criteria_textblock);
		  	ps.setObject(25,String.valueOf(number_of_arms));
		  	ps.setObject(26,enrollment_count);
		  	ps.setObject(27,condition);
		  	ps.setObject(28,study_pop);
		  	ps.setObject(29,sampling_method);
		  	ps.setObject(30,Inclusion_criteria);
		  	ps.setObject(31,gender);
		  	ps.setObject(32,minimum_age);
		  	ps.setObject(33,maximum_age);
		  	ps.setObject(34,healthy_volunteers);
		  	ps.setObject(35,overall_official_last_name);
		  	ps.setObject(36,overall_official_role);
		  	ps.setObject(37,overall_official_affiliation);
		  	ps.setObject(38,overall_contact_location_facility);
		  	ps.setObject(39,overall_contact_location_facility_address_city);
		  	ps.setObject(40,overall_contact_location_facility_address_state);
		  	ps.setObject(41,overall_contact_location_facility_address_zip);
		  	ps.setObject(42,overall_contact_location_facility_address_country);
		  	ps.setObject(43,overall_contact_last_name);
		  	ps.setObject(44,overall_contact_phone);
		  	ps.setObject(45,overall_contact_email);
		  	ps.setObject(46,overall_contact_backup_last_name);
		  	ps.setObject(47,overall_contact_backup_phone);
		  	ps.setObject(48,overall_contact_backup_email);
		  	ps.setObject(49,facility_name);
		  	ps.setObject(50,facility_city);
		  	ps.setObject(51,facility_state);
		  	ps.setObject(52,facility_zip);
		  	ps.setObject(53,facility_country);
		  	ps.setObject(54,facility_status);
		  	ps.setObject(55,facility_name_2);
		  	ps.setObject(56,facility_city_2);
		  	ps.setObject(57,facility_state_2);
		  	ps.setObject(58,facility_zip_2);
		  	ps.setObject(59,facility_contact_2_last_name);
		  	ps.setObject(60,facility_contact_2_phone);
		  	ps.setObject(61,facility_contact_2_email);
		  	ps.setObject(62,contact_investigator_last_name);
		  	ps.setObject(63,contact_investigator_role);
		  	ps.setObject(64,location_countries);
		  	ps.setObject(65,verificationDate);
		  	ps.setObject(66,lastchangedDate);
		  	ps.setObject(67,firstreceivedDate);
		  	ps.setObject(68,responsible_party_type);
		  	ps.setObject(69,is_fda_regulated);
		  	ps.setObject(70,has_expanded_access);
		  	ps.setObject(71,STATUS);
		  	ps.setObject(72,study_results);
		  	ps.setObject(73,conditions);
		  	ps.setObject(74,interventions);
		  	ps.setObject(75,link_url);
		  	ps.setObject(76,link_description);
		  	ps.setObject(77,age_groups);
		  	ps.setObject(78,enrollment);
		  	ps.setObject(79,funded_bys);
		  	ps.setObject(80,other_ids);
		  	ps.setObject(81,first_received);
		  	ps.setObject(82,completionDate);
		  	ps.setObject(83,last_updated);
		  	ps.setObject(84,last_verified);
		  	ps.setObject(85,acronym);
		  	ps.setObject(86,primary_completionDate);
		  	ps.setObject(87,outcome_measures);
		  	ps.setObject(88,url1);
		  	ps.setObject(89,criteria_gender);
		  	ps.setObject(90,criteria_minimum_age);
		  	ps.setObject(91,criteria_maximum_age);
		  	ps.setObject(92,keyword);
		  	ps.setObject(93,reference_PMID);
		  	ps.setObject(94,mesh_trerms);
		  	
		  	if(clinicalStudy.getArmGroup()!=null){
			  	List list1=clinicalStudy.getArmGroup();
			  	for(int i=0;i<list1.size();i++){
			  		ArmGroup armGroup=(ArmGroup) list1.get(i);
			  		arm_group_label+=armGroup.getArmGroupLabel()+"-";
			  		arm_group_type+=armGroup.getArmGroupType()+"-";
			  	}
		  	}else{
		  		arm_group_label=null;
		  		arm_group_type=null;
		  	}
		  	ps.setObject(95,arm_group_label);
		  	ps.setObject(96,arm_group_type);
		  	if(clinicalStudy.getSecondaryOutcome()!=null){
			  	List list=clinicalStudy.getSecondaryOutcome();
			  	for(int i=0;i<list.size();i++){
			  		SecondaryOutcome outcome=(SecondaryOutcome) list.get(i);
			  		secondary_outcome_measure+=outcome.getMeasure()+"-";
			  		secondary_outcome_safety_issue+=outcome.getSafetyIssue()+"-";
			  		secondary_outcome_time_frame+=outcome.getTimeFrame()+"-";
			  	}
		  	}else{
		  		secondary_outcome_measure=null;
		  		secondary_outcome_safety_issue=null;
		  		secondary_outcome_time_frame=null;
		  	}
		  	
		  	ps.setObject(97,secondary_outcome_measure);
		  	ps.setObject(98,secondary_outcome_time_frame);
		  	ps.setObject(99,secondary_outcome_safety_issue);
		  	ps.executeUpdate();
		  System.out.println("Parsing completed");
		  }
		  catch(Exception e){
			  e.printStackTrace();
		  }
		  finally
		  {
			  if (con != null)  
	            {  
	                try  
	                {
	                	ps.close();
	                	con.close ();  
	                }  
	                catch (Exception e) { 
	                	e.printStackTrace();
	                }  
	            }  
		  }
		  	
		  	
	  }

}
