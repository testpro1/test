package com.clinical_trials.retrieve;

/* to search all valid xml files name.
 * 
 * author Rupal Kathiriya
 */

import java.io.*;
import java.util.*;
import javax.naming.spi.DirectoryManager;
import javax.swing.text.StringContent;


public class ClinicalGrantSearch
{
	private static final String _fileEx = ".xml";
	public ArrayList<DirectoryManager> Directories;
	public ArrayList<File> Files;  
	public StringContent directoryMask;
	public StringContent fileMask;
	 
	public ClinicalGrantSearch()
	{
		Directories = new ArrayList<DirectoryManager>();
		Files = new ArrayList<File>();
		directoryMask=new StringContent();
		fileMask=new StringContent();
		
	}
    public void DoSearch(String initialDirectory, String fileMask, String directoryMask, int level)
    {
    	try
    	{  		
    		File[] files1=finder(initialDirectory);
    		System.out.println("File Number to be parsered : " +files1.length);
    		if(files1==null)
    		{
    			System.out.println("file not found");
    		}
    		else
    		{
				if(fileMask.toString().endsWith(_fileEx))
    			{
					if(files1.length!=0)
    				{
    					for(int i=0;i<files1.length;i++)
    					{
	    					Files.add(files1[i]);
    					}
    				}
    				else
    				{
    					System.out.println("invalid file");
    				}
    			}
				else
				{
					System.out.println("invalid file");
				}
			}	
	    }
    	catch (Exception e) {
    		e.printStackTrace();
			// TODO: handle exception
		}
    }
   		public File[] finder(String dirName)
   		{
   	        File dir = new File(dirName);
   	        return dir.listFiles(new FilenameFilter() 
   	        { 
   	                 public boolean accept(File dir, String filename)
   	                    { 
   	                	 	boolean fileEx=filename.endsWith(_fileEx);
   	                	 	return fileEx; 
   	                	}
   	        } );

   	    }
   	
public ArrayList<DirectoryManager> getDirectories() {
		return Directories;
	}

    public ArrayList<File> getFiles() {
		return Files;
	}

	public StringContent getDirectoryMask() {
		return directoryMask;
	}

	public void setDirectoryMask(StringContent directoryMask) {
		this.directoryMask = directoryMask;
	}

	public StringContent getFileMask() 
	{
		return fileMask;
	}

	public void setFileMask(StringContent fileMask) {
		this.fileMask = fileMask;
	}
	
}