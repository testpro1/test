/*
 * author Rupal Kathiriya
 */
package com.clinical_trials.retrieve;

import java.io.File;
import java.sql.SQLException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class Clinical_retrieveXML {
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws SQLException {
		 try{
			ClinicalGrantParserProperties grantParserProperties=new ClinicalGrantParserProperties();
			String getPath=grantParserProperties.getInFolderName();
			String filter=".xml";
			parse(getPath, filter,1);
		 }catch(JAXBException e){
		 		e.printStackTrace();
		 }
		}
		public static void parse(String dirName,String filter,Integer iLevel) throws JAXBException, SQLException {
			//Parses all files satisfying particular name pattern
			//in a given directory and its subdirectories.
			String[] dirList = dirName.split(",");
			for (String dirpath : dirList)
			{
				parseDirectory(dirpath, filter, iLevel);
			}
		}	
		public static void parseDirectory(String dirName,String filter,Integer iLevel) throws JAXBException, SQLException
		{
			try{
			ClinicalGrantSearch search = new ClinicalGrantSearch();
			
			//search for files satisfying provided filter
			search.DoSearch(dirName, filter, null, iLevel);
			JAXBContext jc = JAXBContext.newInstance(ClinicalStudy.class);
        	Unmarshaller unmarshaller = jc.createUnmarshaller();
         	for(File file : search.Files) 
	        {
         		System.out.println("File Name parsing : " +file.getName());
         		try{
         		ClinicalStudy clinicalStudy = (ClinicalStudy) unmarshaller.unmarshal(new File(file.getName()));
         		
         		DataConnection scios360_1=new DataConnection();
             	scios360_1.save(clinicalStudy);
         		}
         		catch(Exception e){
         			e.printStackTrace();
         		}
	        }
         	}catch(JAXBException e){
         		e.printStackTrace();
         	}
			
        }
}
