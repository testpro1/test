package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\n");
      out.write("<head>\n");
      out.write("<title>\n");
      out.write("Clear cookie example\n");
      out.write("</title>\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("function saveCookie(name) {\n");
      out.write("var username = document.myCookieform.cookievalue.value;\n");
      out.write("if (!username)\n");
      out.write("alert('Please insert name in text box !');\n");
      out.write("else {\n");
      out.write("var date=new Date();\n");
      out.write("date.setDate(date.getDate()+1);\n");
      out.write("document.cookie = name + \"=\" + username+\"; expires=\" + date + \"; path=/\";\n");
      out.write("alert(\"Cookie, \" + name + \" successfully created.\");\n");
      out.write("}\n");
      out.write("}\n");
      out.write("\n");
      out.write("function readCookie(cookieName) {\n");
      out.write("if (document.cookie.length>0){\n");
      out.write("cookieStart=document.cookie.indexOf(cookieName + \"=\");\n");
      out.write("if (cookieStart!=-1){ \n");
      out.write("cookieStart=cookieStart + cookieName.length+1; \n");
      out.write("cookieEnd=document.cookie.indexOf(\";\",cookieStart);\n");
      out.write("if (cookieEnd==-1) cookieEnd=document.cookie.length;\n");
      out.write("alert( \"Value of cookie, \"+ cookieName + \", is: \" + unescape(document.cookie.substring(cookieStart,cookieEnd)));\n");
      out.write("}\n");
      out.write("else{\n");
      out.write("alert(\"Cookie, \" + cookieName + \": Not Found.\");\n");
      out.write("}\n");
      out.write("}\n");
      out.write("else{\n");
      out.write("alert(\"Cookie, \" + cookieName + \": Not Found.\");\n");
      out.write("} \n");
      out.write("}\n");
      out.write("\n");
      out.write("function clearCookie(name) {\n");
      out.write("var date=new Date();\n");
      out.write("date.setDate(date.getDate()-1);\n");
      out.write("document.cookie = name+ \"=''; expires=\" + date + \"; path=/\";\n");
      out.write("alert('Successfully erased Cookie ' + name);\n");
      out.write("}\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("</head>\n");
      out.write("<body>\n");
      out.write("<form name=\"myCookieform\">\n");
      out.write("Input Cookie Value <input type=\"text\" name=\"cookievalue\" />\n");
      out.write("</form>\n");
      out.write("<input type=\"submit\" onClick=\"saveCookie('mycookie');\" value=\"Create Cookie\" /><br>\n");
      out.write("<input type=\"button\" onClick=\"readCookie('mycookie');\" value=\"Read Cookie\"/><br>\n");
      out.write("<input type=\"button\" onClick=\"clearCookie('mycookie');\" value=\"Clear Cookie\"/><br>\n");
      out.write("\n");
      out.write("</body>\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
