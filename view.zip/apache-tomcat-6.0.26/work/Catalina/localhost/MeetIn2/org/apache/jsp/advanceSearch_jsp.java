package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import com.verve.meetin.interest.Interestmaster;
import com.verve.meetin.friend.FriendsDAO;

public final class advanceSearch_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!doctype html>\n");
      out.write(" \n");
      out.write("<html lang=\"en\">\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<head>\n");
      out.write("  <meta charset=\"utf-8\" />\n");
      out.write(" <title>meetIn Advance Search, Advance People Search</title>\n");
      out.write("\n");
System.out.println("advancesearch page called *** * * * * * * * * "); 
      out.write("\n");
      out.write("\n");
      out.write(" <script type=\"text/javascript\" src=\"js/jquery-1.8.3.js\"></script>\n");
      out.write("  <script src=\"http://code.jquery.com/ui/1.10.0/jquery-ui.js\"></script>\n");
      out.write(" <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write(" <link rel=\"shortcut icon\" href=\"images/meetin_icon.png\" />\n");
      out.write("<link href=\"css/default.css\" rel=\"stylesheet\" type=\"text/css\" />\n");
      out.write("<script type=\"text/javascript\" src=\"http://maps.google.com/maps/api/js?sensor=false\"></script>\n");
      out.write("<link rel=\"stylesheet\" href=\"css/validationEngine.jquery.css\" type=\"text/css\" media=\"screen\" title=\"no title\" charset=\"utf-8\" />\n");
      out.write("<link rel=\"stylesheet\" href=\"css/template.css\" type=\"text/css\" media=\"screen\" title=\"no title\" charset=\"utf-8\" />\n");
      out.write("<link rel=\"stylesheet\" href=\"css/jquery-ui.css\" type=\"text/css\"  />\n");
      out.write("<link href=\"css/jquery.autocomplete.css\" rel=\"stylesheet\" type=\"text/css\"/>\n");
      out.write("<script type=\"text/javascript\" src=\"js/meetin.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.js\"></script>\n");
      out.write("<script src=\"js/jquery.min.js\" type=\"text/javascript\"></script>\n");
      out.write("<script src=\"js/jquery.validationEngine-en.js\" type=\"text/javascript\"></script>\n");
      out.write("<script src=\"js/jquery.validationEngine.js\" type=\"text/javascript\"></script>\n");
      out.write("<script src=\"js/jquery-ui.js\" type=\"text/javascript\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.autocomplete.js\"></script>\n");
      out.write("  <script>\n");
      out.write("  jQuery.noConflict();\n");
      out.write("  jQuery(document).ready(function() {\n");
      out.write("  \t\t\t\tjQuery(\"#frmsearch\").validationEngine({\n");
      out.write("\t\t\t\t\t  inlineValidation: false\n");
      out.write("\t\t\t\t\t})\n");
      out.write("\t\t\t\t\t \n");
      out.write("\t\t\t\t\tjQuery(\"#startDate\").datepicker({\n");
      out.write("\t\t          \tchangeMonth: true,\n");
      out.write("\t\t          \tchangeYear: true,\n");
      out.write("\t\t          \tdateFormat: 'M dd,yy',\n");
      out.write("\t\t          \tshowOn: \"button\",\n");
      out.write("\t\t          \tgotoCurrent: true,\n");
      out.write("\t\t          \tyearRange: '-50:+15',\n");
      out.write("\t\t          \tconstrainInput: false,\n");
      out.write("\t\t          \tduration: '',\n");
      out.write("\t\t\t\t\tbuttonImage: \"images/calendar.png\",\n");
      out.write("\t\t\t\t\tbuttonImageOnly: true,\n");
      out.write("\t\t          \tonSelect: function (){this.focus();},\n");
      out.write("\t\t          \t// Commented by Rupal dated on 24th april 2012 to solve date picker problem\n");
      out.write("\t\t          \tminDate:new Date()\n");
      out.write("\t\t          \t\n");
      out.write("\t\t        });\n");
      out.write("\t\t\t\t\tjQuery(\"#endDate\").datepicker({\n");
      out.write("\t\t          \tchangeMonth: true,\n");
      out.write("\t\t          \tchangeYear: true,\n");
      out.write("\t\t          \tdateFormat: 'M dd,yy',\n");
      out.write("\t\t          \tyearRange: '-50:+15',\n");
      out.write("\t\t          \tgotoCurrent: true,\n");
      out.write("\t\t          \tshowOn: \"button\",\n");
      out.write("\t\t\t\t\tbuttonImage: \"images/calendar.png\",\n");
      out.write("\t\t\t\t\tbuttonImageOnly: true,\n");
      out.write("\t\t          \tonSelect: function (){this.focus();},\n");
      out.write("\t\t          \tbeforeShow:function(){\n");
      out.write("\t\t          \tvar d=jQuery(\"#startDate\").datepicker('getDate');\n");
      out.write("                    if(d) return {minDate: d}\n");
      out.write("\t\t          \t},\n");
      out.write("\t\t          \t// Commented by Rupal dated on 24th april 2012 to solve datapicker problem\n");
      out.write("\t\t          \t/*minDate: new Date(),\n");
      out.write("\t\t          \t  maxDate:new Date(2020, 1 - 1, 31)*/\n");
      out.write("\t\t\t\t});\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t jQuery(\"#location\").autocomplete(\n");
      out.write("      \t\t\t \"state.do\",\n");
      out.write("      \t\t\t{\n");
      out.write("      \t\t\t\textraParams:{\"fill\":\"city\",\"param\":\"location\"},\n");
      out.write("  \t\t\t\t\tdelay:0, \n");
      out.write("  \t\t\t\t\tminChars:3,\n");
      out.write("  \t\t\t\t\tmatchSubset:1,\n");
      out.write("  \t\t\t\t\tmatchContains:1,\n");
      out.write("  \t\t\t\t\tcacheLength:10,\n");
      out.write("  \t\t\t\t\tmaxItemsToShow:10,\n");
      out.write("  \t\t\t\t\tautoFill:true\n");
      out.write("  \t\t\t\t}\n");
      out.write("    \t\t );\n");
      out.write("    \t\t \n");
      out.write("\t\t\t});\n");
      out.write("\t\t\t\n");
      out.write("\tfunction validateFields()\n");
      out.write("\t{\n");
      out.write("\t  var startDate = document.getElementById(\"startDate\").value;\n");
      out.write("\t  var endDate = document.getElementById(\"endDate\").value;\n");
      out.write("\t  var location =document.getElementById(\"location\").value;\n");
      out.write("\t  if(location == \"\")\n");
      out.write("\t  {\n");
      out.write("\t     alert(\"Please Enter Value for Location\");\n");
      out.write("\t     document.getElementById(\"location\").focus();\n");
      out.write("\t     return false;\n");
      out.write("\t  }\n");
      out.write("\t  if((startDate !=\"\" && endDate == \"\") || (startDate==\"\" && endDate !=\"\"))\n");
      out.write("\t  {\n");
      out.write("\t     alert(\"Please Select Both Date\");\n");
      out.write("\t     return false;\n");
      out.write("\t  } \n");
      out.write("\t  else\n");
      out.write("\t  {\n");
      out.write("\t  \tadvanceSearchResult();\n");
      out.write("\t  }\n");
      out.write("\t}\n");
      out.write("\t\n");
      out.write("\tfunction chkcontrol() \n");
      out.write("\t{\n");
      out.write("\t\n");
      out.write("\t\tvar total=0;\n");
      out.write("\t\tvar selectoption = document.getElementById(\"interest\");\n");
      out.write("\t\t\n");
      out.write("\t\tfor(var i=0; i < selectoption.length; i++)\n");
      out.write("\t\t{\n");
      out.write("\t\t\tif(selectoption[i].selected)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\ttotal =total +1;\n");
      out.write("\t\t\t}\n");
      out.write("\t\t\tif(total > 3)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\talert(\"Only three selection allowed\");\n");
      out.write("\t\t\t\tselectoption[i].selected = false;\n");
      out.write("\t\t\t\treturn false;\n");
      out.write("\t\t\t}\n");
      out.write("\t\t}\n");
      out.write("\t}\n");
      out.write("\t\n");
      out.write("  </script>\n");
      out.write("  \n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">var switchTo5x=true;</script>\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\tstLight.options({publisher: \"222fb8d2-36c2-4e83-85c1-f92516365e7c\", doNotHash: true, doNotCopy: true, hashAddressBar: true});\n");
      out.write("</script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/buttons.js\"></script>\n");
      out.write("\n");
      out.write("<meta property=\"og:title\" content=\"mymeetin\" /> \n");
      out.write("<meta property=\"og:url\" content=\"http://mymeetin.com\" /> \n");
      out.write("<meta property=\"og:image\" content=\"http://www.mymeetin.com/images/logo_small.png\" />\n");
      out.write("<meta property=\"og:description\" content=\"meet your friends from some of the most popular social networking sites\" /> \n");
      out.write("<meta property=\"og:site_name\" content=\"http://mymeetin.com\" /> \n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"js/nicEdit-latest.js\"></script> \n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("//<![CDATA[\n");
      out.write("bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });\n");
      out.write("//]]>\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\t\t\tfunction doAction() {\n");
      out.write("\t\t\t\tif ($('#flag').val() == 0) {\n");
      out.write("\t\t\t\t\t$('#sentmsg').text('');\n");
      out.write("\t\t\t\t\t$('#flag').val(1);\n");
      out.write("\t\t\t\t\t$('#frmsection').show();\n");
      out.write("\t\t\t\t\t$('#frmsection').animate({ marginLeft: '0px' }, 1000);\n");
      out.write("\t\t\t\t\t$('#PatientName').focus();\n");
      out.write("\t\t\t\t} else {\n");
      out.write("\t\t\t\t\t$('#flag').val(0);\n");
      out.write("\t\t\t\t\t$('#frmsection').animate({ marginLeft: '-320px' }, 1000);\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t}\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t</script>\n");
      out.write("\t\t\n");
      out.write("\t<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("\tfunction resetfields()\n");
      out.write("\t{\n");
      out.write("\t   document.getElementById(\"friendemail\").value =\"\";\n");
      out.write("\t   document.getElementById(\"friendemail\").focus();\n");
      out.write("\t}\n");
      out.write("\t</script>\t\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("function validate()\n");
      out.write("{\n");
      out.write("\talert(\"validate\");\n");
      out.write("}\n");
      out.write("\n");
      out.write("function ValidatefriendemailInvite()\n");
      out.write("{\n");
      out.write("\tvar array = document.getElementById(\"friendemail\").value;\n");
      out.write("\tvar arr = array.split(\",\");\n");
      out.write("\tif(arr.length > 10)\n");
      out.write("\t{\n");
      out.write("\t\talert(\"Maximum 10 friends can be invited at a time.\");\n");
      out.write("\t\treturn ;\n");
      out.write("\t}\n");
      out.write("\tfor(i=0;i<arr.length;i++)\n");
      out.write("\t{\n");
      out.write("\t\tvar atpos=arr[i].indexOf(\"@\");\n");
      out.write("\t\tvar dotpos=arr[i].lastIndexOf(\".\");\n");
      out.write("\t\tif (atpos<1 || dotpos<atpos+2 || dotpos+2>=arr[i].length)\n");
      out.write("  \t\t{\n");
      out.write("  \t\t\t\talert(\"Please enter valid email address\");\n");
      out.write("  \t\t\t\treturn;\n");
      out.write("  \t\t}\n");
      out.write("\t}\n");
      out.write("\tvar mail=document.getElementById(\"friendemail\").value;\n");
      out.write("\tvar msg =document.getElementById(\"invite\").innerHTML; \n");
      out.write("\tvar url = \"invitefriendPopup.jsp?mail=\"+ mail+\"&msg=\"+msg;\n");
      out.write("\tvar inviteFriends = getXmlHttpRequestObject();\n");
      out.write("\tif(inviteFriends.readyState == 4 || inviteFriends.readyState == 0){\n");
      out.write("\t\tinviteFriends.open(\"get\", url, true);\n");
      out.write("\t\tinviteFriends.onreadystatechange = function(){\n");
      out.write("\t\t\tif(inviteFriends.readyState == 4 && inviteFriends.status == 200){\n");
      out.write("\t\t\t\t//document.getElementById(\"loading\").style.display = 'none';\n");
      out.write("\t\t\t\t//document.getElementById(\"sentmsg\").style.display ='block';\n");
      out.write("\t\t\t\tdocument.getElementById(\"sentmsg\").innerHTML =inviteFriends.responseText;\n");
      out.write("\t\t\t\tdocument.getElementById(\"friendemail\").value=\"\";\n");
      out.write("\t\t\t}\n");
      out.write("\t\t}\n");
      out.write("\t\tinviteFriends.send(null);\n");
      out.write("\t}\n");
      out.write("\t\n");
      out.write("}\n");
      out.write("</script>\t\t\n");
      out.write("  \n");
      out.write("  \n");
      out.write("  \n");
      out.write("  \n");
      out.write("</head>\n");
      out.write("\n");
      out.write("<body onload=\"setDefaultFocus(document.getElementById('location'))\">\n");
      out.write("<div class=\"wrapper\">\n");
      out.write("\t<div class=\"mainsite\">\n");
      out.write("\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, false);
      out.write("\n");
      out.write("    \t<div class=\"leftside\">\n");
      out.write("    \t<a href=\"index.jsp\">\n");
      out.write("    \t<div class=\"logo\"></div></a>\n");
      out.write("        \t<div class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("                  \t\t<div class=\"buttoncontainer\">\n");
      out.write("                        \t<div><img src=\"images/location_xsmall.png\"/><input id=\"peoplenearmebtn\" type=\"button\" onclick=\"peopleFinder();\" class=\"iphonebutton\" value=\"People Near Me\"/></a></div>\n");
      out.write("                       \t    <div><img src=\"images/upcomingtrip_icon.png\"/><input id=\"upcommingtripbtn\" type=\"button\" onclick=\"people_upCommingTrip();\" class=\"iphonebutton\" value=\"On Upcoming Trip\"/></div>\n");
      out.write("                            <input type=\"hidden\" name=\"action\" value=\"upCommingTrip\" />\n");
      out.write("                            <div><img src=\"images/search_icon.png\"/><a href=\"peoplefinder.do?action=advancesearch\">\n");
      out.write("                            <input id=\"advancesearchbtn\" type=\"button\" class=\"iphonebutton active\" value=\"Advance Search\"/></a></div>\n");
      out.write("                        </div>\n");
      out.write("               \t\t  \t<img id=\"screen1\" src=\"images/proplefinder_bg.png\" />\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\n");
      out.write("            </div>\n");
      out.write("             <div class=\"appstore\" style=\"margin-left: 12px;\"><a href=\"https://itunes.apple.com/us/app/meetin/id590629564?ls=1&mt=8\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-iphone.png\" style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-midtext.png\" style=\"float: left\"/> </a><a href=\"https://play.google.com/store/apps/details?id=com.meetin&feature=search_result#?t=W251bGwsMSwyLDEsImNvbS5tZWV0aW4iXQ..\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-androide.png\" style=\"float: left\"/>  </div></a> \n");
      out.write("\n");
      out.write("            <a href=\"how_it_works.jsp\"><div class=\"appvideo\"><img id=\"appvideo\" src=\"images/appvideo_new.png\" /></div></a>\n");
      out.write("\n");
      out.write("            <div class=\"followus\">\n");
      out.write("            \tFollow Us on:\n");
      out.write("                <div class=\"socialnetwork\">\n");
      out.write("                   <a href=\"javascript:void(0)\" onclick=\"window.open('https://www.facebook.com/pages/MeetIn/495222843824206', '_blank')\">\n");
      out.write("                <div class=\"facebook\"></div></a>\n");
      out.write("                 <a href=\"javascript:void(0)\" onclick=\"window.open('https://twitter.com/mymeetIn', '_blank')\"><div class=\"twitter\"></div></a>\n");
      out.write("                  <a href=\"javascript:void(0)\" onclick=\"window.open('https://plus.google.com/b/108083242642551656394/?partnerid=gplp0', '_blank')\">\n");
      out.write("                 <div class=\"google_plus\"></div></a>\n");
      out.write("                </div>\n");
      out.write("            </div>\n");
      out.write("        </div>\n");
      out.write("        \n");
      out.write("        <div class=\"rightside\">\n");
      out.write("        \t<div id=\"navigation\">\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn active\"><a href=\"peoplefinder.do?action=people\"><span>People Finder</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"addtrip.jsp\"><span>My Travel Plan</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"friend.do?fparam=myfriends\"><span>My Friends</span>\n");
      out.write("                \n");
      out.write("                ");

                	// Code done for showing friend request pending in menu tab
                	
                	int id = Integer.parseInt(session.getAttribute("UserID").toString());
                	
                	Long p = new FriendsDAO().getUserPendingRequestCount(id);
                	
               	            
                if(p != null || p > 0){
                	
                	
                	if(p>0 &&  p<10)
                	{
                	
                
      out.write("\n");
      out.write("                            <span class=\"fr_request\">\n");
      out.write("                            <strong>");
      out.print(p);
      out.write("</strong></span>\n");
      out.write("                            \n");
      out.write("                     ");
}
                           
                   	 if(p >9)  {
      out.write("\n");
      out.write("                                <span class=\"fr_request\">\n");
      out.write("                            <strong>9+</strong></span>\n");
      out.write("                      ");
} } 
      out.write("\n");
      out.write("                \n");
      out.write("                </a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"myprofile.jsp?action=profilevisitors\"><span>My Profile</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"contact.jsp\"><span>Contact Us</span></a></div>                \n");
      out.write("        \t</div>\n");
      out.write("        \t<!-- Ajax loader content start here -->\n");
      out.write("  \t\t\t\t<!--<div id=\"loading\" style=\"width: 100%;height: 100%;top:0;left: 0;position: fixed;display: none;opacity:0.7;z-index: 99;text-align: center;\">\n");
      out.write("  \t\t\t\t<img src=\"images/ajax-loader_new.gif\" alt=\"Loading....\" style=\"position: absolute;top: 260px;left: 650px;z-index: 100;\" />\n");
      out.write("  \t\t\t\t</div>\n");
      out.write("  \t\t\t\t-->\n");
      out.write("  \t\t\t\t<div id=\"loading\" style=\"width: 100%;height: 100%;top:0;left: 0;position: fixed;display: none;opacity:0.7;z-index: 99;text-align: center; background-color: #000000; \"><!--\n");
      out.write("  \t\t\t\t<img src=\"images/ajax-loader_new.gif\" alt=\"Loading....\" style=\"position: absolute;top: 260px;left: 650px;z-index: 100;\" />\n");
      out.write("  \t\t\t\t-->\n");
      out.write("  \t\t\t\t<div style=\"border: 2px solid #FFFFFF; left: 650px; position: absolute; background-color: #FFFFFF; top: 170px; padding: 10px; width: 150px; color: #000000;\"> \n");
      out.write("\t\t\t\t\t<p><img vspace=\"5\" src=\"images/ajax-loader_new.gif\" alt=\"Loading....\" style=\"z-index: 100;\"></p> \n");
      out.write("\t\t\t\t\t<p> Taking too long ? </p>\n");
      out.write("\t\t\t\t\t<br> \n");
      out.write("\t\t\t\t\t<p>\n");
      out.write("\t\t\t\t\t<a href=\"myprofile.jsp?action=profilevisitors\" >Cancel</a> \n");
      out.write("\t\t\t\t\t</p> \n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t\n");
      out.write("  \t\t\t\t</div>\n");
      out.write("  \t\t\t\t<!-- Ajax loader content end here -->\n");
      out.write("\t\t\t<div id=\"upcommingtrip\" style=\"display: none;\"></div>\n");
      out.write("\t\t\t<div id=\"advancesearch\" style=\"display: none;\"></div>\n");
      out.write("            <div style=\"overflow:hidden; height:auto\" id=\"content\">\n");
      out.write("\t\t\t    <div class=\"innercontainer\" id=\"searchform\">\n");
      out.write("\t\t\t    \n");
      out.write("\t\t\t    <div class=\"question-icon\" style=\"clear:both;overflow:hidden ;font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\">\n");
      out.write("\t\t\t\t\t\t<p style=\"float: right;\"><a href=\"javascript:Questionfnc('Advance Search')\">\n");
      out.write("\t\t\t<img src=\"images/icon-question.png\" alt=\"\" style=\"height: 24px;\" />\n");
      out.write("\t\t\t\t\t\t </a></p> </div>\n");
      out.write("\t\t\t    \n");
      out.write("\t\t\t       \t<div class=\"heading\" style=\"height: auto; margin-top: 30px;overflow: hidden;\">\n");
      out.write("\t\t\t       \t\t<img src=\"images/adv_search.png\" align=\"absbottom\"/> Advance Search\n");
      out.write("\t\t\t       \t\t<div class=\"found\" style=\"font-size: 12px;\">Specifing date range and/or interest will only generate meetIn friends</div>\n");
      out.write("\t\t\t    \t</div>\n");
      out.write("\t\t\t    \t<form id=\"frmsearch\" name=\"frmsearch\" method=\"post\" action=\"\">\n");
      out.write("\t\t\t    \t\t<input type=\"hidden\" name=\"action\" value=\"advanceSearchResult\"/>\n");
      out.write("\t\t\t\t\t    <div class=\"generalfrm\">\n");
      out.write("\t\t\t\t\t        <div class=\"lable\">Location</div>\n");
      out.write("\t\t\t\t\t        <input id=\"location\" type=\"text\" name=\"location\" value=\"\" styleClass=\"validate[required]\"/>\n");
      out.write("\t\t\t\t\t        <div class=\"frmline\"></div>\n");
      out.write("\t\t\t\t\t        <div class=\"lable\">From Date</div>\n");
      out.write("\t\t\t\t\t        <input type=\"text\" name=\"startDate\" id=\"startDate\" readonly=\"true\"  />\n");
      out.write("\t\t\t\t            <div class=\"frmline\"></div>\n");
      out.write("\t\t\t\t            <div class=\"lable\">To Date</div>\n");
      out.write("\t\t\t\t            <input type=\"text\" name=\"endDate\" id=\"endDate\" readonly=\"true\" />\n");
      out.write("\t\t\t\t\t        <div class=\"frmline\"></div>\n");
      out.write("\t\t\t\t\t         ");

					           if(request.getAttribute("interestList") !=null)
					           {
					              List interestList = (ArrayList)request.getAttribute("interestList");
					              
					              if(interestList !=null && interestList.size() >0)
					              {
					         
      out.write("\n");
      out.write("\t\t\t\t\t        <div class=\"lable\">Interest</div>\n");
      out.write("\t\t\t\t\t        <select multiple=\"multiple\" id=\"interest\" name=\"interest\" size=\"6\" onchange=\"chkcontrol();\" scrolling=\"no\">\n");
      out.write("\t\t\t\t\t         ");

					             for(int i=0; i < interestList.size(); i++){
                                   Interestmaster interest = new Interestmaster();
                                   interest = (Interestmaster)interestList.get(i);
					         
      out.write("\n");
      out.write("\t\t\t\t\t        \t<option value=\"");
      out.print(interest.getInterestId() );
      out.write("\" />");
      out.print(interest.getName() );
      out.write("</option>\n");
      out.write("\t\t\t\t\t         ");

					        		}
					         
      out.write("\n");
      out.write("\t\t\t\t\t        </select>\n");
      out.write("\t\t\t\t            ");

				            	  }
				            	}
				            
      out.write("\n");
      out.write("\t\t\t\t\t    </div>\n");
      out.write("\t\t\t\t\t    <div class=\"logonsection\">\n");
      out.write("\t\t\t\t\t    \t<input id=\"searchPeople\"  type=\"button\" onclick=\"advanceSearchResult();\" class=\"buttonorg\" value=\"Search People\"/>\n");
      out.write("\t\t\t\t\t    </div>\n");
      out.write("\t\t\t\t    </form>\n");
      out.write("\t\t\t\t    <br/><br/><br/><br/>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t<!-- The below Div tag will display the search result with the use of Ajax functionality -->\n");
      out.write("\t\t\t\t   <div id=\"searchList\" style=\"display: none\"></div>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t <!--  Showing Google Map -->\n");
      out.write("         \t\t\t<div id=\"map\" class=\"rightside\" style=\"display:none\">\n");
      out.write("\t           \t\t\t <div class=\"googlemap\" style=\"margin: 35px 0pt 20px 60px;\">\n");
      out.write("\t                 \t <div id=\"map_canvas\" style=\"width: 480px; height: 239px;\"></div>\n");
      out.write("\t            \t\t</div>\n");
      out.write("         \t\t \t</div>\n");
      out.write("         \t\t \t\n");
      out.write("         \t<!-- These two divs are used to show lightbox popup for user profile details -->\n");
      out.write("\t\t\t<!-- Start Div -->\n");
      out.write("\t\t\t\t<div id=\"light\" class=\"white_content\"></div>\n");
      out.write("\t\t\t\t<div id=\"fade\" class=\"black_overlay\"></div>\n");
      out.write("\t\t\t<!-- End Div -->\n");
      out.write("        </div>\n");
      out.write("    </div><!--mainsite starts here -->\n");
      out.write("    \n");
      out.write("    \n");
      out.write("    <!-- div for invite friends -->\n");
      out.write("    \n");
      out.write("    ");
if( session.getAttribute("name") != null )
    {    
    
      out.write("\n");
      out.write("    \n");
      out.write("    <div class=\"popup-slide\">\n");
      out.write("            <div id=\"frmsection\">\n");
      out.write("                \n");
      out.write("                ");
      //  html:form
      org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f0 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_005fform_005f0.setPageContext(_jspx_page_context);
      _jspx_th_html_005fform_005f0.setParent(null);
      // /advanceSearch.jsp(414,16) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setAction("/friend");
      // /advanceSearch.jsp(414,16) name = method type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setMethod("get");
      // /advanceSearch.jsp(414,16) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setStyleId("frminvitefriend");
      // /advanceSearch.jsp(414,16) name = onsubmit type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setOnsubmit("return Validatefriendemail();");
      int _jspx_eval_html_005fform_005f0 = _jspx_th_html_005fform_005f0.doStartTag();
      if (_jspx_eval_html_005fform_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\n");
          out.write("                     <input type=\"hidden\" name=\"fparam\" value=\"invitefriend\" />    \n");
          out.write("                \n");
          out.write("            <div>    \n");
          out.write("            <div id=\"sentmsg\" style=\"color: green;font-size: 13px;float: right;\">\n");
          out.write("            \n");
          out.write("            </div>\n");
          out.write("                <div class=\"lable\">Friend's Email</div>\n");
          out.write("                <div>\n");
          out.write("                            ");
          if (_jspx_meth_html_005ftext_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                </div>\n");
          out.write("                \n");
          out.write("                <div>\n");
          out.write("                <span class='st_sharethis_large' displayText='ShareThis'></span>\n");
          out.write("                </div>\n");
          out.write("                \n");
          out.write("            </div>\n");
          out.write("            <div>\n");
          out.write("                            \n");
          out.write("                            <div class=\"lable\">Invite Message</div>\n");
          out.write("                \n");
          out.write("                <textarea  id=\"invitemessage\" name=\"invitemessage\" rows=\"3\" cols=\"10\" >\n");
          out.write("                <div id=\"invite\">\n");
          out.write("                <p>\n");
          out.write(" ");
          out.print(session.getAttribute("name") );
          out.write(" would like to invite you to use meetIn (<a href=\"http://www.mymeetin.com\">www.mymeetin.com</a>) to keep in touch with your friends, family, colleagues while you or they are traveling.\n");
          out.write("</p>\n");
          out.write("<p><br/>\n");
          out.write("meetIn connects to some of the most popular social networking sites and gets you updated information even when you are traveling, or at home or when your friends are traveling to tell you when you are at the same place and can meet.\n");
          out.write("</p>\n");
          out.write("<p><br/>\n");
          out.write("meetIn is also available now on iPhone and Android.\n");
          out.write("</p>\n");
          out.write("<p><br/>\n");
          out.write("Register now and meet me on meetIn.\n");
          out.write("</p>\n");
          out.write(" </div>\n");
          out.write("</textarea>\n");
          out.write("                \n");
          out.write("</div>                  \n");
          out.write("    <p align=\"right\" style=\"font-size: 12px; margin-bottom: 5    px; margin-top: 10px;\">\n");
          out.write("                                Invite friends separated by comma\n");
          out.write("    </p>          \n");
          out.write("    \n");
          out.write("    <div>\n");
          out.write("     \n");
          out.write("     \n");
          out.write("     <input type=\"button\" value=\"Invite\" onclick=\"ValidatefriendemailInvite();\"/>\n");
          out.write("                        <input type=\"button\"  value=\"Clear\" onclick=\"resetfields();\" />                    \n");
          out.write("    </div>                \n");
          out.write("                ");
          int evalDoAfterBody = _jspx_th_html_005fform_005f0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_005fform_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
        return;
      }
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
      out.write("\n");
      out.write("                    \n");
      out.write("            </div>\n");
      out.write("            <input id=\"flag\" type=\"hidden\" value=\"0\">\n");
      out.write("            <input type=\"button\" name=\"action\" id=\"say\" onclick=\"doAction()\" class=\"popup-slide-btn\">\n");
      out.write("        </div>\n");
      out.write("    ");
} 
      out.write("\n");
      out.write("    \n");
      out.write("    \n");
      out.write("<!-- Invite friend div end here  -->\n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("    <div class=\"footer\">\n");
      out.write("    \t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, false);
      out.write("\n");
      out.write("    </div><!--footer ends here -->\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("</body>\n");
      out.write("</html>\n");
      out.write("\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_html_005ftext_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f0 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /advanceSearch.jsp(423,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setProperty("friendemail");
    // /advanceSearch.jsp(423,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleId("friendemail");
    // /advanceSearch.jsp(423,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleClass("text-input");
    int _jspx_eval_html_005ftext_005f0 = _jspx_th_html_005ftext_005f0.doStartTag();
    if (_jspx_th_html_005ftext_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
    return false;
  }
}
