package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.List;
import com.verve.meetin.trip.Trips;
import java.text.SimpleDateFormat;
import java.net.URLEncoder;
import com.verve.meetin.trip.TripsDAO;
import sun.misc.BASE64Encoder;

public final class header_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

//System.out.println("/header. p");

		if(request.getParameter("event")==null)
		{
	 
      out.write("\n");
      out.write("\t\t<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">  \n");
      out.write(" \t\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/meetin.js\"></script>\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write(" \n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\t    function showMore(e) \n");
      out.write("\t    {\n");
      out.write("\t    \tvar tg = (window.event) ? e.srcElement : e.target;\n");
      out.write("\t        if(getCookie(\"show\") == \"True\" && tg.nodeName == \"A\" && document.getElementById(\"dropdown_menu\").style.display == \"none\")\n");
      out.write("\t        {\n");
      out.write("\t            document.getElementById(\"dropdown_menu\").style.display=\"block\";\n");
      out.write("\t        }\n");
      out.write("\t        else\n");
      out.write("\t        {\n");
      out.write("\t            document.getElementById(\"dropdown_menu\").style.display=\"none\";\n");
      out.write("\t        }\n");
      out.write("    \t}\n");
      out.write("    \t/*function showLocationToolTip(e, loc)\n");
      out.write("    \t{\n");
      out.write("    \t\tX=(e||event).clientX;\n");
      out.write("\t\t\tY=(e||event).clientY;\n");
      out.write("    \t\tdocument.getElementById(\"location\").style.display = \"block\";\n");
      out.write("    \t\tdocument.getElementById(\"location\").style.top=X;\n");
      out.write("\t        document.getElementById(\"location\").style.left=Y;\n");
      out.write("\t        document.getElementById(\"location\").innerHTML = loc;\n");
      out.write("    \t}\n");
      out.write("    \tfunction hideLocationToolTip()\n");
      out.write("    \t{\n");
      out.write("    \t\tdocument.getElementById(\"location\").style.display = \"none\";\n");
      out.write("    \t}*/\n");
      out.write("\t</script>\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("jQuery.noConflict();\n");
      out.write("jQuery(document).ready(function() {\n");
      out.write("\t//Select all anchor tag with rel set to tooltip\n");
      out.write("\tjQuery('a[rel=tooltip]').mouseover(function(e) {\n");
      out.write("\t\t\n");
      out.write("\t\t//Grab the title attribute's value and assign it to a variable\n");
      out.write("\t\tvar tip = jQuery(this).attr('title');\t\n");
      out.write("\t\t\n");
      out.write("\t\t//Remove the title attribute's to avoid the native tooltip from the browser\n");
      out.write("\t\tjQuery(this).attr('title','');\n");
      out.write("\t\t\n");
      out.write("\t\t//Append the tooltip template and its value\n");
      out.write("\t\tjQuery(this).append('<div id=\"tooltip\"><div class=\"tipHeader\"></div><div class=\"tipBody\">' + tip + '</div><div class=\"tipFooter\"></div></div>');\t\t\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t//Show the tooltip with faceIn effect\n");
      out.write("\t\tjQuery('#tooltip').fadeIn('500');\n");
      out.write("\t\tjQuery('#tooltip').fadeTo('10',0.9);\n");
      out.write("\t\t\n");
      out.write("\t}).mousemove(function(e) {\n");
      out.write("\t\t//Keep changing the X and Y axis for the tooltip, thus, the tooltip move along with the mouse\n");
      out.write("\t\tjQuery('#tooltip').css('top', e.pageY);\n");
      out.write("\t\tjQuery('#tooltip').css('left', e.pageX-200);\n");
      out.write("\t\t\n");
      out.write("\t}).mouseout(function() {\n");
      out.write("\t\n");
      out.write("\t\t//Put back the title attribute's value\n");
      out.write("\t\tjQuery(this).attr('title',jQuery('.tipBody').html());\n");
      out.write("\t\n");
      out.write("\t\t//Remove the appended tooltip template\n");
      out.write("\t\tjQuery(this).children('div#tooltip').remove();\n");
      out.write("\t});\n");
      out.write("});\n");
      out.write("\n");
      out.write("// Created by Rupal Kathiriya to remove cookie from browser while clicking logout- dated on 6th august 2012\n");
      out.write("/*function clearCookie(name) {\n");
      out.write("\tvar date=new Date();\n");
      out.write("\tdate.setDate(date.getDate()-1);\n");
      out.write("\tdocument.cookie = name+ \"=''; expires=\" + date + \"; path=/\";\n");
      out.write("}*/\n");
      out.write("</script>\n");
      out.write("<style>\n");
      out.write("\n");
      out.write("/* Tooltip */\n");
      out.write("\n");
      out.write("a:hover {color:#000;text-decoration:none;}\n");
      out.write(".clear {clear:both}\n");
      out.write("#tooltip {\n");
      out.write("\tposition:absolute;\n");
      out.write("\tz-index:2;\n");
      out.write("\tcolor:#fff;\n");
      out.write("\tfont-size:12px;\n");
      out.write("\twidth:180px;\n");
      out.write("}\n");
      out.write("</style>\n");
      out.write("\t<div style=\"width: 965px;height: auto; margin-bottom: 9px;\" align=\"right\" class=\"username\">\n");
      out.write("    \t<p><strong><img alt=\"\" src=\"images/user.png\"><a href=\"myprofile.jsp?action=aboutme\">");
if(session.getAttribute("name") !=null){
      out.print(session.getAttribute("name") );
} 
      out.write("</a> </strong> \n");
      out.write("    \t<a style=\"text-decoration: none !important;\" href=\"javascript:void(0);\" onclick=\"scrollTo(0,0); viewUserProfile('profile_page.jsp?id='+");
      out.print(session.getAttribute("UserID").toString() );
      out.write(");\"\n");
      out.write("\t\t\ttitle=\"View Profile\"><img src=\"images/view_icon.png\" style=\"vertical-align:text-bottom;\" height=\"17px;\"  border=\"none\" /> </a>&nbsp;\n");
      out.write("    \t");
int h_start =0;
        	int h_end = 2;
        	List trip_list=null;
    	if(session.getAttribute("UserID")!=null)
    	{
    		trip_list = new TripsDAO().getCurrentTripLocation(Integer.valueOf(session.getAttribute("UserID").toString()));
    		session.setAttribute("trip_list", trip_list);
    		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
    		if(trip_list !=null && trip_list.size() > 0)
    		{
    			Trips trip1 = (Trips)trip_list.get(0);
    	
      out.write("\n");
      out.write("    \t<img alt=\"Add Trip\" src=\"images/go_trip.png\">&nbsp;Visiting\n");
      out.write("    \t <a rel=\"tooltip\" title=\"");
      out.print(trip1.getDestination() );
      out.write("\" href=\"javascript:void();\" onclick=\"getEditTripDetail('");
      out.print(new BASE64Encoder().encode(trip1.getTripId().toString().getBytes()));
      out.write("', 'edit')\"><script>\n");
      out.write("var loc ='");
      out.print(trip1.getDestination() );
      out.write("'; loc1 = loc.split(\",\")[0]; \n");
      out.write("    \tif(loc1.length > 10) { loc1 = loc1.substring(0,10) + \"..\";} document.write(loc1);</script></a>,\n");
      out.write("    \t<a href=\"#\" onclick=\"setCookie('show', 'True', 1); showMore(event); return false;\">");
if(trip_list.size() > 1) {
      out.write("more (");
      out.print(trip_list.size()-1);
      out.write(')');
} 
      out.write("</a>&nbsp;<a href=\"addtrip.jsp\">Add Trip</a>\n");
      out.write("    \t");
	} 
            else { 
      out.write("\n");
      out.write("            \t<img alt=\"Add Trip\" src=\"images/go_trip.png\">&nbsp;No Upcoming Trips, &nbsp;<a href=\"addtrip.jsp\">Add Trip</a>\n");
      out.write("           ");
} 
      out.write("\n");
      out.write("    \t&nbsp;<img alt=\"\" src=\"images/home.png\">Lives in  <a rel=\"tooltip\" title=\"\n");
      out.write("    \t");
      out.print(session.getAttribute("default_location") );
      out.write("\" href=\"locationedit.do?action=location_edit\">\n");
      out.write("    \t");
if(session.getAttribute("default_location") !=null)
    	{
      out.write("<script>var loc = '");
      out.print(session.getAttribute("default_location") );
      out.write("'; loc1 = loc.split(\",\")[0]; if(loc1.length > 10) { loc1 = loc1.substring(0,10) + \"..\";} document.write(loc1);</script>");
} 
      out.write("</a>\n");
      out.write("    \t&nbsp; <img alt=\"Add Trip\" src=\"images/logout.png\">\n");
      out.write("    \t<a href=\"login.do?action=signout\" onclick=\"clearCookie('mycookie');\">Logout</a>\n");
      out.write("    <p></p>\n");
      out.write("       <div class=\"popupmsg\" style=\"width:35%; display: none;margin-left: 350px;\" id=\"dropdown_menu\">\n");
      out.write("       <div class=\"popupheading\">\n");
      out.write("       <div class=\"title\">Travel Plan</div>\n");
      out.write("             <div class=\"close\"><img src=\"images/close.png\" onclick=\"setCookie('show','False', 1); showMore(event);\" /></div>\n");
      out.write("       </div>\n");
      out.write("        \t");

        	session.setAttribute("h_start", "0");
			 if(trip_list.size() < 5)
			 {
			     session.setAttribute("h_end", trip_list.size());
                 h_end = trip_list.size();
             }
			 else
			 {
			     session.setAttribute("h_end", 5);
                 h_end = 5;
             }	
        	for(int i=h_start; i<h_end; i++) { 
      out.write("\n");
      out.write("            \t");

            		Trips trip = (Trips)trip_list.get(i);
            		String str=trip.getDestination();
                    	if(str.length()>25){
                     		String newstr=str.substring(0,21).concat("...");
                   	}
	           	
      out.write("\n");
      out.write("\t           \t<div class=\"row\">\n");
      out.write("                \t<div class=\"col\" style=\"width:45%\">");
 if(trip.getDestination().trim().length()>25){
      out.print(str.substring(0,21).concat("..."));
}else{
      out.print(trip.getDestination() );
} 
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:20%\">");
      out.print(sdf.format(trip.getFromDate()) );
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:20%\">");
      out.print(sdf.format(trip.getToDate()) );
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:13%\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0)\" onclick=\"getEditTripDetail('");
      out.print(new BASE64Encoder().encode(trip.getTripId().toString().getBytes()));
      out.write("', 'edit')\"><img src=\"images/edit_trip_icon.png\"/></a></div>\n");
      out.write("         \t\t</div>\n");
      out.write("       ");

            }
        }
       
      out.write(" \n");
      out.write("       <div class=\"row\">\n");
      out.write("       <div style=\"float:right\">\n");
      out.write("       \t\t\t\t");
 if(h_start > 0) {
      out.write("\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"first\" class=\"first\" onclick=\"navigation_header('first', '');\" title=\"First\" />\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"prev\" onclick=\"navigation_header('prev','');\" title=\"Previous\" class=\"previous\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"input\" disabled=\"disabled\"  name=\"first\" class=\"first_disable\"   />\n");
      out.write("\t\t            <input type=\"input\" disabled=\"disabled\"  name=\"prev\" class=\"previous_disable\" />\n");
      out.write("\t\t       \t\t");
} 
      out.write("\n");
      out.write("\t\t       \t\t<div class=\"inputcontainer\">\n");
      out.write("\t\t            <div class=\"inputleft\"></div>\n");
      out.write("\t\t            <div class=\"inputrepeat\">\n");
      out.write("\t\t           \t\t<select id=\"pagi_combo1\" name=\"pagi_combo\" class=\"select\" style=\"width: 100px;\" onchange=\"navigation_header('pagi_combo','se');\">\n");
      out.write("\t\t           \t\t\t");
for(int i=0; i<trip_list.size(); i+=5){
		           			
		           				int j = i + 5; 
		           				if(j > trip_list.size())
		           				
		           					j = trip_list.size();
		           			
      out.write("\n");
      out.write("\t\t           \t\t\t\t<option ");
 String sel = h_start+"-"+h_end; if(sel.equals(i+"-"+j)){ 
      out.write(" selected=\"selected\" ");
} 
      out.write(" value=\"");
      out.print(i );
      out.write('-');
      out.print(j );
      out.write('"');
      out.write('>');
      out.print(i+1 );
      out.write(' ');
      out.write('-');
      out.write(' ');
      out.print(j );
      out.write("</option>\n");
      out.write("\t\t           \t\t\t");
} 
      out.write("\n");
      out.write("\t\t           \t\t</select>\n");
      out.write("\t\t           \t</div>\n");
      out.write("\t\t           \t<div class=\"inputright\"></div>\n");
      out.write("\t\t               <div class=\"number\" style=\"padding: 0 0 0 5px;\"> of ");
      out.print(trip_list.size() );
      out.write(" </div>\n");
      out.write("\t\t \t\t\t</div>\n");
      out.write("\t\t       \t\t");
 if(h_end < trip_list.size()) { 
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" onclick=\"navigation_header('next','');\" class=\"next\" title=\"Next\" />\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"last\" onclick=\"navigation_header('last','');\" class=\"last\" title=\"Last\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" class=\"next_disable\" disabled=\"disabled\"/>\n");
      out.write("\t\t            <input type=\"button\" name=\"last\" class=\"last_disable\" disabled=\"disabled\" />\n");
      out.write("\t\t      \t\t");
} 
      out.write("\n");
      out.write("       </div></div>\n");
      out.write("       </div>\n");
      out.write("    </div>\n");
} else {
      out.write("\n");
      out.write(" \t<div class=\"popupheading\">\n");
      out.write("          <div class=\"title\">Travel Plan</div>\n");
      out.write("             <div class=\"close\"><img src=\"images/close.png\" onclick=\"setCookie('show', 'False', 1); showMore(event);\" /></div>\n");
      out.write("       </div>\n");
      out.write("\t    \t");

        	int h_start = 0;
        	int h_end = 0;
        	List trip_list = new TripsDAO().getCurrentTripLocation(Integer.valueOf(session.getAttribute("UserID").toString()));
        	h_start = Integer.parseInt(session.getAttribute("h_start").toString());
        	h_end = Integer.parseInt(session.getAttribute("h_end").toString());
           	if(request.getParameter("event") != null && request.getParameter("event").equals("next"))
            {
             	
                  session.setAttribute("h_start", String.valueOf(h_end));
                  h_start = h_end;
                  if(trip_list.size() < 5)
                  {
                          session.setAttribute("h_end", String.valueOf(trip_list.size()));
                          h_end = trip_list.size();
                  }
                  else if((h_end+5) < trip_list.size())
                  { 
                   	
                          session.setAttribute("h_end", String.valueOf(h_end+5));
                          h_end = h_end + 5;
                  }
                  else if((h_end+5) > trip_list.size())
                  {
                   
                          session.setAttribute("h_end", String.valueOf(h_end + (trip_list.size() - h_end)));
                          h_end = h_end + (trip_list.size() - h_end);
                  }
                  else if((h_end+5) >= trip_list.size())
                  {
                   	
                          session.setAttribute("h_end", String.valueOf(h_end + (trip_list.size() - h_end)));
                          h_end = trip_list.size();
                  }else{
                  
                  	h_end = trip_list.size();
            		if(trip_list.size() < 5)
            		h_start = 0;
            	else
            	{
            		h_start = (trip_list.size() / 5) * 5;
            		if(h_start == trip_list.size())
            			h_start = h_start - 5;
            		
            	} 
            	session.setAttribute("h_end", h_end);
            	session.setAttribute("h_start", h_start);
            	}
                  
            }
            else if(request.getParameter("event") != null && request.getParameter("event").equals("prev"))
            {
             	
                  if(h_start >= 5)
                  {
                
                          session.setAttribute("h_start", String.valueOf(h_start-5));
                          h_start = h_start - 5;
                  }
                  else if(h_start < 5)
                  {
                
                          session.setAttribute("h_start", String.valueOf(h_start-h_start));
                          h_start = h_start - h_start;
                  }
                  session.setAttribute("h_end", String.valueOf(h_start+5));
                  h_end = h_start + 5;
                
            }
            else if(request.getParameter("event") != null && request.getParameter("event").equals("first")) 
            {
             
            	h_start = 0;
            	if(trip_list.size() < 5)
            	 	
            		h_end = trip_list.size();
            	else
            		h_end = 5;
            	session.setAttribute("h_end", h_end);
            	session.setAttribute("h_start", h_start);
            }
            else if(request.getParameter("event") != null && request.getParameter("event").equals("last")) 
            {
             	h_end = trip_list.size();
            
            	if(trip_list.size() < 5)
            		h_start = 0;
            	else
            	{
            		h_start = (trip_list.size() / 5) * 5;
            
            		if(h_start == trip_list.size())
            			h_start = h_start - 5;
            
            	} 
            	session.setAttribute("h_end", h_end);
            	session.setAttribute("h_start", h_start);
            }
            else if(request.getParameter("event") != null && request.getParameter("event").equals("pagi_combo"))
            {
             	
                String[] s = request.getParameter("pagi_combo").split("-");
                h_start = Integer.parseInt(s[0]);
                h_end = Integer.parseInt(s[1]);
                session.setAttribute("h_end", h_end);
		    	session.setAttribute("h_start", h_start);
            }
             // End Navigation
        	SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy");
        	for(int i=h_start; i<h_end; i++) { 
      out.write("\n");
      out.write("            \t");

            		Trips trip=null;
            		try{
            			trip=(Trips)trip_list.get(i);
            		}catch(Exception e){
            			e.printStackTrace();
            			continue;
            		}
            		String str=trip.getDestination();
                                    	if(str.length()>25)
                                    	{
                                    	   String newstr=str.substring(0,21).concat("...");
                                    	   
                                    	}
	           	
      out.write("\n");
      out.write("\t           \t<div class=\"row\">\n");
      out.write("                \t<div class=\"col\" style=\"width:45%\">");
 if(trip.getDestination().trim().length()>25){
      out.print(str.substring(0,21).concat("..."));
}else{
      out.print(trip.getDestination() );
} 
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:20%\">");
      out.print(sdf.format(trip.getFromDate()) );
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:20%\">");
      out.print(sdf.format(trip.getToDate()) );
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:13%\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0)\" onclick=\"getEditTripDetail('");
      out.print(new BASE64Encoder().encode(trip.getTripId().toString().getBytes()));
      out.write("', 'edit')\"> <img src=\"images/edit_trip_icon.png\"/></a></div>\n");
      out.write("         \t\t</div>\n");
      out.write("       ");

            }
            
      out.write("<div class=\"row\">\n");
      out.write("            <div style=\"float:right\">\n");
      out.write("            \t\t");
 if(h_start > 0) {
      out.write("\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"first\" class=\"first\" onclick=\"navigation_header('first', '');\" title=\"First\" />\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"prev\" onclick=\"navigation_header('prev', '');\" title=\"Previous\" class=\"previous\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"input\" disabled=\"disabled\"  name=\"first\" class=\"first_disable\"   />\n");
      out.write("\t\t            <input type=\"input\" disabled=\"disabled\"  name=\"prev\" class=\"previous_disable\" />\n");
      out.write("\t\t       \t\t");
} 
      out.write("\n");
      out.write("\t\t       \t\t<div class=\"inputcontainer\">\n");
      out.write("\t\t            <div class=\"inputleft\"></div>\n");
      out.write("\t\t            <div class=\"inputrepeat\">\n");
      out.write("\t\t           \t\t<select id=\"pagi_combo1\" name=\"pagi_combo\" class=\"select\" style=\"width: 100px;\" onchange=\"navigation_header('pagi_combo','se');\">\n");
      out.write("\t\t           \t\t\t");
for(int i=0; i<trip_list.size(); i+=5){
		           				int j = i + 5; 
		           				if(j > trip_list.size())
		           					j = trip_list.size();
		           			
      out.write("\n");
      out.write("\t\t           \t\t\t\t<option ");
 String sel = h_start+"-"+h_end; if(sel.equals(i+"-"+j)){ 
      out.write(" selected=\"selected\" ");
} 
      out.write(" value=\"");
      out.print(i );
      out.write('-');
      out.print(j );
      out.write('"');
      out.write('>');
      out.print(i+1 );
      out.write(' ');
      out.write('-');
      out.write(' ');
      out.print(j );
      out.write("</option>\n");
      out.write("\t\t           \t\t\t");
} 
      out.write("\n");
      out.write("\t\t           \t\t</select>\n");
      out.write("\t\t           \t</div>\n");
      out.write("\t\t           \t<div class=\"inputright\"></div>\n");
      out.write("\t\t               <div class=\"number\" style=\"padding: 0 0 0 5px;\"> of ");
      out.print(trip_list.size() );
      out.write(" </div>\n");
      out.write("\t\t \t\t\t</div>\n");
      out.write("\t\t       \t\t");
 if(h_end < trip_list.size()) {
		       		  
      out.write("\n");
      out.write("\t\t       \t\t\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" onclick=\"navigation_header('next', '');\" class=\"next\" title=\"Next\" />\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"last\" onclick=\"navigation_header('last', '');\" class=\"last\" title=\"Last\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" class=\"next_disable\" disabled=\"disabled\"/>\n");
      out.write("\t\t            <input type=\"button\" name=\"last\" class=\"last_disable\" disabled=\"disabled\" />\n");
      out.write("\t\t      \t\t");
} 
      out.write("\n");
      out.write("\t\t      </div></div>\n");
      out.write("            ");

}
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
