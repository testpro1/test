package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.text.SimpleDateFormat;
import org.apache.commons.lang.time.DateFormatUtils;
import com.verve.meetin.friend.Friends;

public final class visitors_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\n');
      out.write('\n');
      out.write('\n');

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
      out.write("\n");
 //System.out.println("/visitors.jsp"); 
      out.write("\n");
      out.write("<div style=\"overflow:hidden; height:auto\" id=\"peoplefinder\">\n");
      out.write("\t  <div class=\"innercontainer\">\n");
      out.write("\t  \n");
      out.write("\t <div class=\"question-icon\" style=\"clear:both;overflow:hidden ;font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\">\n");
      out.write("\t\t\t\t\t\t<p style=\"float: right;\"><a href=\"javascript:Questionfnc('Profile Visitors')\">\n");
      out.write("\t\t\t<img src=\"images/icon-question.png\" alt=\"\" style=\"height: 24px;\" />\n");
      out.write("\t\t\t\t\t\t </a></p> </div> \n");
      out.write("\t  \n");
      out.write("\t     <div class=\"heading\" style=\"overflow:hidden;\"> \n");
      out.write("\t\t\t\t\t\t<div style=\"float: left;\"> \n");
      out.write("\t\t\t\t\t\t   <img src=\"images/profile_visitor.png\" align=\"bottom\"/> Profile Visitors\n");
      out.write("\t\t\t\t\t\t</div> \n");
      out.write("\t\t\t\t\t\t<div class=\"username\" style=\"float: right; font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\"><img align=\"absmiddle\" onclick=\"changePasswordView();\" title=\"Change Password\" src=\"images/change_password.png\" style=\"padding-right:5px;\"><a href=\"javascript:changePasswordView()\" title=\"Change Password\">Change Password</a> </div> \n");
      out.write("                    </div>\n");
      out.write("\t      <!--<div class=\"tableheadingtopbg\"></div>\n");
      out.write("\t      --><div class=\"tableheading\" style=\"margin-top:20px\";>\n");
      out.write("\t          <div class=\"sourcecol\">&nbsp;</div>\n");
      out.write("\t          <div class=\"namecol\" style=\"width:35%\">Name</div>\n");
      out.write("\t          <div class=\"sourcecol\">Date</div> \n");
      out.write("\t      </div>\n");
      out.write("\t      <div class=\"dynamicrow\" style=\"height:auto;\">\n");
      out.write("\t      \n");
      out.write("\t      ");

	      		if(request.getAttribute("visitors_info") != null)
	      		{
	      			/*SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm:ss");*/
	      			ArrayList visitors = (ArrayList)request.getAttribute("visitors_info");
	      			if(visitors !=null && visitors.size() >0)
	      			{
	      				for(int i=0;i < visitors.size();i++)
	      				{	
					   		Object[] object= (Object[])visitors.get(i);
					
		   
      out.write("\n");
      out.write("\t\t  \t\t\t<input type=\"hidden\" id=\"userIdTo");
      out.print(i );
      out.write("\" value=\"");
      out.print((Integer)object[1]);
      out.write("\"/>\n");
      out.write("\t\t  \t\t\t\n");
      out.write("\t\t  \t\t\t<div class=\"row\">\n");
      out.write("\t\t  \t\t\t<div class=\"dynamicsourcecol\" style=\"position: relative;\">\n");
      out.write("\t\t  \t\t\t\n");
      out.write("\t\t  \t\t\t");

                 				String imagePath="";
                 				String imageicon = "";
                 				String image = (String)object[3];
                 				if(image != null)
                 				{
                 					 imagePath = basePath +"profileimage/"+image ;
                 						
                 				} 
                 				else
                 				{
                 					String userimage = (String)object[4];
                 					
                 					if(userimage.equals("Female"))
                 					{
                 						imagePath = basePath+	"images/female.png";
                 					}
                 					if(userimage.equals("Male"))
                 					{
                 						imagePath = basePath+	"images/male.png";
                 					}
                 				
                 				}
                 				 imageicon = basePath + "/images/meetin_corner_meetin.png";
                 		 
      out.write("\n");
      out.write("\t\t  \t\t\t\n");
      out.write("\t\t  \t\t\t<img src=\"");
      out.print(imagePath);
      out.write("\"  height=\"30\" width=\"30\" style=\"display:inline;position: relative;\"/>\n");
      out.write("\t\t  \t\t\t<img src=\"");
      out.print(imageicon);
      out.write("\" width=\"30px\" height=\"30px;\" style=\"position: absolute;left: 0;top: 0;z-index: 99\"/>\n");
      out.write("\t\t  \t\t\t\n");
      out.write("\t\t  \t\t\t</div>  \n");
      out.write("\t\t  \t\t\t<div class=\"col\" style=\"width:35%\">");
      out.print(((String)object[2]).length()>28 ?((String)object[2]).substring(0,26)+"..":((String)object[2]));
      out.write("</div> <!--  class=\"dynamicnamecol\" style=\"width:142px; float:left\" -->\n");
      out.write("\t\t  \t\t\t\n");
      out.write("\t        \t\t<div class=\"col\" style=\"width:24%\">");
      out.print( DateFormatUtils.formatUTC((Date)object[0], "MMM dd, yyyy") );
      out.write("</div><!-- class=\"dynamicsourcecol\" -->\n");
      out.write("            \t\t\n");
      out.write("\t\t  \t\t\t<div class=\"dynamicsourcecol\" style=\"width:33%; \"><!--  class=\"dynamicnamecol\" style=\"width:auto;\"  style=\"float:left; margin-right:10px; font-size:16px; color:#000000;\"-->\n");
      out.write("\t\t  \t\t\t       \t\t\n");
      out.write("\t\t   ");

		   			 	ArrayList checkrequestList =(ArrayList)request.getAttribute("checkRequestStatus");
		   			 	System.out.println("checkrequestList "+checkrequestList.size());
				     	Friends friend = (Friends)checkrequestList.get(i);	
				    	 if(friend == null)
				     		{
	        
      out.write("\n");
      out.write("\t        \t\t\n");
      out.write("\t        \t\t<p name=\"addfriend\">\n");
      out.write("\t\t\t\t\t\t<a href=\"#addfriend\" onclick=\"addMeetInFriends('friend.do?fparam=addasfriend&id='+document.getElementById('userIdTo");
      out.print(i );
      out.write("').value,'profilevisitor');\" title=\"Add as Friend\"><img src=\"images/addfriend.png\" style=\"border: none;float: left;margin-left: 45px;\" vspace=\"0\" /></a>\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t<img src=\"images/view_icon.png\" title=\"View Profile\" style=\"float: left;margin-left: 10px;\" onclick=\"scrollTo(0,0);  viewUserProfile('profile_page.jsp?id=");
      out.print((Integer)object[1]);
      out.write("' )\";/></a>\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\" style=\"margin-left: 15px;float: left\"/></a>\n");
      out.write("\t\t\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callFriendMeetingInviteView(");
      out.print((Integer)object[1]);
      out.write(',');
      out.write('\'');
      out.print((String)object[2]);
      out.write("')\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tstyle=\"border: none;float: left;margin-left: 15px;\" /> </a>\n");
      out.write("\t\t\t\t\t</p>\n");
      out.write("\t        ");
 
		   					}
		   				 else if (friend != null)
		   				  {
		   				
		   				  	if (friend.getStatus().equals("Approve"))
				     		{	
		    
      out.write("\t<p name=\"connect\" style=\"\">\n");
      out.write("\t\t\t\t<img src=\"images/connected_frnd.png\" style=\"border: none;float: left;margin-left: 45px;\" vspace=\"0\" title=\"Connected\"/>\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t<img src=\"images/view_icon.png\" title=\"View Profile\" style=\"float: left;margin-left: 10px;\" onclick=\"scrollTo(0,0);  viewUserProfile('profile_page.jsp?id=");
      out.print((Integer)object[1]);
      out.write("' )\";/></a>\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" onclick=\" scrollTo(0,0); viewUserTripList('profile_page.jsp?id=");
      out.print((Integer)object[1]);
      out.write("');\"><img src=\"images/view_trip_icon.png\" style=\"border: none !important;float: left;margin-left: 15px;\" title=\"Trip List\" border=\"none\"/></a>\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callFriendMeetingInviteView(");
      out.print((Integer)object[1]);
      out.write(',');
      out.write('\'');
      out.print((String)object[2]);
      out.write("')\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tstyle=\"border: none;float: left;margin-left: 15px;\" /> </a>\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t    ");

		    				}
		   				    else if(friend.getUserId2().intValue() == (Integer)object[1] && friend.getStatus().equalsIgnoreCase("Pending"))
		   				     {
			
      out.write("\n");
      out.write("\t\t\t\t\t<p>\n");
      out.write("\t\t\t\t\t<img src=\"images/pendingrequest.png\" style=\"border: none;float: left;margin-left: 45px;\" vspace=\"0\" title=\"Request Pending\"/>\n");
      out.write("\t\t\t\t\t<img src=\"images/view_icon.png\" title=\"View Profile\" style=\"float: left;margin-left: 10px;\" onclick=\"scrollTo(0,0);  viewUserProfile('profile_page.jsp?id=");
      out.print((Integer)object[1]);
      out.write("' )\";/></a>\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\" style=\"margin-left: 15px;float:left; \"/></a>\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callFriendMeetingInviteView(");
      out.print((Integer)object[1]);
      out.write(',');
      out.write('\'');
      out.print((String)object[2]);
      out.write("')\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tstyle=\"border: none;float: left;margin-left: 15px;\" /> </a>\n");
      out.write("\t\t\t\t\t</p>\n");
      out.write("\t\t\t");
		   				     
		   				     }
		   				     else if(friend.getUserId2().intValue() != (Integer)object[1] && friend.getStatus().equalsIgnoreCase("Pending"))
							 {
			
      out.write("\n");
      out.write("\t\t\t\t\t<p name=\"acceptrequest\">\n");
      out.write("\t\t\t\t\t<a href=\"#acceptrequest\" onclick=\"approveOrRejectFriendRequest('profile.do?action=acceptrequest&ref=Approve&acceptref=searchfriend&useridto=");
      out.print((Integer)object[1] );
      out.write("&friendrequestId=");
      out.print(friend.getRelationshipId() );
      out.write("','Approve','");
      out.print((String)object[2] );
      out.write("','profilevisitor');\"><img src=\"images/accept_frndrequest.png\" style=\"border: none;float: left;margin-left: 45px;\" vspace=\"0\" title=\"Accept Request\"/></a>\n");
      out.write("\t\t\t\t\t<img src=\"images/view_icon.png\" title=\"View Profile\" style=\"float: left;margin-left: 10px;\" onclick=\"scrollTo(0,0);  viewUserProfile('profile_page.jsp?id=");
      out.print((Integer)object[1]);
      out.write("' )\";/></a>\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\" style=\"margin-left: 15px;float: left;\"/></a>\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callFriendMeetingInviteView(");
      out.print((Integer)object[1]);
      out.write(',');
      out.write('\'');
      out.print((String)object[2]);
      out.write("')\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tstyle=\"border: none;float: left;margin-left: 15px;\" /> </a>\n");
      out.write("\t\t\t\t\t</p>\n");
      out.write("\t\t\t");
				 
							 }
		   
		   				     
		   				  }
		   	
      out.write("\n");
      out.write("\t\t   \t\t\t</div>\n");
      out.write("            \t\t\n");
      out.write("            \t\t</div>\n");
      out.write("\t\t   \t");

		   				
		   				}
		   		 }
		   		 else
		   		 {
	       
      out.write("\n");
      out.write("\t       <div class=\"infomsg\" style=\"display: block;\">\n");
      out.write("\t       \t\t<img align=\"absmiddle\" hspace=\"5\" src=\"images/info_icon.png\"   />\n");
      out.write("\t       \t\tNo profile visitors found\n");
      out.write("\t       </div>\n");
      out.write("\t       ");

	             }	
	       
      out.write("\n");
      out.write("\t      </div>\n");
      out.write("\t      <!--<div class=\"bottomwhite_large\"></div>\n");
      out.write("\t      --><p>Your profile has been viewed by ");
      out.print(visitors.size() );
      out.write(" person(s) in the past 7 days.</p>\n");
      out.write("\t      ");

	      		}
	      		else {
	      
      out.write("\t\n");
      out.write("\t      <div class=\"infomsg\" style=\"display: block;\">\n");
      out.write("\t      \t<img align=\"absmiddle\" hspace=\"5\" src=\"images/info_icon.png\" />\n");
      out.write("\t      \t\tNo profile visitors found\n");
      out.write("\t      </div>\n");
      out.write("\t       ");

	             }	
	       
      out.write("\n");
      out.write("  </div><!-- content ends here -->\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
