package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.verve.meetin.network.peoplefinder.PeopleFinder;
import com.verve.meetin.trip.Trips;
import java.text.SimpleDateFormat;

public final class viewuserupcomingtrips_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<div class=\"popupmsg\" style=\"width:800px; padding: 0px 0px 0px; top:150px;\">\n");
      out.write("\n");
 //System.out.println("viewuserupcomingtrips.jsp"); 
      out.write('\n');

	   List dateList = new ArrayList(); 
       String name ="";
       String destinationname ="";
       
       if(request.getAttribute("ViewPeopleTripDetail") !=null)
       {
       	  	
          List tripdetailsList  = (ArrayList)request.getAttribute("ViewPeopleTripDetail");
          
          //System.out.println(""+tripdetailsList);
          
          
          if(tripdetailsList !=null && tripdetailsList.size() >0)
          {
             SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");

      out.write("\n");
      out.write("\n");
      out.write(" <div class=\"popupheading\">\n");
      out.write("       <div class=\"title\">View Trips</div>\n");
      out.write("             <div class=\"close\"><img src=\"images/close.png\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\" /></div>\n");
      out.write("</div>\n");

          	for(int i = 0 ;i <tripdetailsList.size();i++)
          	{
	             Object[] object =(Object[]) tripdetailsList.get(i);


      out.write("\n");
      out.write("\t\t\t\t<div class=\"row\">\n");
      out.write("\t\t\t\t   \t<div class=\"col\" style=\"width:50%\">");
      out.print((String)object[0] );
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:25%\">");
      out.print(sdf.format((Date)object[1]));
      out.write("</div>\n");
      out.write("                    <div class=\"col\" style=\"width:25%\">");
      out.print(sdf.format((Date)object[2]) );
      out.write("</div>\n");
      out.write("         \t\t</div>\n");

	      	}
          	
       	 }
    	}
    	else
    	{
    	
      out.write("\n");
      out.write("    \t\n");
      out.write("    \t<div class=\"popupheading\">\n");
      out.write("       <div class=\"title\">View Trips</div>\n");
      out.write("             <div class=\"close\"><img src=\"images/close.png\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\" /></div>\n");
      out.write("\t\t</div>\n");
      out.write("\t\t\t<div class=\"row\">\n");
      out.write("\t\t\t\t   \t<div class=\"col\" style=\"width:100%\">");
out.println("No Trips from User");
      out.write("</div>\n");
      out.write("            </div>\n");
      out.write("\t\t\n");
      out.write("    \t");

    	}


      out.write("\n");
      out.write("</div>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
