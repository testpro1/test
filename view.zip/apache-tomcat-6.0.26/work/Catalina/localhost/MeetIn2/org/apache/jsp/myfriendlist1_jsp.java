package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.verve.meetin.user.User;
import com.verve.meetin.friend.FriendsDAO;
import java.util.*;

public final class myfriendlist1_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

      out.write('\n');
      out.write('\n');
      out.write('\n');

	ArrayList friendlist = (ArrayList) session.getAttribute("friendlist");
	System.out.println("***************************************************************************  "+friendlist.size());
	int start = Integer.parseInt(session.getAttribute("start").toString());
	int end = Integer.parseInt(session.getAttribute("end").toString());

      out.write("\n");
      out.write("\n");
      out.write("<div style=\"overflow:hidden; height:auto\">\t\n");
      out.write("     <div class=\"innercontainer\">\n");
      out.write("      \t<div class=\"heading\" style=\"margin-top:30px; height: auto;overflow: hidden;\">\n");
      out.write("      \t<img src=\"images/trip_icon.png\" align=\"bottom\" /> ");

      	if(session.getAttribute("socialnetworkname").toString().equalsIgnoreCase("Facebook Checkin"))
      	{
      		out.println("Facebook Friends Checked-In (last 7 days)");
      	}else
      	{
      		out.println(session.getAttribute("socialnetworkname").toString()); 
      out.write("&nbsp;Friends\n");
      out.write("      ");
	}
      	
                  /**Code to show the total number of people on a page */
                  
                  
                  if(friendlist !=null && friendlist.size() >0)
                   {
        
      out.write("\n");
      out.write("                 <div class=\"found\"><strong>");
      out.print(friendlist.size() );
      out.write("</strong> friend(s) found</div>\n");
      out.write("        ");
  
				   }
				   else
				   {
	 	
      out.write("\n");
      out.write("\t \t       \t<div class=\"found\">&nbsp;</div>\n");
      out.write("\t \t");

				   }
				   
        
      out.write("\n");
      out.write("     \t </div>\n");
      out.write("     \n");
      out.write("\t\t     <div class=\"tableheading\">\n");
      out.write("\t\t              <div class=\"sourcecol\">&nbsp;</div>\n");
      out.write("\t\t              <div class=\"namecol\">Name</div>\n");
      out.write("\t\t              <div class=\"namecol\">Location</div>\n");
      out.write("\t\t     </div>\n");
      out.write("\n");
      out.write("<div class=\"dynamicrow\">\n");
      out.write("\n");

	if (friendlist != null && friendlist.size() > 0) 
	{
				for (int i = start; i < end; i++)
				{
					ArrayList friendArrayList = (ArrayList) friendlist.get(i);
					String[] socialnetwork = friendArrayList.get(3).toString().split("/");
				
      out.write("\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t<div class=\"row\">\n");
      out.write("\t\t\t\t\t<div class=\"dynamicsourcecol\" style=\"position: relative;\">\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t");

						String imagepath = "";
						String imageicon = "";
					if(socialnetwork[1].equals("meetin_icon.png")){ 
						
						
							imagepath	=basePath+friendArrayList.get(4);
							imageicon =basePath + "images/meetin_corner_meetin.png";
					
      out.write("\n");
      out.write("\t\t\t\t\t\t<img src=\"");
      out.print(imagepath);
      out.write("\" width=\"30px\" height=\"30px;\" style=\"position: relative;\"/>\n");
      out.write("\t\t\t\t\t\t<img src=\"");
      out.print(imageicon);
      out.write("\" width=\"30px\" height=\"30px;\" style=\"position: absolute;left: 0;top: 0;z-index: 99\"/></div>\n");
      out.write("\t\t\t\t\t");
}else
					{ 
						if(friendArrayList.get(4) == null)
						{
							imagepath = basePath+"images/"+socialnetwork[1].toString();
						}
						else
						{
							imagepath =	friendArrayList.get(4).toString();
							if(socialnetwork[1].equals("1_facebook_icon.png"))
							{
								imageicon =basePath + "images/meetin_corner_facebook.png"; 	
							}
							if(socialnetwork[1].equals("2_linkedin_icon.png"))
							{
								imageicon =basePath + "images/meetin_corner_in.png";
							} 
							if(socialnetwork[1].equals("twitter.png"))
							{
								imageicon =basePath + "images/meetin_corner_twitter.png";
							}
							if(socialnetwork[1].equals("4sq.png"))
							{
								imageicon =basePath + "images/meetin_corner_4sq.png";
							}
						}
							
      out.write("\n");
      out.write("\t\t\t\t\t\t\t<img src=\"");
      out.print(imagepath );
      out.write("\" width=\"30px\" height=\"30px;\" style=\"position: relative;\"/>\n");
      out.write("\t\t\t\t\t\t\t<img src=\"");
      out.print(imageicon);
      out.write("\" width=\"30px\" height=\"30px;\" style=\"position: absolute;left: 0;top: 0;z-index: 99\"/></div>\n");
      out.write("\t\t\t\t\t");
} 
      out.write("\n");
      out.write("\t\t\t\t\t\t\t<div class=\"colgrid\" style=\"width: 41%\">\n");
      out.write("\t\t\t\t\t\t\t\t");
 
									if(friendArrayList.get(0).toString().length() > 28) 
						    		out.println(friendArrayList.get(0).toString().substring(0, 28)+"..."); 
								else
							    	out.println(friendArrayList.get(0));
								
      out.write("\n");
      out.write("\t\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t<div class=\"colgrid\" style=\"width: 30%\">\n");
      out.write("\t            ");

	            	if(friendArrayList.get(1).toString().length() >22)
	            			out.println(friendArrayList.get(1).toString().substring(0,16)+"...");
	            	else
	            		out.println(friendArrayList.get(1));
	            
      out.write("\n");
      out.write("\t\t\t\t</div>\t\n");
      out.write("\t            \n");
      out.write("\t            \n");
      out.write("\t            <div class=\"dynamicviewcol\" style=\"width: 135px; \">\n");
      out.write("\t              ");

	              		if(socialnetwork[1].equals("meetin_icon.png"))
		   				{
		 		  
      out.write("\n");
      out.write("\t\t \t\t  \n");
      out.write("\t\t \t\t  ");

					String userId = friendArrayList.get(2).toString();
					userId = userId.substring(userId.indexOf("=")+1,userId.length());
				 
      out.write("\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t <a href=\"javascript:void(0);\" onclick=\" scrollTo(0,0); viewUserProfile('");
      out.print(friendArrayList.get(2));
      out.write("');\"><img src=\"images/view_icon.png\" title=\"View Profile\" border=\"none\"/></a>\n");
      out.write("\t\t\t \t <a href=\"javascript:void(0);\" onclick=\" scrollTo(0,0); viewUserTripList('");
      out.print(friendArrayList.get(2));
      out.write("');\"><img src=\"images/view_trip_icon.png\" title=\"Trip List\" border=\"none\"/></a>\n");
      out.write("\t\t\t \t\n");
      out.write("\t\t\t \t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callFriendMeetingInviteView(");
      out.print(userId);
      out.write(',');
      out.write('\'');
      out.print(friendArrayList.get(0));
      out.write("')\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t \t\n");
      out.write("\t\t\t\t ");

						}
						else if(socialnetwork[1].equals("1_facebook_icon.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" onclick=\"window.open('");
      out.print(friendArrayList.get(2));
      out.write("','name','height=600,width=1000,scrollbars=1');\"><img src=\"images/view_icon.png\" title=\"View Profile\"border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" class=\"\"><img\tsrc=\"images/invite_msg_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t    ");

						}
							else if(socialnetwork[1].equals("2_linkedin_icon.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\"  style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_icon_inactive.png\" border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" class=\"\"><img\tsrc=\"images/invite_msg_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t    ");

						}
						else if(socialnetwork[1].equals("4sq.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\"  style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_icon_inactive.png\" border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" class=\"\"><img\tsrc=\"images/invite_msg_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t    ");

						}  
						else if(socialnetwork[1].equals("gmail_icon.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\"  style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_icon_inactive.png\" border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" class=\"\"><img\tsrc=\"images/invite_msg_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t    ");

						}
						else if(socialnetwork[1].equals("twitter.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\"  style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_icon_inactive.png\" border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" class=\"\"><img\tsrc=\"images/invite_msg_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t    ");

						}
				
      out.write("\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t</div>\t\n");
      out.write("\t\t\t\t");
 
				}
				
      out.write("\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t<!-- pagination starts -->\t\n");
      out.write("\t\t\t\t\t");

						if (friendlist.size() > 0)
						 {
					
      out.write("\n");
      out.write("\t\n");
      out.write("\t\t\t\t<div class=\"pagination\">\n");
      out.write("\t\t\t\t\t\t");

							if (start > 0) {
						
      out.write("\n");
      out.write("\t\t\t\t\t\t\t<input type=\"button\" name=\"first\"\tonclick=\"navigateMyFriendList('First')\" class=\"first\"\ttitle=\"First\" />\n");
      out.write("\t\t\t\t\t\t\t<input type=\"button\" name=\"prev\"\tonclick=\"navigateMyFriendList('Prev')\" class=\"previous\" \ttitle=\"Previous\" />\n");
      out.write("\t\t\t\t\t\t");

						} 
						else 
						{
						
      out.write("\n");
      out.write("\t\t\t\t\t\t\t<input type=\"button\" disabled=\"disabled\" name=\"first\"\tclass=\"first_disable\" />\n");
      out.write("\t\t\t\t\t\t\t<input type=\"button\" disabled=\"disabled\" name=\"prev\"\tclass=\"previous_disable\" />\n");
      out.write("\t\t\t\t\t\t");

						}
						
      out.write("\n");
      out.write("\t\t\t\t\t\t<div class=\"inputcontainer\">\n");
      out.write("\t\t\t\t\t\t<div class=\"inputleft\"></div>\n");
      out.write("\t\t\t\t\t\t<div class=\"inputrepeat\">\n");
      out.write("\t\t\t\t\t\t<select id=\"page_combo\" name=\"page_combo\" class=\"select\" onchange=\"navigateMyFriendList('page_combo')\" style=\"background: white;\">\n");
      out.write("\t\t\t\t\t\t");

					for (int i = 0; i < friendlist.size(); i += 10)
					{
									int j = i + 10;
									if (j > friendlist.size())
										j = friendlist.size();
						
      out.write("\n");
      out.write("\t\t\t\t\t\t<option ");
String sel = start + "-" + end;
						if (sel.equals(i + "-" + j)) {
      out.write("\n");
      out.write("\t\t\t\t\t\t\tselected=\"selected\" ");
}
      out.write(" value=\"");
      out.print(i);
      out.write('-');
      out.print(j);
      out.write('"');
      out.write('>');
      out.print(i + 1);
      out.write("\n");
      out.write("\t\t\t\t\t\t\t-\n");
      out.write("\t\t\t\t\t\t\t");
      out.print(j);
      out.write("</option>\n");
      out.write("\t\t\t\t\t\t");

							}
						
      out.write("\n");
      out.write("\t\t\t\t\t</select>\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t<div class=\"inputright\"></div>\n");
      out.write("\t\t\t\t\t<div class=\"number\" style=\"color: black;\">\n");
      out.write("\t\t\t\t\tof\n");
      out.write("\t\t\t\t\t");
      out.print(friendlist.size());
      out.write("\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t");

					if (end < friendlist.size()) {
				
      out.write("\n");
      out.write("\t\t\t\t\t<input type=\"button\" class=\"next\" name=\"next\"\tonclick=\"navigateMyFriendList('Next')\" title=\"Next\" />\n");
      out.write("\t\t\t\t\t<input type=\"button\" class=\"last\" name=\"next\"\tonclick=\"navigateMyFriendList('Last')\" title=\"Last\" />\n");
      out.write("\t\t\t\t");

					} else {
				
      out.write("\n");
      out.write("\t\t\t\t\t<input type=\"button\" name=\"next\" class=\"next_disable\" disabled=\"disabled\" />\n");
      out.write("\t\t\t\t\t<input type=\"button\" name=\"last\" class=\"last_disable\" disabled=\"disabled\" />\n");
      out.write("\t\t\t\t");

					}
				
      out.write("\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<!-- pagination ends -->\n");
      out.write("\t");

		}
		else 
		{
			
      out.write("\n");
      out.write("\t\t\t <!-- Div tag for Message format -->          \n");
      out.write("              <div class=\"infomsg\" style=\"display:block\">\n");
      out.write("                \t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\"/> No friends found.\n");
      out.write("              </div>\n");
      out.write("\t\t\t");

		}
		
	
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

	}
	else
			{
      out.write("\n");
      out.write("\t\t\t<!-- Div tag for Message format -->          \n");
      out.write("              <div class=\"infomsg\" style=\"display:block\">\n");
      out.write("                \t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\"/> No friends found.\n");
      out.write("              </div>\n");
      out.write("\t\t\t");
}
	
 		
      out.write("\n");
      out.write(" \t\t\n");
      out.write(" \t\t\t\t\n");
      out.write(" \t\n");
      out.write(" </div>\n");
      out.write(" </div>\n");
      out.write("\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n");
      out.write("<html>\n");
      out.write("<head>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
      out.write("\n");
      out.write("</head>\n");
      out.write("\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
