package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import java.util.Iterator;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.user.User;
import com.google.code.facebookapi.ToJsonObject;
import com.restfb.json.JsonObject;

public final class peoplenearme_005fnew_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


	String userProfile = "";
	String latitude = "";
	String langitude = "";
	String friendname = "";
	String socialsiteIcon = "";
	Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
	ArrayList<String> locationList = new ArrayList<String>();
	String loggedinuserlatlang = "";
	String imageName = "";
	String userId = "";
  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

	String imagePath = request.getScheme() + "://"
					+ request.getServerName() + ":" + request.getServerPort()
					+ request.getContextPath();
 
      out.write('\n');

	String user_travelling = "no";
	String friend_travelling = "no";
	List trip_list = (ArrayList) session.getAttribute("trip_list");

	if (trip_list.size() > 0) {
		user_travelling = "yes";
	}

      out.write('\n');
      out.write('\n');

	ArrayList friends = (ArrayList) session.getAttribute("friends");
	int start = Integer.parseInt(session.getAttribute("start")
			.toString());
	int end = Integer.parseInt(session.getAttribute("end").toString());
	String location = "";

      out.write('\n');
      out.write('\n');
      out.write('\n');
      out.write("\n");
      out.write("\t\n");
      out.write("<input type=\"hidden\" id=\"default_location\"\tvalue=\"");
      out.print(session.getAttribute("default_location").toString());
      out.write("\" />\n");
      out.write("\n");

	if (session.getAttribute("LatLongList") != null) {
		latitude = "";
		langitude = "";
		friendname = "";
		socialsiteIcon = "";
		imageName = "";
		userId = "";

		List latlongList = (ArrayList) session.getAttribute("LatLongList");

		System.out.println("lat long list size ***  "+latlongList.size());

		for (int l = start; l < end; l++) {
			User user = new User();
			user = (User) latlongList.get(l);

			latitude = latitude + user.getLocLat() + "_";
			langitude = langitude + user.getLocLang() + "_";
			//friendname = user.getFullname() + "_";
			friendname = friendname + user.getFullname() + "_";

			socialsiteIcon = socialsiteIcon
					+ user.getGoogleMarkerIcon().split("/")[1] + ",";
					
			imageName = imageName + user.getImage() + ",";
			
			userId = userId + user.getUserKey() + "_";
		}
	}
	if (request.getAttribute("LatLong") != null) {
		loggedinuserlatlang = "";
		loggedinuserlatlang = (String) request.getAttribute("LatLong");
	}
	if(request.getAttribute("Profile") !=null)
	{
		
		User u = (User) request.getAttribute("Profile");
		userProfile = u.getFullname();
						
		if(u.getImage() !=null && !u.getImage().equals("")){
			userProfile = userProfile + "&" + imagePath + "/profileimage/" + u.getImage();
		}
		else{
			if(u.getGender().equalsIgnoreCase("Male")){
				userProfile = userProfile + "&" + imagePath + "/images/male.png";
			}else{
			userProfile = userProfile + "&" + imagePath +  "images/female.png";
			}
		}
		
	}

      out.write("\n");
      out.write("<input type=\"hidden\" id=\"userId\" value='");
      out.print(userId);
      out.write("' />\n");
      out.write("<div style=\"overflow: hidden; height: auto\" id=\"content\">\n");
      out.write("<div class=\"innercontainer\">\n");
      out.write("\n");
      out.write("<div class=\"question-icon\" style=\"clear:both;overflow:hidden ;font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\">\n");
      out.write("\t\t\t\t\t\t<p style=\"float: right;\"><a href=\"javascript:Questionfnc('People Near Me')\">\n");
      out.write("\t\t\t<img src=\"images/icon-question.png\" alt=\"\" style=\"height: 24px;\" />\n");
      out.write("\t\t\t\t\t\t </a></p> </div>\n");
      out.write("\n");
      out.write("\n");
      out.write("\t<div class=\"generalfrm\" style=\"height: auto;\">\n");
      out.write("\t\t");

			if (session.getAttribute("showlivinglocation") != null) {
		
      out.write("\n");
      out.write("\t\t<div class=\"lable\">\n");
      out.write("\t\t\tLiving Location\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			} else {
		
      out.write("\n");
      out.write("\t\t<div class=\"lable\">\n");
      out.write("\t\t\tCurrent Location\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			}
		
      out.write("\n");
      out.write("\t\t<!--  The below lines of code will fill up the drop down list for current locations -->\n");
      out.write("\t\t");

			ArrayList<String> locationList = new ArrayList<String>();
			if (session.getAttribute("current_location") != null) {
				locationList = (ArrayList) session.getAttribute("current_location");

				if (locationList != null && locationList.size() > 1) {
				location = locationList.get(0).toString();
		
      out.write("\n");
      out.write("\n");
      out.write("\t\t");

			session.setAttribute("clocation", locationList.get(0).toString());
		
      out.write("\n");
      out.write("\n");
      out.write("\t\t<div class=\"inputleft\"></div>\n");
      out.write("\t\t<div class=\"inputrepeat\" style=\"margin-bottom: 10px;\">\n");
      out.write("\t\t\t<select id=\"locationId\" name=\"locationname\" style=\"width: auto;\"\n");
      out.write("\t\t\t\tclass=\"select\" onchange=\"loadPeopleNearMe('meetIn');\">\n");
      out.write("\t\t\t\t");

					for (int i = 0; i < locationList.size(); i++)
					{
					
				
      out.write("\n");
      out.write("\t\t\t\t<option value=\"");
      out.print(locationList.get(i));
      out.write("\"\n");
      out.write("\t\t\t\t\t");
if (locationList.get(i).equalsIgnoreCase((String)request.getAttribute("SelectedLoc"))) {
					location = locationList.get(i).toString();
					
      out.write("\n");
      out.write("\t\t\t\t\tselected=\"selected\" ");
}
      out.write('>');
      out.print(locationList.get(i));
      out.write("</option>\n");
      out.write("\t\t\t\t");

					}
				
      out.write("\n");
      out.write("\t\t\t</select>\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<div class=\"inputright\"></div>\n");
      out.write("\t\t");

			} else if (locationList != null && locationList.size() == 1) {
					if (session.getAttribute("default_location").toString()
							.equals(locationList.get(0))) {
		
      out.write("\n");
      out.write("\t\t<div>\n");
      out.write("\t\t\t<input type=\"text\" value=\"");
      out.print(locationList.get(0).toString());
      out.write("\"\n");
      out.write("\t\t\t\tname=\"location\" readonly=\"readonly\" />\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			} else {
						session.setAttribute("clocation", locationList.get(0));
		
      out.write("\n");
      out.write("\t\t<div>\n");
      out.write("\t\t\t<input type=\"text\" value=\"");
      out.print(locationList.get(0).toString());
      out.write("\"\n");
      out.write("\t\t\t\tname=\"location\" readonly=\"readonly\" />\n");
      out.write("\t\t</div>\n");
      out.write("\n");
      out.write("\t\t");

			}
				}
			}
			if (session.getAttribute("upcomingtrip") != null) {
				if (session.getAttribute("showlivinglocation") != null) {
					
					int futureTrip = Integer.parseInt(session.getAttribute("futureTrip").toString());
					System.out.println("future trip ::  "+futureTrip);
					if(futureTrip >0 )
					{
						location = locationList.get(0).toString();		
		
      out.write("\n");
      out.write("\n");
      out.write("\t\t<div\n");
      out.write("\t\t\tstyle=\"height: 20px; margin-top: 10px; margin-left: 170px; clear: both;\">\n");
      out.write("\t\t\t<div style=\"width: 50px; float: left; line-height: 30px;\">\n");
      out.write("\n");
      out.write("\t\t\t\t<input type=\"hidden\" id=\"clocation\"\n");
      out.write("\t\t\t\t\tvalue=\"");
      out.print(session.getAttribute("clocation"));
      out.write("\">\n");
      out.write("\n");
      out.write("\t\t\t\t<input type=\"checkbox\" name=\"showCurLocation\" id=\"loc\"\n");
      out.write("\t\t\t\t\tonclick=\"loadPeopleNearMe('meetIn');\" checked=\"checked\"\n");
      out.write("\t\t\t\t\tstyle=\"width: auto !important;\" />\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<div class=\"lable1\"\n");
      out.write("\t\t\t\tstyle=\"width: 230px; color: #000; float: left; line-height: 20px;\">\n");
      out.write("\t\t\t\tPeople near my living location\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

					}
			user_travelling = "no";
				}

				else {
		
      out.write("\n");
      out.write("\n");
      out.write("\t\t<div style=\"margin-top: 10px; margin-left: 170px; clear: both;\">\n");
      out.write("\t\t\t<div style=\"width: 35px; float: left; line-height: 30px;\">\n");
      out.write("\t\t\t\t<input type=\"checkbox\" name=\"showCurLocation\" id=\"loc\"\n");
      out.write("\t\t\t\t\tonclick=\"loadPeopleNearMe('meetIn');\" style=\"width: auto !important;\" />\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<div class=\"lable1\"\n");
      out.write("\t\t\t\tstyle=\"width: 230px; color: #000; float: left; line-height: 20px;\">\n");
      out.write("\t\t\t\tPeople near my living location\n");
      out.write("\t\t\t</div>\n");
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			}
			}
		
      out.write("\n");
      out.write("\t</div>\n");
      out.write("\n");
      out.write("\t<div class=\"heading\" style=\"margin-top: 30px; height: auto; overflow: hidden\">\n");
      out.write("\t\t<div style=\"float: left; line-height: 32px;\">\n");
      out.write("\t\t\tPeople from\n");
      out.write("\t\t</div>\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t<!-- \n");
      out.write("\tdiv tag for select box for social networking sites\t\n");
      out.write(" -->\n");
      out.write("\t\t<div style=\"height: 26px; padding: 5px; width: 165px; float: left;\">\n");
      out.write("\t\t\t<div class=\"inputleft\"></div>\n");
      out.write("\t\t\t<div class=\"inputrepeat\">\n");
      out.write("\t\t\t\t<select id=\"filter\" class=\"select\" name=\"filter\" id=\"socialMedia\"\n");
      out.write("\t\t\t\t\tstyle=\"width: 150px; background: white;\"\n");
      out.write("\t\t\t\t\tonchange=\"loadPeopleNearMe(this.value);\">\n");
      out.write("\t\t\t\t\t<option value=\"meetIn\">meetIn</option>\n");
      out.write("\t\t\t\t\t");

						
						List<Integer> networkListIds = new ArrayList<Integer>();
						List<String> networkList = new ArrayList<String>();
						networkListIds = new NetworkDAO()
								.getUserSocialNetworkSiteId(Integer.parseInt(session
										.getAttribute("UserID").toString()));
						networkList = new NetworkDAO()
								.getUserSocialNetworkSiteNames(networkListIds);
						for (int i = 0; i < networkList.size(); i++) {
						
						
						if(networkList.get(i).toString().equalsIgnoreCase("Tripit")){
							continue;
						}
					
      out.write("\n");
      out.write("\t\t\t\t\t<option value=\"");
      out.print(networkList.get(i).toString());
      out.write("\"\n");
      out.write("\t\t\t\t\t\t");
if (request.getParameter("filter") != null
						&& request.getParameter("filter").equals(
								networkList.get(i).toString())) {
      out.write("\n");
      out.write("\t\t\t\t\t\tselected=\"selected\" ");
}
      out.write('>');
      out.print(networkList.get(i).toString());
      out.write("</option>\n");
      out.write("\n");
      out.write("\t\t\t\t\t");

						}
					
      out.write("\n");
      out.write("\t\t\t\t\t<option value=\"All\" ");
if (request.getParameter("filter") != null
						&& request.getParameter("filter").equals("All")) {
      out.write("selected=\"selected\" ");
}
      out.write(">All Networks</option>\n");
      out.write("\t\t\t\t</select>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<div class=\"inputright\"></div>\n");
      out.write("\t\t</div>\n");
      out.write("\n");
      out.write("\t\t<!-- pagination starts -->\n");
      out.write("\t\t");

				
			if (friends.size() > 0) {
		
      out.write("\n");
      out.write("\n");
      out.write("\t\t<div class=\"pagination\">\n");
      out.write("\t\t\t");

				if (start > 0) {
			
      out.write("\n");
      out.write("\t\t\t<input type=\"button\" name=\"first\"\n");
      out.write("\t\t\t\tonclick=\"navigatePeopleMeFriendList('First')\" class=\"first\"\n");
      out.write("\t\t\t\ttitle=\"First\" />\n");
      out.write("\t\t\t<input type=\"button\" name=\"prev\"\n");
      out.write("\t\t\t\tonclick=\"navigatePeopleMeFriendList('Prev')\" class=\"previous\"\n");
      out.write("\t\t\t\ttitle=\"Previous\" />\n");
      out.write("\t\t\t");

				} else {
			
      out.write("\n");
      out.write("\t\t\t<input type=\"button\" disabled=\"disabled\" name=\"first\"\n");
      out.write("\t\t\t\tclass=\"first_disable\" />\n");
      out.write("\t\t\t<input type=\"button\" disabled=\"disabled\" name=\"prev\"\n");
      out.write("\t\t\t\tclass=\"previous_disable\" />\n");
      out.write("\t\t\t");

				}
			
      out.write("\n");
      out.write("\t\t\t<div class=\"inputcontainer\">\n");
      out.write("\t\t\t\t<div class=\"inputleft\"></div>\n");
      out.write("\t\t\t\t<div class=\"inputrepeat\">\n");
      out.write("\t\t\t\t\t<select id=\"page_combo\" name=\"page_combo\" class=\"select\"\n");
      out.write("\t\t\t\t\t\tonchange=\"navigatePeopleMeFriendList('page_combo')\"\n");
      out.write("\t\t\t\t\t\tstyle=\"background: white;\">\n");
      out.write("\t\t\t\t\t\t");

							for (int i = 0; i < friends.size(); i += 10) {
									int j = i + 10;
									if (j > friends.size())
										j = friends.size();
						
      out.write("\n");
      out.write("\t\t\t\t\t\t<option ");
String sel = start + "-" + end;
					if (sel.equals(i + "-" + j)) {
      out.write("\n");
      out.write("\t\t\t\t\t\t\tselected=\"selected\" ");
}
      out.write(" value=\"");
      out.print(i);
      out.write('-');
      out.print(j);
      out.write('"');
      out.write('>');
      out.print(i + 1);
      out.write("\n");
      out.write("\t\t\t\t\t\t\t-\n");
      out.write("\t\t\t\t\t\t\t");
      out.print(j);
      out.write("</option>\n");
      out.write("\t\t\t\t\t\t");

							}
						
      out.write("\n");
      out.write("\t\t\t\t\t</select>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t<div class=\"inputright\"></div>\n");
      out.write("\t\t\t\t<div class=\"number\" style=\"color: white;\">\n");
      out.write("\t\t\t\t\tof\n");
      out.write("\t\t\t\t\t");
      out.print(friends.size());
      out.write("\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				if (end < friends.size()) {
			
      out.write("\n");
      out.write("\t\t\t<input type=\"button\" class=\"next\" name=\"next\"\n");
      out.write("\t\t\t\tonclick=\"navigatePeopleMeFriendList('Next')\" title=\"Next\" />\n");
      out.write("\t\t\t<input type=\"button\" class=\"last\" name=\"next\"\n");
      out.write("\t\t\t\tonclick=\"navigatePeopleMeFriendList('Last')\" title=\"Last\" />\n");
      out.write("\t\t\t");

				} else {
			
      out.write("\n");
      out.write("\t\t\t<input type=\"button\" name=\"next\" class=\"next_disable\"\n");
      out.write("\t\t\t\tdisabled=\"disabled\" />\n");
      out.write("\t\t\t<input type=\"button\" name=\"last\" class=\"last_disable\"\n");
      out.write("\t\t\t\tdisabled=\"disabled\" />\n");
      out.write("\t\t\t");

				}
			
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			}
		
      out.write("\n");
      out.write("\t</div>\n");
      out.write("\n");
      out.write("\n");
      out.write("\t<div class=\"tableheading \" style=\"\">\n");
      out.write("\t\t<div class=\"sourcecol\">\n");
      out.write("\t\t\t&nbsp;&nbsp;\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<div class=\"namecol\">\n");
      out.write("\t\t\tName\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			if(session.getAttribute("LastModifiedDate") !=null){
		
      out.write("\n");
      out.write("\t\t<div id=\"size1\">\n");
      out.write("\t\t\tLast updated on ");
      out.print(session.getAttribute("LastModifiedDate") );
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t\n");
      out.write("\t\t");
	
			}
			
		 
      out.write("\n");
      out.write("\t</div>\n");
      out.write("\n");
      out.write("\t<div class=\"dynamicrow\">\n");
      out.write("\t\t");

			if (friends != null && friends.size() > 0) {
				for (int i = start; i < end; i++) {
					ArrayList l = (ArrayList) friends.get(i);
					//String imageicon = imagePath + "/" + l.get(2);
					String[] socialnetwork = l.get(2).toString().split("/");
					
					String image ="";
					String imageicon = "";
					if(socialnetwork[1].equalsIgnoreCase("meetin_icon.png"))
					{
						image = imagePath + "/"+l.get(6).toString();
						imageicon = imagePath + "/images/meetin_corner_meetin.png";
					}
					else
					{
						if(l.get(6) == null)
						{
							image = imagePath +"/images/"+socialnetwork[1].toString();
						}
						else
						{
							image = l.get(6).toString();
							if(socialnetwork[1].equals("1_facebook_icon.png"))
							{
								imageicon =imagePath + "/images/meetin_corner_facebook.png"; 	
							}
							if(socialnetwork[1].equals("2_linkedin_icon.png"))
							{
								imageicon =imagePath + "/images/meetin_corner_in.png";
							} 
							if(socialnetwork[1].equals("twitter.png"))
							{
								imageicon =imagePath + "/images/meetin_corner_twitter.png";
							}
							if(socialnetwork[1].equals("4sq.png"))
							{
								imageicon =imagePath + "/images/meetin_corner_4sq.png";
							}
						}
					}
					//System.out.println(l.get(6).toString());
					
		
      out.write("\n");
      out.write("\t\t<div class=\"row\">\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t<div class=\"colgrid\" style=\"width: 7%;position: relative;\"> \n");
      out.write("\t\t\t\t<img alt=\"\" src=\"");
      out.print(image);
      out.write("\" width=\"30px\" height=\"30px;\" style=\"position: relative;\">\n");
      out.write("\t\t\t\t<img src=\"");
      out.print(imageicon);
      out.write("\" width=\"30px\" height=\"30px;\" style=\"position: absolute;left: 0;top: 0;z-index: 99\"/>\n");
      out.write("\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<div class=\"colgrid\" style=\"width: 75%\">\n");
      out.write("\t\t\t\t");

					out.print(l.get(0));
				
      out.write("\n");
      out.write("\t\t\t</div>\t\n");
      out.write("\n");
      out.write("\t\t\t<div class=\"colgrid\" style=\"width: 18%;\">\n");
      out.write("\t\t\t\t");

					if (socialnetwork[1].equalsIgnoreCase("meetin_icon.png")) {
				
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"scrollTo(0,0); viewUserProfile('");
      out.print(l.get(1).toString());
      out.write("');\"\n");
      out.write("\t\t\t\t\ttitle=\"View Profile\"><img src=\"images/view_icon.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t");

					} else if (socialnetwork[1]
									.equalsIgnoreCase("1_facebook_icon.png")) {
				
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"window.open('");
      out.print(l.get(1).toString());
      out.write("','name','height=600,width=1000,scrollbars=1');\"\n");
      out.write("\t\t\t\t\ttitle=\"View Profile\"><img src=\"images/view_icon.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"><img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/view_uptrip_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" class=\"\"><img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/invite_msg_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t\t\t");

					} else if (socialnetwork[1]
									.equalsIgnoreCase("2_linkedin_icon.png")
									|| socialnetwork[1]
											.equalsIgnoreCase("gmail_icon.png")
									|| socialnetwork[1].equalsIgnoreCase("twitter.png")
									|| socialnetwork[1].equalsIgnoreCase("4sq.png")
									
									) {
				
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"> <img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/view_icon_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"><img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/view_uptrip_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" class=\"\"><img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/invite_msg_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\n");
      out.write("\t\t\t\t");

					}

							if (l.get(5) != null && !(l.get(5).equals(""))) 
							{
								if (user_travelling.equals("yes")) {
									friend_travelling = "yes";
								}
								if (user_travelling.equals("no")) {
									friend_travelling = "yes";
								}
				
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"getPeopleUpcomingTripDetail('");
      out.print(l.get(5).toString());
      out.write("');\"\n");
      out.write("\t\t\t\t\ttitle=\"View Trip\"><img src=\"images/view_uptrip.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t");

					String id = l.get(1).toString();  
					int Id = Integer.parseInt(id.substring(id.indexOf("=")+1));
					
					 
      out.write("\t\t\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callMeetingInviteView1('");
out.print(Id);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(location);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(user_travelling);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_travelling);
      out.write("');\"\n");
      out.write("\t\t\t\t\ttitle=\"Send Message\" class=\"\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t\t");

					} else if ((!socialnetwork[1].equals("gmail_icon.png"))
									&& (!socialnetwork[1].equals("1_facebook_icon.png"))
									&& (!socialnetwork[1].equals("2_linkedin_icon.png"))
									&& (!socialnetwork[1].equals("twitter.png"))
									&& (!socialnetwork[1].equals("4sq.png"))
									) {
								if (user_travelling.equals("yes")) {
									friend_travelling = "no";
								}
								if (user_travelling.equals("no")) {
									friend_travelling = "no";
								}
				
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"><img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/view_uptrip_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t\t\t");

					String id = l.get(1).toString();  
					int Id = Integer.parseInt(id.substring(id.indexOf("=")+1));	
				
      out.write("\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callMeetingInviteView1('");
out.print(Id);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(location);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(user_travelling);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_travelling);
      out.write("');\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t");

				
					}
				
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t</div>\n");
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			}
			} else {
		
      out.write("\n");
      out.write("\t\t<!-- Div tag for Message format -->\n");
      out.write("\t\t-\n");
      out.write("\t\t<div class=\"infomsg\" style=\"display: block\">\n");
      out.write("\t\t\t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\" />\n");
      out.write("\t\t\tNo friends found that match your location.\n");
      out.write("\t\t</div>\n");
      out.write("\t\t");

			}
		
      out.write("\n");
      out.write("\n");
      out.write("\t</div>\n");
      out.write("\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("<a id=\"googleDiv\" href=\"#map\"\n");
      out.write("\tonclick=\"showHideGoogleMap('");
      out.print(latitude);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(langitude);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friendname);
      out.write("', '");
      out.print(socialsiteIcon);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(loggedinuserlatlang);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(imageName);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(userProfile );
      out.write("')\">Show\n");
      out.write("\tGoogle Map</a>\n");
      out.write("<div class=\"googlemap\" id=\"map\" style=\"display: none;\">\n");
      out.write("\t<div id=\"map_canvas\" style=\"width: 670px; height: 350px;\"></div>\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("</div>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
