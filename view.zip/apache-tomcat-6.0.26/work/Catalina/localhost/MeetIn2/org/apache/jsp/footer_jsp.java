package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class footer_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<p>\n");
      out.write("\t\t\t\t\t<a href=\"index.jsp?ref=home\">Home</a>|\n");
      out.write("\t\t\t\t\t<a href=\"how_it_works.jsp\">How It Works</a>|\n");
      out.write("\t\t\t\t\t<a href=\"features.jsp\">Features</a>|\n");
      out.write("\t\t\t\t\t<a href=\"feedback.jsp\">Feedback</a>|\n");
      out.write("\t\t\t\t\t<a href=\"contact.jsp\">Contact Us</a>|\n");
      out.write("\t\t\t\t\t<a href=\"privacy-policy.jsp\">Privacy Policy</a>|\n");
      out.write("\t\t\t\t\t<a href=\"disclaimer.jsp\">Disclaimer</a>|\n");
      out.write("\t\t\t\t\t<a href=\"support/index.html\" target=\"_blank\">Support</a>\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t\t<p>\n");
      out.write("\t\t\t\t\t&nbsp;\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t\t<p>\n");
      out.write("\t\t\t\t\tmeetIn is an application of <a href=\"http://www.offshoremobiledevelopment.com\" target=\"_blank\" class=\"ft_link\">Verve Mobile Labs</a> | iPhone is\n");
      out.write("\t\t\t\t\ttrademarks of Apple Inc., registered in U.S. and other countries.\n");
      out.write("\t\t\t\t\tApp Store is a service mark of Apple Inc.\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t\t<p class=\"copyright\">\n");
      out.write("\t\t\t\t\tCopyright @ 2012-13 meetIn. All rights reserved.\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t</div>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
