package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.ArrayList;
import com.verve.meetin.trip.Trips;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.List;
import java.util.Enumeration;
import com.verve.meetin.friend.FriendsDAO;
import java.util.Collections;
import java.util.Iterator;

public final class myfriends_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
//System.out.println("/myfriends.jsp"); 
      out.write("\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
      out.write("<html xmlns=\"http://www.w3.org/1999/xhtml\">\n");
      out.write("<head>\n");
      out.write("\n");
      out.write("<!---------------------Google analytics code Start------------------------------->\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("  var _gaq = _gaq || [];\n");
      out.write("  _gaq.push(['_setAccount', 'UA-9594176-7']);\n");
      out.write("  _gaq.push(['_trackPageview']);\n");
      out.write("\n");
      out.write("  (function() {\n");
      out.write("    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;\n");
      out.write("    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';\n");
      out.write("    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);\n");
      out.write("  })();\n");
      out.write("\n");
      out.write("</script>  \n");
      out.write("\n");
      out.write("<!---------------------Google analytics code End ------------------------------->\n");
      out.write("\n");
      out.write("\n");
      out.write("<script src=\"js/jquery.min.js\" type=\"text/javascript\"></script>\n");
      out.write("  <script type=\"text/javascript\" src=\"js/meetin.js\"></script> \n");
      out.write("   <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.js\">\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">var switchTo5x=true;</script>\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\tstLight.options({publisher: \"222fb8d2-36c2-4e83-85c1-f92516365e7c\", doNotHash: true, doNotCopy: true, hashAddressBar: true});\n");
      out.write("</script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/buttons.js\"></script>\n");
      out.write("\n");
      out.write("\n");
      out.write("<meta property=\"og:title\" content=\"mymeetin\" /> \n");
      out.write("<meta property=\"og:url\" content=\"http://mymeetin.com\" /> \n");
      out.write("<meta property=\"og:image\" content=\"http://www.mymeetin.com/images/logo_small.png\" />\n");
      out.write("<meta property=\"og:description\" content=\"meet your friends from some of the most popular social networking sites\" /> \n");
      out.write("<meta property=\"og:site_name\" content=\"http://mymeetin.com\" /> \n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"js/nicEdit-latest.js\"></script> \n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("//<![CDATA[\n");
      out.write("bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });\n");
      out.write("//]]>\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\t\t\tfunction doAction() {\n");
      out.write("\t\t\t\tif ($('#flag').val() == 0) {\n");
      out.write("\t\t\t\t$('#sentmsg').text('');\n");
      out.write("\t\t\t\t\t$('#flag').val(1);\n");
      out.write("\t\t\t\t\t$('#frmsection').show();\n");
      out.write("\t\t\t\t\t$('#frmsection').animate({ marginLeft: '0px' }, 1000);\n");
      out.write("\t\t\t\t\t$('#PatientName').focus();\n");
      out.write("\t\t\t\t} else {\n");
      out.write("\t\t\t\t\t$('#flag').val(0);\n");
      out.write("\t\t\t\t\t$('#frmsection').animate({ marginLeft: '-320px' }, 1000);\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t}\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t</script>\n");
      out.write("\t\t\n");
      out.write("\t<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("\tfunction resetfields()\n");
      out.write("\t{\n");
      out.write("\t   document.getElementById(\"friendemail\").value =\"\";\n");
      out.write("\t   document.getElementById(\"friendemail\").focus();\n");
      out.write("\t}\n");
      out.write("\t</script>\t\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("function validate()\n");
      out.write("{\n");
      out.write("\talert(\"validate\");\n");
      out.write("}\n");
      out.write("\n");
      out.write("function ValidatefriendemailInvite()\n");
      out.write("{\n");
      out.write("\tvar array = document.getElementById(\"friendemail\").value;\n");
      out.write("\tvar arr = array.split(\",\");\n");
      out.write("\tif(arr.length > 10)\n");
      out.write("\t{\n");
      out.write("\t\talert(\"Maximum 10 friends can be invited at a time.\");\n");
      out.write("\t\treturn ;\n");
      out.write("\t}\n");
      out.write("\tfor(i=0;i<arr.length;i++)\n");
      out.write("\t{\n");
      out.write("\t\tvar atpos=arr[i].indexOf(\"@\");\n");
      out.write("\t\tvar dotpos=arr[i].lastIndexOf(\".\");\n");
      out.write("\t\tif (atpos<1 || dotpos<atpos+2 || dotpos+2>=arr[i].length)\n");
      out.write("  \t\t{\n");
      out.write("  \t\t\t\talert(\"Please enter valid email address\");\n");
      out.write("  \t\t\t\treturn;\n");
      out.write("  \t\t}\n");
      out.write("\t}\n");
      out.write("\tvar mail=document.getElementById(\"friendemail\").value;\n");
      out.write("\tvar msg =document.getElementById(\"invite\").innerHTML;  \n");
      out.write("\tvar url = \"invitefriendPopup.jsp?mail=\"+ mail+\"&msg=\"+msg;\n");
      out.write("\tvar inviteFriends = getXmlHttpRequestObject();\n");
      out.write("\tif(inviteFriends.readyState == 4 || inviteFriends.readyState == 0){\n");
      out.write("\t\tinviteFriends.open(\"get\", url, true);\n");
      out.write("\t\tinviteFriends.onreadystatechange = function(){\n");
      out.write("\t\t\tif(inviteFriends.readyState == 4 && inviteFriends.status == 200){\n");
      out.write("\t\t\t\t//document.getElementById(\"loading\").style.display = 'none';\n");
      out.write("\t\t\t\t//document.getElementById(\"sentmsg\").style.display ='block';\n");
      out.write("\t\t\t\tdocument.getElementById(\"sentmsg\").innerHTML =inviteFriends.responseText;\n");
      out.write("\t\t\t\tdocument.getElementById(\"friendemail\").value=\"\";\n");
      out.write("\t\t\t}\n");
      out.write("\t\t}\n");
      out.write("\t\tinviteFriends.send(null);\n");
      out.write("\t}\n");
      out.write("\t\n");
      out.write("}\n");
      out.write("</script>\t\t\n");
      out.write("\n");

	String imagePath = request.getScheme() + "://"
					+ request.getServerName() + ":" + request.getServerPort()
					+ request.getContextPath();
 
      out.write("\n");
      out.write("\n");
      out.write("<meta http-equiv='cache-control' content='no-cache'><meta http-equiv='expires' content='0'><meta http-equiv='pragma' content='no-cache'>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
      out.write("<meta http-equiv=\"refresh\" content=\"");
      out.print(session.getMaxInactiveInterval());
      out.write("; URL=");
out.println(imagePath+"/session_invalidate.jsp");
      out.write("\" />\n");
      out.write("<title>meetIn - My Friend Page</title>\n");
      out.write("<link rel=\"shortcut icon\" href=\"images/meetin_icon.png\" />\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write("<script type=\"text/javascript\" src=\"js/meetin.js\"></script>\n");
      out.write("<script src=\"js/jquery.min.js\" type=\"text/javascript\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write("</head>\n");
	String socialNetwork = "meetIn"; 
	if(request.getParameter("socialNetwork") != null) {
      out.write('\n');
      out.write('	');
 socialNetwork = request.getParameter("socialNetwork"); 
      out.write(' ');
      out.write('\n');
} 
      out.write("\n");
      out.write("<body onload=\"viewFriends('meetIn','0');\">\n");
      out.write("<div class=\"wrapper\">\n");
      out.write("\t<!--mainsite starts here -->\n");
      out.write("\t<div class=\"mainsite\">\n");
      out.write("\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, false);
      out.write("\n");
      out.write("    \t<div class=\"leftside\">\n");
      out.write("    \t<a href=\"index.jsp\">\n");
      out.write("    \t<div class=\"logo\"></div>\n");
      out.write("    \t</a>\n");
      out.write("        \t<div class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("                  \t\t<div class=\"buttoncontainer\">\n");
      out.write("                        \t<div><img src=\"images/myfriends_icon.png\"/><input type=\"button\" class=\"iphonebutton active\" value=\"My Friends\"></div>\n");
      out.write("                            <div style=\"position: relative\"><img src=\"images/pending_request_icon.png\"/><input type=\"button\" class=\"iphonebutton\" value=\"Pending Request\" onclick=\"callPendingFriendRequest();\" />");
if(session.getAttribute("CountPendingRequest") != null){
      out.write("\n");
      out.write("                            <span style=\"-moz-border-radius:4px 4px 4px 4px;background-color: red;top: 0px;right: 0px;margin-right: 8px; font-size:10px; color:#FFFFFF;margin-left: -25px;margin-top: 5px;padding: 2px 4px;position: absolute;\"><strong>");
      out.print(session.getAttribute("CountPendingRequest") );
      out.write("</strong></span>");
} 
      out.write("</div>\n");
      out.write("                            <div><img src=\"images/search_friends_icon.png\"/><input type=\"button\" class=\"iphonebutton\" value=\"Search Friends\" onclick=\"callSearchFriend();\"/></div>\n");
      out.write("                            <div><img src=\"images/Invite_friends_icon.png\"/><input type=\"button\" class=\"iphonebutton\" value=\"Invite Friends\" onclick=\"callInviteFriend();\"/></div>\n");
      out.write("                        </div>\n");
      out.write("               \t\t  \t<img id=\"screen1\" src=\"images/myfriends_bg.jpg\" />\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\t\n");
      out.write("            </div>\n");
      out.write("            \n");
      out.write("           \n");
      out.write("    <div class=\"appstore\" style=\"margin-left: 12px;\"><a href=\"https://itunes.apple.com/us/app/meetin/id590629564?ls=1&mt=8\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-iphone.png\"  style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-midtext.png\" style=\"float: left\"/> </a><a href=\"https://play.google.com/store/apps/details?id=com.meetin&feature=search_result#?t=W251bGwsMSwyLDEsImNvbS5tZWV0aW4iXQ..\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-androide.png\" style=\"float: left\"/>  </div></a> \n");
      out.write("\n");
      out.write("            <a href=\"how_it_works.jsp\"><div class=\"appvideo\"><img id=\"appvideo\" src=\"images/appvideo_new.png\" /></div></a>\n");
      out.write("            \n");
      out.write("            <div class=\"followus\">\n");
      out.write("            \tFollow Us on:\n");
      out.write("                <div class=\"socialnetwork\">\n");
      out.write("                 <a href=\"javascript:void(0)\" onclick=\"window.open('https://www.facebook.com/pages/MeetIn/495222843824206', '_blank')\">\n");
      out.write("                <div class=\"facebook\"></div></a>\n");
      out.write("             \n");
      out.write("                 <a href=\"javascript:void(0)\" onclick=\"window.open('https://twitter.com/mymeetIn', '_blank')\"><div class=\"twitter\"></div></a>\n");
      out.write("                  <a href=\"javascript:void(0)\" onclick=\"window.open('https://plus.google.com/b/108083242642551656394/?partnerid=gplp0', '_blank')\">\n");
      out.write("                 <div class=\"google_plus\"></div></a>\n");
      out.write("                </div>\n");
      out.write("            </div>\n");
      out.write("        </div>\n");
      out.write("        \n");
      out.write("        <div class=\"rightside\">\n");
      out.write("        \t<div id=\"navigation\">\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"peoplefinder.do?action=people\"><span>People Finder</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"addtrip.jsp\"><span>My Travel Plan</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn active\"><a href=\"#\"><span>My Friends</span>\n");
      out.write("                \n");
      out.write("                \n");
      out.write("                \t\t\t\t    ");

                	// Code done for showing friend request pending in menu tab
                	
                	int id = Integer.parseInt(session.getAttribute("UserID").toString());
                	//System.out.println("id for the user is ---------------  "+id);
                	Long p = new FriendsDAO().getUserPendingRequestCount(id);
                	//System.out.println("pending request is ---   "+p);
               	            
                if(p != null || p > 0){
                	
                	
                	if(p>0 &&  p<10)
                	{
                	
                 //System.out.println("inside if case ---------- ");
      out.write("\n");
      out.write("                            <span class=\"fr_request\">\n");
      out.write("                            <strong>");
      out.print(p);
      out.write("</strong></span>\n");
      out.write("                            \n");
      out.write("                     ");
}
                           
                   	 if(p >9)  {
      out.write("\n");
      out.write("                                <span class=\"fr_request\">\n");
      out.write("                            <strong>9+</strong></span>\n");
      out.write("                      ");
} } 
      out.write("\n");
      out.write("            \n");
      out.write("                \n");
      out.write("                \n");
      out.write("            \n");
      out.write("                \n");
      out.write("                \n");
      out.write("                </a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"myprofile.jsp?action=profilevisitors\"><span>My Profile</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"contact.jsp\"><span>Contact Us</span></a></div>                \n");
      out.write("        \t</div>\n");
      out.write("        \t<!-- These two divs are used to show lightbox popup for user profile details -->\n");
      out.write("\t\t\t\t<!-- Start Div -->\n");
      out.write("\t\t\t\t\t<div id=\"light\" class=\"white_content\"></div>\n");
      out.write("\t\t\t\t\t<div id=\"fade\" class=\"black_overlay\"></div>\n");
      out.write("\t\t\t\t<!-- End Div -->\n");
      out.write("            <div style=\"overflow:hidden; height:auto\">\n");
      out.write("                <div class=\"innercontainer\">\n");
      out.write("                \n");
      out.write("                <div class=\"question-icon\" style=\"clear:both;overflow:hidden ;font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\">\n");
      out.write("\t\t\t\t\t\t<p style=\"float: right;\"><a href=\"javascript:Questionfnc('My Friends')\">\n");
      out.write("\t\t\t<img src=\"images/icon-question.png\" alt=\"\" style=\"height: 24px;\" />\n");
      out.write("\t\t\t\t\t\t </a></p> </div>\n");
      out.write("                \n");
      out.write("\t\t\t\t\t<div class=\"heading\">\n");
      out.write("                    \t<img src=\"images/myfriends.png\" align=\"absbottom\"/> View Your Friends\n");
      out.write("                    </div>\n");
      out.write("                    <div class=\"networkfrm\">\n");
      out.write("                    <div class=\"img\"><img src=\"images/meetin_icon.png\" /></div>\n");
      out.write("                    <div class=\"lable\"><a href=\"#\" onclick=\"document.getElementById('loading').style.display='block';setTimeout('viewFriends(\\'meetIn\\',\\'0\\')',1000);\">meetIn</a></div>\n");
      out.write("                    ");

                       if(request.getAttribute("socialnetworklist") !=null)
                       {
                          ArrayList resultList = (ArrayList)request.getAttribute("socialnetworklist");
                          for(int i = 0; i < resultList.size();i++)
                          {
                           
                             Object[] object = (Object[]) resultList.get(i);
                       
                       		if( ((String)object[0]).toString().equalsIgnoreCase("Tripit"))
                       		{
                       			System.out.println((String)object[0]);
                       			continue;
                       		}      
                    
      out.write("\n");
      out.write("                      \t<div class=\"frmline\"></div>\n");
      out.write("                    \t<div class=\"img\"><img src=\"");
      out.print((String)object[1] );
      out.write("\" /></div>\n");
      out.write("                        <div class=\"lable\"><a href=\"#\" onclick=\"document.getElementById('loading').style.display='block';setTimeout('viewFriends(\\'");
      out.print((String)object[0] );
      out.write("\\',\\'");
      out.print((Integer) object[2]);
      out.write("\\')',1000);return false;\">");
      out.print((String)object[0] );
      out.write("</a></div>\n");
      out.write("                    ");
		 
                          }
                       }
                      
			 		
      out.write("\n");
      out.write("\t\t\t \t\t<div class=\"frmline\"></div>\n");
      out.write("                    <div class=\"img\"><img src=\"images/all_friends.png\" /></div>\n");
      out.write("                    <div class=\"lable\"><a href=\"#\" onclick=\"document.getElementById('loading').style.display='block';setTimeout('viewFriends(\\'All\\',\\'10\\')',1000);\">All Friends</a></div>\n");
      out.write("                    </div>\n");
      out.write("                </div><!-- content ends here -->\n");
      out.write("                \n");
      out.write("                <!-- Ajax loader content start here -->\n");
      out.write("  \t\t\t\t<!--<div id=\"loading\" style=\"width: 100%;height: 100%;top:0;left: 0;position: fixed;display: none;opacity:0.7;z-index: 99;text-align: center;\">\n");
      out.write("  \t\t\t\t<img src=\"images/ajax-loader_new.gif\" alt=\"Loading....\" style=\"position: absolute;top: 260px;left: 650px;z-index: 100;\" />\n");
      out.write("  \t\t\t\t</div>\n");
      out.write("  \t\t\t\t-->\n");
      out.write("  \t\t\t\t<div id=\"loading\" style=\"width: 100%;height: 100%;top:0;left: 0;position: fixed;display: none;opacity:0.7;z-index: 99999;text-align: center; background-color: #000000; \"><!--\n");
      out.write("  \t\t\t\t<img src=\"images/ajax-loader_new.gif\" alt=\"Loading....\" style=\"position: absolute;top: 260px;left: 650px;z-index: 100;\" />\n");
      out.write("  \t\t\t\t-->\n");
      out.write("  \t\t\t\t<div  style=\"border: 2px solid #FFFFFF; left: 650px; position: absolute; background-color: #FFFFFF; top: 170px; padding: 10px; width: 150px; color: #000000;\"> \n");
      out.write("\t\t\t\t\t<p><img vspace=\"5\" src=\"images/ajax-loader_new.gif\" alt=\"Loading....\" style=\"z-index: 100;\"></p> \n");
      out.write("\t\t\t\t\t<p>Taking too long ?</p>\n");
      out.write("\t\t\t\t\t<br/> \n");
      out.write("\t\t\t\t\t<p>\n");
      out.write("\t\t\t\t\t\t<a href=\"friend.do?fparam=myfriends\" >Cancel</a> \n");
      out.write("\t\t\t\t\t</p>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("  \t\t\t\t</div>\n");
      out.write("  \t\t\t\t<!-- Ajax loader content end here -->\n");
      out.write("  \t\t\t\t<!-- Display MeetIn Friends as Default friend List -->\n");
      out.write("  \t\t\t\t<!--  Start Tag here -->\n");
      out.write("  \t\t\t\t\n");
      out.write("       </div>\n");
      out.write("       <!-- The below Div tag display the Friends based on Social network site selected by User -->\n");
      out.write("        <div id=\"myfriendlist\"></div> \n");
      out.write("             \n");
      out.write("    </div><!--mainsite starts here -->\n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    <!-- div for invite friends -->\n");
      out.write("    \n");
      out.write("    ");
if( session.getAttribute("name") != null )
    {    
    
      out.write("\n");
      out.write("    \n");
      out.write("    <div class=\"popup-slide\">\n");
      out.write("            <div id=\"frmsection\">\n");
      out.write("                \n");
      out.write("                ");
      //  html:form
      org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f0 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_005fform_005f0.setPageContext(_jspx_page_context);
      _jspx_th_html_005fform_005f0.setParent(null);
      // /myfriends.jsp(324,16) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setAction("/friend");
      // /myfriends.jsp(324,16) name = method type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setMethod("get");
      // /myfriends.jsp(324,16) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setStyleId("frminvitefriend");
      // /myfriends.jsp(324,16) name = onsubmit type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setOnsubmit("return Validatefriendemail();");
      int _jspx_eval_html_005fform_005f0 = _jspx_th_html_005fform_005f0.doStartTag();
      if (_jspx_eval_html_005fform_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\n");
          out.write("                     <input type=\"hidden\" name=\"fparam\" value=\"invitefriend\" />    \n");
          out.write("                \n");
          out.write("            <div>    \n");
          out.write("            <div id=\"sentmsg\" style=\"color: green;font-size: 13px;float: right;\">\n");
          out.write("            \n");
          out.write("            </div>\n");
          out.write("                <div class=\"lable\">Friend's Email</div>\n");
          out.write("                <div>\n");
          out.write("                            ");
          if (_jspx_meth_html_005ftext_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                </div>\n");
          out.write("                \n");
          out.write("                <div>\n");
          out.write("                <span class='st_sharethis_large' displayText='ShareThis'></span>\n");
          out.write("                </div>\n");
          out.write("                \n");
          out.write("            </div>\n");
          out.write("            <div>\n");
          out.write("                            \n");
          out.write("                            <div class=\"lable\">Invite Message</div>\n");
          out.write("                \n");
          out.write("                <textarea  id=\"invitemessage\" name=\"invitemessage\" rows=\"3\" cols=\"10\" >\n");
          out.write("                <div id=\"invite\">\n");
          out.write("                <p>\n");
          out.write(" ");
          out.print(session.getAttribute("name") );
          out.write(" would like to invite you to use meetIn (<a href=\"http://www.mymeetin.com\">www.mymeetin.com</a>) to keep in touch with your friends, family, colleagues while you or they are traveling.\n");
          out.write("</p>\n");
          out.write("<p><br/>\n");
          out.write("meetIn connects to some of the most popular social networking sites and gets you updated information even when you are traveling, at home or when your friends are traveling.\n");
          out.write("</p>\n");
          out.write("<p><br/>\n");
          out.write("meetIn is also available now on iPhone and Android.\n");
          out.write("</p>\n");
          out.write("<p><br/>\n");
          out.write("Register now and meet me on meetIn.\n");
          out.write("</p>\n");
          out.write(" </div>\n");
          out.write("</textarea>\n");
          out.write("                \n");
          out.write("</div>                  \n");
          out.write("    <p align=\"right\" style=\"font-size: 12px; margin-bottom: 5    px; margin-top: 10px;\">\n");
          out.write("                                Invite friends separated by comma\n");
          out.write("    </p>          \n");
          out.write("    \n");
          out.write("    <div>\n");
          out.write("     \n");
          out.write("     \n");
          out.write("     <input type=\"button\" value=\"Invite\" onclick=\"ValidatefriendemailInvite();\"/>\n");
          out.write("                        <input type=\"button\"  value=\"Clear\" onclick=\"resetfields();\" />                    \n");
          out.write("    </div>                \n");
          out.write("                ");
          int evalDoAfterBody = _jspx_th_html_005fform_005f0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_005fform_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
        return;
      }
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
      out.write("\n");
      out.write("                    \n");
      out.write("            </div>\n");
      out.write("            <input id=\"flag\" type=\"hidden\" value=\"0\">\n");
      out.write("            <input type=\"button\" name=\"action\" id=\"say\" onclick=\"doAction()\" class=\"popup-slide-btn\">\n");
      out.write("        </div>\n");
      out.write("    ");
} 
      out.write("\n");
      out.write("    \n");
      out.write("    \n");
      out.write("<!-- Invite friend div end here  -->\n");
      out.write("    \n");
      out.write("    \n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("    <div class=\"footer\">\n");
      out.write("    \t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, false);
      out.write("\t\t\n");
      out.write("    </div><!--footer ends here -->\n");
      out.write("  </div>\n");
      out.write("</div>\n");
      out.write("</body>\n");
      out.write("</html>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_html_005ftext_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f0 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /myfriends.jsp(333,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setProperty("friendemail");
    // /myfriends.jsp(333,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleId("friendemail");
    // /myfriends.jsp(333,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleClass("text-input");
    int _jspx_eval_html_005ftext_005f0 = _jspx_th_html_005ftext_005f0.doStartTag();
    if (_jspx_th_html_005ftext_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
    return false;
  }
}
