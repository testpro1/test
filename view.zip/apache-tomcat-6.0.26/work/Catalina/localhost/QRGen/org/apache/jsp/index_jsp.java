package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\n");
      out.write("  <head>\n");
      out.write("  <link rel=\"stylesheet\" href=\"css/cropper.css\" type=\"text/css\" ></link>\n");
      out.write("<script type=\"text/javascript\" src=\"js/cropper.js\"></script>\n");
      out.write("\n");
      out.write("    <script type=\"text/javascript\" src=\"js/jquery.min.js\"></script>\n");
      out.write("  <script type=\"text/javascript\" src=\"js/jscolor.js\"></script>\n");
      out.write("  <link rel=\"stylesheet\" href=\"css/validationEngine.jquery.css\" type=\"text/css\"></link>\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.validationEngine-en.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.validationEngine.js\"></script>\n");
      out.write("\t\n");
      out.write("\t<title>Bluads QR Code Generator</title>\n");
      out.write("\t<style type=\"text/css\">\n");
      out.write("\t\tbody {\n");
      out.write("\t\t\tfont-family: sans-serif;\n");
      out.write("\t\t}\n");
      out.write("\t\t.data, .data td {\n");
      out.write("\t\t\tborder-collapse: collapse;\n");
      out.write("\t\t\twidth: 100%;\n");
      out.write("\t\t\tborder: 1px solid #aaa;\n");
      out.write("\t\t\tmargin: 5px;\n");
      out.write("\t\t\tpadding: 5px;\n");
      out.write("\t\t}\n");
      out.write("\t\t.data tr {\n");
      out.write("\t\t\tfont-weight: bold;\n");
      out.write("\t\t\tbackground-color: #5C82FF;\n");
      out.write("\t\t\tcolor: white;\n");
      out.write("\t\t\tmargin: 5px;\n");
      out.write("\t\t\tpadding: 5px;\n");
      out.write("\t\t}\n");
      out.write("\t\t.textbox\n");
      out.write("\t\t{ \n");
      out.write("\t\t\tmargin:5px 0px;\n");
      out.write("\t\t}\n");
      out.write("\t\tlabel { \n");
      out.write("\t\t\tclear: left;\n");
      out.write("\t\t\tmargin-left: 50px;\n");
      out.write("\t\t\tfloat: left;\n");
      out.write("\t\t\twidth: 5em;\n");
      out.write("\t\t}\n");
      out.write("\t\t\n");
      out.write("\t\t#testWrap {\n");
      out.write("\t\t\twidth: 300px;\n");
      out.write("\t\t\tfloat: left;\n");
      out.write("\t\t\tmargin: 20px 0 0 50px; /* Just while testing, to make sure we return the correct positions for the image & not the window */\n");
      out.write("\t\t}\n");
      out.write("\t\t\n");
      out.write("\t\t#previewArea {\n");
      out.write("\t\t\tmargin: 20px; 0 0 20px;\n");
      out.write("\t\t\tfloat: left;\n");
      out.write("\t\t}\n");
      out.write("\t\t\n");
      out.write("\t\t#results {\n");
      out.write("\t\t\tclear: both;\n");
      out.write("\t\t}\n");
      out.write("\t</style>\n");
      out.write("\t<script>\n");
      out.write("\t//JQuery Validation function for image file \n");
      out.write("\t\tif (jQuery){\n");
      out.write("\t\t\tjQuery(function(jQuery) {\n");
      out.write("\n");
      out.write("\t\t\t\tjQuery('#frmDetails input[type=\"submit\"]').click(function(e){\n");
      out.write("\t\t\t\t\tvar form = jQuery('#frmDetails');\n");
      out.write("\t\t\t\t\tvar file = jQuery('input[type=\"file\"]', form).val();\n");
      out.write("\t\t\t\t\tvar exts = ['jpg','jpeg','gif','png'];\n");
      out.write("\t\t\t\t\tvar msg = jQuery('.msg', form);\n");
      out.write("\t\t\t\t\tmsg.hide();\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t\t// first check if file field has any value\n");
      out.write("\t\t\t\t\tif ( file ) {\n");
      out.write("\t\t\t\t\t\t// split file name at dot\n");
      out.write("\t\t\t\t\t\tvar get_ext = file.split('.');\n");
      out.write("\t\t\t\t\t\t// reverse name to check extension\n");
      out.write("\t\t\t\t\t\tget_ext = get_ext.reverse();\n");
      out.write("\n");
      out.write("\t\t\t\t\t\t// check file type is valid as given in 'exts' array\n");
      out.write("\t\t\t\t\t\tif ( jQuery.inArray ( get_ext[0].toLowerCase(), exts ) > -1 ){\n");
      out.write("\t\t\t\t\t\t//\tmsg.show().html( '<strong style=\"color:#090\">Allowed extension!</strong>' );\n");
      out.write("\t\t\t\t\t\t}\n");
      out.write("\t\t\t\t\t\t else {\n");
      out.write("\t\t\t\t\t\t\tmsg.show().html( '<strong style=\"color:#f00\">Invalid file!</strong>' );\n");
      out.write("\t\t\t\t\t\t\treturn false;\n");
      out.write("\t\t\t\t\t\t}\n");
      out.write("\t\t\t\t\t}else{\n");
      out.write("\t\t\t\t\t\tmsg.show().html( '<strong style=\"color:#f00\">Please select file!</strong>' );\n");
      out.write("\t\t\t\t\t\treturn false;\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t}\n");
      out.write("\t\t\t\t});\n");
      out.write("\n");
      out.write("\t\t\t});\n");
      out.write("\t\t}\n");
      out.write("\t\t// JQuery function for preview of an image.\n");
      out.write("\t    function readURL(input) {\n");
      out.write("\t\t    if (input.files && input.files[0]) {\n");
      out.write("\t\t    var reader = new FileReader();\n");
      out.write("\t\t    reader.onload = function (e) {\n");
      out.write("\t\t    jQuery('#img_prev')\n");
      out.write("\t\t    .attr('src', e.target.result)\n");
      out.write("\t\t    .width(80)\n");
      out.write("\t\t    .height(80);\n");
      out.write("\t\t    };\n");
      out.write("\t\t    reader.readAsDataURL(input.files[0]);\n");
      out.write("\t\t    }\n");
      out.write("\t    }\n");
      out.write("\t   function showImage() {\n");
      out.write("\t       \tvar e=document.getElementById('testWrap');\n");
      out.write("\t       \t//e.style.display ='block';\t\n");
      out.write("\t       \t//preview(); \n");
      out.write("\t    }\n");
      out.write("\t    \n");
      out.write("\t  function preview() \n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\talert(\"\");\n");
      out.write("\t\t\t\tjQuery(\".imgCrop_dragArea\").empty();\n");
      out.write("\t\t\t\tnew Cropper.ImgWithPreview\n");
      out.write("\t\t\t\t('img_prev',\n");
      out.write("\t\t\t\t\t{ \n");
      out.write("\t\t\t\t\t\tminWidth: 200, \n");
      out.write("\t\t\t\t\t\tminHeight: 120,\n");
      out.write("\t\t\t\t\t\tratioDim: { x: 200, y: 120 },\n");
      out.write("\t\t\t\t\t\tdisplayOnInit: true, \n");
      out.write("\t\t\t\t\t\tonEndCrop: onEndCrop,\n");
      out.write("\t\t\t\t\t\tpreviewWrap: 'previewArea'\n");
      out.write("\t\t\t\t\t} \n");
      out.write("\t\t\t\t) \n");
      out.write("\t\t\t} \n");
      out.write("\tfunction onEndCrop( coords, dimensions ) {\n");
      out.write("  \t\t\talert(\"end crop\");\n");
      out.write("\t\t\t$( 'x1' ).value = coords.x1;\n");
      out.write("\t\t\t$( 'y1' ).value = coords.y1;\n");
      out.write("\t\t\t$( 'x2' ).value = coords.x2;\n");
      out.write("\t\t\t$( 'y2' ).value = coords.y2;\n");
      out.write("\t\t\t$( 'width' ).value = dimensions.width;\n");
      out.write("\t\t\t$( 'height' ).value = dimensions.height;\n");
      out.write("\t\t}\t\t\n");
      out.write("    </script>\n");
      out.write("    <script>\n");
      out.write("    //JQuery function for inline validation.\n");
      out.write("\tjQuery.noConflict();\n");
      out.write("\t\n");
      out.write("\tjQuery(document).ready(function() {\n");
      out.write("\t\t\t\tjQuery(\"#frmDetails\").validationEngine({inlineValidation: false})\n");
      out.write("\t});\n");
      out.write("</script>\n");
      out.write("</head>\n");
      out.write("  \n");
      out.write("  <body>\n");
      out.write("\t<h2>Bluads QR Code Generator</h2>\n");
      out.write("\t<form action=\"qrcode\" method=\"post\" enctype=\"multipart/form-data\" id=\"frmDetails\">\n");
      out.write("\t\n");
      out.write("\t\t<table>\n");
      out.write("\t\t\t<tr><td>URL :</td>\n");
      out.write("\t\t\t\t<td><input type=\"text\" name=\"url\" class=\"validate[required,custom[url]] textbox\" id=\"url\" value=\"http://\"/></td>\t\t\t\t\n");
      out.write("\t\t\t</tr>\n");
      out.write("\t\t\t<tr><td>Top Label :</td>\n");
      out.write("\t\t\t\t<td><input type=\"text\" name=\"top\" maxlength=\"100\" class=\"validate[required] textbox\" id=\"top\"/></td>\n");
      out.write("\t\t\t</tr>\n");
      out.write("\t\t\t<tr><td>Bottom Label :</td>\n");
      out.write("\t\t\t\t<td><input type=\"text\" name=\"bottom\" maxlength=\"100\" class=\"validate[required] textbox\" id=\"bottom\"/></td>\n");
      out.write("\t\t\t</tr>\n");
      out.write("\t\t\t<tr><td>Right Label :</td>\n");
      out.write("\t\t\t\t<td><input type=\"text\" name=\"right\" maxlength=\"25\" class=\"validate[required] textbox\" id=\"right\"/></td>\n");
      out.write("\t\t\t</tr>\n");
      out.write("\t\t\t<tr><td>Offer Details :</td>\n");
      out.write("\t\t\t\t<td><textarea rows=\"4\" name=\"offer\" class=\"validate[required] textbox\" id=\"offer\"></textarea></td>\n");
      out.write("\t\t\t</tr>\n");
      out.write("\t\t\t<tr><td></td><td>Select jpg/jpeg/gif/png File</td></tr>\n");
      out.write("\t\t\t<tr><td>Logo/Image offer :</td>\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t<td><input type='file' onchange=\"readURL(this);\" class=\"textbox\" name=\"file\" id=\"file\"/>\n");
      out.write("\t\t\t\t  </td>\t\t\t\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t<td>\t\n");
      out.write("\t\t\t\t\t<img id=\"img_prev\" src=\"#\" alt=\"Logo Image\" />\t\t\t\n");
      out.write("\t\t\t\t</td>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t<td><p class=\"msg\"></p></td>\t\t\t\t\n");
      out.write("\t\t\t</tr>\n");
      out.write("\t\t\t<tr><td>Border Color :</td>\n");
      out.write("\t\t\t \t<td><input class=\"color\" name=\"color\"/></td>\n");
      out.write("\t\t\t</tr>\n");
      out.write("\t\t</table>\n");
      out.write("\t\t<div style=\"margin-top: 20px;\">\n");
      out.write("\t\t\t<input type=\"submit\" value=\"Generate QR Code\" />\n");
      out.write("\t\t</div>\n");
      out.write("\t</form>\n");
      out.write("\n");
      out.write("  </body>\n");
      out.write("</html>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
