package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.hibernate.controller.cropper;

public final class NewCrop_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"\n");
      out.write("\"http://www.w3.org/TR/html4/loose.dtd\">\n");
      out.write("<html>\n");
      out.write("  <head>\n");
      out.write("    <script type=\"text/javascript\" src=\"js/jquery.min.js\"></script>\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/jquery.Jcrop.min.js\"></script>\n");
      out.write("\t<link rel=\"stylesheet\" href=\"css/jquery.Jcrop.css\" type=\"text/css\" />\n");
      out.write("    <title>Crop and save</title>\n");
      out.write("  </head>\n");
      out.write("  <body>\n");
      out.write("    <img src=\"detroit-nights.jpg\" id=\"cropbox\" height=\"400\" width=\"400\" />\n");
      out.write("\n");
      out.write("    <script type=\"text/javascript\">\n");
      out.write("      $(window).load(function(){\n");
      out.write("        var jcrop_api;\n");
      out.write("        initJcrop();\n");
      out.write("        function initJcrop()//{{{\n");
      out.write("        {\n");
      out.write("          jcrop_api = $.Jcrop('#cropbox',{ onChange: setCoords, onSelect: setCoords });\n");
      out.write("          jcrop_api.setSelect([100,100,300,300]);\n");
      out.write("          jcrop_api.setOptions({ allowSelect: true, allowMove: true, allowResize: true, aspectRatio: 1 });\n");
      out.write("        }\n");
      out.write("      });\n");
      out.write("      function setCoords(c)\n");
      out.write("      {\n");
      out.write("        jQuery('#x1').val(c.x);\n");
      out.write("        jQuery('#y1').val(c.y);\n");
      out.write("        jQuery('#x2').val(c.x2);\n");
      out.write("        jQuery('#y2').val(c.y2);\n");
      out.write("        jQuery('#w').val(c.w);\n");
      out.write("        jQuery('#h').val(c.h);\n");
      out.write("      };      \n");
      out.write("    </script>\n");
      out.write("    <form action=\"cropper\" method=\"post\" >\n");
      out.write("      <input type=\"hidden\" name=\"x1\" id=\"x1\"/>\n");
      out.write("      <input type=\"hidden\" name=\"y1\" id=\"y1\"/>\n");
      out.write("      <input type=\"hidden\" name=\"x2\" id=\"x2\"/>\n");
      out.write("      <input type=\"hidden\" name=\"y2\" id=\"y2\"/>\n");
      out.write("      <input type=\"hidden\" name=\"w\" id=\"w\"/>\n");
      out.write("      <input type=\"hidden\" name=\"h\" id=\"h\"/>\n");
      out.write("      \t<input type=\"hidden\" size=\"4\" id=\"f\" name=\"f\" value=\"jpg\" />\n");
      out.write("        <input type=\"hidden\" size=\"4\" id=\"i\" name=\"i\" value=\"detroit-nights.jpg\"/>\n");
      out.write("      <input type=\"submit\" value=\"Crop\" name=\"action\" />\n");
      out.write("    </form>\n");
      out.write("  </body>\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
