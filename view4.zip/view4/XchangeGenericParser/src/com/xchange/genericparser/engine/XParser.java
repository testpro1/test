package com.xchange.genericparser.engine;

import java.awt.Event;
import java.io.*;
import org.apache.commons.logging.*;
import com.xchange.Exceptions.*;
import com.xchange.FileUtils.*;
import com.xchange.genericparser.conversion.WriterFactory;
import com.xchange.genericparser.engine.ParserConfig.DataConverter;
import com.xchange.xchangewriter.XchangeParserProperties;

public class XParser implements Parser//, Runnable
{
	private static Log log = LogFactory.getLog(XParser.class);//Logger(MethododBase.GetCurrentMethod().DeclaringType);
    private DataConverter _dataConverter;
	private URWriter _urWriter;
	public Event reportProgressEventHandler;
	public Event ParsingCompleteEventHandler;		
	
	public XParser(DataConverter dataConvertor)
	{
		//default constructor
		this._dataConverter = dataConvertor;
		try {
			this._urWriter =(URWriter)WriterFactory.getWriter(_dataConverter);
            if (log.isInfoEnabled())
            {
            	log.info("Created URWriter.");
            }
		} 
		catch (Exception ex)
		{
			log.error("Failed to create URWriter!");
            log.error(ex);
			try {
				throw (ex);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	@Override
	public void parse() throws ParameterNotSupportedException 
	{
		if (_dataConverter.watchMethod.toString().equals(DataConverterWatchmethod.onetime.toString())) 
		{
			try {
				oneTimeParser();
			} catch (BlankSourceFileException e) {
				System.out.println(e+"-"+e.get_destination()+""+e.get_source());
			}			
		}
		else if (_dataConverter.watchMethod.equals(DataConverterWatchmethod.eventbased)) 
		{
			eventBasedParser();
		}
		else if (_dataConverter.watchMethod.equals(DataConverterWatchmethod.polling)) 
		{
			try {
				poolingParser();
			} catch (BlankSourceFileException e) {
				
				System.out.println(e+"-"+e.get_destination()+""+e.get_source());
			}
		}
		else 
		{
			throw new ParameterNotSupportedException(_dataConverter.watchMethod.toString());
		}
	}	
	private void parseFile(File file)
	{
		if(log.isDebugEnabled())
		{
			log.debug("IN");
		}
		parseFile(file.getAbsolutePath());
		if(log.isDebugEnabled())
		{
			log.debug("OUT");
		}
	}	
	private void parseFile(String fileName){
		if(log.isDebugEnabled()) {
			log.debug("IN");
		}
		this._urWriter.convert(fileName);
		if(log.isDebugEnabled()) {
			log.debug("OUT");
		}
	}
	@SuppressWarnings("unused")
	private void parse(String dirName,String filter) throws BlankSourceFileException{
		if(log.isDebugEnabled()) {
			log.debug("IN");
		}
		parseDirectory(dirName, filter, 0);
		if(log.isDebugEnabled()) {
			log.debug("OUT");
		}
	}
	private void parse(String dirName,String filter,Integer iLevel) throws BlankSourceFileException{
		//Parses all files satisfying particular name pattern
		//in a given directory and its subdirectories.
		if(log.isDebugEnabled()) {
			log.debug("IN");
		}
		String[] dirList = dirName.split(",");
			for (String dirpath : dirList)
			{
				parseDirectory(dirpath, filter, iLevel);
			}
		ParsingCompleteEvent pce = new ParsingCompleteEvent(Thread.currentThread().getName());
		onParsingComplete(pce);
			if(log.isDebugEnabled()) 
			{
				log.debug("OUT");
			}
	}	
	private void parseDirectory(String dirName,String filter,Integer iLevel) throws BlankSourceFileException
	{
		Search search = new Search();
		long fileParsedNo = 0;
        long fileInvalidNo = 0;
        String fullFilter = filter;
        //search for files satisfying provided filter
        search.DoSearch(dirName, filter, null, iLevel);
        if (log.isInfoEnabled()) {
        	try
        	{
        	log.info("Parsing " + search.Files.size()+ " " + fullFilter + " files.");
        	}
        	catch(Exception e)
        	{
        		e.printStackTrace();
        	}
        }
        for (File file : search.Files) 
        {
        	try 
        	{
        		parseFile(file);
				handleProcessedFile(file, true);
				fileParsedNo += 1;
			}
        	catch (Exception ex)
			{
		        // log error and continue
                log.error("Failed to parse file: " + file.getName());
                log.error(ex);
                handleProcessedFile(file, false);
                fileInvalidNo += 1;
             }
			ParseEvents pe = new ParseEvents(file, fileInvalidNo + fileParsedNo, Long.parseLong(search.Files.size() + "") );
			onSampleProcessed(pe);
		}
        ParsingCompleteEvent pce = new ParsingCompleteEvent(Thread.currentThread().getName());
        onParsingComplete(pce);        
        if (log.isDebugEnabled()) 
        {
        	log.debug("OUT");
        }
        if (log.isInfoEnabled())
        {
            log.info("Successfuly parsed " + fileParsedNo+ " files.");
            log.info(fileInvalidNo + " invalid files not parsed.");
            log.info("Examine error-log.txt file for additional information.");
        }
	}	
	private void handleProcessedFile(File file,boolean processed) throws BlankSourceFileException{
		//A helper method for moving processed files.
		String source = file.getPath();
		String destination = XchangeParserProperties.getOutFolderPath();
		FileManager fileManager = new FileManager();
		// how to handle situation where file with the same name already exist
		HandleFileExist hfe = HandleFileExist.RenameWithGuid;  
		if (_dataConverter.fileExistHandling.toString().equals(DataConverterFileexisthandling.renamewithguid.toString())) 
		{
			hfe = HandleFileExist.RenameWithGuid;
		} 
		else if (_dataConverter.fileExistHandling.equals(DataConverterFileexisthandling.renamewithcount)) {
			hfe = HandleFileExist.RenameWithCount;
			
		}else if (_dataConverter.fileExistHandling.equals(DataConverterFileexisthandling.overwrite)) {
			hfe = HandleFileExist.Overwrite;
			
		}else if (_dataConverter.fileExistHandling.equals(DataConverterFileexisthandling.none)) {
			hfe = HandleFileExist.None;
		}
		fileManager.MoveFile(source, destination, hfe);
	}

	private void oneTimeParser() throws BlankSourceFileException{
		  if (log.isInfoEnabled())
	      {
	    	  log.info("IN");
	      }
		 // OneTimeParser simply calls parse method and then exits.In difference to PoolingParser and EventBasedParser it does not run a separate thread or enters an infinite parsing loop.
	      parse(XchangeParserProperties.getInFolderPath(),this._dataConverter.fileFilter,this._dataConverter.descentLevel);
		  if (log.isInfoEnabled()) 
		  {
	    	log.info("OUT");
		  }
	}	
	private void poolingParser() throws BlankSourceFileException
	{
		//Implements a pooling parser. Pooling is performed in a separate thread which wakes up from sleep every predefined amount of time, checks for the existence of new files to parse and then performs parsing.
	     if (log.isInfoEnabled()) 
	     {
	    	  log.info("IN");
	     }
	     while (true)
         {
              if (log.isInfoEnabled())
              {
            	  log.info("Waking up and parsing...");
              }         
              parse(XchangeParserProperties.getInFolderPath(), this._dataConverter.fileFilter, this._dataConverter.descentLevel);
              if (log.isInfoEnabled()) 
              {
            	  log.info("Sleeping for:" + this._dataConverter.watchInterval + " milliseconds.");
              }
              try {
				Thread.sleep(Long.parseLong(this._dataConverter.watchInterval));
              } catch (NumberFormatException e) {
				e.printStackTrace();
              } catch (InterruptedException e) {
				e.printStackTrace();
              }
         }
	}
	private void eventBasedParser()
	{
        //Implements an event-based parser. FileSystemMonitor is used to watch for new files and generate events triggered by file creation.
		if (log.isInfoEnabled()) {
			log.info("IN");
		}	
		FileSystemMonitor fsm = new FileSystemMonitor();
		fsm.setPath(this._dataConverter.parseDir);
		fsm.setFilter(this._dataConverter.fileFilter);
		fsm.setIncludeSubdirectories(true);
		fsm.setNotifyFilter(NotifyFilters.LastAccess);
		///#### STILL TO IMPLEMENT
		while (true)
        {
        // Wait in an infinite loop.
        }
	}	
	private void onSampleProcessed(ParseEvents e)
	{
		//Invoke the ReportProgress event; called whenever a file is processed
		////#### STILL TO IMPLEMENT
		/*if (reportProgress!= null) 
		{
            ReportProgress(this, e);			
		}*/		
	}	
	private void onParsingComplete(ParsingCompleteEvent e){
		// Invoke the ParsingComplete event; called whenever is parsing completed (all files parsed).
	}
	public void setDataConverter(DataConverter _dataConverter) {
		this._dataConverter = _dataConverter;
	}
	public DataConverter getDataConverter() 
	{
		return _dataConverter;
	}
	public void setUrWriter(URWriter _urWriter) {
		this._urWriter = _urWriter;
	}
	public URWriter getUrWriter() {
		return _urWriter;
	}	
	/*private void OnChanged(Object source, FileSystemEventArgs e)
	{
	    // Specify what is done when a file is created.
	    if (log.isInfoEnabled()) log.info("File: " + e.FullPath + " " + e.ChangeType);
	    ParseFile(e.FullPath);
	}*/

	/*public void run() 
	{
		 if (log.isInfoEnabled())
		 {
	        	log.info("INRUN");
	        	
	        	System.out.println("In run method::"+Thread.currentThread());
	     }
		 this.parse();
		 if (log.isInfoEnabled())
		 {
	        	log.info("OUTRUN");
	     }
	}*/
}
