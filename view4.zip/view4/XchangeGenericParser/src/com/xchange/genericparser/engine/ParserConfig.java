package com.xchange.genericparser.engine;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DataConverter">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="class-path" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="code" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="completed-dir" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="config-location" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="default-assembly-line" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="default-building" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="default-partner" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="default-site" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="default-station-type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="descent-level" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                 &lt;attribute name="description" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="error-dir" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="file-exist-handling" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="file-filter" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="final-outcome-strategy" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="handle-invalid-row" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                 &lt;attribute name="mapping-file-path" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="output-queue" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="parse-dir" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="stations-config-file" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="stations-lookup-strategy" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="stations-lookup-url" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="subtest-outcome-strategy" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="watch-interval" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                 &lt;attribute name="watch-method" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="log-config-file" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="parsing-mode" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="run-as" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="service-description" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="service-name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "dataConverter"
})
@XmlRootElement(name = "ParserConfig")
public class ParserConfig {

    @XmlElement(name = "DataConverter", required = true)
   protected List<ParserConfig.DataConverter> dataConverter;
    @XmlAttribute(name = "log-config-file")
    protected String logConfigFile;
    @XmlAttribute(name = "parsing-mode")
    protected String parsingMode;
    @XmlAttribute(name = "run-as")
    protected String runAs;
    @XmlAttribute(name = "service-description")
    protected String serviceDescription;
    @XmlAttribute(name = "service-name")
    protected String serviceName;

    /**
     * Gets the value of the dataConverter property.
     * 
     * @return
     *     possible object is
     *     {@link ParserConfig.DataConverter }
     *     
     */
   

    public List<ParserConfig.DataConverter> getDataConverter() {
        if (dataConverter == null) {
            dataConverter = new ArrayList<ParserConfig.DataConverter>();
        }
        return this.dataConverter;
    }

    /**
     * Gets the value of the logConfigFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogConfigFile() {
        return logConfigFile;
    }

    /**
     * Sets the value of the logConfigFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogConfigFile(String value) {
        this.logConfigFile = value;
    }

    /**
     * Gets the value of the parsingMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParsingMode() {
        return parsingMode;
    }

    /**
     * Sets the value of the parsingMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParsingMode(String value) {
        this.parsingMode = value;
    }

    /**
     * Gets the value of the runAs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRunAs() {
        return runAs;
    }

    /**
     * Sets the value of the runAs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRunAs(String value) {
        this.runAs = value;
    }

    /**
     * Gets the value of the serviceDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceDescription() {
        return serviceDescription;
    }

    /**
     * Sets the value of the serviceDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceDescription(String value) {
        this.serviceDescription = value;
    }

    /**
     * Gets the value of the serviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets the value of the serviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceName(String value) {
        this.serviceName = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="class-path" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="code" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="completed-dir" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="config-location" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="default-assembly-line" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="default-building" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="default-partner" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="default-site" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="default-station-type" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="descent-level" type="{http://www.w3.org/2001/XMLSchema}int" />
     *       &lt;attribute name="description" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="error-dir" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="file-exist-handling" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="file-filter" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="final-outcome-strategy" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="handle-invalid-row" type="{http://www.w3.org/2001/XMLSchema}int" />
     *       &lt;attribute name="mapping-file-path" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="output-queue" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="parse-dir" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="stations-config-file" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="stations-lookup-strategy" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="stations-lookup-url" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="subtest-outcome-strategy" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="watch-interval" type="{http://www.w3.org/2001/XMLSchema}int" />
     *       &lt;attribute name="watch-method" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class DataConverter {

        @XmlAttribute(name = "class-path")
        protected String classPath;
        @XmlAttribute
        protected String code;
        @XmlAttribute(name = "completed-dir")
        protected String completedDir;
        @XmlAttribute(name = "config-location")
        protected String configLocation;
        @XmlAttribute(name = "default-assembly-line")
        protected String defaultAssemblyLine;
        @XmlAttribute(name = "default-building")
        protected String defaultBuilding;
        @XmlAttribute(name = "default-partner")
        protected String defaultPartner;
        @XmlAttribute(name = "default-site")
        protected String defaultSite;
        @XmlAttribute(name = "default-station-type")
        protected String defaultStationType;
        @XmlAttribute(name = "descent-level")
        protected Integer descentLevel;
        @XmlAttribute
        protected String description;
        @XmlAttribute(name = "error-dir")
        protected String errorDir;
        @XmlAttribute(name = "file-exist-handling")
        protected String fileExistHandling;
        @XmlAttribute(name = "file-filter")
        protected String fileFilter;
        @XmlAttribute(name = "final-outcome-strategy")
        protected String finalOutcomeStrategy;
        @XmlAttribute(name = "handle-invalid-row")
        protected Integer handleInvalidRow;
        @XmlAttribute(name = "mapping-file-path")
        protected String mappingFilePath;
        @XmlAttribute
        protected String name;
        @XmlAttribute(name = "output-queue")
        protected String outputQueue;
        @XmlAttribute(name = "parse-dir")
        protected String parseDir;
        @XmlAttribute(name = "stations-config-file")
        protected String stationsConfigFile;
        @XmlAttribute(name = "stations-lookup-strategy")
        protected String stationsLookupStrategy;
        @XmlAttribute(name = "stations-lookup-url")
        protected String stationsLookupUrl;
        @XmlAttribute(name = "subtest-outcome-strategy")
        protected String subtestOutcomeStrategy;
        @XmlAttribute(name = "watch-interval")
        protected String watchInterval;
        @XmlAttribute(name = "watch-method")
        protected String watchMethod;

        /**
         * Gets the value of the classPath property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getClassPath() {
            return classPath;
        }

        /**
         * Sets the value of the classPath property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setClassPath(String value) {
            this.classPath = value;
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        /**
         * Gets the value of the completedDir property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCompletedDir() {
            return completedDir;
        }

        /**
         * Sets the value of the completedDir property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCompletedDir(String value) {
            this.completedDir = value;
        }

        /**
         * Gets the value of the configLocation property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getConfigLocation() {
            return configLocation;
        }

        /**
         * Sets the value of the configLocation property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setConfigLocation(String value) {
            this.configLocation = value;
        }

        /**
         * Gets the value of the defaultAssemblyLine property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDefaultAssemblyLine() {
            return defaultAssemblyLine;
        }

        /**
         * Sets the value of the defaultAssemblyLine property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDefaultAssemblyLine(String value) {
            this.defaultAssemblyLine = value;
        }

        /**
         * Gets the value of the defaultBuilding property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDefaultBuilding() {
            return defaultBuilding;
        }

        /**
         * Sets the value of the defaultBuilding property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDefaultBuilding(String value) {
            this.defaultBuilding = value;
        }

        /**
         * Gets the value of the defaultPartner property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDefaultPartner() {
            return defaultPartner;
        }

        /**
         * Sets the value of the defaultPartner property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDefaultPartner(String value) {
            this.defaultPartner = value;
        }

        /**
         * Gets the value of the defaultSite property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDefaultSite() {
            return defaultSite;
        }

        /**
         * Sets the value of the defaultSite property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDefaultSite(String value) {
            this.defaultSite = value;
        }

        /**
         * Gets the value of the defaultStationType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDefaultStationType() {
            return defaultStationType;
        }

        /**
         * Sets the value of the defaultStationType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDefaultStationType(String value) {
            this.defaultStationType = value;
        }

        /**
         * Gets the value of the descentLevel property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getDescentLevel() {
            return descentLevel;
        }

        /**
         * Sets the value of the descentLevel property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setDescentLevel(Integer value) {
            this.descentLevel = value;
        }

        /**
         * Gets the value of the description property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDescription() {
            return description;
        }

        /**
         * Sets the value of the description property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDescription(String value) {
            this.description = value;
        }

        /**
         * Gets the value of the errorDir property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getErrorDir() {
            return errorDir;
        }

        /**
         * Sets the value of the errorDir property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setErrorDir(String value) {
            this.errorDir = value;
        }

        /**
         * Gets the value of the fileExistHandling property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFileExistHandling() {
            return fileExistHandling;
        }

        /**
         * Sets the value of the fileExistHandling property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFileExistHandling(String value) {
            this.fileExistHandling = value;
        }

        /**
         * Gets the value of the fileFilter property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFileFilter() {
            return fileFilter;
        }

        /**
         * Sets the value of the fileFilter property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFileFilter(String value) {
            this.fileFilter = value;
        }

        /**
         * Gets the value of the finalOutcomeStrategy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFinalOutcomeStrategy() {
            return finalOutcomeStrategy;
        }

        /**
         * Sets the value of the finalOutcomeStrategy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFinalOutcomeStrategy(String value) {
            this.finalOutcomeStrategy = value;
        }

        /**
         * Gets the value of the handleInvalidRow property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getHandleInvalidRow() {
            return handleInvalidRow;
        }

        /**
         * Sets the value of the handleInvalidRow property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setHandleInvalidRow(Integer value) {
            this.handleInvalidRow = value;
        }

        /**
         * Gets the value of the mappingFilePath property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMappingFilePath() {
            return mappingFilePath;
        }

        /**
         * Sets the value of the mappingFilePath property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMappingFilePath(String value) {
            this.mappingFilePath = value;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

        /**
         * Gets the value of the outputQueue property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOutputQueue() {
            return outputQueue;
        }

        /**
         * Sets the value of the outputQueue property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOutputQueue(String value) {
            this.outputQueue = value;
        }

        /**
         * Gets the value of the parseDir property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getParseDir() {
            return parseDir;
        }

        /**
         * Sets the value of the parseDir property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setParseDir(String value) {
            this.parseDir = value;
        }

        /**
         * Gets the value of the stationsConfigFile property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getStationsConfigFile() {
            return stationsConfigFile;
        }

        /**
         * Sets the value of the stationsConfigFile property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStationsConfigFile(String value) {
            this.stationsConfigFile = value;
        }

        /**
         * Gets the value of the stationsLookupStrategy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getStationsLookupStrategy() {
            return stationsLookupStrategy;
        }

        /**
         * Sets the value of the stationsLookupStrategy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStationsLookupStrategy(String value) {
            this.stationsLookupStrategy = value;
        }

        /**
         * Gets the value of the stationsLookupUrl property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getStationsLookupUrl() {
            return stationsLookupUrl;
        }

        /**
         * Sets the value of the stationsLookupUrl property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStationsLookupUrl(String value) {
            this.stationsLookupUrl = value;
        }

        /**
         * Gets the value of the subtestOutcomeStrategy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSubtestOutcomeStrategy() {
            return subtestOutcomeStrategy;
        }

        /**
         * Sets the value of the subtestOutcomeStrategy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSubtestOutcomeStrategy(String value) {
            this.subtestOutcomeStrategy = value;
        }

        /**
         * Gets the value of the watchInterval property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public String getWatchInterval() {
            return watchInterval;
        }

        /**
         * Sets the value of the watchInterval property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setWatchInterval(String value) {
            this.watchInterval = value;
        }

        /**
         * Gets the value of the watchMethod property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getWatchMethod() {
            return watchMethod;
        }

        /**
         * Sets the value of the watchMethod property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setWatchMethod(String value) {
            this.watchMethod = value;
        }

    }

}
