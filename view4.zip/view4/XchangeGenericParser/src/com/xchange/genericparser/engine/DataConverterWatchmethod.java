package com.xchange.genericparser.engine;


public enum DataConverterWatchmethod {
	polling,
    eventbased,
    onetime,
}
