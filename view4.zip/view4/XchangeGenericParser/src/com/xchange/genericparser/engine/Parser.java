package com.xchange.genericparser.engine;

import com.xchange.Exceptions.ParameterNotSupportedException;

public interface Parser {
	
	void parse() throws ParameterNotSupportedException;
}
