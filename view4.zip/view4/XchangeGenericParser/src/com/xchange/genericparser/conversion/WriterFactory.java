package com.xchange.genericparser.conversion;

import java.lang.reflect.*;
import com.xchange.Exceptions.ExchangeJarNotFoundException;
import com.xchange.genericparser.engine.ParserConfig.*;

public class WriterFactory
{	
	@SuppressWarnings("unchecked")
	public static IURWriter getWriter(DataConverter conv) throws ExchangeJarNotFoundException 
	{
		String className= conv.getClassPath();
		try
		{
			ClassLoader classLoader=WriterFactory.class.getClassLoader();
			Class referencedClass=classLoader.loadClass(className);
			Constructor[] referencedConstructors = referencedClass.getConstructors();
			for(Constructor referencedConstructor: referencedConstructors)
			{
				return (IURWriter) referencedConstructor.newInstance(conv);
			}
		}
		catch(Exception e)
		{
			throw new ExchangeJarNotFoundException(className,e);
		}
		return null;
	}	
	
	
}