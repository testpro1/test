package com.xchange.genericparser.conversion;

public interface IURWriter {
	
	void convert(String fileName);
}
