package com.xchange.genericparserconsole;

import java.io.*;
import org.apache.commons.logging.*;
import com.xchange.Exceptions.*;
import com.xchange.genericparser.engine.ParserService;

public class GenericParser 
{
	private static Log log = LogFactory.getLog(GenericParser.class);
	public static void main(String args[]) throws Exception
	{log.info("start of main");
		start(args);
	}
	private static void start(String[] args) throws ConfigureFileNotFoundException, SourceNotFoundException, DependecyNotFoundException, InvalidConfigurationSchemaException
	{
		if(log.isDebugEnabled())log.debug("IN");	
		//String fileName="conf\\ParserConfig.xml";
		String fileName="E:\\workspace\\XchangeGenericParser\\src\\conf\\ParserConfig.xml";
		File file=new File(fileName);
		if(!file.exists()){
			throw new ConfigureFileNotFoundException(fileName);
		}
		else{
			ParserService parserService;
			parserService = new ParserService(file.getPath());
			parserService.run();
		}
		if(log.isDebugEnabled())log.debug("OUT");
		return;
	}
}