package com.xchange.FileUtils;

public enum DataConverterFileexisthandling {
	 renamewithguid,
	 renamewithcount,
	 overwrite,
	 none,
}
