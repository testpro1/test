package com.xchange.xchangewriter;

import java.io.*;
import java.util.*;

public class XchangeParserProperties {
	private static Properties props = new Properties();
	static
	{
		InputStream inStream=null;
		try {
			inStream = Thread.currentThread().getContextClassLoader().getResource("XchangeParserProperties.ini").openStream();
			props.load(inStream);
		}
		catch(Throwable t)
		{
			throw new 
			IllegalStateException("Failed to read SX SQS System Configuration Properties");
		}
	finally
	{
		if(inStream!=null)
		{
		try {
			inStream.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		}		
	}
	}
	public static String getInFolderName(){
		return props.getProperty("inFolderPath").trim();
	}
	public static String getInFolderPath(){
		String path =getInFolderName();
		File dir = new File(path);
		if(!dir.exists()) {
			dir.mkdir();
		}
		return path;
	}	
	public static String getOutFolderName(){
		return props.getProperty("outFolderPath").trim();
	}
	public static String getOutFolderPath(){
		String path =getOutFolderName();
		File dir = new File(path);
		if(!dir.exists()) {
			dir.mkdir();
		}
		return path;
	}	
	public static String getErrorFolderName(){
		return props.getProperty("errorFolderPath").trim();
	}
	public static String getErrorFolderPath(){
		String path = getErrorFolderName();
		File dir = new File(path);
		if(!dir.exists()) {
			dir.mkdir();
		}
		return path;
	}	
	public static String getlogFolderName(){
		return props.getProperty("logFolderPath").trim();
	}
	public static String getlogFolderPath(){
		String path =getlogFolderName();
		File dir = new File(path);
		if(!dir.exists()) {
			dir.mkdir();
		}
		return path;
	}
	public static String getUnitFolderName(){
		return props.getProperty("unitFolderPath").trim();
	}
	public static String getUnitFolderPath(){
		String path =getUnitFolderName();
		File dir = new File(path);
		if(!dir.exists()) {
			dir.mkdir();
		}
		return path;
	}
}