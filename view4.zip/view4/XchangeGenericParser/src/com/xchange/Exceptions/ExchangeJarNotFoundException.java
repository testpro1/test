package com.xchange.Exceptions;

public class ExchangeJarNotFoundException extends Exception {
	public static final long serialVersionUID = 43L;
	private static final String _message="Exchange Jar file is missing ";
	private String _jarFileName;
	public ExchangeJarNotFoundException(String jarFileName,Exception e) {
	super(_message);
	_jarFileName=jarFileName;
	}
	public String get_jarFileName() {
		return _jarFileName;
	}
	
}
