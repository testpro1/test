package com.xchange.Exceptions;
public class ConfigureFileNotFoundException extends Exception {
	public static final long serialVersionUID = 43L;
	private static final String _message = "Specified file does not exist";
	private String _configFile;
	
	public String get_configFile()
	{
		return _configFile;
	}
	public ConfigureFileNotFoundException(String configFile) {	
			super(_message);
			
	}

}
