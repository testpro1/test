package com.xchange.Exceptions;


public class StationConfigNotFoundException extends Exception {
	private static final long serialVersionUID = 43L;
	private static final String _message = "Found wrong location station config";
	private String _stationConfigLocation;
	
	public StationConfigNotFoundException(String stationConfigLocation) {
		super(_message);
		_stationConfigLocation=stationConfigLocation;
	}
	public  String get_stationConfigLocation() {
		return _stationConfigLocation;
	}
}
