package com.xchange.Exceptions;

public class InvalidConfigurationSchemaException extends Exception {
	private static final long serialVersionUID = 43L;
	private static final String _message = "The given xml can not be serialized to the class object.";
	private String _xmlFilePath;
	private String _serializableClassName;
	public InvalidConfigurationSchemaException(String xmlFilePath, String serializableClassName, Exception innerException) {
		super(_message,innerException);
		_xmlFilePath = xmlFilePath;
		_serializableClassName = serializableClassName; 
	}
	public String get_xmlFilePath()
	{	
		return _xmlFilePath;	
	}
	public String get_serializableClassName() {
		return _serializableClassName;
	}
}
