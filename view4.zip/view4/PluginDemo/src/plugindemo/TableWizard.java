package plugindemo;

import java.util.ArrayList;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
public class TableWizard{
/*public void setTable1(Shell shell,Display display,ArrayList<String> tableName, ArrayList<String> colName,ArrayList<String> colTypes) {
			// TODO Auto-generated method stub
	 shell.setText("Tables");
	 shell.pack();
			try{
			//System.out.println("****************"+tableName.size());
			//System.out.println("****************"+colName.size());
			int y=20;
			int r=20;
			
			for(int j=0;j<tableName.size();j++){
				Table table= new Table (shell, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
				TableItem item1 = new TableItem(table,0);
				item1.setText (tableName.get(j));
				//Color gray = display.getSystemColor(SWT.COLOR_GRAY); 
				//item1.setBackground(gray);
				
			for (int i=0; i<colName.size(); i++) {
				TableItem item = new TableItem(table,1);
				//TableColumn column = new TableColumn (table, SWT.BORDER_SOLID);
				//TableColumn column1 = new TableColumn (table, SWT.BORDER_SOLID);
				for(int k=0;k<colTypes.size();k++){
					//column.setText (colName.get(i));
					//column1.setText (colTypes.get(k));
					item.setText(colName.get(i)+"  "+colName.get(k));
				}
			}
			Rectangle clientArea = shell.getClientArea ();
			y+=20;
			
			table.setBounds (clientArea.x+y, clientArea.y+r, 150, 150);
			y=y+150;
			}
			shell.setSize (1500,1500);
			shell.open ();
			colName.clear();
	
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch ()) display.sleep ();
			}
			display.dispose ();
		}catch(Exception e){
			e.printStackTrace();
		}
		}*/
public void setTable(Shell shell,Display display,ArrayList<String> tableName, ArrayList<String> colName,ArrayList<String> colTypes) {
	// TODO Auto-generated method stub
	try{
		System.out.println("tableName "+tableName.size());
		System.out.println("colName "+colName.size());
		int y=20;
		int r=20;
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns=4;
		shell.setLayout(gridLayout);
		gridLayout.numColumns=4;
		
		for(int k=0;k<tableName.size();k++){
		Table table = new Table (shell, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION|SWT.V_SCROLL|SWT.H_SCROLL );
		table.setLinesVisible (true);
		table.setHeaderVisible (true);
		TableColumn column = new TableColumn (table, SWT.NONE);
		column.setText (tableName.get(k));
		
		GridData data = new GridData(SWT.HORIZONTAL, SWT.HORIZONTAL, true, false);
		//GridData data = new GridData(GridData.END, GridData.BEGINNING, true,true, 6, 1);	
		data.heightHint = 150;
		data.widthHint=250;
		table.setLayoutData(data);
		String[] titles = {" "," "};
		for (int i=0; i<titles.length; i++) {
			new TableColumn (table, SWT.NONE);
			//column.setText (" ");
		}	
		for (int i=0; i<colName.size(); i++) {
			TableItem item = new TableItem (table, SWT.NONE);
			item.setText (0,colName.get(i));
			item.setText (1, colTypes.get(i));
		}
		for (int i=0; i<titles.length; i++) {
			table.getColumn (i).pack ();
		}
		Rectangle clientArea = shell.getClientArea ();
		y+=20;
		
		table.setBounds (clientArea.x+y, clientArea.y+r, 150, 150);
		y=y+150;
		
		}
		shell.setSize(1500,1500);
		shell.pack ();
		shell.open ();
		tableName.clear();
		colName.clear();
		colTypes.clear();
		}catch(Exception e){
			e.printStackTrace();
		}
	}


}