package plugindemo.handlers;

import plugindemo.DBHandler;
import plugindemo.ConnectivityDialog;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.jface.window.Window;
/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class SampleHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public SampleHandler() {
	}
	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 */
	public Object execute(ExecutionEvent args) throws ExecutionException {
		try{
		Shell shell = new Shell();
		  ConnectivityDialog dialog = new ConnectivityDialog(shell);
		  dialog.create();
		  if (dialog.open() == Window.OK) {
		    System.out.println("UserName "+dialog.getUserName());
		    System.out.println("pass "+dialog.getPassword());
		    System.out.println("Driver "+dialog.getDBDriver());
		    System.out.println("host "+dialog.getHost());
		    System.out.println("port "+dialog.getPort());
		    System.out.println("database Name "+dialog.getDatabaseName());
		    System.out.println("***************************************************");  
		    @SuppressWarnings("rawtypes")
			DBHandler dbHandler=new DBHandler();
		    Display display=null;
		    dbHandler.getConnection(shell,display,dialog.getUserName(),dialog.getPassword(),dialog.getDBDriver(), dialog.getDatabaseName(),
		    		dialog.getHost(),dialog.getPort());
		  } 
		 
		}catch(Exception e){
			e.printStackTrace();
		}
		//IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		/*MessageDialog.openInformation(
				window.getShell(),
				"HelloWorld",
				"Hello, Rupal");*/
		return null;
	}
}
