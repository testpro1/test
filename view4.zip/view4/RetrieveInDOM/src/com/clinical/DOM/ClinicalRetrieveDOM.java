/* To insert all data using DOM
 * author Rupal Kathiriya
 */
package com.clinical.DOM;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class ClinicalRetrieveDOM {
	PreparedStatement ps = null;
		 static Connection con = null;
		 //static String url = "jdbc:mysql://23.21.195.200:3306/";
		 //String db = "millipore";
		 static String url = "jdbc:mysql://localhost:3306/";
		 static String db = "millipore";
		 static String driver = "com.mysql.jdbc.Driver";
		 static String username = "root";
		 static String password = "root";
		
		 public static Connection getMyconnection()
		  {
			  try{
				   Class.forName(driver);
			  	   con = DriverManager.getConnection(url+db,username, password);
				 }
			  	catch (Exception e){
			  		e.printStackTrace();
			  	}
			return con;  
		  }
	//public static void main(String argv[]) {
		 public void save(){
		 try{
			 
				String startDate = null;
				String verificationDate=null;
				String lastchangedDate=null;
				String firstreceivedDate=null;
				String primary_completionDate=null;
				String completionDate=null;
				
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMM yyyy");
					
					SimpleDateFormat changedDate=new SimpleDateFormat("yyyy-MM-dd");
					SimpleDateFormat changedDate1=new SimpleDateFormat("MMMM d, yyyy");
					//String rg = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";
					
					String sqlString = "insert into clinical_trials(id_info_nct_id,id_info_org_study_id,required_header_url,brief_title,official_title,sponsors_lead_sponsor_agency,sponsors_lead_sponsor_agency_class,source,brief_summary_textblock,detailed_description_textblock,collaborator_agency,collaborator_agency_class,overall_status,oversight_info_authority,start_date,study_type,study_design,oversight_info_has_dmc,phase,primary_outcome_measure,primary_outcome_time_frame,primary_outcome_safety_issue,primary_outcome_description,eligibility_criteria_textblock,number_of_arms,enrollment_count,condition1,study_pop,sampling_method,Inclusion_criteria,gender,minimum_age,maximum_age,healthy_volunteers,overall_official_last_name,overall_official_role,overall_official_affiliation,overall_contact_location_facility,overall_contact_location_facility_address_city,overall_contact_location_facility_address_state,overall_contact_location_facility_address_zip,overall_contact_location_facility_address_country,overall_contact_last_name,overall_contact_phone,overall_contact_email,overall_contact_backup_last_name,overall_contact_backup_phone,overall_contact_backup_email,facility_name,facility_city,facility_state,facility_zip,facility_country,facility_status,facility_name_2,facility_city_2,facility_state_2,facility_zip_2,facility_contact_2_last_name,facility_contact_2_phone,facility_contact_2_email,contact_investigator_last_name,contact_investigator_role,location_countries,verification_date,lastchanged_date,firstreceived_date,responsible_party_type,is_fda_regulated,has_expanded_access,status,study_results,conditions,interventions,link_url,link_description,age_groups,enrollment,funded_bys,other_ids,first_received,completion_date,last_updated,last_verified,acronym,primary_completion_date,outcome_measures,url,criteria_gender,criteria_minimum_age,criteria_maximum_age,keyword,reference_PMID,mesh_trerms,arm_group_label,arm_group_type,secondary_outcome_measure,secondary_outcome_time_frame,secondary_outcome_safety_issue,rank) values(?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?," +
							"?,?,?,?,?,?,?,?,?,?)";
					
					
					ps = getMyconnection().prepareStatement(sqlString);
					System.out.println("Parsing started.......");
					
				//	System.out.println("download_date : " + getTagValue("download_date", getchildValue(getRootElement("required_header"))));
				//	System.out.println("link_text : " + getTagValue("link_text", getchildValue(getRootElement("required_header"))));
				//	System.out.println("intervention_type : " + getTagValue("intervention_type", getchildValue(getRootElement("intervention"))));
				//	System.out.println("arm_group_label : " + getTagValue("arm_group_label", getchildValue(getRootElement("intervention"))));
					
					
					String NctId=getTagValue("nct_id", getchildValue(getRootElement("id_info")));
					String studyId= getTagValue("org_study_id", getchildValue(getRootElement("id_info")));
					String url= getTagValue("url", getchildValue(getRootElement("required_header")));
					String briefTitle=getRootElement("brief_title").item(0).getTextContent();
		        	
					String officialTitle=null;
					
					String SpoLeadAgency="";
					String spoLeadAgencyclass="";
					String collaborator_agency="";
		        	String collaborator_agency_class="";
					NodeList nodeLst1 =getRootElement("sponsors");
					for (int i = 0; i < nodeLst1.getLength(); i++) {
						Node myNode = nodeLst1.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element productElement = (Element) myNode;
							
						
							NodeList contactList = productElement.getElementsByTagName("lead_sponsor");
							for (int j = 0; j < contactList.getLength(); j++) {
								Node contactNode = contactList.item(j);
								if (contactNode.getNodeType() == Node.ELEMENT_NODE){
									Element contactElement = (Element) contactNode;
									NodeList contactNodeList = contactElement.getElementsByTagName("agency");
									Element contactEle = (Element)contactNodeList.item(0);
									NodeList lastName = contactEle.getChildNodes();
									SpoLeadAgency+= ((Node) lastName.item(0)).getNodeValue()+";";
									
									NodeList contactPhoneList = contactElement.getElementsByTagName("agency_class");
									Element contactPhoneEle = (Element)contactPhoneList.item(0);
									NodeList phone = contactPhoneEle.getChildNodes();
									spoLeadAgencyclass+= ((Node) phone.item(0)).getNodeValue()+";";
								}
							}
							NodeList facilityList = productElement.getElementsByTagName("collaborator");
							for (int j = 0; j < facilityList.getLength(); j++) {
								Node contactNode = facilityList.item(j);
								if (contactNode.getNodeType() == Node.ELEMENT_NODE) {
									Element contactElement = (Element) contactNode;
									NodeList contactNodeList = contactElement.getElementsByTagName("agency");
									Element contactEle = (Element)contactNodeList.item(0);
									NodeList Name = contactEle.getChildNodes();
									collaborator_agency+= ((Node) Name.item(0)).getNodeValue()+";";
									
									
									NodeList agency_classNodeList = contactElement.getElementsByTagName("agency_class");
									Element agency_classEle = (Element)agency_classNodeList.item(0);
									NodeList agency_className = agency_classEle.getChildNodes();
									collaborator_agency_class+= ((Node) agency_className.item(0)).getNodeValue()+";";
									
								}
								
									
							}
						}
					}
					String source=null;
					if(getRootElement("source").item(0)!=null){
					 source=getRootElement("source").item(0).getTextContent();
					}
					String briefSumTextBox=null;
					if(getTagValue("textblock", getchildValue(getRootElement("brief_summary")))!=null){
						briefSumTextBox=getTagValue("textblock", getchildValue(getRootElement("brief_summary")));
					}
					String detailedDescTextBox=null;
					if(getchildValue(getRootElement("detailed_description"))!=null){
						detailedDescTextBox=getTagValue("textblock", getchildValue(getRootElement("detailed_description")));
					}
					String overAllStatus=null;
					if(getRootElement("overall_status").item(0)!=null){
						 overAllStatus=getRootElement("overall_status").item(0).getTextContent();
					}
		        	
		        	
		        	String oversightInfoAuthority= getTagValue("authority", getchildValue(getRootElement("oversight_info")));
		        	
		        	if(getRootElement("start_date").item(0)!=null){
		        	String start_date=getRootElement("start_date").item(0).getTextContent();//clinicalStudy.getStartDate();
		        	//if(start_date.matches(rg)){
		        	if(start_date!=null){
		        	 	Date s_date = (Date)sdf1.parse(1+" "+start_date);
						startDate = sdf.format(s_date);
		        	}else{
						  start_date = null;
					}
		        	}
		        	String studyType=getRootElement("study_type").item(0).getTextContent();
		        	String studyDesign=getRootElement("study_design").item(0).getTextContent();
		        	String oversight_info_has_dmc=null;
		        	try{
		        	if(getRootElement("oversight_info")!=null){
		        		if(getchildValue(getRootElement("oversight_info"))!=null){
		        			if(getTagValue("has_dmc",getchildValue(getRootElement("oversight_info")))!=null){
		        		oversight_info_has_dmc= getTagValue("has_dmc",getchildValue(getRootElement("oversight_info")));
		        	}}}
		        	}catch(Exception e){
		        		oversight_info_has_dmc=null;
		        	}
		        	String phase=getRootElement("phase").item(0).getTextContent();
					
					
					String primary_outcome_measure="";
					String primary_outcome_time_frame="";
					String primary_outcome_safety_issue="";
					String primary_outcome_description="";
					
					NodeList primary_outcome =getRootElement("primary_outcome");
					for (int i = 0; i < primary_outcome.getLength(); i++) {
						Node myNode = primary_outcome.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element productElement = (Element) myNode;
							NodeList productIdList = productElement.getElementsByTagName("measure");
							Element productIdElement = (Element) productIdList.item(0);
							NodeList productId = productIdElement.getChildNodes();
							primary_outcome_measure+= ((Node) productId.item(0)).getNodeValue()+";";
							
							if(productElement.getElementsByTagName("time_frame")!=null){
								NodeList time_frameList = productElement.getElementsByTagName("time_frame");
								Element time_frameElement = (Element)time_frameList.item(0);
								if(time_frameElement!=null){
									NodeList time_frameId = time_frameElement.getChildNodes();
									primary_outcome_time_frame+= ((Node)time_frameId.item(0)).getNodeValue()+";";
								}	
							}
							
							NodeList safety_issueList = productElement.getElementsByTagName("safety_issue");
							Element safety_issueElement = (Element) safety_issueList.item(0);
							if(safety_issueElement!=null){
							NodeList safety_issueId = safety_issueElement.getChildNodes();
							primary_outcome_safety_issue+=((Node) safety_issueId.item(0)).getNodeValue()+";";
							}
							if(productElement.getElementsByTagName("description")!=null){							
								NodeList descriptionList = productElement.getElementsByTagName("description");
								Element descriptionElement = (Element) descriptionList.item(0);
							if(descriptionElement!=null){
								NodeList descriptionId = descriptionElement.getChildNodes();
								primary_outcome_description+=((Node)descriptionId.item(0)).getNodeValue()+";";
							}}
						}
					}
					String eligibility_criteria_textblock=null;
					if(getRootElement("criteria").item(0)!=null){
						eligibility_criteria_textblock=getRootElement("criteria").item(0).getTextContent();
					}
					String number_of_arms=null;
					String enrollment_count=null;
					String condition=null;
					if(getRootElement("condition").item(0)!=null){
						condition=getRootElement("condition").item(0).getTextContent();
					}
					String study_pop=null;
					if(getRootElement("study_pop").item(0)!=null){
						study_pop=getRootElement("study_pop").item(0).getTextContent();
					}
					String sampling_method=null;
					if(getRootElement("sampling_method").item(0)!=null){
						sampling_method=getRootElement("sampling_method").item(0).getTextContent();
					}
					
					String Inclusion_criteria=null;//required
					String gender=getTagValue("gender", getchildValue(getRootElement("eligibility")));
					String minimum_age=getTagValue("minimum_age", getchildValue(getRootElement("eligibility")));
					String maximum_age=getTagValue("maximum_age", getchildValue(getRootElement("eligibility")));
					String healthy_volunteers=null;
					if(getTagValue("healthy_volunteers", getchildValue(getRootElement("eligibility")))!=null){
						healthy_volunteers=getTagValue("healthy_volunteers", getchildValue(getRootElement("eligibility")));
					}
					String overall_official_last_name=null;
					String overall_official_role=null;
					String overall_official_affiliation=null;
					if(getchildValue(getRootElement("overall_official"))!=null){
					overall_official_last_name=getTagValue("last_name", getchildValue(getRootElement("overall_official")));
					overall_official_role=getTagValue("role", getchildValue(getRootElement("overall_official")));
					overall_official_affiliation=getTagValue("affiliation", getchildValue(getRootElement("overall_official")));
					}
					 
					String overall_contact_location_facility="";
					String overall_contact_location_facility_address_city="";
					String overall_contact_location_facility_address_state="";
					String overall_contact_location_facility_address_zip="";
					String overall_contact_location_facility_address_country="";
					String facility_contact_2_last_name="";                         
					String facility_contact_2_phone="";                             
					String facility_contact_2_email="";      
					NodeList LocnodeLst1 =getRootElement("location");
					for (int i = 0; i < LocnodeLst1.getLength(); i++) {
						Node myNode = LocnodeLst1.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element productElement = (Element) myNode;
							NodeList productIdList = productElement.getElementsByTagName("status");
							Element productIdElement = (Element) productIdList.item(0);
							if(productIdElement!=null){
							NodeList productId = productIdElement.getChildNodes();
							}
						
							NodeList contactList = productElement.getElementsByTagName("contact");
							for (int j = 0; j < contactList.getLength(); j++) {
								Node contactNode = contactList.item(j);
								if (contactNode.getNodeType() == Node.ELEMENT_NODE){
									Element contactElement = (Element) contactNode;
									NodeList contactNodeList = contactElement.getElementsByTagName("last_name");
									Element contactEle = (Element)contactNodeList.item(0);
									if(contactEle!=null){
									NodeList lastName = contactEle.getChildNodes();
									facility_contact_2_last_name+= ((Node) lastName.item(0)).getNodeValue()+";";
									}
									NodeList contactPhoneList = contactElement.getElementsByTagName("phone");
									Element contactPhoneEle = (Element)contactPhoneList.item(0);
									if(contactPhoneEle!=null){
									NodeList phone = contactPhoneEle.getChildNodes();
									facility_contact_2_phone+= ((Node) phone.item(0)).getNodeValue()+";";
									}
									NodeList emailList = contactElement.getElementsByTagName("email");
									Element emailEle = (Element)emailList.item(0);
									if(emailEle!=null){
									NodeList email = emailEle.getChildNodes();
									facility_contact_2_email+= ((Node) email.item(0)).getNodeValue()+";";
									}
								}
							}
							NodeList facilityList = productElement.getElementsByTagName("facility");
							for (int j = 0; j < facilityList.getLength(); j++) {
								Node contactNode = facilityList.item(j);
								if (contactNode.getNodeType() == Node.ELEMENT_NODE) {
									Element contactElement = (Element) contactNode;
									NodeList contactNodeList = contactElement.getElementsByTagName("name");
									Element contactEle = (Element)contactNodeList.item(0);
									if(contactEle!=null){
									NodeList Name = contactEle.getChildNodes();
									overall_contact_location_facility+= ((Node) Name.item(0)).getNodeValue()+";";
									}
								}
								NodeList addressList = productElement.getElementsByTagName("address");
								for (int k = 0; k < addressList.getLength(); k++) {
									Node addressNode = addressList.item(k);
									if(addressNode.getNodeType() == Node.ELEMENT_NODE) {
										Element addressElement = (Element) addressNode;
										NodeList addresstNodeList = addressElement.getElementsByTagName("city");
										Element addressEle = (Element)addresstNodeList.item(0);
										NodeList lastName = addressEle.getChildNodes();
										
										overall_contact_location_facility_address_city+=((Node) lastName.item(0)).getNodeValue()+";";								
										if(productElement.getElementsByTagName("state")!=null){
										NodeList statetNodeList = addressElement.getElementsByTagName("state");
										Element stateEle = (Element)statetNodeList.item(0);
											if(stateEle!=null){
												NodeList state = stateEle.getChildNodes();
												overall_contact_location_facility_address_state+=((Node)state.item(0)).getNodeValue()+";";
											}
										}
										NodeList ziptNodeList = addressElement.getElementsByTagName("zip");
										Element zipEle = (Element)ziptNodeList.item(0);
										if(zipEle!=null){
										NodeList zip = zipEle.getChildNodes();
										overall_contact_location_facility_address_zip+= ((Node) zip.item(0)).getNodeValue()+";";
										}
										NodeList countrytNodeList = addressElement.getElementsByTagName("country");
										Element countryEle = (Element)countrytNodeList.item(0);
										NodeList countryName = countryEle.getChildNodes();
										overall_contact_location_facility_address_country+= ((Node) countryName.item(0)).getNodeValue()+";";
									}
								}	
							}
						}
					}
					String overall_contact_last_name=null;
					if(getchildValue(getRootElement("overall_contact"))!=null){
					
						overall_contact_last_name=getTagValue("last_name", getchildValue(getRootElement("overall_contact")));	
					}
					String overall_contact_phone=null;
					
					try{                         
						overall_contact_phone=getTagValue("phone", getchildValue(getRootElement("overall_contact")));
					}catch(Exception e){
						overall_contact_phone=null;
					}
					
					String overall_contact_email=null;
					try{
					if(getRootElement("overall_contact")!=null){
						if(getTagValue("email", getchildValue(getRootElement("overall_contact")))!=null){
						overall_contact_email= getTagValue("email", getchildValue(getRootElement("overall_contact")));
						}
					}}catch(Exception e){
						overall_contact_email=null;
					}
					
					String overall_contact_backup_last_name="";                
					String overall_contact_backup_phone="";                    
					String overall_contact_backup_email="";      
					NodeList overall_contact_backupLst =getRootElement("overall_contact_backup");
					for (int i = 0; i < overall_contact_backupLst.getLength(); i++) {
						Node myNode = overall_contact_backupLst.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element productElement = (Element) myNode;
							NodeList productIdList = productElement.getElementsByTagName("last_name");
							Element productIdElement = (Element) productIdList.item(0);
							NodeList productId = productIdElement.getChildNodes();
							overall_contact_backup_last_name+=((Node) productId.item(0)).getNodeValue()+";";
							
							NodeList phoneList = productElement.getElementsByTagName("phone");
							Element phoneElement = (Element) phoneList.item(0);
							if(phoneElement!=null){
								NodeList phoneId = phoneElement.getChildNodes();
								overall_contact_backup_phone+=((Node) phoneId.item(0)).getNodeValue()+";";
							}
							NodeList emailList = productElement.getElementsByTagName("email");
							Element emailElement = (Element) emailList.item(0);
							if(emailElement!=null){
								NodeList emailId = emailElement.getChildNodes();
								overall_contact_backup_email+=((Node) emailId.item(0)).getNodeValue()+";";
							}
						}
					}
					
					String facility_name=null;                                  
					String facility_city=null;                                      
					String facility_state=null;                                     
					String facility_zip=null;                                        
					
					String facility_country=null;                                
					String facility_status=null;                               
					
					String facility_name_2=null;                              
					String facility_city_2=null;                                 
					String facility_state_2=null;                                     
					String facility_zip_2=null;     
					
				
					String contact_investigator_last_name=null;                    
					String contact_investigator_role=null;
					
						
					String location_countries=getTagValue("country", getchildValue(getRootElement("location_countries")));
					
					if(getRootElement("verification_date").item(0)!=null){
					String verification_date=getRootElement("verification_date").item(0).getTextContent();
					if(verification_date!=null){
		        	 	Date s_date = (Date)sdf1.parse(1+" "+verification_date);
		        	 	verificationDate = sdf.format(s_date);
		        	}else{
		        		verification_date = null;
					}
					}
					
					String lastchanged_date=getRootElement("lastchanged_date").item(0).getTextContent();
					
					if(lastchanged_date!=null){
		        	 	Date s_date = (Date)changedDate1.parse(lastchanged_date);
		        	 	lastchangedDate = changedDate.format(s_date);
		        	}else{
		        		lastchanged_date = null;
					}
					String firstreceived_date=getRootElement("firstreceived_date").item(0).getTextContent();      
					if(firstreceived_date!=null){
		        	 	Date s_date = (Date)changedDate1.parse(firstreceived_date);
		        	 	firstreceivedDate = changedDate.format(s_date);
		        	}else{
		        		firstreceived_date = null;
					}
					String responsible_party_type="";
					NodeList responsible_party =getRootElement("responsible_party");
					for (int i = 0; i < responsible_party.getLength(); i++) {
						
						Node myNode = responsible_party.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element name_titleElement = (Element) myNode;
							NodeList name_titleList = name_titleElement.getElementsByTagName("name_title");
							Element name_titElement = (Element) name_titleList.item(0);
							if(name_titElement!=null){
								NodeList name_titleId = name_titElement.getChildNodes();
								responsible_party_type+= ((Node) name_titleId.item(0)).getNodeValue()+";";
							}
							
							//NodeList organizationList = name_titleElement.getElementsByTagName("organization");
							//Element organizationElement = (Element) organizationList.item(0);
							//NodeList organization = organizationElement.getChildNodes();
							
							 
							
						}
					}
					
					
					
					String is_fda_regulated=null;
					String has_expanded_access=null;
					if(getRootElement("has_expanded_access").item(0)!=null){                              
						has_expanded_access=getRootElement("has_expanded_access").item(0).getTextContent();                                  
					}
					String STATUS=null;                                               
					String study_results=null;                                       
					String conditions=null;                                           
					String interventions=null;
					if(getchildValue(getRootElement("intervention"))!=null){
						interventions= getTagValue("intervention_name", getchildValue(getRootElement("intervention")));                              
					}
					String link_url=null; 
					String link_description=null;
					
					try{
						link_url= getTagValue("url", getchildValue(getRootElement("link")));
						link_description= getTagValue("description", getchildValue(getRootElement("link")));
					}catch(Exception e){
						System.out.println(e.getMessage());
						link_url=null;
						link_description=null;
					}
					String age_groups=null;
					String enrollment=null;
					
					String funded_bys=null;                                           
					String other_ids=null;                                           
					String first_received=null;//clinicalStudy.getFirstreceivedDate();                                      
					if(getRootElement("completion_date").item(0)!=null){
					String completion_date=getRootElement("completion_date").item(0).getTextContent();  
					
					if(completion_date!=null){
		        	 	Date s_date = (Date)sdf1.parse(1+" "+completion_date);
		        	 	completionDate = sdf.format(s_date);
		        	}else{
		        		completion_date = null;
					}
					}
					String last_updated=null;                                         
					String last_verified=null;
					String acronym=null;
					if(getRootElement("acronym").item(0)!=null){
						acronym=getRootElement("acronym").item(0).getTextContent();                                              
					}
					String primary_completion_date=null;                              
					
					if(primary_completion_date!=null){
		        	 	Date s_date = (Date)sdf1.parse(1+" "+primary_completion_date);
		        	 	primary_completionDate = sdf.format(s_date);
		        	}else{
		        		primary_completion_date = null;
					}
					String outcome_measures=null;                                     
					String url1=null;                                                  
					String criteria_gender=null;                                      
					String criteria_minimum_age=null;                           
					String criteria_maximum_age=null;                                 
					
					String keyword=null;
					NodeList keyword1 =getRootElement("keyword");
					for (int i = 0; i < keyword1.getLength(); i++) {
						keyword+=keyword1.item(i).getTextContent();
						
					}
					String reference_PMID="";
					NodeList reference =getRootElement("reference");
					for (int i = 0; i < reference.getLength(); i++) {
						if(reference.item(i)!=null){
						Node myNode = reference.item(i);
						
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element name_titleElement = (Element) myNode;
							if(name_titleElement!=null){
								NodeList name_titleList = name_titleElement.getElementsByTagName("PMID");
								Element name_Element = (Element) name_titleList.item(0);
							if(name_Element!=null){
								NodeList name_titleId = name_Element.getChildNodes();
								reference_PMID+= ((Node) name_titleId.item(0)).getNodeValue()+";";
							}}
						}
						}
					}
					
					String mesh_trerms="";
					NodeList condition_browse =getRootElement("condition_browse");
					for (int i = 0; i < condition_browse.getLength(); i++) {
						
						Node myNode = condition_browse.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element name_titleElement = (Element) myNode;
							NodeList name_titleList = name_titleElement.getElementsByTagName("mesh_term");
							for (int j = 0; j < name_titleList.getLength(); j++) {
								mesh_trerms+=name_titleList.item(j).getTextContent()+";";
								
							}
						}
					}
					
					String arm_group_label="";                                      
					String arm_group_type="";  
					NodeList nodeLst =getRootElement("arm_group");
					for (int i = 0; i < nodeLst.getLength(); i++) {
						
						Node myNode = nodeLst.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element productElement = (Element) myNode;
							NodeList productIdList = productElement.getElementsByTagName("arm_group_label");
							Element productIdElement = (Element) productIdList.item(0);
							NodeList productId = productIdElement.getChildNodes();
							
							arm_group_label+=((Node) productId.item(0)).getNodeValue()+";";
							
							NodeList productDescriptionList = productElement.getElementsByTagName("arm_group_type");
							Element productDescriptionElement = (Element) productDescriptionList.item(0);
							if( productDescriptionElement!=null){
							NodeList productDescription = productDescriptionElement.getChildNodes();
							arm_group_type+= ((Node) productDescription.item(0)).getNodeValue()+";";
							}
							
							NodeList priceList = productElement.getElementsByTagName("description");
							if( (Element) priceList.item(0)!=null){
							Element priceElement = (Element) priceList.item(0);
							NodeList price = priceElement.getChildNodes();
							
							}
						}
					}
					String secondary_outcome_measure ="";                  
					String secondary_outcome_time_frame="";                
					String secondary_outcome_safety_issue="";
					NodeList secondary_outcome =getRootElement("secondary_outcome");
					for (int i = 0; i < secondary_outcome.getLength(); i++) {
						
						Node myNode = secondary_outcome.item(i);
						if (myNode.getNodeType() == Node.ELEMENT_NODE) {
							Element productElement = (Element) myNode;
							NodeList productIdList = productElement.getElementsByTagName("measure");
							Element productIdElement = (Element) productIdList.item(0);
							NodeList productId = productIdElement.getChildNodes();
							secondary_outcome_measure+=((Node) productId.item(0)).getNodeValue()+";";
							
							NodeList safety_issueList = productElement.getElementsByTagName("safety_issue");
							Element safety_issueElement = (Element) safety_issueList.item(0);
							if(safety_issueElement!=null){
							NodeList safety_issueId = safety_issueElement.getChildNodes();
							secondary_outcome_safety_issue+=((Node) safety_issueId.item(0)).getNodeValue()+";";
							}
							if(productElement.getElementsByTagName("time_frame")!=null){							
								NodeList time_frameList = productElement.getElementsByTagName("time_frame");
								Element time_frameElement = (Element) time_frameList.item(0);
							if(time_frameElement!=null){
								NodeList time_frameId = time_frameElement.getChildNodes();
								secondary_outcome_time_frame+=((Node)time_frameId.item(0)).getNodeValue()+";";
							}}
						}
					}
					
					
					String rank=getXMLRootElement();
					
					ps.setObject(1,NctId);
				  	ps.setObject(2,studyId);
				  	ps.setObject(3,url);
				  	ps.setObject(4,briefTitle);
				  	ps.setObject(5,officialTitle);
				  	ps.setObject(6,SpoLeadAgency);
				  	ps.setObject(7,spoLeadAgencyclass);
				  	ps.setObject(8,source);
				  	ps.setObject(9,briefSumTextBox);
				  	ps.setObject(10,detailedDescTextBox);
				  	ps.setObject(11,collaborator_agency);
				  	ps.setObject(12,collaborator_agency_class);
				  	ps.setObject(13,overAllStatus);
				  	ps.setObject(14,oversightInfoAuthority);
				  	ps.setObject(15,startDate);
				  	ps.setObject(16,studyType);
				  	ps.setObject(17,studyDesign);
				  	ps.setObject(18,oversight_info_has_dmc);
				  	ps.setObject(19,phase);
				  	ps.setObject(20,primary_outcome_measure);
				  	ps.setObject(21,primary_outcome_time_frame);
				  	ps.setObject(22,primary_outcome_safety_issue);
				  	ps.setObject(23,primary_outcome_description);
				  	ps.setObject(24,eligibility_criteria_textblock);
				  	ps.setObject(25,String.valueOf(number_of_arms));
				  	ps.setObject(26,enrollment_count);
				  	ps.setObject(27,condition);
				  	ps.setObject(28,study_pop);
				  	ps.setObject(29,sampling_method);
				  	ps.setObject(30,Inclusion_criteria);
				  	ps.setObject(31,gender);
				  	ps.setObject(32,minimum_age);
				  	ps.setObject(33,maximum_age);
				  	ps.setObject(34,healthy_volunteers);
				  	ps.setObject(35,overall_official_last_name);
				  	ps.setObject(36,overall_official_role);
				  	ps.setObject(37,overall_official_affiliation);
				  	ps.setObject(38,overall_contact_location_facility);
				  	ps.setObject(39,overall_contact_location_facility_address_city);
				  	ps.setObject(40,overall_contact_location_facility_address_state);
				  	ps.setObject(41,overall_contact_location_facility_address_zip);
				  	ps.setObject(42,overall_contact_location_facility_address_country);
				  	ps.setObject(43,overall_contact_last_name);
				  	ps.setObject(44,overall_contact_phone);
				  	ps.setObject(45,overall_contact_email);
				  	ps.setObject(46,overall_contact_backup_last_name);
				  	ps.setObject(47,overall_contact_backup_phone);
				  	ps.setObject(48,overall_contact_backup_email);
				  	ps.setObject(49,facility_name);
				  	ps.setObject(50,facility_city);
				  	ps.setObject(51,facility_state);
				  	ps.setObject(52,facility_zip);
				  	ps.setObject(53,facility_country);
				  	ps.setObject(54,facility_status);
				  	ps.setObject(55,facility_name_2);
				  	ps.setObject(56,facility_city_2);
				  	ps.setObject(57,facility_state_2);
				  	ps.setObject(58,facility_zip_2);
				  	ps.setObject(59,facility_contact_2_last_name);
				  	ps.setObject(60,facility_contact_2_phone);
				  	ps.setObject(61,facility_contact_2_email);
				  	ps.setObject(62,contact_investigator_last_name);
				  	ps.setObject(63,contact_investigator_role);
				  	ps.setObject(64,location_countries);
				  	ps.setObject(65,verificationDate);
				  	ps.setObject(66,lastchangedDate);
				  	ps.setObject(67,firstreceivedDate);
				  	ps.setObject(68,responsible_party_type);
				  	ps.setObject(69,is_fda_regulated);
				  	ps.setObject(70,has_expanded_access);
				  	ps.setObject(71,STATUS);
				  	ps.setObject(72,study_results);
				  	ps.setObject(73,conditions);
				  	ps.setObject(74,interventions);
				  	ps.setObject(75,link_url);
				  	ps.setObject(76,link_description);
				  	ps.setObject(77,age_groups);
				  	ps.setObject(78,enrollment);
				  	ps.setObject(79,funded_bys);
				  	ps.setObject(80,other_ids);
				  	ps.setObject(81,first_received);
				  	ps.setObject(82,completionDate);
				  	ps.setObject(83,last_updated);
				  	ps.setObject(84,last_verified);
				  	ps.setObject(85,acronym);
				  	ps.setObject(86,primary_completionDate);
				  	ps.setObject(87,outcome_measures);
				  	ps.setObject(88,url1);
				  	ps.setObject(89,criteria_gender);
				  	ps.setObject(90,criteria_minimum_age);
				  	ps.setObject(91,criteria_maximum_age);
				  	ps.setObject(92,keyword);
				  	ps.setObject(93,reference_PMID);
				  	ps.setObject(94,mesh_trerms);
				  	
				  	ps.setObject(95,arm_group_label);
				  	ps.setObject(96,arm_group_type);
				  	
				  	ps.setObject(97,secondary_outcome_measure);
				  	ps.setObject(98,secondary_outcome_time_frame);
				  	ps.setObject(99,secondary_outcome_safety_issue);
				  	ps.setObject(100,rank);
				  	ps.executeUpdate();
				  System.out.println("Parsing completed");
				  }
				  catch(Exception e){
					  e.printStackTrace();
				  }
				  finally
				  {
					 // System.out.println("connection is closed");
					  if (con != null)  
			            {  
			                try  
			                {
			                	ps.close();
			                	con.close ();  
			                }  
			                catch (Exception e) { 
			                	e.printStackTrace();
			                }  
			            }  
				  }
				  	
				  	
			  }
	 	  
	

	private static String getTagValue(String sTag, Element eElement) {
		Node nValue=null;
		try{
		if(eElement.getElementsByTagName(sTag)!=null){	
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
		
	    nValue = (Node) nlList.item(0);
	    if(nValue.getNodeValue()!=null){
	    	return nValue.getNodeValue();
	    }
	    return null;
		}else{
			return null;
		}
		}
	 	catch(Exception e){
	 		
	 		 nValue=null;
	 		
	 		//e.printStackTrace();
	 	}
	 	return null;
	  }
	private static  Element getchildValue(NodeList nodeList){
		 Element eElement=null;
		 try{
			 for (int temp = 0; temp < nodeList.getLength(); temp++) {
				 Node nNode = nodeList.item(temp);
				 if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	 		       eElement = (Element) nNode;
	 		       if(eElement!=null){
	 		    	   
	 		    	   return eElement;
	 		       }
	 		       
				 }
			 }	
		
		 }catch(Exception e){
			 System.out.print("Error :" + e.getMessage());
			 if(eElement==null){
				 return null;
		       }
		       	
		 }
		 return null;
	}
	private static NodeList getRootElement(String eleName){
		try{
			File fXmlFile = new File(Clinical_retrieveXML.FILE_NAME);
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName(eleName);
			if(nList!=null){
			return nList;}else{
				return null;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	private static String getXMLRootElement(){
		try{
			File fXmlFile = new File(Clinical_retrieveXML.FILE_NAME);
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			Element Ele= doc.getDocumentElement();
			String rank=Ele.getAttribute("rank");
			return rank;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
}
