/*
 * author Rupal Kathiriya
 */
package com.clinical.DOM;

import java.io.File;
import java.sql.SQLException;

public class Clinical_retrieveXML {
	
	public static String FILE_NAME;
	public static void main(String args[]) throws SQLException{
		ClinicalGrantParserProperties grantParserProperties=new ClinicalGrantParserProperties();
		String getPath=grantParserProperties.getInFolderName();
		String filter=".xml";
		parse(getPath, filter,1);
	}
		 public Clinical_retrieveXML() throws  SQLException {
			// TODO Auto-generated constructor stub
			
		}
		public static void parse(String dirName,String filter,Integer iLevel) throws  SQLException {
			//Parses all files satisfying particular name pattern
			//in a given directory and its subdirectories.
			String[] dirList = dirName.split(",");
			for (String dirpath : dirList)
			{
				parseDirectory(dirpath, filter, iLevel);
			}
		}
		public static String mainFile=null;
		public String fileName=null;
		public String getFileName() {
			fileName=mainFile;
			return fileName;
		}
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}
		public static void parseDirectory(String dirName,String filter,Integer iLevel) throws  SQLException
		{
			ClinicalGrantSearch search = new ClinicalGrantSearch();
			//search for files satisfying provided filter
			search.DoSearch(dirName, filter, null, iLevel);
		 	for(File file : search.Files) 
	        {
         		System.out.println("File Name parsing : " +file.getName());
         		try{
         				FILE_NAME = file.getName();
         				ClinicalRetrieveDOM clinicalRetrieveDOM=new ClinicalRetrieveDOM();
         			 	clinicalRetrieveDOM.save();
         		}
         		catch(Exception e){
         			e.printStackTrace();
         		}
	        }
		 	
        }
		
}
