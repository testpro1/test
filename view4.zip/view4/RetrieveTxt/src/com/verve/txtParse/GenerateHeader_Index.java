/**
 * Mapping file pojo
 * 
 * author Rupal Kathiriya
 */
package com.verve.txtParse;

public class GenerateHeader_Index {
	int song_name=1;
	int album_name=2;
	int	artist_name=3;
	int composer_name=4;
	int primary_genre_name=5;
	int isrc=6;
	int upc=7;
	int song_url=8;
	int artist_url=9;
	int composer_url=10;
	int album_artwork_url=11;
	int song_preview_url=12;	
	int song_price=13;
	int album_price=14;	
	int p_line=15;	
	int copyright=16;	
	int track_length=17;
	int original_release_date=18;	
	int itunes_release_date=19;	
	int content_rating=20;
	
	
	public int getSong_name() {
		return song_name;
	}
	public void setSong_name(int songName) {
		song_name = songName;
	}
	public int getAlbum_name() {
		return album_name;
	}
	public void setAlbum_name(int albumName) {
		album_name = albumName;
	}
	public int getArtist_name() {
		return artist_name;
	}
	public void setArtist_name(int artistName) {
		artist_name = artistName;
	}
	public int getComposer_name() {
		return composer_name;
	}
	public void setComposer_name(int composerName) {
		composer_name = composerName;
	}
	public int getPrimary_genre_name() {
		return primary_genre_name;
	}
	public void setPrimary_genre_name(int primaryGenreName) {
		primary_genre_name = primaryGenreName;
	}
	public int getIsrc() {
		return isrc;
	}
	public void setIsrc(int isrc) {
		this.isrc = isrc;
	}
	public int getUpc() {
		return upc;
	}
	public void setUpc(int upc) {
		this.upc = upc;
	}
	public int getSong_url() {
		return song_url;
	}
	public void setSong_url(int songUrl) {
		song_url = songUrl;
	}
	public int getArtist_url() {
		return artist_url;
	}
	public void setArtist_url(int artistUrl) {
		artist_url = artistUrl;
	}
	public int getComposer_url() {
		return composer_url;
	}
	public void setComposer_url(int composerUrl) {
		composer_url = composerUrl;
	}
	public int getAlbum_artwork_url() {
		return album_artwork_url;
	}
	public void setAlbum_artwork_url(int albumArtworkUrl) {
		album_artwork_url = albumArtworkUrl;
	}
	public int getSong_preview_url() {
		return song_preview_url;
	}
	public void setSong_preview_url(int songPreviewUrl) {
		song_preview_url = songPreviewUrl;
	}
	public int getSong_price() {
		return song_price;
	}
	public void setSong_price(int songPrice) {
		song_price = songPrice;
	}
	public int getAlbum_price() {
		return album_price;
	}
	public void setAlbum_price(int albumPrice) {
		album_price = albumPrice;
	}
	public int getP_line() {
		return p_line;
	}
	public void setP_line(int pLine) {
		p_line = pLine;
	}
	public int getCopyright() {
		return copyright;
	}
	public void setCopyright(int copyright) {
		this.copyright = copyright;
	}
	public int getTrack_length() {
		return track_length;
	}
	public void setTrack_length(int trackLength) {
		track_length = trackLength;
	}
	public int getOriginal_release_date() {
		return original_release_date;
	}
	public void setOriginal_release_date(int originalReleaseDate) {
		original_release_date = originalReleaseDate;
	}
	public int getItunes_release_date() {
		return itunes_release_date;
	}
	public void setItunes_release_date(int itunesReleaseDate) {
		itunes_release_date = itunesReleaseDate;
	}
	public int getContent_rating() {
		return content_rating;
	}
	public void setContent_rating(int contentRating) {
		content_rating = contentRating;
	}
	
	

}
