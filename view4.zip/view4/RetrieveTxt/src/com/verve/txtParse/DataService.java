/**
 * Mapping table pojo
 * 
 * author Rupal Kathiriya
 */

package com.verve.txtParse;

import java.util.Date;

public class DataService {
	String fd_title,fd_name,fd_link,fd_price,fd_contentype,fd_category,fd_artistname,fd_artisturl,
			fd_update,fd_imagesmall,fd_imagemedium,fd_imagelarge,fd_rights,fd_content,fd_description;
	int fd_itemcount;
	Date fd_releasedate;
	
	public String getFd_title() {
		return fd_title;
	}
	public void setFd_title(String fdTitle) {
		fd_title = fdTitle;
	}
	public String getFd_name() {
		return fd_name;
	}
	public void setFd_name(String fdName) {
		fd_name = fdName;
	}
	public String getFd_link() {
		return fd_link;
	}
	public void setFd_link(String fdLink) {
		fd_link = fdLink;
	}
	public String getFd_price() {
		return fd_price;
	}
	public void setFd_price(String fdPrice) {
		fd_price = fdPrice;
	}
	public String getFd_contentype() {
		return fd_contentype;
	}
	public void setFd_contentype(String fdContentype) {
		fd_contentype = fdContentype;
	}
	public String getFd_category() {
		return fd_category;
	}
	public void setFd_category(String fdCategory) {
		fd_category = fdCategory;
	}
	public String getFd_artistname() {
		return fd_artistname;
	}
	public void setFd_artistname(String fdArtistname) {
		fd_artistname = fdArtistname;
	}
	public String getFd_artisturl() {
		return fd_artisturl;
	}
	public void setFd_artisturl(String fdArtisturl) {
		fd_artisturl = fdArtisturl;
	}
	public String getFd_update() {
		return fd_update;
	}
	public void setFd_update(String fdUpdate) {
		fd_update = fdUpdate;
	}
	public String getFd_imagesmall() {
		return fd_imagesmall;
	}
	public void setFd_imagesmall(String fdImagesmall) {
		fd_imagesmall = fdImagesmall;
	}
	public String getFd_imagemedium() {
		return fd_imagemedium;
	}
	public void setFd_imagemedium(String fdImagemedium) {
		fd_imagemedium = fdImagemedium;
	}
	public String getFd_imagelarge() {
		return fd_imagelarge;
	}
	public void setFd_imagelarge(String fdImagelarge) {
		fd_imagelarge = fdImagelarge;
	}
	public String getFd_rights() {
		return fd_rights;
	}
	public void setFd_rights(String fdRights) {
		fd_rights = fdRights;
	}
	public String getFd_content() {
		return fd_content;
	}
	public void setFd_content(String fdContent) {
		fd_content = fdContent;
	}
	public String getFd_description() {
		return fd_description;
	}
	public void setFd_description(String fdDescription) {
		fd_description = fdDescription;
	}
	public int getFd_itemcount() {
		return fd_itemcount;
	}
	public void setFd_itemcount(int fdItemcount) {
		fd_itemcount = fdItemcount;
	}
	public Date getFd_releasedate() {
		return fd_releasedate;
	}
	public void setFd_releasedate(Date fdReleasedate) {
		fd_releasedate = fdReleasedate;
	}
	

}
