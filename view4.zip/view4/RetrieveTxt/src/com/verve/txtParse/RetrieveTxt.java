/* RetrieveXMl handles parsed the all records.
 * 
 * author Rupal Kathiriya
 */
package com.verve.txtParse;

import java.io.*;
import java.sql.*;
import java.util.*;

public class RetrieveTxt {
	
	private String[] _sourceValueArray;
	private ArrayList<DataService> _objectValue=new ArrayList<DataService>();
	private int _stop=20000;
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws SQLException {
	try{
		Wejunkie_junkieappParserProperties grantParserProperties=new Wejunkie_junkieappParserProperties();
		String getPath=grantParserProperties.getInFolderName();
		String filter=".txt";
		RetrieveTxt retrieveTxt=new RetrieveTxt();
		retrieveTxt.parse(getPath, filter,1);
		System.gc();
		System.out.println("Cleanup completed..."); 
		 	}catch(Exception e){
		 		e.printStackTrace();
		 	}
		}
		public void parse(String dirName,String filter,Integer iLevel) throws SQLException, FileNotFoundException {
			//Parses all files satisfying particular name pattern
			//in a given directory and its subdirectories.
			String[] dirList = dirName.split(",");
			for (String dirpath : dirList)
			{
				parseDirectory(dirpath, filter, iLevel);
			}
		}
		// filtering files from directory
		public void parseDirectory(String dirName,String filter,Integer iLevel) throws SQLException, FileNotFoundException
		{
			Wejunkie_junkieappSearch search = new Wejunkie_junkieappSearch();
			
			search.DoSearch(dirName, filter, null, iLevel);
         	for(File file : search.Files) 
	        {
         		readFile(dirName+"/"+file.getName());
         	}
        }
		//Buffering the input file and skipped the lines which starting from #
		public void readFile(String fileName) throws FileNotFoundException, SQLException {
			try {
				int lineNo = 0;
				FileInputStream fstream = new FileInputStream(fileName);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
				String lineValue = bufferedReader.readLine();
				while ((lineValue = bufferedReader.readLine()) != null) {
					lineNo++;
					if(lineNo!=0)
					{
						if(!lineValue.startsWith("#")){
							processLine(lineValue, lineNo);
						}else{
							continue;
						}
					}					
				}
				in.close();
				fstream.close();
				bufferedReader.close();
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		//Mapping values with table index and set it
		public  void processLine(String line,int lineNo) throws SQLException{
			int count=0;
				_sourceValueArray=line.split("	");
				DataService dataService=new DataService();
				for(int i=0;i<_sourceValueArray.length;i++){
					count++;
					GenerateHeader_Index generateHeaderIndex=new GenerateHeader_Index();
					if(generateHeaderIndex.getSong_name()==count){
						dataService.setFd_title(_sourceValueArray[i]);
					}if(generateHeaderIndex.getAlbum_name()==count){
						dataService.setFd_name(_sourceValueArray[i]);
					}if(generateHeaderIndex.getArtist_name()==count){
						dataService.setFd_artistname(_sourceValueArray[i]);
					}if(generateHeaderIndex.getSong_url()==count){
						dataService.setFd_link(_sourceValueArray[i]);
					}if(generateHeaderIndex.getArtist_url()==count){
						dataService.setFd_artisturl(_sourceValueArray[i]);
					}if(generateHeaderIndex.getAlbum_artwork_url()==count){
						dataService.setFd_imagesmall(_sourceValueArray[i]);
					}if(generateHeaderIndex.getAlbum_artwork_url()==count){
						dataService.setFd_imagemedium(_sourceValueArray[i]);
					}if(generateHeaderIndex.getAlbum_artwork_url()==count){
						dataService.setFd_imagelarge(_sourceValueArray[i]);
					}if(generateHeaderIndex.getCopyright()==count){
						dataService.setFd_rights(_sourceValueArray[i]);
					}if(generateHeaderIndex.getAlbum_price()==count){
						dataService.setFd_price(_sourceValueArray[i]);
					}
				}
				_objectValue.add(dataService);
				if(_stop==lineNo){
					DataConnection scios360_1=new DataConnection();
		            scios360_1.save(_objectValue);
		            _objectValue.clear();
		            _sourceValueArray=null;
					_stop=_stop+20000;
					System.gc();
					System.out.println("Cleanup completed..."); 
				}
				
		}
	}


