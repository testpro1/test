/*
 * author Rupal Kathiriya
 */

package xmltransform;

import java.io.File;
import java.sql.SQLException;

public class ParseXML {
	//public static  String FILE_NAME;
	//public static  String FILE_PATH;
	public static  String fileName;
	public static  String filePath;
	String userName;
	String password;
	String dbDriver;
	String databaseName; 
	String host;
	String port;
	String tableName;
	
	public  String getFileName() {
		return fileName;
	}
	public  void setFileName(String fileName) {
		ParseXML.fileName = fileName;
	}
	public String getFilePath() {
		return filePath;
	}
	public  void setFilePath(String filePath) {
		ParseXML.filePath = filePath;
	}
	@SuppressWarnings("static-access")
	public ParseXML(String fileName,String filePath){
		this.fileName=fileName;
		this.filePath=filePath;
	}
	public ParseXML(String userName, String password,String dbDriver, String databaseName, String host, String port) throws  SQLException {
		this.userName=userName;
		this.password=password;
		this.dbDriver=dbDriver;
		this.databaseName=databaseName;
		this.host=host;
		this.port=port;
		XmlTransformProperties grantParserProperties=new XmlTransformProperties();
		@SuppressWarnings("static-access")
		String getPath=grantParserProperties.getInFolderPath();
		String filter=".xml";
		parse(getPath, filter,1);
	}
	
	public  void parse(String dirName,String filter,Integer iLevel) throws  SQLException {
		//Parses all files satisfying particular name pattern
		//in a given directory and its subdirectories.
		String[] dirList = dirName.split(",");
		for (String dirpath : dirList)
		{
			parseDirectory(dirpath, filter, iLevel);
		}
	}
		@SuppressWarnings("static-access")
		public  void parseDirectory(String dirName,String filter,Integer iLevel) throws  SQLException
		{
			XmlFileSearch search = new XmlFileSearch();
			XmlTransformProperties grantParserProperties=new XmlTransformProperties();
			//search for files satisfying provided filter
			search.DoSearch(dirName, filter, null, iLevel);
		 	for(File file : search.Files) 
	        {
         		System.out.println("File Name parsing : " +file.getName());
         		try{
         				//FILE_NAME = file.getName();
     					//FILE_PATH=grantParserProperties.getInFolderPath();
         				setFileName(file.getName());
         				setFilePath(grantParserProperties.getInFolderPath());
         				GenerateTableScript generateTableScript=new GenerateTableScript();
         				generateTableScript.GenerateTable(getFileName(),getFilePath(), userName, password,dbDriver, databaseName,  host, port);
         				
         		}
         		catch(Exception e){
         			e.printStackTrace();
         		}
	      }
	}
}
