package xmltransform;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.io.*;

public class DownloadZip {
	
public void createZip(String filePath,String dirPath,String extractFileName){

	try
	  {
	  ZipOutputStream out = new ZipOutputStream(new 
	BufferedOutputStream(new FileOutputStream(dirPath)));
	  byte[] data = new byte[1000]; 
	  BufferedInputStream in = new BufferedInputStream(new FileInputStream(filePath));
	  int count;
	 out.putNextEntry(new ZipEntry(extractFileName));
	 while((count = in.read(data,0,1000)) != -1)
	 {  
	 out.write(data, 0, count);
	 }
	 in.close();
	 out.flush();
	 out.close();
	  System.out.println("Your file is zipped");
	 }
	 catch(Exception e)
	  {
	 e.printStackTrace();
	  }  
}
}