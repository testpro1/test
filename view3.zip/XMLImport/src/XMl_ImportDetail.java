import java.io.*;
import java.sql.*;
import java.util.*;


public class XMl_ImportDetail {
	
		
	public static void main(String args[]) {  
		  
		  System.out.println("now we are going to connect with a database ");  
		  
		  try {  
		
		   Class.forName("com.mysql.jdbc.Driver");  
		  
		   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/abc", "root", "root");  
		   Statement st = con.createStatement();  
		  
		   System.out.println("connection has been made ");  
		  
		   Scanner scanner = new Scanner(System.in);  
		   System.out.println("please enter table name ");  
		   String tableName = scanner.next();  
		  
		   String strr = null;  
		  
		   System.out.println("Enter no of columns you like to use: ");  
		   int noc = scanner.nextInt();  
		  
		   for (int i = 1; i <= noc; i++) {  
		    BufferedReader bf = new BufferedReader(new InputStreamReader(  
		      System.in));  
		    System.out.println("Enter column name with type ");  
		    String s1 = bf.readLine();  
		    if (strr == null) {  
		     strr = s1;  
		  
		    } else {  
		     strr = strr + s1;  
		     System.out.println("strr  "+strr);
		    }  
		  
		   }  
		  
		   st.executeUpdate("create table " + tableName + "(" + strr + ")");  
		   System.out.println("your table " + tableName  
		     + " has been created!!!");  
		  
		   ResultSet rs = st.executeQuery("SELECT * FROM " + tableName);  
		   ResultSetMetaData rsmd = rs.getMetaData();  
		   int NumOfCol = rsmd.getColumnCount();  
		   System.out.println("Number of Columns of your table =" + tableName  + " " + NumOfCol);  
		   System.out.println("Column names are ");  
		   for (int i = 1; i <= NumOfCol; i++) {  
			   System.out.println(rsmd.getColumnName(i));  
		   }  
		   String strn = null;  
		   System.out.println("please enter values you need to insert");  
		  
		   for (int i = 1; i <= NumOfCol; i++) {  
		    String s5 = scanner.next();  
		    if (strn == null) {  
		     strn = s5;  
		  
		    } else  
		     strn = strn + s5;  
		  
		   }  
		   System.out.println("strn   "+strn);  
		  
		   st.executeUpdate("insert into " + tableName + " values" + "("  
		     + strn + ")");  
		   System.out.println("your table " + tableName  
		     + " has been filled!!!");  
		  
		   con.close();  
		   System.out.println("connection has been colsed ");  
		  
		  }  
		  
		  catch (Exception e) {  
		  
		   System.out.println(e.getMessage());  
		  }  
		  
		 }  
		  
}
