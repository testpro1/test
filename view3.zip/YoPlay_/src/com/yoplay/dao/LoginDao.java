package com.yoplay.dao;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.text.Normalizer;
import java.util.regex.Pattern;


import com.yoplay.to.AboutMeTo;
import com.yoplay.to.ReferenceTo;
import com.yoplay.to.TermsPolicyTo;
import com.yoplay.util.HibernateUtil;

public class LoginDao {
	 	SessionFactory sf = null;
	    Session ses = null;
	    Transaction tra = null;
	    Query query = null;
	    
	    public LoginDao() {
	        sf = HibernateUtil.getSessionFactory();
	        ses = sf.openSession();
	        tra = ses.beginTransaction();
	    }
	    public boolean chkPass(ReferenceTo log){
	    	try{
	    		boolean isValid = false;
		        StringBuilder buil = new StringBuilder();
		        buil.append("select eid,password from ReferenceTo bean where bean.eid=:eid and bean.password=:password");
		        query = ses.createQuery(buil.toString());
		        query.setString("eid", log.getEid());
		        query.setString("password", log.getPassword());
		        List alldata = query.list();
		        if (alldata.size() == 1) {
		            isValid = true;
		        }else {
		            isValid = false;
		        }
		        return isValid;
	    		
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    	return true;
	    }
	    public String deAccent(String str) {
	        String nfdNormalizedString = Normalizer.normalize(str, Normalizer.Form.NFD); 
	        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
	        return pattern.matcher(nfdNormalizedString).replaceAll("");
	    }
	    public boolean InsertRecord(ReferenceTo log) {
	        try {
	        	String name=deAccent(log.getFname().toString());
	        	System.out.println("name::"+name);
	        	log.setFname(name);
	            ses.save(log);
	            tra.commit();
	            return true;
	        } catch (Exception e) {
	            tra.rollback();
	          return false;
	        }
	    }
		public List<AboutMeTo> viewUsr(){
			query = ses.createQuery("from AboutMeTo");
			return query.list();
	    }
	
		public List<TermsPolicyTo> viewTerms_Policy(){
			query = ses.createQuery("from TermsPolicyTo");
			return query.list();
        }
	  public Boolean getUser(ReferenceTo log) {
	        boolean isValid = false;
	        StringBuilder buil = new StringBuilder();
	        buil.append("select eid,password from ReferenceTo bean where bean.eid=:eid and bean.password=:password");
	        query = ses.createQuery(buil.toString());
	        query.setString("eid", log.getEid());
	        query.setString("password", log.getPassword());
	        List alldata = query.list();
	        if (alldata.size() == 1) {
	            isValid = true;
	        }else {
	            isValid = false;
	        }
	        return isValid;
	    }
	  public boolean forgotPass(ReferenceTo log){
	    	try{
	    		boolean isValid = false;
		        StringBuilder buil = new StringBuilder();
		        buil.append("select eid,password from ReferenceTo bean where bean.eid=:eid and bean.password=:password");
		        query = ses.createQuery(buil.toString());
		        query.setString("eid", log.getEid());
		        query.setString("password", log.getPassword());
		        List alldata = query.list();
		        if (alldata.size() == 1) {
		            isValid = true;
		        }else {
		            isValid = false;
		        }
		        return isValid;
	    		
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    	return true;
	    }
	
}