package com.yoplay.dao;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.yoplay.to.AboutMeTo;
import com.yoplay.to.GeneralTo;
import com.yoplay.to.TermsPolicyTo;
import com.yoplay.util.HibernateUtil;

public class GeneralDao {
	 	SessionFactory sf = null;
	    Session ses = null;
	    Transaction tra = null;
	    Query query = null;

	    public GeneralDao() {
	        sf = HibernateUtil.getSessionFactory();
	        ses = sf.openSession();
	        tra = ses.beginTransaction();
	    }	    
	    public boolean InsertRecord(GeneralTo log) {
	        try {
	        	ses.save(log);
	            tra.commit();
	            return true;
	        } catch (Exception e) {
	            tra.rollback();
	            e.printStackTrace();
	            return false;
	        }
	    }
	   	public void deleteAboutMe(){
	    		query = ses.createQuery("delete from AboutMeTo");
	    		query.executeUpdate();
	            }
	    public boolean InsertRecordAboutMe(AboutMeTo log) {
	        try {
	        	deleteAboutMe();
	        	System.out.println(log.getAboutme());
	        	ses.save(log);
	            tra.commit();
	            return true;
	        } catch (Exception e) {
	            tra.rollback();
	            e.printStackTrace();
	            return false;
	        }
	        
	    }
	    
	    
	    public boolean InsertRecordTermsPolicy(TermsPolicyTo log) {
	        try {
	        	deleteTerms_Policy();
	        	ses.save(log);
	            tra.commit();
	            return true;
	        } catch (Exception e) {
	            tra.rollback();
	            e.printStackTrace();
	            return false;
	        }
	    }
		public void deleteTerms_Policy(){
    		query = ses.createQuery("delete from TermsPolicyTo");
    		query.executeUpdate();
            }

	public List<GeneralTo> viewUsr(){
		query = ses.createQuery("from ReferenceTo");
        return query.list();
        }
	 
}