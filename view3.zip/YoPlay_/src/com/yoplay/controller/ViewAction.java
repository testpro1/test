
package com.yoplay.controller;

import com.yoplay.dao.LoginDao;
import com.yoplay.to.AboutMeTo;
import com.yoplay.to.TermsPolicyTo;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class ViewAction extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	//System.out.println("in view");
        LoginDao userDAO = new LoginDao();
        List<AboutMeTo> data=userDAO.viewUsr();
        request.setAttribute("usersList", data);
        List<TermsPolicyTo> terms=userDAO.viewTerms_Policy();
        request.setAttribute("termsandpolicy", terms);
        //request.setAttribute("usersList", userDAO.getAllUser());
        RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
        response.setContentType("text/html");
        rd.forward(request, response);
//      request.getRequestDispatcher("viewData.jsp").forward(request, response);
    } 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	//System.out.println("in get");
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
