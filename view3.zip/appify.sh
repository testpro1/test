#!/bin/bash
if [ $# = 2 ]
then 
echo "#!/usr/bin/env xdg-open

[Desktop Entry]
Version=1.0
Name= "$2"
GenericName=Web Browser
Exec=firefox -P WebApps -no-remote $1
Terminal=false
X-MultipleArgs=false
Type=Application
Icon=firefox
Categories=Application;Network;
MimeType=text/html;
StartupWMClass=Firefox
StartupNotify=true" > ~/.local/share/applications/"$2".desktop
exit
fi
if [ $# == 1 ]
then
echo "Please give the program either two arguments or no arguments.  Thanks :)"
exit
fi
URL=`zenity --entry --text="Enter complete URL of website:"`
if [ $? != 0 ] 
then 
exit
fi
NAME="`zenity --entry --text="Enter desired name of menu item:"`"
if [ $? != 0 ]
then
exit
fi
test "$URL" = "";
RETURN3=$?
test "$NAME" = "";
RETURN4=$?
if [[ ($RETURN3 == 0) || ($RETURN4 == 0) ]]
then
zenity --error --text="Please retry, giving values for both dialog boxes!  Thanks :)"
exit
fi
echo "#!/usr/bin/env xdg-open

[Desktop Entry]
Version=1.0
Name= "$NAME"
GenericName=Web Browser
Exec=firefox -P WebApps -no-remote $URL
Terminal=false
X-MultipleArgs=false
Type=Application
Icon=firefox
Categories=Application;Network;
MimeType=text/html;
StartupWMClass=Firefox
StartupNotify=true" > ~/.local/share/applications/"$2".desktop
