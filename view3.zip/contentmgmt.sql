/*
SQLyog Community Edition- MySQL GUI v8.05 
MySQL - 5.1.69-0ubuntu0.11.10.1 : Database - contentmgmt
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`contentmgmt` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `contentmgmt`;

/*Table structure for table `contentMenu` */

DROP TABLE IF EXISTS `contentMenu`;

CREATE TABLE `contentMenu` (
  `menuId` int(11) NOT NULL AUTO_INCREMENT,
  `menuName` varchar(100) DEFAULT NULL,
  `pageTitle` varchar(100) DEFAULT NULL,
  `pageAlias` varchar(100) DEFAULT NULL,
  `metaDes` varchar(100) DEFAULT NULL,
  `metaKey` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`menuId`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `contentMenu` */

insert  into `contentMenu`(`menuId`,`menuName`,`pageTitle`,`pageAlias`,`metaDes`,`metaKey`) values (1,'About Us','About Usa','About Us','About Us','About Us'),(2,'Get Started','Get Started123','Get Started','Get Started','Get Started'),(3,'How To Play','How To Play titles','How To Play','How To Play','How To Play'),(4,'Promotion','Promotion','Promotion','Promotion','Promotion');

/*Table structure for table `subMenu` */

DROP TABLE IF EXISTS `subMenu`;

CREATE TABLE `subMenu` (
  `subMenuId` int(11) NOT NULL AUTO_INCREMENT,
  `contentMenu_childId` int(11) DEFAULT NULL,
  `contentMenu_parentId` int(11) DEFAULT NULL,
  `subMenuName` varchar(255) DEFAULT NULL,
  `subMetaDes` varchar(255) DEFAULT NULL,
  `subMetaKey` varchar(255) DEFAULT NULL,
  `subPageAlias` varchar(255) DEFAULT NULL,
  `subPageTitle` varchar(255) DEFAULT NULL,
  `menuId` int(11) DEFAULT NULL,
  PRIMARY KEY (`subMenuId`),
  KEY `FK909D27BFAF673DA9` (`menuId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `subMenu` */

/*Table structure for table `thirdLevelMenu` */

DROP TABLE IF EXISTS `thirdLevelMenu`;

CREATE TABLE `thirdLevelMenu` (
  `thirdLevelId` int(11) NOT NULL AUTO_INCREMENT,
  `subMenuId` int(11) DEFAULT NULL,
  `thirdLevelMetaDes` varchar(255) DEFAULT NULL,
  `thirdLevelMetaKey` varchar(255) DEFAULT NULL,
  `thirdLeveName` varchar(255) DEFAULT NULL,
  `thirdLevelPageAlias` varchar(255) DEFAULT NULL,
  `thirdLevelPageTitle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`thirdLevelId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `thirdLevelMenu` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
