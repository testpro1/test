/*configuration with mysql database.
 * 
 * author Rupal Kathiriya
 */

package com.verve.txtParse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@SuppressWarnings("static-access")
public class DataConnection {
	Wejunkie_junkieappParserProperties webJunkieParserProperties=new Wejunkie_junkieappParserProperties();
	String getPath=webJunkieParserProperties.getInFolderName();
	 Connection con = null;
	 String url = webJunkieParserProperties.getUrl();
	 String db =webJunkieParserProperties.getDB();
	 String driver = webJunkieParserProperties.getDriver();
	 String username = webJunkieParserProperties.getUsername();
	 String password = webJunkieParserProperties.getPassword();
	  public Connection getMyconnection()
	  {
		  try{
			   Class.forName(driver);
		  	   con = DriverManager.getConnection(url+db,username, password);
			 }
		  	catch (Exception e){
		  		e.printStackTrace();
		  	}
		return con;  
	  }
	public void save(List<DataService> list) throws SQLException
	{
		PreparedStatement ps = null;
		@SuppressWarnings("unused")
		String startDate = null;
		@SuppressWarnings("unused")
		String endDate = null;
		
		try{
			/*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			*/
			String sqlString = "insert into feeds1(feed_source_id,fd_title,fd_name,fd_link,fd_price," +
					"fd_contentype,fd_category,fd_artistname,fd_artisturl," +
					"fd_update,fd_imagesmall,fd_imagemedium,fd_imagelarge," +
					"fd_rights,fd_releasedate,fd_itemcount,fd_content," +
					"fd_description) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			ps = getMyconnection().prepareStatement(sqlString);
			for(int i=0;i<list.size();i++){
			//System.out.println(list.get(i).getFd_releasedate());
			ps.setInt(1,1);
			ps.setString(2,list.get(i).getFd_title());
		  	ps.setString(3,list.get(i).getFd_name());
		  	ps.setString(4,list.get(i).getFd_link());
		  	ps.setString(5,list.get(i).getFd_price());
		  	ps.setString(6,"");
		  	ps.setString(7,"");
		  	ps.setString(8,list.get(i).getFd_artistname());
		  	ps.setString(9,list.get(i).getFd_artisturl());
		  	ps.setString(10,"");
		  	ps.setString(11,list.get(i).getFd_imagesmall());
		  	ps.setString(12,list.get(i).getFd_imagemedium());
		  	ps.setString(13,list.get(i).getFd_imagelarge());
		  	ps.setString(14,list.get(i).getFd_rights());
		  	ps.setObject(15,"2012-9-9");
		  	ps.setInt(16,0);
		  	ps.setString(17,"");
		  	ps.setString(18,"");
		  	
		  	ps.executeUpdate();
		  }
			System.out.println("Parsing completed");
		  }
		  catch(Exception e){
			  e.printStackTrace();
		  }
		  finally
		  {
			  if (con != null)  
	            {  
	                try  
	                {
	                	ps.close();
	                	con.close ();  
	                }  
	                catch (Exception e) { 
	                	e.printStackTrace();
	                }  
	            }  
			  
		  }
		  	
		  	
	  }

}
