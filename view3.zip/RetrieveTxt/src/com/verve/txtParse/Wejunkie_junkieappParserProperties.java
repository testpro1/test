/*this property class handles to get path from properties file.
 * 
 * author Rupal Kathiriya
 */
package com.verve.txtParse;

import java.io.*;
import java.util.*;

public class Wejunkie_junkieappParserProperties {
	private static Properties props = new Properties();
	static
	{
		InputStream inStream=null;
		try {
			inStream = Thread.currentThread().getContextClassLoader().getResource("Wejunkie_junkieappParserProperties.property").openStream();
			props.load(inStream);
		}
		catch(Throwable t)
		{
			throw new 
			IllegalStateException("Failed to read SX SQS System Configuration Properties");
		}
	finally
	{
		if(inStream!=null)
		{
		try {
			inStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		}		
	}
	}
	public static String getInFolderName(){
		return props.getProperty("inFolderPath").trim();
	}
	public static String getInFolderPath(){
		String path =getInFolderName();
		File dir = new File(path);
		if(!dir.exists()) {
			dir.mkdir();
		}
		return path;
	}	
	public static String getUrl(){
		return props.getProperty("url").trim();
	}
	public static String getUrlPath(){
		String path =getUrl();
		return path;
	}
	public static String getDB(){
		return props.getProperty("db").trim();
	}
	public static String getDBName(){
		String name =getDB();
		return name;
	}
	public static String getDriver(){
		return props.getProperty("driver").trim();
	}
	public static String getDriverPath(){
		String name =getDriver();
		return name;
	}
	public static String getUsername(){
		return props.getProperty("username").trim();
	}
	public static String getUsernamePath(){
		String name =getUsername();
		return name;
	}
	public static String getPassword(){
		return props.getProperty("password").trim();
	}
	public static String getPasswordPath(){
		String name =getPassword();
		return name;
	}
}