package com.SCOIS360.NSF;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class RetriveNSF_Xml {
	@SuppressWarnings("unchecked")
	public static void main(String args[]){
		try{
			JAXBContext jc = JAXBContext.newInstance(Awardslist.class);
        	Unmarshaller unmarshaller = jc.createUnmarshaller();
        	Awardslist awardslist = (Awardslist) unmarshaller.unmarshal(new File("src/new1.xml"));
     		List list= awardslist.getAward();
     		System.out.println("List size: "+list.size());
     		
     	}catch(JAXBException e){
			e.printStackTrace();
		}
	}

}
