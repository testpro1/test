package plugindemo;



import java.io.*;
import java.io.ObjectInputStream.GetField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

	public class DataRetrive<K> {
		static String UserName="gaurav";
		 static  String Password="google.com";
		  static String DBDriver="com.mysql.jdbc.Driver";
		  static String Host="192.168.1.6";
		  static String Port="3306";
		static String   DatabaseName="meetin2";
		
		static Connection con=null;
		static Statement stmt=null;
		static String query=null;
		static String columnQuery=null;
		static ResultSet resultSet=null;
		static String tableQuery=null;
		static String tableQuery1=null;
		static ResultSet resultSet2=null;
		static ResultSet resultSet3=null;
		static ResultSet resultSet4=null;
		static ArrayList<String> addTable=new ArrayList<String>();
		static ArrayList<String> addCol=new ArrayList<String>();
		static ArrayList<String> addTypes=new ArrayList<String>();
		
		public static void getConnection(String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) throws SQLException{
			
			try {
				Class.forName(DBDriver);
				System.out.println(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				query="show databases";
				resultSet=stmt.executeQuery(query);
				//int i=1;
				while(resultSet.next()){
					//System.out.println("DAtabase Name**********"+resultSet.getString(1));
					//i++;
					if(resultSet.getString(1).equalsIgnoreCase(DatabaseName)){
						query="show tables";
						resultSet2=stmt.executeQuery(query);
						while(resultSet2.next()){
						//addTable.add(resultSet2.getString(1));	
						//System.out.println( "Table NAME  ********"+resultSet2.getString(1));
						getColumns(resultSet2.getString(1), UserName, Password, DBDriver, DatabaseName, Host, Port);
						//TableWizard tableWizard=new TableWizard();
						//tableWizard.setTable(addTable,addCol,addTypes);
						}
					} 
				}
				//con.close();	
				
			} catch (Exception e) {
				System.out.println("DB HANDLER********** 1");	
				//e.printStackTrace();
			}
		}
		
		public static void getColumns(String tableName,String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) throws SQLException{
			try {
				getData(tableName,UserName, Password, DBDriver,DatabaseName, Host, Port);
				/*//addTable.add(tableName);
				System.out.println( "Table NAME  ********get_city_state_view");//+resultSet2.getString(1));
				Class.forName(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				tableQuery="show columns from get_city_state_view";
				resultSet3=stmt.executeQuery(tableQuery);
				while(resultSet3.next()){
					addCol.add(resultSet3.getString(1));
					//addTypes.add(resultSet3.getString(2));
					System.out.println("columns Name**********"+resultSet3.getString(1));
					
				}
				
				con.close();*/
			}catch (Exception e) {
				System.out.println("DB HANDLER************2");
				//e.printStackTrace();
			}
		}
		public static void getData(String tableName,String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port){
			try {
				//addTable.add(tableName);
				//System.out.println( "Table NAME  ********"+resultSet2.getString(1));
				Class.forName(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				tableQuery="select * from "+tableName;
				resultSet4=stmt.executeQuery(tableQuery);
				int columns = resultSet4.getMetaData().getColumnCount();
				String xml_output = "\n<data>\n";
			
				for(int x = 0 ; x < 1; x++){
				while (resultSet4.next()) {
					xml_output += "\t<row>\n";
						Class.forName(DBDriver);
						con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
						stmt=con.createStatement();
						tableQuery1="show columns from "+tableName;
						resultSet3=stmt.executeQuery(tableQuery1);
						for (int i = 1; i <= columns;i++) {
						while(resultSet3.next()){
							xml_output += "\t\t<"+resultSet3.getString(1)+">" +resultSet4.getString(i++)+ "</"+resultSet3.getString(1)+">\n";
						}
					}
						xml_output += "\t</row>\n";
					}
			}
			 con.close();
			xml_output += "</data>";
			 Writer output = null;
			  
			  File file = new File("/home/verve/Desktop/"+tableName+(new Date()).getTime()+".xml");
			  output = new BufferedWriter(new FileWriter(file));
			  output.write(xml_output);
			  output.close();
			  System.out.println("Your file has been written");  
			 con.close();
			
			}catch(Exception e){
				e.printStackTrace();
			}
			}
			
		/*	try {
				//addTable.add(tableName);
				//System.out.println( "Table NAME  ********"+resultSet2.getString(1));
				Class.forName(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				tableQuery="select * from get_city_state_view";//+tableName;
				resultSet4=stmt.executeQuery(tableQuery);
				while(resultSet4.next()){
					System.out.println("DATA**********"+resultSet4.getString(1));
				}
				
				con.close();
			}catch (Exception e) {
				System.out.println("DB HANDLER************2");
				//e.printStackTrace();
			}
			*/
		
	public static void main(String args[]) throws SQLException, ParserConfigurationException, IOException, TransformerException{
				getConnection(UserName, Password, DBDriver, DatabaseName, Host, Port);
	}
		
	}
	

