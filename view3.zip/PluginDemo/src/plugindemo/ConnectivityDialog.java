package plugindemo;


import java.sql.SQLException;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
public class ConnectivityDialog extends TitleAreaDialog {

  private Text userNameText;
  private Text passwordText;
  private Text DBDriverText;
  private Text hostText;
  private Text portText;
  private Text databaseText;
  private String userName;
  private String password;
  private String DBDriver;
  
  //private String Url="jdbc:mysql://192.168.1.6:3306/strutsdemodb";
  
  private String host;
  private String port;
  private String databaseName;
  
  public ConnectivityDialog(Shell parentShell) {
    super(parentShell);
  
  }

  @Override
  public void create() {
    super.create();
    // Set the title
    setTitle("This is my first own dialog");
    // Set the message
    setMessage("Database Connectivity", 
        IMessageProvider.INFORMATION);
  }
  
  @Override
  protected Control createDialogArea(Composite parent) {
    GridLayout layout = new GridLayout();
    layout.numColumns = 2;
    // layout.horizontalAlignment = GridData.FILL;
    parent.setLayout(layout);

    // The text fields will grow with the size of the dialog
    GridData gridData = new GridData();
    gridData.grabExcessHorizontalSpace = true;
    gridData.horizontalAlignment = GridData.FILL;

    Label label1 = new Label(parent, SWT.NONE);
    label1.setText("User Name");

    userNameText = new Text(parent, SWT.BORDER);
    userNameText.setLayoutData(gridData);
    
    Label label2 = new Label(parent, SWT.NONE);
    label2.setText("Password");
    // You should not re-use GridData
    gridData = new GridData();
    gridData.grabExcessHorizontalSpace = true;
    gridData.horizontalAlignment = GridData.FILL;
    
    passwordText = new Text(parent,SWT.BORDER| SWT.PASSWORD);
    
    passwordText.setLayoutData(gridData);
    
    Label label3 = new Label(parent, SWT.NONE);
    label3.setText("Database driver");
   
    gridData = new GridData();
    gridData.grabExcessHorizontalSpace = true;
    gridData.horizontalAlignment = GridData.FILL;
    
    DBDriverText = new Text(parent, SWT.BORDER);
    DBDriverText.setLayoutData(gridData);
    
    Label label4 = new Label(parent, SWT.NONE);
    label4.setText("Host");
   
    gridData = new GridData();
    gridData.grabExcessHorizontalSpace = true;
    gridData.horizontalAlignment = GridData.FILL;
    
    hostText = new Text(parent, SWT.BORDER);
    hostText.setLayoutData(gridData);
    
    Label label5 = new Label(parent, SWT.NONE);
    label5.setText("Port");
    
    gridData = new GridData();
    gridData.grabExcessHorizontalSpace = true;
    gridData.horizontalAlignment = GridData.FILL;
    
    portText = new Text(parent, SWT.BORDER);
    portText.setLayoutData(gridData);
    
    Label label6 = new Label(parent, SWT.NONE);
    label6.setText("Database");
    
    gridData = new GridData();
    gridData.grabExcessHorizontalSpace = true;
    gridData.horizontalAlignment = GridData.FILL;
    
    databaseText = new Text(parent, SWT.BORDER);
    databaseText.setLayoutData(gridData);
    
    return parent;
  }

  @Override
  protected void createButtonsForButtonBar(Composite parent) {
    GridData gridData = new GridData();
    gridData.verticalAlignment = GridData.FILL;
    gridData.horizontalSpan = 3;
    gridData.grabExcessHorizontalSpace = true;
    gridData.grabExcessVerticalSpace = true;
    gridData.horizontalAlignment = SWT.CENTER;

    parent.setLayoutData(gridData);
    // Create Add button
    // Own method as we need to overview the SelectionAdapter
    createOkButton(parent, OK, "Add", true);
    // Add a SelectionListener
    // Create Cancel button
    Button cancelButton =createButton(parent, CANCEL, "Cancel", false);
    // Add a SelectionListener
    cancelButton.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        setReturnCode(CANCEL);
        close();
      }
    });
  }

  protected Button createOkButton(Composite parent, int id,String label,boolean defaultButton) {
    // increment the number of columns in the button bar
    ((GridLayout) parent.getLayout()).numColumns++;
    Button button = new Button(parent, SWT.PUSH);
    button.setText(label);
    button.setFont(JFaceResources.getDialogFont());
    button.setData(new Integer(id));
    button.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent event) {
        if (isValidInput()) {
          okPressed();
        }
      }
    });
    if (defaultButton) {
      Shell shell = parent.getShell();
      if (shell != null) {
        shell.setDefaultButton(button);
      }
    }
    setButtonLayoutData(button);
    return button;
  }
  
  

  private boolean isValidInput() {
    boolean valid = true;
    if (userNameText.getText().length() == 0) {
      setErrorMessage("Please enter valid type or All fields are required ");
      valid = false;
    }
    if (passwordText.getText().length() == 0) {
      setErrorMessage("Please enter valid type or All fields are required");
      valid = false;
    }
    if (DBDriverText.getText().length() == 0) {
        setErrorMessage("Please enter valid type or All fields are required");
        valid = false;
      }
    if (hostText.getText().length() == 0) {
        setErrorMessage("Please enter valid type or All fields are required");
        valid = false;
      }
    if (portText.getText().length() == 0) {
        setErrorMessage("Please enter valid type or All fields are required");
        valid = false;
      }
    if (databaseText.getText().length() == 0) {
        setErrorMessage("Please enter valid type or All fields are required");
        valid = false;
      }
    return valid;
  }
  
  @Override
  protected boolean isResizable() {
    return true;
  }
  // Coyy textFields because the UI gets disposed
  // and the Text Fields are not accessible any more.
  private void saveInput() {
    userName = userNameText.getText();
    password = passwordText.getText();
    DBDriver=DBDriverText.getText();
    host=hostText.getText();
    port= portText.getText();
    databaseName= databaseText.getText();
  }


 
@Override
  protected void okPressed() {
    saveInput();
    super.okPressed();
  }
  
 
 
  	public String getUserName() {
		return userName;
	}
	public String getPassword() {
		return password;
	}
	public String getDBDriver() {
		return DBDriver;
	}

	public String getHost() {
		return host;
	}

	public String getPort() {
		return port;
	}

	public String getDatabaseName() {
		return databaseName;
	}
	
public void setDBDriver(String dBDriver) {
	this.DBDriver=dBDriver;
}
public void setHost(String host) {
	this.host =host;
}
public void setPort(String port) {
	this.port =port;
}
public void setDatabaseName(String databaseName) {
	this.databaseName = databaseName;
}
 public static void main(String args[]) throws SQLException{
	 Display display =new Display();
	  Shell shell = new Shell();
	  ConnectivityDialog dialog = new ConnectivityDialog(shell);
	  dialog.create();
	  if (dialog.open() == Window.OK) {
		  System.out.println("***************************************************");
		  DBHandler dbHandler=new DBHandler();
		  dbHandler.getConnection(shell,display,dialog.getUserName(),dialog.getPassword(),dialog.getDBDriver(), dialog.getDatabaseName(),dialog.getHost(),dialog.getPort());
	  }
 	}
} 