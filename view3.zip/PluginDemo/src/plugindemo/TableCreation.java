package plugindemo;

import org.eclipse.swt.*;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class TableCreation {

							public static void main (String [] args) {
	
								Display display = new Display ();
								Shell shell = new Shell (display);
								int y=20;
								int r=20;
								GridLayout gridLayout = new GridLayout();
								gridLayout.numColumns=4;
								shell.setLayout(gridLayout);
								gridLayout.numColumns=4;
								
								for(int k=0;k<=20;k++){
									
								Table table = new Table (shell, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION|SWT.V_SCROLL|SWT.H_SCROLL );
								table.setLinesVisible (true);
								table.setHeaderVisible (true);
								System.out.println("Size "+table.getSize());
								GridData data = new GridData(SWT.HORIZONTAL, SWT.HORIZONTAL, true, false);
								//GridData data = new GridData(GridData.END, GridData.BEGINNING, true,true, 6, 1);	
								data.heightHint = 150;
								data.widthHint=250;
								table.setLayoutData(data);
								String[] titles = { "Cdfgdfg", "!dfgdfg"};
								for (int i=0; i<titles.length; i++) {
									TableColumn column = new TableColumn (table, SWT.NONE);
									column.setText (titles [i]);
								}	
								int count = 128;
								for (int i=0; i<count; i++) {
									TableItem item = new TableItem (table, SWT.NONE);
									item.setText (0, "xsdfsdf");
									item.setText (1, "ysdfsf");
									
								}
								for (int i=0; i<titles.length; i++) {
									table.getColumn (i).pack ();
									
								}
								Rectangle clientArea = shell.getClientArea ();
								y+=20;
								
								table.setBounds (clientArea.x+y, clientArea.y+r, 150, 150);
								y=y+150;
								
								}
								
								shell.setSize(1500,1500);
								shell.pack ();
								shell.open ();
								while (!shell.isDisposed ()) {
									if (!display.readAndDispatch ()) display.sleep ();
								}
								display.dispose ();
							}
					} 