
package plugindemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

	public class DBHandler<K> {
		Connection con=null;
		Statement stmt=null;
		String query=null;
		String columnQuery=null;
		ResultSet resultSet=null;
		String tableQuery=null;
		ResultSet resultSet2=null;
		ResultSet resultSet3=null;
		ArrayList<String> addTable=new ArrayList<String>();
		ArrayList<String> addCol=new ArrayList<String>();
		ArrayList<String> addTypes=new ArrayList<String>();
		public void getConnection(Shell shell,Display display,String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) throws SQLException{
			UserName="gaurav";
			  Password="google.com";
			  DBDriver="com.mysql.jdbc.Driver";
			  Host="192.168.1.6";
			  Port="3306";
			  DatabaseName="meetin2";
			try {
				Class.forName(DBDriver);
				System.out.println(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				query="show databases";
				resultSet=stmt.executeQuery(query);
				//int i=1;
				while(resultSet.next()){
					//System.out.println("DAtabase Name**********"+resultSet.getString(1));
					//i++;
					if(resultSet.getString(1).equalsIgnoreCase(DatabaseName)){
						query="show tables";
						resultSet2=stmt.executeQuery(query);
						while(resultSet2.next()){
						//addTable.add(resultSet2.getString(1));	
						//System.out.println( "Table NAME  ********"+resultSet2.getString(1));
						getColumns(resultSet2.getString(1), UserName, Password, DBDriver, DatabaseName, Host, Port);
						TableWizard tableWizard=new TableWizard();
						tableWizard.setTable(shell,display,addTable,addCol,addTypes);
						}
						while (!shell.isDisposed()) {
							if (!display.readAndDispatch ()) display.sleep ();
							}
							display.dispose();
					} 
				}
				con.close();	
				
			} catch (Exception e) {
				System.out.println("DB HANDLER********** 1");	
				//e.printStackTrace();
			}
		}
		
		public void getColumns(String tableName,String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) throws SQLException{
			try {
				addTable.add(tableName);
				Class.forName(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				tableQuery="show columns from "+tableName;
				resultSet3=stmt.executeQuery(tableQuery);
				while(resultSet3.next()){
					addCol.add(resultSet3.getString(1));
					addTypes.add(resultSet3.getString(2));
					
					//System.out.println("columns Name**********"+resultSet3.getString(1));
				}
				con.close();
			} catch (Exception e) {
				System.out.println("DB HANDLER************2");
				//e.printStackTrace();
			}
			
		}
	
		
	}
	

