
                      SigmaProbe, SigmaProbe API Version 5.0
				   README File


This file contains information that supplements the SigmaProbe 
v5.0 documentation.
     
=========
Contents
=========

1.0 Important Notes
2.0 Introduction
3.0 Release Notes
4.0 Prerequisites
5.0 Directory Hierarchy
6.0 SigmaProbe Examples	 	
7.0 Bug Reports and Feedback
8.0 SigmaProbe Documentation
9.0 Web Pages


==================
1.0 Important Notes
==================

     Serial Number entry has been disabled for your installation of SigmaProbe.
     When asked for serial number during the SigmaProbe installation you may
     enter any value.

==================
2.0 Introduction
==================

     Thank you for installing this release of the SigmaProbe and SigmaProbe API.
     The SigmaProbe is monitoring and delivery mechanisam for test unit reports
     created with use of SigmaProbe API. It runs as a Java application on a test
     station and communicates (delivers unit reports to) with SigmaConnect server.
     SigmaProbe API is a set of methods that can be used inside a test executive 
     to capture test information and create unit reports (each unit report is a
     XML file). 

==================
3.0 Release Notes
==================

      SigmaProbe VC++ API, SigmaProbe VB API, SigmaProbe/NI TestStand API and 
      SigmaProbe NI LabView API are the most current version of API available. 
      
      Updates from previous release:
      
      * Improved SigmaProbe service:
        a.) Faster delivery through multithreaded support
        b.) New monitoring options and statistics collection 
        c.) Better integration with Windows environment
        d.) New configuration options (see description in SigmaProbe-config.xml file).

	  * API - Addition of Product Category element
	  * Integration - Integration with Agilent VEE
	  * Addition of Verify sample application.
	  
      For up to date release notes and for additional information pertaining to this 
      release please check the Release Notes under your secured SigmaQuest web site 
      location (SigmaQuest will provide sign-in information as well as user id and 
      password). 
 
      The on-line release notes will be updated as needed, so you should 
      check them occasionally for the latest information. 

==================
4.0 Prerequisites
==================

      This release uses MS XML Services 4.0 SP2 on Windows platform. 
      MS XML Services 4.0, SP2 is included with the SigmaProbe setup.
      
      This release requires Java SDK SE 1.4.2 or better, or Java JRE 1.4.2 or better.
      Java JRE 1.4.2_05 is included with the SigmaProbe setup.			
     
========================
5.0 Directory Hierarchy
========================

      The following directory hierarchy may be somewhat different for your installation.
      Depending on which components you have choosen to install, and which release you
      have, your installation may look different.
	

[SigmaProbe]
	|__________readme.txt
	|__________license.txt
	|__________copyright.txt
	|
	|__________[Service]
	|
	|__________[Docs]
	|		
	|__________[API]
	|	    |	|________[VB]___________[SPAPI]
	|		|
	|		|________[TestStand]_____[SPAPI]
	|		|
	|		|________[LabView]
	|
	|
	|__________[Examples]
			|________[VB]
			|________[VC++]
			|________[TestStand]
			|________[LabWindows]	

========================
6.0 SigmaProbe Examples
========================

      Examples subdirectory under SigmaProbe install directory contains sample applications
      for each language/environment API is available in. Look for README files inside
      each sample directory for information how to build and modify sample projects.  

=============================
7.0 Bug Reports and Feedback
=============================

      Please report all bugs, feedbacks, and comments directly to SigmaQuest engineering 
      team email addresses: 

      support@sigmaquest.com

=============================
8.0 SigmaProbe Documentation
=============================

     The SigmaProbe documentation is included as part of SigmaProbe setup.
     You can access it from Starts/Programs/SigmaProbe/SigmaProbe/Documentation/ and
     Starts/Programs/SigmaProbe/SigmaProbe API/Documentation/.
     
     To view documentation you need Adobe Acrobat Reader 6.0.	 
     Latest version of Adobe Acrobat Reader can be obtained from Adobe site:
     http://www.adobe.com.
	
     The on-line SigmaProbe Documentation contains API specifications,
     user guides, developer guides, reference pages, demos, 
     and links to related information. The latest copy can be obtained from
     your secured SigmaQuest web site location (SigmaQuest will provide sign-in 
     information as well as user id and password). 

=========================
9.0 SigmaQuest Web Pages
=========================

     For additional information, products and support please refer to SigmaQuest web site:

     http://www.sigmaquest.com/

(c) Copyright SigmaQuest, Inc. 2001-2005. All rights reserved.

