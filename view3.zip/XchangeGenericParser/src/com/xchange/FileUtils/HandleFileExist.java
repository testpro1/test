package com.xchange.FileUtils;

public enum HandleFileExist {
	  Overwrite,
      RenameWithGuid,
      RenameWithCount,
      None,
      
}
