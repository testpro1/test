package com.xchange.FileUtils;

import java.io.*;
import com.xchange.Exceptions.BlankSourceFileException;

public class FileManager
{
	public String source;
	public String destination;
	public HandleFileExist handleFileExist;
    
	public FileManager() 
	{
    source=new String();
    destination=new String();
    }
    public void LogFileInfo(File fileInfo) {
    }
    public void LogFileInfo(String fileName){
    }    
    public void MoveFile(String source, String destination, HandleFileExist handleFileExist) throws BlankSourceFileException{
    	try{
    		File file=new File(source);
    		File dir=new File(destination);
    		file.renameTo(new File(dir, file.getName()));
    		}
		catch(Exception e)
		{
			e.printStackTrace();
		}    	
    }
}
