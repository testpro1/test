package com.xchange.Exceptions;

public class InValidDestinationException extends Exception{
	public static final long serialVersionUID = 43L;
public InValidDestinationException(String message) {
	// TODO Auto-generated constructor stub
	super(message);
}	
}

