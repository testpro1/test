package com.xchange.Exceptions;

public class SourceNotFoundException extends Exception {
	public static final long serialVersionUID = 43L;
	private static final String _message = "Config Source File Not Found";
	private String _sourceFile;
	public SourceNotFoundException(String sourceFile )
	{
		super(_message);
		_sourceFile=sourceFile;
	}
	public String get_sourceFile() {
		return _sourceFile;
	}
}
