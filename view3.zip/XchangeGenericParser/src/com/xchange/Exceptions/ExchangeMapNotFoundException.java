package com.xchange.Exceptions;

public class ExchangeMapNotFoundException extends Exception {
	public static final long serialVersionUID = 43L;
	public ExchangeMapNotFoundException(String message) {
	super(message);
		// TODO Auto-generated constructor stub
	}

}
