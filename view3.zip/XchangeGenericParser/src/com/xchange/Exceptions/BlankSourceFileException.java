package com.xchange.Exceptions;

public class BlankSourceFileException extends Exception {
	public static final long serialVersionUID = 43L;
	private static final String _message="Destination or source not found";
	private static String _destination;
	private static String _source;
	public BlankSourceFileException(String destination,String source,Exception e) {
		super(_message);
		_destination=destination;
		_source=source;
	}
	public String get_destination() {
		return _destination;
	}
	public String get_source() {
		return _source;
	}
	
}
