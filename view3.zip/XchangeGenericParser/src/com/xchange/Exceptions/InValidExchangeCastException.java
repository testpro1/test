package com.xchange.Exceptions;


public class InValidExchangeCastException extends Exception {
	public static final long serialVersionUID = 43L;
	private static final String _message = "";
	private static String _parseDirectory; 
	private static String _parseFileFilter;
	public InValidExchangeCastException(String parseDirectory,String fileFilter) 
	{
		super(_message);
		_parseDirectory=parseDirectory;
		_parseFileFilter=fileFilter;
	}
	public String get_parseDirectory() {
		return _parseDirectory;
	}
	public String get_parseFileFilter() {
		return _parseFileFilter;
	}
}
