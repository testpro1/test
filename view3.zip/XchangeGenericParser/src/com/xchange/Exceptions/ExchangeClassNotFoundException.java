package com.xchange.Exceptions;


public class ExchangeClassNotFoundException extends Exception{
	public static final long serialVersionUID = 43L;
	private static final String _message = "can not find the parseDirectory path or fileFilter or parseLevel";
	private static String _parseDirectory; 
	private static String _parseFileFilter;
	private static int _parseLevel;
	public ExchangeClassNotFoundException(String parseDirectory,String fileFilter,int level)
	{
		super(_message);
		_parseDirectory=parseDirectory;
		_parseFileFilter=fileFilter;
		_parseLevel=level;		
	}
	public String get_parseDirectory() {
		return _parseDirectory;
	}
	public String get_parseFileFilter() {
		return _parseFileFilter;
	}
	public int get_parseLevel() {
		return _parseLevel;
	}
}
