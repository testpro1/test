package com.xchange.Exceptions;

public class DependecyNotFoundException extends Exception {
	public static final long serialVersionUID = 43L;
	private static final String _message = "The given project dependency not found.";
	private String _dependencyName;
	public DependecyNotFoundException(String dependencyName, Exception innerException) {
		super(_message,innerException);
		_dependencyName = dependencyName;
	}
	public String get_dependencyName() {
		return _dependencyName;
	}
}
