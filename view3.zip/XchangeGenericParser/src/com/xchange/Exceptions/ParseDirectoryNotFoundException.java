package com.xchange.Exceptions;

public class ParseDirectoryNotFoundException extends Exception{
	public static final long serialVersionUID = 43L;
	private static final String _message = "can not find the parseDirectory path or fileFilter or parseLevel";
	private static String _parseDirectory; 
	private static String _parseFileFilter;
	private static int _parseLevel;
	
	ParseDirectoryNotFoundException(String parseDirectory,String fileFilter,int fileLevel )
	{
		super(_message);
		_parseDirectory=parseDirectory;
		_parseFileFilter=fileFilter;
		_parseLevel=fileLevel;		
	}
	public static String get_parseDirectory() {
		return _parseDirectory;
	}
	public static String get_parseFileFilter() {
		return _parseFileFilter;
	}
	public static int get_parseLevel() {
		return _parseLevel;
	}
	
		
	

}
