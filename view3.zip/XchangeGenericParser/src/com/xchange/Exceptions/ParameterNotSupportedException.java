package com.xchange.Exceptions;

public class ParameterNotSupportedException extends Exception{
	private static final long serialVersionUID = 43L;
	private static final String _message = "Wrong watch method specified! Proper values are 'one-time', 'polling' or 'event-based'.";
	private String _wrongParameterValue;
	public ParameterNotSupportedException(String wrongParameterValue) {
		super(_message);
		_wrongParameterValue = wrongParameterValue; 
	}
	public String get_wrongParameterValue() {
		return _wrongParameterValue;
	}
}
