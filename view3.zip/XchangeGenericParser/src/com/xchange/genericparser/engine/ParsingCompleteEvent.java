package com.xchange.genericparser.engine;


public class ParsingCompleteEvent
{
	private String threadName = null;
	
	public ParsingCompleteEvent(String threadName)
	{
		this.threadName=threadName;
	}
	
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	public String getThreadName() {
		return this.threadName;
	}
	
}
