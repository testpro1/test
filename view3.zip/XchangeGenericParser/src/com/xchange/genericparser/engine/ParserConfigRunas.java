package com.xchange.genericparser.engine;

public enum ParserConfigRunas {
	console,
    service,
}
