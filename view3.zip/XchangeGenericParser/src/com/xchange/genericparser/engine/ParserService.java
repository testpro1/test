package com.xchange.genericparser.engine;

import java.io.*;
import java.util.*;
import javax.xml.bind.*;
import org.apache.commons.logging.*;
import com.xchange.Exceptions.*;
import com.xchange.genericparser.engine.ParserConfig.DataConverter;


public class ParserService implements Runnable
{
	private static Log log = LogFactory.getLog(ParserService.class);
	//private static ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
	private Hashtable<Thread, Object> threadCollection;
	private ParserConfig _parserConfig;// = null;
	private Thread workerThread;//= null;
	public ParserService(String fileName) throws DependecyNotFoundException,InvalidConfigurationSchemaException
	{
		if (log.isDebugEnabled()) {log.debug("IN");}
		JAXBContext context;
		File file=new File(fileName);
		if(!file.exists())
		{
			try {
					throw new SourceNotFoundException(fileName);
			} catch (SourceNotFoundException e) {
			System.out.println(e+""+e.get_sourceFile());
			}
		}
		else
		{
			try {	
				context = JAXBContext.newInstance(ParserConfig.class);
				Unmarshaller unmarshaller = context.createUnmarshaller();
				unmarshaller.setSchema(null);
				this._parserConfig = (ParserConfig)unmarshaller.unmarshal(new File(fileName));
			}
			catch (JAXBException e) 
			{
				throw new DependecyNotFoundException(JAXBContext.class.toString(),e);
			}
			catch(Exception ex)
			{
				throw new InvalidConfigurationSchemaException(fileName,ParserConfig.class.toString(), ex);
			}
		}
		
		this.threadCollection = new Hashtable<Thread, Object>();
		this.workerThread = new Thread();
		if (log.isDebugEnabled()) 
		{
			log.debug("OUT");
		}
	};	
	private void runAsService()
	{
		//run parser in service mode
		if (log.isInfoEnabled()) 
		{
			log.info("Running as a windows service.");
		}
		///#### STILL TO IMPLEMENT
		return;
	}
	
	private void runAsConsole() throws InterruptedException, ParameterNotSupportedException
	{
		//run parser in Console mode
		if (log.isInfoEnabled()) {
			log.info("Running as a console application.");
		}
        runParser();
    return;
	}
	protected void threadProc() throws InterruptedException, ParameterNotSupportedException
	{
		//thread procedure to be executed by Worker thread
		if (log.isDebugEnabled()) {
			log.debug("IN");
		}
		// We are on a separate thread now.. 
		runParser();
        
		if (log.isDebugEnabled()) {
        	log.debug("OUT");
        }
	}	
	public void start()
	{
		//start worker thread and leave main thread dealing with SCM.
		this.workerThread.start();
		if (log.isFatalEnabled()) {
			log.info("Application started.");
		}
	}
	public void stop()
	{
		this.workerThread.interrupt();
	
		if (log.isInfoEnabled()) {
			log.info("Application stopped.");
		} 
	}	
	@SuppressWarnings("deprecation")
	public void pause() 
	{
		this.workerThread.suspend(); //this.workerThread.suspend();
		if (log.isInfoEnabled()) {
			log.info("Application Paused.");
		}
	}	
	@SuppressWarnings("deprecation")
	public void resume()
	{
		this.workerThread.resume(); //this.workerThread.join(); //
		if (log.isInfoEnabled()) {
			log.info("Application resumed.");
		}
	}
	
	public void run()
	{
		if (log.isDebugEnabled()) {
	      log.debug("IN");
	    }
      // done with command line processing, check how we run...
		if (this._parserConfig.runAs.toString().equals(ParserConfigRunas.service.toString()))
		{
			runAsService();
		}
		else if (this._parserConfig.runAs.toString().equals(ParserConfigRunas.console.toString()))
		{
			try {
				runAsConsole();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ParameterNotSupportedException e) {
				System.out.println(e+""+e.get_wrongParameterValue());
			} 
		}
		else 
		{
			log.error("Unknown running mode!");
		}      
		if (log.isDebugEnabled())
		{
			log.debug("OUT");
		}
	}
	public void runParser() throws InterruptedException, ParameterNotSupportedException
	{
		if (log.isDebugEnabled()) {
			log.debug("IN"); 
		}

        if (log.isInfoEnabled()) {
        	log.info("Creating data converters...");
        }
        
        // For each converter we create a separate thread
        // load test specs for each parsing format
        
		for (DataConverter dataConverter : this._parserConfig.dataConverter) {
			startParserThread(dataConverter);
		}       
        if (log.isDebugEnabled()) {
        	log.debug("OUT");
        }
	}
	
	public void startParserThread(DataConverter dataConverter) throws InterruptedException, ParameterNotSupportedException
	{
		if (log.isInfoEnabled()) {
			log.info("IN");
		}
		XParser parser= new XParser(dataConverter);
		parser.parse();
		// Thread thread = new Thread(parser);
		//thread.start();	
		/*Runnable runnable =  new XParser(dataConverter);
		Thread thread = new Thread(runnable);
		try
			{
				Thread.sleep(1000);
				System.out.println("IN PARSER SERVICE:::"+Thread.currentThread());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}	
			 thread.start();*/
		
		// String convType = "onetime";
		
		@SuppressWarnings("unused")
		String convType;
		 if (dataConverter.watchMethod.toString().equals(DataConverterWatchmethod.eventbased.toString())) 
		 {
			convType = "EventBase";
			//thread.setName(dataConverter.code +"_"+ convType);
		 }
		 else if (dataConverter.watchMethod.toString().equals(DataConverterWatchmethod.polling + "")) 
		 {
			convType = "Polling";
			//thread.setName(dataConverter.code +"_"+ convType);
		 }
		 else if(dataConverter.watchMethod.toString().equals(DataConverterWatchmethod.onetime.toString()))
		 {
           convType = "onetime"; 
          // thread.setName(dataConverter.code +"_"+ convType);
           log.info("IN****");
          }		 	
		//thread.setName(dataConverter.code +"_"+ convType);
		if(log.isInfoEnabled())
		 {
			//log.info("Starting thread " + thread.getName());
		 }
		/////---One Line---------->threadCollection.Add(thread.getName(), thread);
		// threadCollection.put(workerThread, thread);
		 //System.out.println("::::thread Collection::::"+threadCollection.put(workerThread, thread));
		if (log.isInfoEnabled())
		 {
        	log.info("OUT");
		 }
	}
	private boolean isOneTimeParse(String threadName)
	{
        String convType = "onetime";
        int pos = threadName.lastIndexOf("_");
        if(pos > 0)
        {
            convType = threadName.substring(pos + 1);
        }
        if (log.isDebugEnabled()) 
        {
        	log.debug("Thread is running as " + convType + " converter.");
        }
        if (convType.equals("onetime"))
        {
            return true;
        }
        else
            return false;
	}
	@SuppressWarnings({ "unused", "static-access", "deprecation" })
	private void onParsingComplete(Object sender,ParsingCompleteEvent e)
	{
		if (log.isDebugEnabled()) {
			log.debug("IN");
		}
		if (threadCollection.containsKey(e.getThreadName())) 
		{
			Thread thread = (Thread)threadCollection.get(e.getThreadName());
			if (thread.isAlive()) 
			{
			    // check here if the thread is in one-time parse mode and
                // only then abort it
				if (isOneTimeParse(thread.getName())) 
				{
					thread.currentThread().stop();
					if (log.isDebugEnabled()){
						log.debug("Aborted thread: " + e.getThreadName());
					}
				}
			}
		}
		if (allThreadsAborted()) 
		{
            if (log.isDebugEnabled()) {
            	log.debug("All threads aborted. Exiting...");
            }
			stop();
		}
		 if (log.isDebugEnabled()) {
			 log.debug("OUT");
		 }
	}
	private boolean allThreadsAborted()
	{
		for (Object key: threadCollection.values()) {
			Thread thread = (Thread) threadCollection.get(key);
			if (thread.isAlive())
			{
				return false;
			}
		}
		return true;
	}
	
	
}
