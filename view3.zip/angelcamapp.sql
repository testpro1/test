/*
SQLyog Community Edition- MySQL GUI v8.05 
MySQL - 5.1.69-0ubuntu0.11.10.1 : Database - angelcam
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`angelcam` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `angelcam`;

/*Table structure for table `aboutMe` */

DROP TABLE IF EXISTS `aboutMe`;

CREATE TABLE `aboutMe` (
  `aboutId` int(11) NOT NULL AUTO_INCREMENT,
  `aboutMe` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `lang` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`aboutId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `aboutMe` */

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`login_id`,`email`,`password`) values (1,'admin','admin');

/*Table structure for table `contactUs` */

DROP TABLE IF EXISTS `contactUs`;

CREATE TABLE `contactUs` (
  `contactId` int(11) NOT NULL AUTO_INCREMENT,
  `contactName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `sub` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`contactId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `contactUs` */

/*Table structure for table `credits` */

DROP TABLE IF EXISTS `credits`;

CREATE TABLE `credits` (
  `creditId` int(11) NOT NULL AUTO_INCREMENT,
  `credits` int(11) DEFAULT NULL,
  `userId_credits` int(11) DEFAULT NULL,
  `userWS` text,
  PRIMARY KEY (`creditId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `credits` */

insert  into `credits`(`creditId`,`credits`,`userId_credits`,`userWS`) values (1,10,1,'¬í\0sr\0\Zcom.angelcam.domain.UserWS\0\0\0\0\0\0\0\0	L\0dobt\0Ljava/lang/String;L\0emailq\0~\0L\0\remergencynameq\0~\0L\0emergencynumberq\0~\0L\0	firstnameq\0~\0L\0genderq\0~\0L\0lastnameq\0~\0L\0passwordq\0~\0L\0userIdt\0Ljava/lang/Integer;xpt\0\n13/09/1986t\0rup@vervesys.comppt\0rupalt\0femalet\0hello hellot\0123123sr\0java.lang.Integerâ ¤÷‡8\0I\0valuexr\0java.lang.Number†¬•”à‹\0\0xp\0\0\0'),(2,10,2,'¬í\0sr\0\Zcom.angelcam.domain.UserWS\0\0\0\0\0\0\0\0	L\0dobt\0Ljava/lang/String;L\0emailq\0~\0L\0\remergencynameq\0~\0L\0emergencynumberq\0~\0L\0	firstnameq\0~\0L\0genderq\0~\0L\0lastnameq\0~\0L\0passwordq\0~\0L\0userIdt\0Ljava/lang/Integer;xpt\0\n13/09/1986t\0rupal@vervesys.comppt\0rupalt\0femalet\0hello hellot\0123123sr\0java.lang.Integerâ ¤÷‡8\0I\0valuexr\0java.lang.Number†¬•”à‹\0\0xp\0\0\0');

/*Table structure for table `user_registration` */

DROP TABLE IF EXISTS `user_registration`;

CREATE TABLE `user_registration` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `dob` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `emergencyname` varchar(255) DEFAULT NULL,
  `emergencynumber` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `user_registration` */

insert  into `user_registration`(`userId`,`dob`,`email`,`emergencyname`,`emergencynumber`,`firstname`,`gender`,`lastname`,`password`) values (1,'13/09/1986','rup@vervesys.com',NULL,NULL,'rupal','female','hello hello','123123'),(2,'13/09/1986','rupal@vervesys.com',NULL,NULL,'rupal','female','hello hello','123123');

/*Table structure for table `user_videoUpload` */

DROP TABLE IF EXISTS `user_videoUpload`;

CREATE TABLE `user_videoUpload` (
  `videoId` int(11) NOT NULL AUTO_INCREMENT,
  `actualUrl` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `userWs_userId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`videoId`),
  KEY `FKE45977E8A268AFE4` (`userId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user_videoUpload` */

insert  into `user_videoUpload`(`videoId`,`actualUrl`,`url`,`userWs_userId`,`userId`) values (1,'sfdf','http://vpcl030:8080/AngelCamApp/AdminLogin',1,NULL),(2,'dsfgdfg','http://vpcl030:8080/AngelCamApp/AdminLogin',1,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
