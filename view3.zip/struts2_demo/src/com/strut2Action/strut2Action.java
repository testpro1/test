package com.strut2Action;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
 
@SuppressWarnings("serial")
public class strut2Action extends ActionSupport{
    private String userName;
    private String message;
 
    @Action(value="/welcome",results={ @Result(name="success",location="/content/welcome-user.jsp")})
    public String execute() {
            message = "Welcome " + userName;
            System.out.println("!!!!!!!!!!!!!!!!"+message);
            return "success";
    }
 
    public void setUserName(String userName) {
            this.userName = userName;
    }
 
    public void setMessage(String message) {
            this.message = message;
    }
 
    public String getUserName() {
            return userName;
    }
 
    public String getMessage() {
            return message;
    }
}