package spring.demo;

public class HelloSpring {
public void Hello(){
	System.out.println("hello Spring ");
}
}
