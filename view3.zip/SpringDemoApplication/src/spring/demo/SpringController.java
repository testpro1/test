package spring.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class SpringController {
	public static void main(String args[]){
		XmlBeanFactory beanFactory=new XmlBeanFactory(new ClassPathResource("applicationContext.xml"));
		HelloSpring helloSpring=(HelloSpring)beanFactory.getBean("HelloSpringBean");
		helloSpring.Hello();
	}
}
