package com.verve;

public class Spring3HelloWorld {
	public void sayHello(){
		System.out.println("Hello Spring 3.0");
		}
}
