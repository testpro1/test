package xmltransform.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.jface.window.Window;
import xmltransform.ConnectivityDialog;
import xmltransform.TableSelectionDialog;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class SampleHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public SampleHandler() {
	}
	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 */
	public Object execute(ExecutionEvent event) throws ExecutionException {
		 try{
			  Shell shell = new Shell();
			  ConnectivityDialog dialog = new ConnectivityDialog(shell);
			  dialog.create();
			  
			 if(dialog.open() == Window.OK) {
				System.out.println("Export ***************************************************");
				Display display=null;
				new TableSelectionDialog(shell,display,dialog.getUserName(),dialog.getPassword(),dialog.getDBDriver(), dialog.getDatabaseName(),dialog.getHost(),dialog.getPort());
			 }
		 }catch(Exception e){
			System.out.println("Sample Handler ********");
		 }
	return null;
	
}
}
