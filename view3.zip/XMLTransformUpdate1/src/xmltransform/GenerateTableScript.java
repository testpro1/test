package xmltransform;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class GenerateTableScript {
	String filePath;
	String fileName;
	String userName;
	String password;
	String dbDriver;
	String databaseName; 
	String host;
	String port;
	String tableName;
	
	public GenerateTableScript(){ 
		
	}
		public GenerateTableScript(String userName, String password,String dbDriver, String databaseName, String host, String port) {
			this.userName=userName;
			this.password=password;
			this.dbDriver=dbDriver;
			this.databaseName=databaseName;
			this.host=host;
			this.port=port;
		}
		@SuppressWarnings({ "unused", "static-access" })
		//public static void main(String argv[]) throws SQLException {
		public void GenerateTable(String fileName,String filePath,String userName, String password,String dbDriver, String databaseName, String host, String port) throws SQLException{
			System.out.println("****** "+fileName);
			System.out.println("****** "+filePath);
			try {
			Class.forName(dbDriver);  
			Connection con = DriverManager.getConnection("jdbc:mysql://"+host+":"+port+"/",userName,password);  
			Statement st = con.createStatement();  
			st.executeUpdate("CREATE DATABASE IF NOT EXISTS "+databaseName+" ");
			st.execute("USE "+databaseName+"");
			
			String strr =null;
			String comma=",";
			
			File fXmlFile = new File(filePath+"/"+fileName);
			
			System.out.println(fXmlFile);
			
			int fIndex=0;
			fIndex=fileName.indexOf(".xml");
			System.out.println(fIndex);
			tableName=fileName.substring(0,fIndex);
			
			System.out.println(tableName);
			//File fXmlFile = new File("/home/verve/Desktop/mi_friends.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			System.out.println("Root element :"+ doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName("row");
			System.out.println("-----------------------");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				NodeList element = nNode.getChildNodes();
				for (int i = 0; i < element.getLength(); i++) {
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						//Element eElement = (Element) nNode;
						int findex=0;
						int lindex=0;
						String getVal=element.item(i).getAttributes().getNamedItem("type").toString();
						findex=getVal.indexOf("\"");
						lindex=getVal.lastIndexOf("\"");
						String dataType=getVal.substring(findex+1, lindex);
						
						String getVal1=element.item(i).getAttributes().getNamedItem("key").toString();
						int findex1=getVal1.indexOf("\"");
						int lindex1=getVal1.lastIndexOf("\"");
						String dataType1=getVal1.substring(findex1+1, lindex1);
						String createPri=null;
						if (strr == null) {  
							if(dataType1.equalsIgnoreCase("PRIMARY KEY") || dataType1.equalsIgnoreCase("PRI")){
								createPri="PRIMARY KEY "+"("+element.item(i).getNodeName()+")";
								strr =element.item(i).getNodeName()+" "+dataType+comma+createPri;  
							}else
							{
								strr =element.item(i).getNodeName()+" "+dataType; 
							}
						}else {  
							if(dataType!=null){
								if(dataType1.equalsIgnoreCase("PRIMARY KEY") || dataType1.equalsIgnoreCase("PRI")){
									createPri="PRIMARY KEY "+"("+element.item(i).getNodeName()+")";
									strr = strr+comma+element.item(i).getNodeName()+" "+dataType+comma+createPri;  
								}else
								{
									strr = strr+comma+element.item(i).getNodeName()+" "+dataType;  
								}
							}
						}  
					}
				}
				break;
			}
			System.out.println("strr   "+strr);
			if(strr!=null){
			st.executeUpdate("DROP TABLE IF EXISTS " +tableName);
			st.executeUpdate("create table " + tableName + "(" + strr + ")");  
			ResultSet rs = st.executeQuery("SELECT * FROM " + tableName);  
			ResultSetMetaData rsmd = rs.getMetaData();  
			int NumOfCol = rsmd.getColumnCount();  
			System.out.println("Number of Columns of your table =" +tableName  + " " + NumOfCol);  
			System.out.println("Column names are ");  
			for (int i = 1; i <= NumOfCol; i++) {  
			   System.out.println(rsmd.getColumnName(i));  
			}  
			}
			con.close();  
			ImportXmlData importXmlData=new ImportXmlData(tableName,fileName,filePath,userName,password,dbDriver,databaseName,host,port);
			importXmlData.getRootElement();
			}	catch (Exception e) {
		
			System.out.println("Connection was wrong");
			
			e.printStackTrace();
		}
	}
		
	
	/*public static void main(String args[]) throws SQLException{
		GenerateTable();
	}*/
}