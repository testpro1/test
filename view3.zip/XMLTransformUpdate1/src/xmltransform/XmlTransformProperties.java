/*this property class handles to get path from properties file.
 * 
 * author Rupal Kathiriya
 */
package xmltransform;

import java.io.*;
import java.util.*;

public class XmlTransformProperties {
	private static Properties props = new Properties();
	static
	{
		InputStream inStream=null;
		try {
			inStream = Thread.currentThread().getContextClassLoader().getResource("XMLPluginProperties.property").openStream();
			props.load(inStream);
		}
		catch(Throwable t)
		{
			throw new 
			IllegalStateException("Failed to read SX SQS System Configuration Properties");
		}
	finally
	{
		if(inStream!=null)
		{
		try {
			inStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		}		
	}
	}
	public static String getInFolderName(){
		return props.getProperty("inFolderPath").trim();
	}
	public static String getInFolderPath(){
		String path =getInFolderName();
		File dir = new File(path);
		if(!dir.exists()) {
			dir.mkdir();
		}
		return path;
	}	
	
}