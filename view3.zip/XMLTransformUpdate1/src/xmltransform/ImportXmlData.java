package xmltransform;

import java.io.*;
import java.sql.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class ImportXmlData {
	static PreparedStatement ps = null;
	 static Connection con = null;
	 static  Statement st =null;
	 //static String url = "jdbc:mysql://localhost:3306/";
	 static String db = null;
	 static String driver;
	 static String username;
	 static String password;
	 static String host;
	 static String port;
	 static String fileName;
	 static String filePath;
	 static String tableName;
	 
	 public ImportXmlData() {
		// TODO Auto-generated constructor stub
	 }
	 
	@SuppressWarnings("static-access")
	public ImportXmlData(String tableName,String fileName, String filePath, String userName,String password, String dbDriver, String databaseName,String host, String port) {
		this.tableName=tableName;
		this.fileName=fileName;
		this.filePath=filePath;
		this.username=userName;
		this.password=password;
		this.driver=dbDriver;
		this.db=databaseName;
		this.host=host;
		this.port=port;
	}
	public static Connection getMyconnection()
	{
		try{
			   Class.forName(driver);
		  	   con = DriverManager.getConnection("jdbc:mysql://"+host+":"+port+"/"+db,username,password);
		}catch (Exception e){
		  		e.printStackTrace();
		}
		return con;  
	}
	private static boolean save(String data) throws SQLException{
	//boolean flag=false; 
	try{
		 String sqlString= "insert into " + tableName + " values" + "(" + data + ")";
		 ps = getMyconnection().prepareStatement(sqlString);
		 ps.executeUpdate();
			 //flag=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 finally{
			  if (con != null)  
	            {  
	                try  
	                {
	                	// System.out.println("in try");
	                	ps.close();
	                	con.close ();  
	                }catch (Exception e) { 
	                	// System.out.println("closed");
	                	e.printStackTrace();
	                }  
	            }  
		  }
	 return true;
		// data=null;
	  	
	}
	private static String getTagValue(String sTag, Element eElement) {
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
		Node nValue = (Node) nlList.item(0);
		if(nValue!=null){
		return nValue.getNodeValue();
		}else{
			return "";
		}
	}
	
	private static String getchildValue(NodeList nodeList){
		String getTag=null;
		String getDTypes=null;
		String data=null;
		String properVal=null;
		String comma=",";
		 try{
			 for (int temp = 0; temp < nodeList.getLength(); temp++) {
				 Node nNode = nodeList.item(temp);
				 Element eElement = (Element) nNode;
				 NodeList element = nNode.getChildNodes();
				 
				 for (int i = 0; i < element.getLength(); i++) {
					 if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						 getDTypes=element.item(i).getAttributes().getNamedItem("type").toString();
						 getTag=element.item(i).getNodeName();
						 properVal=getProperValue(getDTypes,getTagValue(getTag,eElement));
						 //// System.out.println("*************************"+data);
						 if (data == null) {
							 data =properVal;
						 }else{
							 data =data+comma+properVal;	
							 System.out.println("data "+data);
						 }
					 }
					 if(getTag!=null){
						 continue;
		 		    	   //return getTag;
					 }else{
		 		    	 // System.out.println("Completed");
		 		     }
				 }//First row
				 System.out.println("data "+data);
				 save(data);
				 data=null;
			 }	
		 }catch(Exception e){
			 // System.out.print("Error :" + e.getMessage());
			 if(getTag==null){
				 return null;
		     }
		 }
		 return null;
	}
	public static NodeList getRootElement(){
		try{
			File fXmlFile = new File(filePath+"/"+fileName);
			System.out.println("import path"+fXmlFile);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("row");
			if(nList!=null){
				getchildValue(nList);
				return nList;
			}else{
				//System.out.println("null");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	public static String getProperValue(String dTypes,String dValue){
		// System.out.println("****"+dTypes+"****"+dValue);
		try{
			int findex=0;
			int lindex=0;
			findex=dTypes.indexOf("\"");
			if(dTypes.lastIndexOf("(")!=-1){
				lindex=dTypes.lastIndexOf("(");
			}else{
				lindex=dTypes.lastIndexOf("\"");
			}
			String dataType=dTypes.substring(findex+1, lindex);
			// System.out.println(dataType.toUpperCase());
			if((dataType.toUpperCase()).equals(DataTypeDetails.DATE.toString())){
				if(!dValue.equals(null)){
					dValue="\""+dValue+"\"";
					System.out.println("dVal  "+dValue);
				}
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.BLOB.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValuesssss    "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.REAL.toString())){
				// System.out.println("dValuesssss    "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.NUMERIC.toString())){
				// System.out.println("dValuesssss    "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.VARCHAR.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValuesssss    "+dValue);
			}	
			if((dataType.toUpperCase()).equals(DataTypeDetails.BIGINT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.MEDIUMTEXT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.LONGBLOB.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.MEDIUMINT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.BINARY.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.BIT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.BOOL.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.BOOLEAN.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.CHAR.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.DATETIME.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.DECIMAL.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			if((dataType.toUpperCase()).equals(DataTypeDetails.DOUBLE.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.ENUM.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.FLOAT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.INT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.YEAR.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.VARBINARY.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.TINYINT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.TIMESTAMP.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.TIME.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.TEXT.toString())){
				dValue="\""+dValue+"\"";
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.SMALLINT.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
				
			}if((dataType.toUpperCase()).equals(DataTypeDetails.SET.toString())){
				// System.out.println("dValueeeeeeeeeee   "+dValue);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return dValue;
	}	
	/*public static void main(String args[]){
		
		getRootElement(fileName,filePath,UserName, Password, DBDriver, DatabaseName, Host, Port);
	}*/
	}