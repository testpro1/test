package xmltransform;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

	public class ExportXmlForm {
		static Connection con=null;
		static Statement stmt=null;
		static Statement stmt1=null;
		static String query=null;
		static String columnQuery=null;
		static ResultSet resultSet=null;
		static String tableQuery=null;
		static String tableQuery1=null;
		static ResultSet resultSet2=null;
		static ResultSet resultSet3=null;
		static ResultSet resultSet4=null;
		static ArrayList<String> addTable=new ArrayList<String>();
		static ArrayList<String> addCol=new ArrayList<String>();
		static ArrayList<String> addTypes=new ArrayList<String>();
		
		public static void getConnection(String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) throws SQLException{
			try {
				Class.forName(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				query="show databases";
				
				resultSet=stmt.executeQuery(query);
				while(resultSet.next()){
					if(resultSet.getString(1).equalsIgnoreCase(DatabaseName)){
						query="show tables";
						resultSet2=stmt.executeQuery(query);
						while(resultSet2.next()){
						getData(resultSet2.getString(1),UserName, Password, DBDriver,DatabaseName, Host, Port);
					}
					} 
				}
				
			} catch (Exception e) {
				System.out.println("connection closed successfully ********** 1");	
				e.printStackTrace();
			}
			finally
			  {
				  if (con != null )  
		            {  
		                try  
		                {
		                	stmt.close();
		                	con.close();
		                }  
		                catch (Exception e) { 
		                	e.printStackTrace();
		                }  
		            }  
			  }
		}
		
		public static void getColumns(String tableName,String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) throws SQLException{
			try {
				getData(tableName,UserName, Password, DBDriver,DatabaseName, Host, Port);
			}catch (Exception e) {
				System.out.println("connection closed successfully ********** 2");
			}
		}
		public static void getData(String tableName,String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) throws IOException, SQLException{
			String xml_output=null;
			try {
				Class.forName(DBDriver);
				con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
				stmt=con.createStatement();
				tableQuery="select * from "+tableName;
				resultSet4=stmt.executeQuery(tableQuery);
				int columns = resultSet4.getMetaData().getColumnCount();
				 xml_output = "<data>";
				while (resultSet4.next()) {
					xml_output += "<row>";
						Class.forName(DBDriver);
						con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
						stmt1=con.createStatement();
						tableQuery1="show columns from "+tableName;
						resultSet3=stmt1.executeQuery(tableQuery1);
						for (int i = 1; i <= columns;i++) {
						while(resultSet3.next()){
							xml_output += "<"+resultSet3.getString(1)+" type=\""+resultSet3.getString(2)+"\" key=\""+resultSet3.getString(4)+"\">"+resultSet4.getString(i++)+"</"+resultSet3.getString(1)+">";
						}
					}
						xml_output += "</row>";
					}
			
			}catch(Exception e){
				System.out.println("connection closed successfully ********** 3");
			}
			finally
			  {
				  if (con != null )  
		            {  
		                try  
		                {
		                	stmt.close();
		                	con.close();
		                }  
		                catch (Exception e) { 
		                	System.out.println("connection closed successfully ********** 4");
		                }  
		            }  
			  }
				
			 xml_output += "</data>";
			 Writer output = null;
			 XmlTransformProperties grantParserProperties=new XmlTransformProperties();
			 @SuppressWarnings("static-access")
			 String getPath=grantParserProperties.getInFolderPath();
			 String filter=".xml";

			 String filePath=getPath+"/"+tableName+filter;
			 String dirPath="/home/verve/Desktop/"+tableName+".zip";
			 String extractFileName=tableName+".xml";
			 File file = new File(filePath);
			  
			 output = new BufferedWriter(new FileWriter(file));
			 output.write(xml_output);
			 output.close();
			 System.out.println("Your file has been written");  
			 
			 DownloadZip downloadZip=new DownloadZip();
			 downloadZip.createZip(filePath,dirPath,extractFileName);
			
			}
	}