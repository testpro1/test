package xmltransform;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class test1 {
	public static void main(String args[]) throws ParseException{
		System.out.println("hello");
		//Date date =new Date("21-09-04");
		String start_date="nov 11,2012";
		String startDate = null;
		String test="2012-11-11";
		
		/*DateFormat df = new SimpleDateFormat("dd MMMM yyyy");
		String text = df.format(date);
		System.out.println(text);
		*/
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd,yyyy");
		Date s_date = (Date)sdf1.parse(start_date);
		startDate = sdf.format(s_date);
		
		Date date = sdf.parse(startDate);
		Date date1 = sdf.parse(test);
		System.out.println(date);
		System.out.println(date1);
		
		if(date.compareTo(date1)==0){
			System.out.println("true");
		}
	}
}