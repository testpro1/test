package xmltransform;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
/**
 * ZetCode Java SWT tutorial
 *
 * In this program, we use the Combo
 * widget to select an option. 
 * The selected option is shown in the
 * Label widget.
 *
 * @author Rupal Kathiriya
 * website zetcode.com
 * last modified June 2009
 */

public class TableSelectionDialog{

	Shell shell;
    Connection con=null;
	Statement stmt=null;
	String query=null;
	String columnQuery=null;
	ResultSet resultSet=null;
	String tableQuery=null;
	static boolean deleteFlag = false;
    public TableSelectionDialog(Shell shell,Display display,String UserName,String Password,String DBDriver,String DatabaseName,String Host,String Port) 
    {
    	shell.setText("Combo");
        initUI(shell,display,UserName,Password,DBDriver,DatabaseName,Host,Port);
        shell.setSize(400, 250);
        shell.setLocation(450, 300);
        shell.open();
    }
    public void initUI(final Shell shell,final Display display,final String UserName,final String Password,final String DBDriver,final String DatabaseName,final String Host,final String Port) {
        final Label label = new Label(shell, SWT.LEFT);
        final Label label1 = new Label(shell, SWT.LEFT);
        label.setLocation(10, 100);
        label.pack();
        label1.setText("Select table name to generate XML");
        label1.setLocation(50, 5);
        label1.pack();
        
        
          
        final Combo combo = new Combo(shell, SWT.DROP_DOWN);
        
        
	    System.out.println("for combo "+UserName);
	    System.out.println("for combo "+Password);
	       
        try {
			Class.forName(DBDriver);
			con =DriverManager.getConnection("jdbc:mysql://"+Host+":"+Port+"/"+DatabaseName,UserName,Password);
			stmt=con.createStatement();
			query="show databases";
			resultSet=stmt.executeQuery(query);
			while(resultSet.next()){
				if(resultSet.getString(1).equalsIgnoreCase(DatabaseName)){
					query="show tables";
					resultSet=stmt.executeQuery(query);
					while(resultSet.next()){
						combo.add(resultSet.getString(1));
					}
				}
			}
			con.close();	
		}catch (Exception e) {
			System.out.println("DB HANDLER********** 1");
			//e.printStackTrace();
		}
        combo.addSelectionListener(new SelectionAdapter() {
           @Override
           public void widgetSelected(SelectionEvent e) {
        	   label.setText("Please wait while exporting "+combo.getText()+ ".xml file after click on create");
               label.pack();
            };
        });
        
        final Button buttonOK = new Button(shell, SWT.PUSH);
        buttonOK.setText("Create");
        buttonOK.setBounds(120, 70, 80, 25);
        Listener listener = new Listener() {
            @SuppressWarnings("static-access")
			public void handleEvent(Event event) {
                if (event.widget == buttonOK) {
                	if(!combo.getText().isEmpty()){
                	deleteFlag = true;
                	ExportXmlForm dataRetrive=new ExportXmlForm();
                    try{
     					dataRetrive.getData(combo.getText(), UserName, Password, DBDriver, DatabaseName, Host, Port);
     					label.setText(combo.getText()+ ".xml is exported successfully");
     	                label.pack();
     				}catch(IOException e1) {
     					e1.printStackTrace();
     				}catch(SQLException e1) {
     					e1.printStackTrace();
     				}}else{
     					label.setText("Select any file to export");
     	                label.pack();
     				}
               } else {
                    deleteFlag = false;
               }
            }
          };
        buttonOK.addListener(SWT.Selection, listener);
        combo.setLocation(50, 30);
        combo.pack();
    }
    
   /* public static void main(String[] args) {
        Shell shell=new Shell();
    	Display display = new Display();
        new TableSelectionDialog(shell, display, "gaurav", "google.com","com.mysql.jdbc.Driver","meetin2","192.168.1.6","3306");
        display.dispose();
    }*/
}
