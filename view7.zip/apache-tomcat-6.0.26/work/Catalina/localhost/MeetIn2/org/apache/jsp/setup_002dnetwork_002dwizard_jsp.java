package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.Networkmaster;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAuthorizationRequestUrl;
import com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;
import com.verve.meetin.network.NetworkConstraint;

public final class setup_002dnetwork_002dwizard_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<h2 class=\"socialnetwork\">My Social Networks</h2>\n");
      out.write("\t<div class=\"socialmain\">\n");
      out.write("\t\t<ul>\n");
      out.write("\t\t");

					 List networkList = new ArrayList();
                     networkList = new NetworkDAO().getSocialNetworkSites();
                       
                       if(networkList !=null && networkList.size() > 0){
                       
                         for(int i=0; i < networkList.size(); i++){
                            Networkmaster network = new Networkmaster();
                             network = (Networkmaster)networkList.get(i);
                             String networkusername = new NetworkDAO().getNetworkUserName((Integer)session.getAttribute("UserID"), network.getSocialNetworkSiteId());
                      
                      		if(	network.getSocialNetworkSiteName().equalsIgnoreCase("Foursquare Checkin"))
                      		{
                      			continue;
                      		}	       
		
      out.write("\n");
      out.write("\t\t\t<li class=\"sociallist\">\n");
      out.write("\t\t\t\t\t<img src=\"");
      out.print(network.getSocialNetworkSiteIcon() );
      out.write("\" />");
      out.print(network.getSocialNetworkSiteName() );
      out.write("\n");
      out.write("\t\t\t    \t<span class=\"demo\">");
if(!networkusername.equals("")) out.print("("+networkusername+")"); 
      out.write("</span>\n");
      out.write("\t\t");

					  boolean result = new NetworkDAO().checkUserSocialNetwork((Integer)session.getAttribute("UserID"),network.getSocialNetworkSiteId());
					  if(result)
					  {
		
      out.write("\n");
      out.write("\t\t\t\t\t\t<a href=\"usernetwork.do?action=remove&userid=");
      out.print(session.getAttribute("UserID"));
      out.write("&siteid=");
      out.print(network.getSocialNetworkSiteId() );
      out.write("&show_wizard=show_wizard\" onclick=\"return confirmSubmit();\" class=\"none\"><img src=\"images/remove.png\" border=\"none\" title=\"Remove\" hspace=\"10px\" style=\"margin-right: 30px;\"/></a>\n");
      out.write("\t\t");


					  }else
					  {
					  		if(network.getSocialNetworkSiteId().intValue() == NetworkConstraint.SOCIAL_NETWORK_FACEBOOK)
					  		{
		
      out.write("\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"javascript: void(0);\" onclick=\"facebookLogin('");
      if (_jspx_meth_bean_005fmessage_005f0(_jspx_page_context))
        return;
      out.write('\'');
      out.write(',');
      out.write('\'');
      if (_jspx_meth_bean_005fmessage_005f1(_jspx_page_context))
        return;
      out.write('\'');
      out.write(',');
      out.write('\'');
      if (_jspx_meth_bean_005fmessage_005f2(_jspx_page_context))
        return;
      out.write("');\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\" /></a>\n");
      out.write("\t\t\t\t\t\t\t\t");
 session.setAttribute("facebookRedirect","/setupnetwork.jsp "); 
      out.write("  <!-- This session Attribute is for facebook redirect Flag -->\n");
      out.write("\t\t");

							}
						else if(network.getSocialNetworkSiteId().intValue() == NetworkConstraint.SOCIAL_NETWORK_LINKEDIN)
							{
		
      out.write("\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"javascript: void(0);\" onclick=\"LinkedInLogin();\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\" /></a>\n");
      out.write("\t\t");

							}
						else if (network.getSocialNetworkSiteId().intValue() == NetworkConstraint.SOCIAL_NETWORK_GMAIL)
							{
									ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
          String authorizeUrl = new GoogleAuthorizationRequestUrl(resource.getString("gmail.client.id").toString(),resource.getString("gmail.callback.url"),resource.getString("gmail.scope.url")).setAccessType("offline").setApprovalPrompt("force").build();
		
      out.write("\n");
      out.write("\t\t\t<a href=\"javascript: void(0);\" onclick=\"GmailLogin('");
      out.print(authorizeUrl );
      out.write("');\"\tclass=\"none\">\n");
      out.write("\t\t\t<img src=\"images/plus_icon.png\" alt=\"add icon\" /></a>\n");
      out.write("\t\t");
					
							}
							else if(network.getSocialNetworkSiteId().intValue() == NetworkConstraint.SOCIAL_NETWORK_TWITTER)
							{
							
		
      out.write("\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"javascript: void(0);\" onclick=\"twitterLogin();\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\" /></a>\n");
      out.write("\t\t");
					
							}
							else if(network.getSocialNetworkSiteId().intValue() == NetworkConstraint.SOCIAL_NETWORK_TRIPIT)
							{
					
      out.write("\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"javascript: void(0);\" onclick=\"tripitLogin();\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\" /></a>\n");
      out.write("\t\t\t\t\t");
									
							}
							else if(network.getSocialNetworkSiteId().intValue() == NetworkConstraint.SOCIAL_NETWORK_FOURSQUARE)
							{
					
      out.write("\n");
      out.write("<a href=\"javascript: void(0);\" onclick=\"foursquareLogin('");
      if (_jspx_meth_bean_005fmessage_005f3(_jspx_page_context))
        return;
      out.write('\'');
      out.write(',');
      out.write('\'');
      if (_jspx_meth_bean_005fmessage_005f4(_jspx_page_context))
        return;
      out.write("');\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\" /></a>\n");
      out.write("\t\t\t\t\t");
									
							}
					  }
		 
      out.write("\n");
      out.write("\t\t\t</li>\n");
      out.write("\t\t");

				}
			}
		
      out.write("\n");
      out.write("\t\t\n");
      out.write("\t\t\n");
      out.write("\t\t\t<!--<li class=\"sociallist\"><img src=\"images/gmail_icon.png\" />Gmail<a href=\"#\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\"></a></li>\n");
      out.write("\t\t\t<li class=\"sociallist\"><img src=\"images/2_linkedin_icon.png\" />Linkedin<a href=\"#\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\"></a></li>\n");
      out.write("\t\t\t<li class=\"sociallist\"><img src=\"images/twitter.png\" />Twitter<a href=\"#\" class=\"none\"><img src=\"images/plus_icon.png\" alt=\"add icon\"></a></li>\n");
      out.write("\t\t\t-->\n");
      out.write("\t\t\n");
      out.write("\t\t</ul>\n");
      out.write("\t\t<div class=\"donot arrow\">\n");
      out.write("\t\t\t<a href=\"#\" onClick=\"showAddTripWizard();\"><img src=\"images/more_arrow_icon.png\" alt=\"read more\"></a>\n");
      out.write("\t\t</div>\n");
      out.write("\t</div>\n");
      out.write("<div class=\"clear\">&nbsp;</div>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_bean_005fmessage_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f0 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f0.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f0.setParent(null);
    // /setup-network-wizard.jsp(49,63) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f0.setKey("facebook.app_id");
    int _jspx_eval_bean_005fmessage_005f0 = _jspx_th_bean_005fmessage_005f0.doStartTag();
    if (_jspx_th_bean_005fmessage_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f0);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f1 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f1.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f1.setParent(null);
    // /setup-network-wizard.jsp(49,103) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f1.setKey("facebook.redirect_uri");
    int _jspx_eval_bean_005fmessage_005f1 = _jspx_th_bean_005fmessage_005f1.doStartTag();
    if (_jspx_th_bean_005fmessage_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f1);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f2(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f2 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f2.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f2.setParent(null);
    // /setup-network-wizard.jsp(49,149) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f2.setKey("facebook.scope");
    int _jspx_eval_bean_005fmessage_005f2 = _jspx_th_bean_005fmessage_005f2.doStartTag();
    if (_jspx_th_bean_005fmessage_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f2);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f3(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f3 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f3.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f3.setParent(null);
    // /setup-network-wizard.jsp(84,57) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f3.setKey("foursquare.Client_id");
    int _jspx_eval_bean_005fmessage_005f3 = _jspx_th_bean_005fmessage_005f3.doStartTag();
    if (_jspx_th_bean_005fmessage_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f3);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f3);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f4(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f4 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f4.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f4.setParent(null);
    // /setup-network-wizard.jsp(84,102) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f4.setKey("foursquare.Redirect_URI");
    int _jspx_eval_bean_005fmessage_005f4 = _jspx_th_bean_005fmessage_005f4.doStartTag();
    if (_jspx_th_bean_005fmessage_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f4);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f4);
    return false;
  }
}
