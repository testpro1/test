package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Enumeration;
import java.util.Collections;
import com.verve.meetin.trip.Trips;
import com.verve.meetin.user.User;
import com.verve.meetin.network.NetworkDAO;

public final class peoplenearme_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

String latitude = "";
	String langitude = "";
	String friendname = "";
	String socialsiteIcon = "";
	Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
	ArrayList<String> locationList = new ArrayList<String>();
	String loggedinuserlatlang = "";
	String imageName = "";
	String userId = "";
  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
 int size =0;
      out.write('\n');
      out.write('\n');
      out.write("\n");
      out.write("\t<input type=\"hidden\" id=\"default_location\" value=\"");
      out.print(session.getAttribute("default_location").toString());
      out.write("\" />\n");
      out.write("\t\n");
      out.write("\t\n");

	
	if (request.getAttribute("LatLongList") != null) 
	{
		latitude = "";
		langitude = "";
		friendname = "";
		socialsiteIcon = "";
		imageName = "";
		userId = "";

		List latlongList = (ArrayList) request.getAttribute("LatLongList");
		
		
		for (int l = 0; l < latlongList.size(); l++) 
		{
			User user = new User();
			user = (User) latlongList.get(l);
			
			latitude = latitude + user.getLocLat() + "_";
			langitude = langitude + user.getLocLang() + "_";
			//friendname = user.getFullname() + "_";
			friendname = friendname + user.getFullname() + "_";
			
			socialsiteIcon = socialsiteIcon	+ user.getGoogleMarkerIcon().split("/")[1] + ",";
			imageName = imageName + user.getImage() + ",";
			userId = userId + user.getUserKey() + "_";
					
			}
	}
	if (request.getAttribute("LatLong") != null) 
	{
		loggedinuserlatlang = "";
		loggedinuserlatlang = (String) request.getAttribute("LatLong");
	}

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<input type=\"hidden\" id=\"latitude\" value='");
      out.print(latitude);
      out.write("' />\n");
      out.write("<input type=\"hidden\" id=\"langitude\" value='");
      out.print(langitude);
      out.write("' />\n");
      out.write("<input type=\"hidden\" id=\"friendname\" value='");
      out.print(friendname);
      out.write("' />\n");
      out.write("<input type=\"hidden\" id=\"googlemarkericon\" value='");
      out.print(socialsiteIcon);
      out.write("' />\n");
      out.write("<input type=\"hidden\" id=\"loggedinuserlatlang\"\n");
      out.write("\tvalue='");
      out.print(loggedinuserlatlang);
      out.write("' />\n");
      out.write("<input type=\"hidden\" id=\"imageName\" value='");
      out.print(imageName);
      out.write("' />\n");
      out.write("<input type=\"hidden\" id=\"userId\" value='");
      out.print(userId);
      out.write("' />\n");
      out.write("<div style=\"overflow: hidden; height: auto\" id=\"content\">\n");
      out.write("\t<div class=\"innercontainer\">\n");
      out.write("\t\t<div class=\"generalfrm\" style=\"height: auto;\">\n");
      out.write("\t\t\t");

				if (session.getAttribute("showlivinglocation") != null) 
				{
			
      out.write("\n");
      out.write("\t\t\t<div class=\"lable\">\n");
      out.write("\t\t\t\tLiving Location\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				} else {
			
      out.write("\n");
      out.write("\t\t\t<div class=\"lable\">\n");
      out.write("\t\t\t\tCurrent Location\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				}
			
      out.write("\n");
      out.write("\t\t\t<!--  The below lines of code will fill up the drop down list for current locations -->\n");
      out.write("\t\t\t");

				ArrayList<String> locationList = new ArrayList<String>();
			if (session.getAttribute("current_location") != null) 
			{
					locationList = (ArrayList) session.getAttribute("current_location");

					if (locationList != null && locationList.size() > 1) 
					{
			
      out.write("\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t");

			 			 
			session.setAttribute("clocation",locationList.get(0).toString());
			 
      out.write("\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t<div class=\"inputleft\"></div>\n");
      out.write("\t\t\t<div class=\"inputrepeat\" style=\"margin-bottom: 10px;\">\n");
      out.write("\t\t\t\t<select id=\"locationId\" name=\"locationname\" style=\"width: auto;\"\n");
      out.write("\t\t\t\t\tclass=\"select\"\tonchange=\"findPeopleFromUpcomingTrip(this.value,'peoplefinder');showStreetAddress('',this.value)\">\n");
      out.write("\t\t\t\t\t");

						for (int i = 0; i < locationList.size(); i++) 
						{
					
      out.write("\n");
      out.write("\t\t\t\t\t\t<option value=\"");
      out.print(locationList.get(i));
      out.write('"');
      out.write('>');
      out.print(locationList.get(i));
      out.write("</option>\n");
      out.write("\t\t\t\t\t");

						}
					
      out.write("\n");
      out.write("\t\t\t\t</select>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<div class=\"inputright\"></div>\n");
      out.write("\t\t\t");

					}
					 else if (locationList != null && locationList.size() == 1 ) 
					 {
				
			
				if(session.getAttribute("default_location").toString().equals(locationList.get(0)))
				{
				
				
      out.write("\t\n");
      out.write("\t\t\t<div>\n");
      out.write("\t\t\t\t<input type=\"text\" value=\"");
      out.print(locationList.get(0).toString());
      out.write("\"\tname=\"location\" readonly=\"readonly\" />\n");
      out.write("\t\t\t</div>\n");
      out.write("\n");
      out.write("\t\t\t\t");

				}
				else
				{
				
					session.setAttribute("clocation",locationList.get(0));
				
      out.write("\n");
      out.write("\t\t\t\t\t<div>\n");
      out.write("\t<input type=\"text\" value=\"");
      out.print(locationList.get(0).toString());
      out.write("\"\tname=\"location\" readonly=\"readonly\" />\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t");

				}
				
				
			
      out.write("\n");
      out.write("\t\t\t\n");
      out.write("\n");
      out.write("\t\t\t");

				}
				}
				if (session.getAttribute("upcomingtrip") != null)
				 {
					if (session.getAttribute("showlivinglocation") != null) 
					{
				
					
			
      out.write("\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t<div style=\"height: 20px;margin-top: 10px; margin-left: 170px; clear: both; \">\n");
      out.write("\t\t\t\t<div style=\"width: 50px; float: left; line-height: 30px;\">\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t<input type=\"hidden\" id=\"clocation\"  value=\"");
      out.print(session.getAttribute("clocation") );
      out.write("\">\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t\t\t<input type=\"checkbox\" name=\"showCurLocation\" id=\"loc\"\n");
      out.write("\t\t\tonclick=\"loadPeopleNearMyLocation();\"  checked=\"checked\"\n");
      out.write("\t\t\t\t\t\tstyle=\"width: auto !important;\" />\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t<div class=\"lable1\" style=\"width: 230px; color: #000; float: left; line-height: 20px;\">\n");
      out.write("\t\t\t\t\tPeople near my living location\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				}
				 
				else 
				{
							
			
      out.write("\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t<div style=\"margin-top: 10px; margin-left: 170px; clear: both;\">\n");
      out.write("\t\t\t\t<div style=\"width: 35px; float: left; line-height: 30px;\">\n");
      out.write("\t\t\t\t\t<input type=\"checkbox\" name=\"showCurLocation\" id=\"loc\"\n");
      out.write("\t\t\t\t\t\tonclick=\"loadPeopleNearMyLocation();\" style=\"width: auto!important;\" />\n");
      out.write("\t\t\t\t</div><div class=\"lable1\" style=\"width: 230px; color: #000; float: left; line-height: 20px;\"> People near my living location</div>\n");
      out.write("\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				}
				}
			
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<div class=\"heading\"\n");
      out.write("\t\t\tstyle=\"margin-top: 30px; height: auto; overflow: hidden\">\n");
      out.write("\n");
      out.write("\t\t\t<div style=\"float: left;\">\n");
      out.write("\t\t\t\t<img src=\"images/location_icon.png\" align=\"bottom\" />\n");
      out.write("\t\t\t\tList of people near you\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				/**Code to show the total number of people on a page */
				friends = (Hashtable<String, List<String>>) session
						.getAttribute("friends");
				if (friends != null && friends.size() > 0) {
			
      out.write("\n");
      out.write("\t\t\t");

				} else {
			
      out.write("\n");
      out.write("\t\t\t<div class=\"found\">\n");
      out.write("\t\t\t\t&nbsp;\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				}
			
      out.write("\n");
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t\n");
      out.write("\t\t<div class=\"friends\">\n");
      out.write("\t\t\n");
      out.write("\t\t<div class=\"tableheading\">\n");
      out.write("\t\t\t<div class=\"sourcecol\">\n");
      out.write("\t\t\t\t&nbsp;\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<div class=\"namecol\">\n");
      out.write("\t\t\t\tName\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<div class=\"dynamicrow\">\n");
      out.write("\t\t\t");

				try {
					if (request.getAttribute("friends") != null)
						friends = (Hashtable<String, List<String>>) request.getAttribute("friends");
					else
						friends = (Hashtable<String, List<String>>) session.getAttribute("friends");
//-------------------------------------------------------------------------------------------------------------------				
				
					session.setAttribute("friends", friends);
					if (!friends.containsKey("ERROR")) {

						List<String> name = new ArrayList();
						Enumeration<String> em = friends.keys();
						while (em.hasMoreElements()) 
						{
							String key = em.nextElement();
							name.add(friends.get(key.toString()).get(0) + "::"+ key);
						}
						Collections.sort(name, String.CASE_INSENSITIVE_ORDER);

						List<List<String>> sorted_list = new ArrayList<List<String>>();
												
						Iterator<String> iter = name.iterator();
						while (iter.hasNext()) {
							String nkey = iter.next();
							if (request.getAttribute("filter") != null
									|| request.getParameter("filter").equals("all")
									||

		friends.get(nkey.split("::")[1]).get(2).toLowerCase().contains(request.getParameter("filter").toString().toLowerCase())) {

								List<String> sort_name = new ArrayList<String>();
								sort_name.add(nkey.split("::")[1]);
								sort_name.add(nkey.split("::")[0]);
								sort_name.add(friends.get(nkey.split("::")[1]).get(1));
								sort_name.add(friends.get(nkey.split("::")[1]).get(2));
			    				sort_name.add(friends.get(nkey.split("::")[1]).get(3)); // user latitude
								sort_name.add(friends.get(nkey.split("::")[1]).get(4)); // user langitude
								sort_name.add(friends.get(nkey.split("::")[1]).get(5));

								// show meetin friend image in google map when click on meetin icon
								String siteicon = friends.get(nkey.split("::")[1]).get(2);
								
								if (siteicon == "images/meetin_icon.png"		&& request.getAttribute("AllowLocationEdit") != null) {

									String friendid = friends.get(nkey.split("::")[1]).get(1);
									String friend_id = friendid.substring(20);
				
									String imageName = "";
									String imagePath = request.getScheme() + "://"
											+ request.getServerName() + ":"
											+ request.getServerPort()
											+ request.getContextPath();
									if (friends.get(nkey.split("::")[1]).get(6) != null
											&& !friends.get(nkey.split("::")[1])
													.get(6).toString().equals("")) {
										imageName = imagePath
												+ "/profileimage/"
												+ friend_id
												+ "_"
												+ friends.get(nkey.split("::")[1])
														.get(6);
									} else {
										if (friends.get(nkey.split("::")[1]).get(7)
												.toString().toLowerCase().equals(
														"male"))
											imageName = imagePath
													+ "/images/male.png";
										else
											imageName = imagePath
													+ "/images/female.png";
									}
									sort_name.add(imageName); //meetin friend image
								} else
									sort_name.add(friends.get(nkey.split("::")[1])
											.get(6)); //social frd image
								sorted_list.add(sort_name);
							}
						}
	
					
						size = sorted_list.size();

						//Implement Navigation
						int start = Integer.parseInt(session.getAttribute("start")
								.toString());
						int end = Integer.parseInt(session.getAttribute("end")
								.toString());
						if (request.getParameter("event") != null
								&& request.getParameter("event").equals("next")) {
							session.setAttribute("start", String.valueOf(end));
							start = end;
							if (sorted_list.size() < 10) {
								session.setAttribute("end", String
										.valueOf(sorted_list.size()));
								end = sorted_list.size();
							} else if ((end + 10) < sorted_list.size()) {
								session.setAttribute("end", String
										.valueOf(end + 10));
								end = end + 10;
							} else if ((end + 10) > sorted_list.size()) {
								session.setAttribute("end", String.valueOf(end
										+ (sorted_list.size() - end)));
								end = end + (sorted_list.size() - end);
							} else if ((end + 10) >= sorted_list.size()) {
								session.setAttribute("end", String.valueOf(end
										+ (sorted_list.size() - end)));
								end = sorted_list.size();
							}
						} else if (request.getParameter("event") != null
								&& request.getParameter("event").equals("prev")) {
							if (start >= 10) {
								session.setAttribute("start", String
										.valueOf(start - 10));
								start = start - 10;
							} else if (start < 10) {
								session.setAttribute("start", String.valueOf(start
										- start));
								start = start - start;
							}
							session.setAttribute("end", String.valueOf(start + 10));
							end = start + 10;
						} else if (request.getParameter("event") != null
								&& request.getParameter("event").equals("first")) {
							start = 0;
							if (sorted_list.size() < 10)
								end = sorted_list.size();
							else
								end = 10;
							session.setAttribute("end", end);
							session.setAttribute("start", start);
						} else if (request.getParameter("event") != null
								&& request.getParameter("event").equals("last")) {
							end = sorted_list.size();
							if (sorted_list.size() < 10)
								start = 0;
							else {
								start = (sorted_list.size() / 10) * 10;
								if (start == sorted_list.size())
									start = start - 10;
							}
							session.setAttribute("end", end);
							session.setAttribute("start", start);
						} else if (request.getParameter("event") != null
								&& request.getParameter("event").equals(
										"pagi_combo")) {
							String[] s = request.getParameter("pagi_combo").split(
									"-");
							start = Integer.parseInt(s[0]);
							end = Integer.parseInt(s[1]);
							session.setAttribute("end", end);
							session.setAttribute("start", start);
						} else {
							start = 0;
							if (sorted_list.size() < 10)
								end = sorted_list.size();
							else
								end = 10;
							session.setAttribute("end", end);
							session.setAttribute("start", start);
						}
						//end nevigation
						if (session.getAttribute("friends") != null) {
							if (friends != null && friends.size() > 0) {
								//Iterator iter1 = sorted_list.iterator();
								//while(iter1.hasNext())
								for (int i = start; i < end; i++) {
									//List friend_info = (List)iter1.next();
									
									List friend_info = sorted_list.get(i);
									
			
      out.write("\n");
      out.write("\n");
      out.write("\t\t\t");

				String styleClass = "row";
									/* This code work fine on single page */
									if (friend_info.get(0).toString().equals(
											request.getAttribute("selectFrd_id"))) {
										styleClass = "row_highlight";
									}
			
      out.write("\n");
      out.write("\t\t\t<div class=\"");
      out.print(styleClass);
      out.write("\">\n");
      out.write("\t\t\t\t<div class=\"dynamicsourcecol\">\n");
      out.write("\t\t\t\t\t<img src=\"");
      out.print(friend_info.get(3).toString());
      out.write("\" />\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t<div class=\"dynamicnamecol\">\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t");

						if (friend_info.get(1).toString().length() > 28) {
					
      out.write("\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0)\"\n");
      out.write("\t\t\t\t\t\tonclick=\"getFriendforTrip'");
      out.print(friend_info.get(4));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(5));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(1));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(3));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(loggedinuserlatlang);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(7));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(0));
      out.write("')\">\n");
      out.write("\t\t\t\t\t\t");
      out.print(friend_info.get(1).toString().substring(0, 28)+ "...");
      out.write(" </a>\n");
      out.write("\t\t\t\t\t");

						} else {
					
      out.write("\n");
      out.write("\t\t\t\t\t<a href=\"#googlemap\"\n");
      out.write("\t\t\t\t\t\tonclick=\"getFriendforTrip'");
      out.print(friend_info.get(4));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(5));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(1));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(3));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(loggedinuserlatlang);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(7));
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(0));
      out.write("')\">\n");
      out.write("\t\t\t\t\t\t");
      out.print(friend_info.get(1));
      out.write("</a>\n");
      out.write("\t\t\t\t\t");

						}
					
      out.write("\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t<div class=\"dynamicviewcol\">\n");
      out.write("\t\t\t\t\t");

					String[] socialnetwork = friend_info.get(3).toString().split("/");
					if (socialnetwork[1].equals("meetin_icon.png")) {
					
      out.write("\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\t\tonclick=\"scrollTo(0,0); viewUserProfile('");
      out.print(friend_info.get(2).toString());
      out.write("');\"\n");
      out.write("\t\t\t\t\t\ttitle=\"View Profile\"><img src=\"images/view_icon.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t");

						} else if (socialnetwork[1].equals("1_facebook_icon.png")) {
					
      out.write("\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\t\tonclick=\"window.open('");
      out.print(friend_info.get(2).toString());
      out.write("','name','height=600,width=1000,scrollbars=1');\"\n");
      out.write("\t\t\t\t\t\ttitle=\"View Profile\"><img src=\"images/view_icon.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"><img src=\"images/view_uptrip_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" \tstyle=\"cursor: auto;\" class=\"\"><img src=\"images/invite_msg_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\t\t\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t");

						} else if (socialnetwork[1].equals("2_linkedin_icon.png")) {
					
      out.write("\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" \t>\n");
      out.write("\t\t\t\t\t\t <img src=\"images/view_icon_inactive.png\"\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t \n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"\n");
      out.write("\t\t\t\t\t\t><img src=\"images/view_uptrip_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"\t class=\"\"><img src=\"images/invite_msg_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\t\t\n");
      out.write("\t\t\t\t\t\t \n");
      out.write("\t\t\t\t\t");

						} else if (socialnetwork[1].equals("gmail_icon.png")) {
					
      out.write("\n");
      out.write("\t\t\t\t\t\t<a href=\"javascript:void(0);\"\t>\n");
      out.write("\t\t\t\t\t\t <img src=\"images/view_icon_inactive.png\" \tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t \n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"\n");
      out.write("\t\t\t\t\t\t><img src=\"images/view_uptrip_inactive.png\" style=\"cursor: auto;\" \n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" \tstyle=\"cursor: auto;\"  class=\"\"><img src=\"images/invite_msg_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t");

						}
					 else if (socialnetwork[1].equals("twitter.png")) {
					
      out.write("\n");
      out.write("\t\t\t\t\t\t<a href=\"javascript:void(0);\"\tstyle=\"cursor: auto;\" >\n");
      out.write("\t\t\t\t\t\t <img src=\"images/view_icon_inactive.png\"\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t \n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" \n");
      out.write("\t\t\t\t\t\t><img src=\"images/view_uptrip_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"  \t class=\"\"><img src=\"images/invite_msg_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t");

						}	
						
					if (friend_info.get(6) != null	&& !(friend_info.get(6).equals(""))) {
					
      out.write("\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\t\tonclick=\"getPeopleUpcomingTripDetail('");
      out.print(friend_info.get(6).toString());
      out.write("');\"title=\"View Trip\"><img src=\"images/view_uptrip.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" onclick=\"callMeetingInviteView('");
      out.print(friend_info.get(0).toString());
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(locationList.get(0));
      out.write("');\"\n");
      out.write("\t\t\t\t\t\ttitle=\"Send Message\" class=\"\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t");

						}
					else if( (!socialnetwork[1].equals("gmail_icon.png")) && (!socialnetwork[1].equals("1_facebook_icon.png")) && (!socialnetwork[1].equals("2_linkedin_icon.png")) && (!socialnetwork[1].equals("twitter.png")))
					{
					
      out.write("\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\"\n");
      out.write("\t\t\t\t\t\t><img src=\"images/view_uptrip_inactive.png\"\n");
      out.write("\t\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" onclick=\"callMeetingInviteView('");
      out.print(friend_info.get(0).toString());
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(locationList.get(0));
      out.write("');\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t");

					}
					
      out.write("\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				}
			
      out.write("\n");
      out.write("\t\t\t<div style=\"height: 26px; padding: 5px; width: 200px; float: left\">\n");
      out.write("\t\t\t\t<div class=\"inputleft\"></div>\n");
      out.write("\t\t\t\t<div class=\"inputrepeat\">\n");
      out.write("\t\t\t\t\t<select id=\"filter\" class=\"select\" name=\"filter\"\n");
      out.write("\t\t\t\t\t\tstyle=\"width: 150px;\" onchange=\"nevigation_PeopleNearMe('','');\">\n");
      out.write("\t\t\t\t\t\t<option value=\"all\">\n");
      out.write("\t\t\t\t\t\t\tAll Friends\n");
      out.write("\t\t\t\t\t\t</option>\n");
      out.write("\t\t\t\t\t\t");
List<Integer> networkListIds = new ArrayList<Integer>();
											List<String> networkList = new ArrayList<String>();
											networkListIds = new NetworkDAO().getUserSocialNetworkSiteId(Integer
															.parseInt(session.getAttribute(
																	"UserID").toString()));
											networkList = new NetworkDAO()
													.getUserSocialNetworkSiteNames(networkListIds);
											for (int i = 0; i < networkList.size(); i++) {
						
      out.write("\n");
      out.write("\t\t\t\t\t\t<option value=\"");
      out.print(networkList.get(i));
      out.write("\"\n");
      out.write("\t\t\t\t\t\t\t");
if (request.getParameter("filter") != null
										&& request.getParameter("filter")
												.equals(
														networkList.get(i)
																.toString())) {
      out.write("\n");
      out.write("\t\t\t\t\t\t\tselected=\"selected\" ");
}
      out.write('>');
      out.print(networkList.get(i));
      out.write("</option>\n");
      out.write("\t\t\t\t\t\t");

							}
						
      out.write("\n");
      out.write("\t\t\t\t\t\t");
if(networkListIds.size()>0){ 
      out.write("\n");
      out.write("\t\t\t\t\t\t<option value=\"meetin\"\n");
      out.write("\t\t\t\t\t\t");
if (request.getParameter("filter") != null&& request.getParameter("filter").equals("meetin")) {
      out.write("\n");
      out.write("\t\t\t\t\t\tselected=\"selected\" ");
}
      out.write(">meetIn</option>\t\t\n");
      out.write("\t\t\t\t\t\t");
} 
      out.write("\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t</select>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t<div class=\"inputright\"></div>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t\n");
      out.write("\t\t\t<!-- Div tag for Paging -->\n");
      out.write("\t\t\t<div class=\"pagination\">\n");
      out.write("\t\t\t\t");

					if (start > 0) {
				
      out.write("\n");
      out.write("\t\t\t\t<input type=\"button\" name=\"first\" onclick=\"nevigation_PeopleNearMe('first','');\" class=\"first\"\t\ttitle=\"First\" />\t\n");
      out.write("\t\t\t\t<input type=\"button\" name=\"prev\"  onclick=\"nevigation_PeopleNearMe('prev','');\" class=\"previous\"\ttitle=\"Previous\"/>\n");
      out.write("\t\t\t\t");

					} else {
				
      out.write("\n");
      out.write("\t\t\t\t<input type=\"input\" disabled=\"disabled\" name=\"first\"\n");
      out.write("\t\t\t\t\tclass=\"first_disable\" />\n");
      out.write("\t\t\t\t<input type=\"input\" disabled=\"disabled\" name=\"prev\"\n");
      out.write("\t\t\t\t\tclass=\"previous_disable\" />\n");
      out.write("\t\t\t\t");

					}
				
      out.write("\n");
      out.write("\t\t\t\t<div class=\"inputcontainer\">\n");
      out.write("\t\t\t\t\t<div class=\"inputleft\"></div>\n");
      out.write("\t\t\t\t\t<div class=\"inputrepeat\">\n");
      out.write("\t\t\t\t\t\t<select id=\"pagi_combo\" name=\"pagi_combo\" class=\"select\"\n");
      out.write("\t\t\t\t\t\t\tonchange=\"nevigation_PeopleNearMe('pagi_combo');\">\n");
      out.write("\t\t\t\t\t\t\t");

								for (int i = 0; i < sorted_list.size(); i += 10) {
													int j = i + 10;
													if (j > sorted_list.size())
														j = sorted_list.size();
							
      out.write("\n");
      out.write("\t\t\t\t\t\t\t<option\n");
      out.write("\t\t\t\t\t\t\t\t");
String sel = start + "-" + end;
								if (sel.equals(i + "-" + j)) {
      out.write("\n");
      out.write("\t\t\t\t\t\t\t\tselected=\"selected\" ");
}
      out.write(" value=\"");
      out.print(i);
      out.write('-');
      out.print(j);
      out.write('"');
      out.write('>');
      out.print(i + 1);
      out.write("\n");
      out.write("\t\t\t\t\t\t\t\t-\n");
      out.write("\t\t\t\t\t\t\t\t");
      out.print(j);
      out.write("</option>\n");
      out.write("\t\t\t\t\t\t\t");

								}
							
      out.write("\n");
      out.write("\t\t\t\t\t\t</select>\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t<div class=\"inputright\"></div>\n");
      out.write("\t\t\t\t\t<div class=\"number\">\n");
      out.write("\t\t\t\t\t\tof\n");
      out.write("\t\t\t\t\t\t");
      out.print(sorted_list.size());
      out.write("\n");
      out.write("\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t");

					if (end < sorted_list.size()) {
				
      out.write("\n");
      out.write("\t\t\t\t<input type=\"button\" class=\"next\" name=\"next\"\n");
      out.write("\t\t\t\t\tonclick=\"nevigation_PeopleNearMe('next','');\" title=\"Next\" />\n");
      out.write("\t\t\t\t<input type=\"button\" class=\"last\" name=\"last\"\n");
      out.write("\t\t\t\t\tonclick=\"nevigation_PeopleNearMe('last','');\" title=\"Last\" />\n");
      out.write("\n");
      out.write("\t\t\t\t");

					} else {
				
      out.write("\n");
      out.write("\t\t\t\t<input type=\"button\" name=\"next\" class=\"next_disable\"\n");
      out.write("\t\t\t\t\tdisabled=\"disabled\" />\n");
      out.write("\t\t\t\t<input type=\"button\" name=\"last\" class=\"last_disable\"\n");
      out.write("\t\t\t\t\tdisabled=\"disabled\" />\n");
      out.write("\t\t\t\t");

					}
				
      out.write("\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				} else {
			
      out.write("\n");
      out.write("\t\t\t<!-- Div tag for Message format -->\n");
      out.write("\t\t\t<div class=\"infomsg\" style=\"display: block\">\n");
      out.write("\t\t\t\t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\" />\n");
      out.write("\t\t\t\tNo friends found that match your location.\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				}

						}
					} else {
			
      out.write("\n");
      out.write("\t\t\t<!-- Div tag for Message format -->\n");
      out.write("\t\t\t<div class=\"infomsg\" style=\"display: block\">\n");
      out.write("\t\t\t\t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\" />\n");
      out.write("\t\t\t\tNo friends found that match your location.\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t");

				}

				} catch (Exception ex) {
					ex.printStackTrace();
				}
			
      out.write("\n");
      out.write("\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<div id=\"size1\">  \t \n");
      out.write("\t\t\t\t");
if(size == 0)
					{
					out.println("<strong>No Friend(s) Found</strong>");
				 
      out.write("\n");
      out.write("\t\t\t\t \t");
}else{ 
      out.write("\t\n");
      out.write("\t\t\t\t\t<strong>");
      out.print(size);
      out.write(" Friend(s) Found</strong>  \n");
      out.write("\t\t\t\t\t");
} 
      out.write("\n");
      out.write("\t\t\t</div>\n");
      out.write(" \t\t\t\n");
      out.write("\t</div>\n");
      out.write("\t</div>\n");
      out.write("</div>\n");
      out.write("<!--  -->\n");
      out.write("<a name=\"googlemap\" >&nbsp;</a>\n");
      out.write("\n");
      out.write("<!-- Ajax loader content start here -->\n");
      out.write("<div id=\"loading\" style=\"width: 100%;height: 100%;top:0;left: 0;position: fixed;display: none;opacity:0.7;background-color: white;z-index: 99;text-align: center;\">\n");
      out.write("<img src=\"images/ajax-loader_new.gif\" alt=\"Loading....\" style=\"position: absolute;top: 260px;left: 650px;z-index: 100;\" />\n");
      out.write("</div>\n");
      out.write("<!-- Ajax loader content end here -->\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
