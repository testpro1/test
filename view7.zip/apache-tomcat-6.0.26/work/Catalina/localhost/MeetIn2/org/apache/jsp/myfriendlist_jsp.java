package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.verve.meetin.user.User;
import com.verve.meetin.friend.FriendsDAO;

public final class myfriendlist_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


	Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
System.out.println("/myfriendlist.jsp"); 
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\tfunction setSelectedIndex(s, v) {\n");
      out.write("\t\t for ( var i = 0; i < s.options.length; i++ ) {\n");
      out.write("\t\t     if ( s.options[i].value == v ) {\n");
      out.write("\t\t         s.options[i].selected = true;\n");
      out.write("\t\t         return;\n");
      out.write("\t\t     }\n");
      out.write("\t\t }\n");
      out.write("\t}\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("<div style=\"overflow:hidden; height:auto\">\n");
      out.write("     <div class=\"innercontainer\">\n");
      out.write("      \t<div class=\"heading\" style=\"margin-top:30px; height: auto;overflow: hidden;\">\n");
      out.write("      \t<img src=\"images/trip_icon.png\" align=\"bottom\" /> ");
      out.print(session.getAttribute("socialnetworkname") );
      out.write("&nbsp;Friends\n");
      out.write("      \t");

                  /**Code to show the total number of people on a page */
                  friends = (Hashtable<String,List<String>>)session.getAttribute("friendlist");
                  if(friends !=null && friends.size() >0)
                   {
        
      out.write("\n");
      out.write("                 <div class=\"found\"><strong>");
      out.print(friends.size() );
      out.write("</strong> friend(s) found</div>\n");
      out.write("        ");
  
				   }
				   else
				   {
	 	
      out.write("\n");
      out.write("\t \t       \t<div class=\"found\">&nbsp;</div>\n");
      out.write("\t \t");

				   }
        
      out.write("\n");
      out.write("     \t </div>\n");
      out.write("     \n");
      out.write("\t\t     <div class=\"tableheading\">\n");
      out.write("\t\t              <div class=\"sourcecol\">&nbsp;</div>\n");
      out.write("\t\t              <div class=\"namecol\">Name</div>\n");
      out.write("\t\t              <div class=\"namecol\">Location</div>\n");
      out.write("\t\t     </div>\n");
      out.write("\t\t     <div class=\"dynamicrow\">\n");
      out.write("\t\t     ");
	
					int start = 0, end = 0;
					 List sorted_list = new ArrayList();
        			//String path = request.getContextPath();
	    			//String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";    	
			      //  String imagePath="";		    

                     if(session.getAttribute("friendlist") !=null) {
				   		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();

				   	 String friend_id = "";
					
				   	 friends = (Hashtable<String, List<String>>)session.getAttribute("friendlist");
				   	 //if(!friends.containsKey("ERROR")){
				   	 
				   	 List<String> name = new ArrayList();
					 Enumeration<String> em = friends.keys();
					 while(em.hasMoreElements())
						{
							String key = em.nextElement();
							name.add(friends.get(key.toString()).get(0)+"::"+key);
							
						}
						
					 Collections.sort(name, String.CASE_INSENSITIVE_ORDER);
					 //List sorted_list = new ArrayList();
					 Iterator<String> iter = name.iterator();
					 
					 while(iter.hasNext())
						{
							List sort_name = new ArrayList();
							String nkey = iter.next();
							sort_name.add(nkey.split("::")[1]);
					
							sort_name.add(nkey.split("::")[0]);
					
							sort_name.add(friends.get(nkey.split("::")[1]).get(1));
					
							sort_name.add(friends.get(nkey.split("::")[1]).get(2));
					
							sort_name.add(friends.get(nkey.split("::")[1]).get(3));
					
					
							sorted_list.add(sort_name);
						}
						
					// Implement the Navigation
					start = Integer.parseInt(session.getAttribute("start").toString());
                    end = Integer.parseInt(session.getAttribute("end").toString());
                    if(request.getParameter("event") != null && request.getParameter("event").equals("next"))
                    {
                            session.setAttribute("start", String.valueOf(end));
                            start = end;
                            if(sorted_list.size() < 10)
                            {
                                    session.setAttribute("end", String.valueOf(sorted_list.size()));
                                    end = sorted_list.size();
                            }
                            else if((end+10) < sorted_list.size())
                            { 
                                    session.setAttribute("end", String.valueOf(end+10));
                                    end = end + 10;
                            }
                            else if((end+10) > sorted_list.size())
                            {
                                    session.setAttribute("end", String.valueOf(end + (sorted_list.size() - end)));
                                    end = end + (sorted_list.size() - end);
                            }
                            else if((end+10) >= sorted_list.size())
                            {
                                    session.setAttribute("end", String.valueOf(end + (sorted_list.size() - end)));
                                    end = sorted_list.size();
                            }
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("prev"))
                    {
                            if(start >= 10)
                            {
                                    session.setAttribute("start", String.valueOf(start-10));
                                    start = start - 10;
                            }
                            else if(start < 10)
                            {
                                    session.setAttribute("start", String.valueOf(start-start));
                                    start = start - start;
                            }
                            session.setAttribute("end", String.valueOf(start+10));
                            end = start + 10;
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("first")) 
                    {
                    	start = 0;
                    	if(sorted_list.size() < 10)
                    		end = sorted_list.size();
                    	else
                    		end = 10;
                    	session.setAttribute("end", end);
                    	session.setAttribute("start", start);
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("last")) 
                    {
                    	end = sorted_list.size();
                    	if(sorted_list.size() < 10)
                    		start = 0;
                    	else
                    	{
                    		start = (sorted_list.size() / 10) * 10;
                    		if(start == sorted_list.size())
                    			start = start - 10;
                    	} 
                    	session.setAttribute("end", end);
                    	session.setAttribute("start", start);
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("pagi_combo"))
                    {
                    	String[] s = request.getParameter("pagi_combo").split("-");
                    	start = Integer.parseInt(s[0]);
                    	end = Integer.parseInt(s[1]);
                    	session.setAttribute("end", end);
		                session.setAttribute("start", start);
                    }
                     // End Navigation	
				   	 if(sorted_list != null && sorted_list.size() > 0) 
							{
								
								for(int i=start;i<end;i++)
								{
									List friend_info = (List)sorted_list.get(i);

			
      out.write("\n");
      out.write("\t\t\t<div class=\"row\">\n");
      out.write("\t\t\t\t<div class=dynamicsourcecol><img src=\"");
      out.print(friend_info.get(4) );
      out.write("\" border=\"none\"/></div>\n");
      out.write("\t\t\t\t<div class=\"colgrid\" style=\"width: 41%\">\n");
      out.write("\t\t\t\t\t");
 if(friend_info.get(1).toString().length() > 28) 
					    	out.println(friend_info.get(1).toString().substring(0, 28)+"..."); 
						else
						    out.println(friend_info.get(1));
					
      out.write("\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t            <div class=\"colgrid\" style=\"width: 31%\">\n");
      out.write("\t            ");

	            	if(friend_info.get(2).toString().length() >22)
	            			out.println(friend_info.get(2).toString().substring(0,16)+"...");
	            	else
	            		out.println(friend_info.get(2));
	            
      out.write("\n");
      out.write("\t            </div>\t\n");
      out.write("\t            <div class=\"dynamicviewcol\" style=\"width: 92px; margin-left:40px;\">\n");
      out.write("\t              ");

	              		String[] socialnetwork = friend_info.get(4).toString().split("/");
		   				if(socialnetwork[1].equals("meetin_icon.png"))
		   				{
		 		  
      out.write("\n");
      out.write("\t\t\t \t <a href=\"javascript:void(0);\" onclick=\" scrollTo(0,0); viewUserProfile('");
      out.print(friend_info.get(3));
      out.write("');\"><img src=\"images/view_icon.png\" title=\"View Profile\" border=\"none\"/></a>\n");
      out.write("\t\t\t \t <a href=\"javascript:void(0);\" onclick=\" scrollTo(0,0); viewUserTripList('");
      out.print(friend_info.get(3));
      out.write("');\"><img src=\"images/view_trip_icon.png\" title=\"Trip List\" border=\"none\"/></a>\n");
      out.write("\t\t\t\t ");

						}
						else if(socialnetwork[1].equals("1_facebook_icon.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" onclick=\"window.open('");
      out.print(friend_info.get(3));
      out.write("','name','height=600,width=1000,scrollbars=1');\"><img src=\"images/view_icon.png\" title=\"View Profile\"border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t    ");

						} 
						else if(socialnetwork[1].equals("2_linkedin_icon.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\"  style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_icon_inactive.png\" border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t    ");

						}
						else if(socialnetwork[1].equals("gmail_icon.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\"  style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_icon_inactive.png\" border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t    ");

						}  
						else if(socialnetwork[1].equals("twitter.png"))
						{
		    	 
      out.write("\n");
      out.write("\t\t     \t\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\"  style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_icon_inactive.png\" border=\"none\" /></a>\n");
      out.write("\t\t     \t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t    ");

						}
						
			
      out.write("\n");
      out.write("\t\t\t\t </div>\n");
      out.write("         \t</div>\n");
      out.write("         \t");

					}
		    
      out.write("\n");
      out.write("\t\t    \t<div class=\"pagination\">\n");
      out.write("\t\t\t\t\t ");
 if(start > 0) {
      out.write("\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"first\" class=\"first\" onclick=\"nevigation('first','');\" title=\"First\" />\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"prev\" onclick=\"nevigation('prev','');\" title=\"Previous\" class=\"previous\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"input\" disabled=\"disabled\"  name=\"first\" class=\"first_disable\"   />\n");
      out.write("\t\t            <input type=\"input\" disabled=\"disabled\"  name=\"prev\" class=\"previous_disable\" />\n");
      out.write("\t\t       \t\t");
} 
      out.write("\n");
      out.write("\t\t       \t\t<div class=\"inputcontainer\">\n");
      out.write("\t\t            <div class=\"inputleft\"></div>\n");
      out.write("\t\t            <div class=\"inputrepeat\">\n");
      out.write("\t\t           \t\t<select id=\"pagi_combo\" name=\"pagi_combo\" class=\"select\" style=\"width: 100px;\" onchange=\"nevigation('pagi_combo');\">\n");
      out.write("\t\t           \t\t\t");
for(int i=0; i<sorted_list.size(); i+=10){
		           				int j = i + 10; 
		           				if(j > sorted_list.size())
		           					j = sorted_list.size();
		           			
      out.write("\n");
      out.write("\t\t           \t\t\t\t<option ");
 String sel = start+"-"+end; if(sel.equals(i+"-"+j)){ 
      out.write(" selected=\"selected\" ");
} 
      out.write(" value=\"");
      out.print(i );
      out.write('-');
      out.print(j );
      out.write('"');
      out.write('>');
      out.print(i+1 );
      out.write(' ');
      out.write('-');
      out.write(' ');
      out.print(j );
      out.write("</option>\n");
      out.write("\t\t           \t\t\t");
} 
      out.write("\n");
      out.write("\t\t           \t\t</select>\n");
      out.write("\t\t           \t</div>\n");
      out.write("\t\t           \t<div class=\"inputright\"></div>\n");
      out.write("\t\t               <div class=\"number\"> of ");
      out.print(sorted_list.size() );
      out.write(" </div>\n");
      out.write("\t\t \t\t\t</div>\n");
      out.write("\t\t       \t\t");
 if(end < sorted_list.size()) { 
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" onclick=\"nevigation('next','');\" class=\"next\" title=\"Next\" />\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"last\" onclick=\"nevigation('last','');\" class=\"last\" title=\"Last\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" class=\"next_disable\" disabled=\"disabled\"/>\n");
      out.write("\t\t            <input type=\"button\" name=\"last\" class=\"last_disable\" disabled=\"disabled\" />\n");
      out.write("\t\t      \t\t");
} 
      out.write("\n");
      out.write("\t\t\t </div>\n");
      out.write("\t\t    \n");
      out.write("\t\t    ");

		    	}
				else 
				{
			
      out.write("\n");
      out.write("\t\t\t <!-- Div tag for Message format -->          \n");
      out.write("              <div class=\"infomsg\" style=\"display:block\">\n");
      out.write("                \t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\"/> No friends found.\n");
      out.write("              </div>\n");
      out.write("\t\t\t");

				}
				/*}else {*/
      out.write("\n");
      out.write("\t\t\t\t<!-- Div tag for Message format -->          \n");
      out.write("              <!--<div class=\"infomsg\" style=\"display:block\">\n");
      out.write("                \t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\"/> \n");
      out.write("              </div>\n");
      out.write("\t\t\t-->");
 //} 
			}
			else
			{
      out.write("\n");
      out.write("\t\t\t<!-- Div tag for Message format -->          \n");
      out.write("              <div class=\"infomsg\" style=\"display:block\">\n");
      out.write("                \t<img src=\"images/info_icon.png\" align=\"absmiddle\" hspace=\"5\"/> No friends found.\n");
      out.write("              </div>\n");
      out.write("\t\t\t");
}
			
      out.write("\n");
      out.write("\t\t\t\t");
 
    if(session.getAttribute("gmail_error") != null) 
    {
        List error_list = (List)session.getAttribute("gmail_error");
        String error = error_list.get(0).toString();
        out.println(error);
        session.removeAttribute("gmail_error");
    }
    if(session.getAttribute("facebook_error") != null) 
    {
        List error_list = (List)session.getAttribute("facebook_error");
        String error = error_list.get(0).toString();
        out.println(error);
        session.removeAttribute("facebook_error");
    }
    if(session.getAttribute("linkedin_error") != null) 
    {
        List error_list = (List)session.getAttribute("linkedin_error");
        String error = error_list.get(0).toString();
        out.println(error);
        session.removeAttribute("linkedin_error");
    }
    if(session.getAttribute("twitter_error") != null) 
    {
        List error_list = (List)session.getAttribute("twitter_error");
        String error = error_list.get(0).toString();
        out.println(error);
        session.removeAttribute("twitter_error");
    }

      out.write("\n");
      out.write("\t\t\t<script> </script>\t\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t</div>\n");
      out.write("</div>       \n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
