package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.verve.meetin.user.User;

public final class signup_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fstyle_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleId_005fstyleClass_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fstyle_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleId_005fstyleClass_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fstyle_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleId_005fstyleClass_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!doctype html>\n");
      out.write(" \n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<html xmlns=\"http://www.w3.org/1999/xhtml\">\n");
      out.write("<head>\n");
      out.write("    <meta charset=\"utf-8\" />\n");
      out.write("    <title>meetIn Signup Page</title>\n");
      out.write("   \n");
      out.write("    <script src=\"http://code.jquery.com/jquery-1.8.3.js\"></script>\n");
      out.write("    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write("   \t<meta http-equiv='cache-control' content='no-cache'/><meta http-equiv='expires' content='0'/><meta http-equiv='pragma' content='no-cache'/>\n");
      out.write("\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
      out.write("\t<meta http-equiv=\"refresh\" content=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pageContext.session.maxInactiveInterval}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" url=\"mymeetin.jsp\" />\n");
      out.write("\t\n");
      out.write("\t<meta name=\"description\" content=\"Using meetIn to Search People for Free, free social network people search.\" />\n");
      out.write("\t<meta name=\"keywords\" content=\"Advance Search, Advance People Search, Search People for Free, free social network people search\" />\n");
      out.write("\t\n");
      out.write("\t<link rel=\"shortcut icon\" href=\"images/meetin_icon.png\" />\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/jquery-1.js\"></script>\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/imagescroll.js\"></script>\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/meetin.js\"></script>\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/changepassword.js\"></script>\n");
      out.write("\t<!-- This is google map script -->\n");
      out.write("\t<link href=\"css/default.css\" rel=\"stylesheet\" type=\"text/css\"/>\n");
      out.write("\t<script type=\"text/javascript\" src=\"http://maps.google.com/maps/api/js?sensor=false\"></script>\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write("\t<script type=\"text/javascript\" src=\"js/custom-form-elements.js\"></script>\n");
      out.write("\t<!-- This is jquery validation engine  -->\n");
      out.write("\t<link rel=\"stylesheet\" href=\"css/validationEngine.jquery.css\" type=\"text/css\" media=\"screen\" title=\"no title\" charset=\"utf-8\" />\n");
      out.write("\t<link rel=\"stylesheet\" href=\"css/template.css\" type=\"text/css\" media=\"screen\" title=\"no title\" charset=\"utf-8\" />\n");
      out.write("\t<link rel=\"stylesheet\" href=\"css/jquery-ui.css\" type=\"text/css\"  />\n");
      out.write("\t<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js\" type=\"text/javascript\"></script>\n");
      out.write("\t<script src=\"js/jquery.validationEngine-en.js\" type=\"text/javascript\"></script>\n");
      out.write("  \t<script src=\"js/jquery.validationEngine.js\" type=\"text/javascript\"></script>\n");
      out.write("\t<script src=\"js/jquery-ui.js\" type=\"text/javascript\"></script>\n");
      out.write("\t\n");
      out.write("\t\n");
      out.write("   \n");
      out.write("   \n");
      out.write("    <style>\n");
      out.write("    .ui-autocomplete-loading {\n");
      out.write("        background: white url('images/ui-anim_basic_16x16.gif') right center no-repeat;\n");
      out.write("    }\n");
      out.write("    \n");
      out.write("    </style>\n");
      out.write("    <script>\n");
      out.write("    jQuery.noConflict();\n");
      out.write("    jQuery(function() {\n");
      out.write("        function log( message ) {\n");
      out.write("            jQuery( \"<div>\" ).text( message ).prependTo( \"#log\" );\n");
      out.write("            jQuery( \"#log\" ).scrollTop( 0 );\n");
      out.write("        }\n");
      out.write(" \n");
      out.write("        jQuery( \"#city\" ).autocomplete({\n");
      out.write("            source: function( request, response ) {\n");
      out.write("                jQuery.ajax({\n");
      out.write("                    url: \"http://ws.geonames.org/searchJSON\",\n");
      out.write("                    dataType: \"jsonp\",\n");
      out.write("                    data: {\n");
      out.write("                        featureClass: \"P\",\n");
      out.write("                        style: \"full\",\n");
      out.write("                        maxRows: 12,\n");
      out.write("                        name_startsWith: request.term\n");
      out.write("                    },\n");
      out.write("                    success: function( data ) {\n");
      out.write("                        response( jQuery.map( data.geonames, function( item ) {\n");
      out.write("                            return {\n");
      out.write("                                label: item.name + (item.adminName1 ? \", \" + item.adminName1 : \"\") + \", \" + item.countryName,\n");
      out.write("                                value: item.name + (item.adminName1 ? \", \" + item.adminName1 : \"\") + \", \" + item.countryName\n");
      out.write("                            }\n");
      out.write("                        }));\n");
      out.write("                    }\n");
      out.write("                });\n");
      out.write("            },\n");
      out.write("            minLength: 2,\n");
      out.write("            select: function( event, ui ) {\n");
      out.write("                log( ui.item ?\n");
      out.write("                    \"Selected: \" + ui.item.label :\n");
      out.write("                    \"Nothing selected, input was \" + this.value);\n");
      out.write("            },\n");
      out.write("            open: function() {\n");
      out.write("                jQuery( this ).removeClass( \"ui-corner-all\" ).addClass( \"ui-corner-top\" );\n");
      out.write("            },\n");
      out.write("            close: function() {\n");
      out.write("                jQuery( this ).removeClass( \"ui-corner-top\" ).addClass( \"ui-corner-all\" );\n");
      out.write("            }\n");
      out.write("        });\n");
      out.write("    });\n");
      out.write("\n");
      out.write("\n");
      out.write("\t\t\n");
      out.write("\t\tjQuery(document).ready(function() {\n");
      out.write("\t\t            \n");
      out.write("\t\t\t\t\tjQuery(\"#frmregister\").validationEngine(\n");
      out.write("\t\t\t\t\t{\n");
      out.write("\t\t\t\t\t\tinlineValidation: false\n");
      out.write("\t\t\t\t\t})\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t\tjQuery(\"#birthdate\").datepicker({\n");
      out.write("\t\t          \tchangeMonth: true,\n");
      out.write("\t\t          \tchangeYear: true,\n");
      out.write("\t\t          \tdateFormat: 'M dd,yy',\n");
      out.write("\t\t          \tshowOn: \"button\",\n");
      out.write("\t\t\t\t\tbuttonImage: \"images/calendar.png\",\n");
      out.write("\t\t\t\t\tbuttonImageOnly: true,\n");
      out.write("\t\t          \tonSelect: function (){this.focus();},\n");
      out.write("\t\t          \tminDate:new Date(1950, 1 - 1, 26),\n");
      out.write("\t\t          \tmaxDate:'-15Y'\n");
      out.write("\t\t\t\t});\n");
      out.write("\t\t\t\t});\n");
      out.write("    </script>\n");
      out.write("    <script type=\"text/javascript\">\n");
      out.write("\t\tfunction callMyMeetin(){\n");
      out.write("\t\t\t  window.location.href=\"mymeetin.jsp\";\n");
      out.write("\t\t}\n");
      out.write("\t</script>\n");
      out.write("    <script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("  var _gaq = _gaq || [];\n");
      out.write("  _gaq.push(['_setAccount', 'UA-9594176-11']);\n");
      out.write("  _gaq.push(['_trackPageview']);\n");
      out.write("\n");
      out.write("  (function() {\n");
      out.write("    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;\n");
      out.write("    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';\n");
      out.write("    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);\n");
      out.write("  })();\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("</head>\n");

	
	System.out.println("sign up page");
	
	//out.print("Code :"+session.getAttribute("code"));
	 String name = "";
	 String email="";
	 String birthdate="";
	 String country="";
	 String state = "";
	 String city="";
	 String gender="";
	 String cities="";
	 if (request.getAttribute("fullname")!=null)
	 { 
	 	name = request.getAttribute("fullname").toString();
	 	
	 }
	 if (request.getAttribute("email") != null)
	 {  
	 	email = request.getAttribute("email").toString();
	 	
	 }
	 if (request.getAttribute("birthdate") != null)
	 {  
	 	birthdate = request.getAttribute("birthdate").toString();
	 	
	 }	
	 if(request.getAttribute("gender") != null)
	 {
	 	gender = request.getAttribute("gender").toString();

	 }
	 if(request.getAttribute("city") != null)
	 {
	 	city = request.getAttribute("city").toString();
	 }	
	

      out.write("\n");
      out.write("<body>\n");
      out.write(" \n");
      out.write(" <body onload=\"initialize(40.7488,-73.9846,'New York'); setDefaultFocus(document.getElementById('fullname')); CustomizedHtmlControl();\" onunload=\"GUnload();\">\n");
try{ 
	

      out.write("\n");
      out.write("<div class=\"wrapper\">\n");
      out.write("\t<!--mainsite starts here -->\n");
      out.write("\t<div class=\"mainsite\">\n");
      out.write("    \t<div class=\"leftside\">\n");
      out.write("    \t<a href=\"index.jsp\">\n");
      out.write("    \t\t<div class=\"logo\"></div>\n");
      out.write("    \t\t</a>\n");
      out.write("        \t<div class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("               \t\t  <img id=\"screen1\" src=\"images/screen01.jpg\" alt=\"Splash Screen\"/>\n");
      out.write("               \t\t  <img id=\"screen2\" src=\"images/screen02.jpg\" alt=\"meetIn Screen\" style=\"left: 202px;\"/>\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\t\n");
      out.write("            </div>\n");
      out.write("            \n");
      out.write("           <div class=\"appstore\" style=\"margin-left: 12px;\"><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-iphone.png\" style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-midtext.png\" style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-androide.png\" style=\"float: left\"/>  </div></a>\n");
      out.write("            <a href=\"How_It_Works.jsp\"><div class=\"appvideo\"><img id=\"appvideo\" src=\"images/appvideo_new.png\" onmouseout=\"mouseout1();\" onmouseover=\"mouseover1();\"/></div></a>\n");
      out.write("\n");
      out.write("                        \n");
      out.write("            <div class=\"followus\">\n");
      out.write("            \tFollow Us on:\n");
      out.write("                <div class=\"socialnetwork\">\n");
      out.write("                   <a href=\"javascript:void(0)\" onclick=\"window.open('https://www.facebook.com/pages/MeetIn/495222843824206', '_blank')\">\n");
      out.write("                <div class=\"facebook\"></div></a>\n");
      out.write("             \n");
      out.write("                 <a href=\"javascript:void(0)\" onclick=\"window.open('https://twitter.com/mymeetIn', '_blank')\"><div class=\"twitter\"></div></a>\n");
      out.write("                </div>\n");
      out.write("            </div>\n");
      out.write("        </div>\n");
      out.write("        <div class=\"rightside\">\n");
      out.write("        \t<div id=\"navigation\">\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"index.jsp\"><span>Home</span></a></div>\n");
      out.write("                 <div id=\"nav\" class=\"submitBtn active\"><a href=\"mymeetin.jsp\"><span>My meetIn</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"How_It_Works.jsp\"><span>How It Works</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"ComingSoon.jsp\"><span>Features</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"feedback.jsp\"><span>Feedback</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"contact.jsp\"><span>Contact Us</span></a></div>\n");
      out.write("        \t</div>\n");
      out.write("\t\t\t\t\n");
      out.write("            <div style=\"overflow:hidden; height:auto\">\n");
      out.write("                <div class=\"innercontainer\">\n");
      out.write("\t\t\t\t\t<div class=\"heading\">\n");
      out.write("                    \t<img src=\"images/signup_icon.png\" align=\"absbottom\"/> Sign Up\n");
      out.write("                    </div>\n");
      out.write("                    <p align=\"right\" style=\"font-size:12px; text-align:right; margin-bottom:-10px; margin-top:20px;\">Fill up all details. All fields are mandatory.</p>\n");
      out.write("                    \n");
      out.write("                    ");
      //  html:form
      org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f0 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_005fform_005f0.setPageContext(_jspx_page_context);
      _jspx_th_html_005fform_005f0.setParent(null);
      // /signup.jsp(226,20) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setAction("/register");
      // /signup.jsp(226,20) name = method type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setMethod("post");
      // /signup.jsp(226,20) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setStyleId("frmregister");
      int _jspx_eval_html_005fform_005f0 = _jspx_th_html_005fform_005f0.doStartTag();
      if (_jspx_eval_html_005fform_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\n");
          out.write("                      <input type=\"hidden\" name=\"action\" value=\"register\"/>\n");
          out.write("                        <div class=\"generalfrm\">\n");
          out.write("                            <div class=\"lable\">Full Name</div>\n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f0 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f0.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
          // /signup.jsp(230,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setProperty("fullname");
          // /signup.jsp(230,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setValue(name );
          // /signup.jsp(230,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setSize("50");
          // /signup.jsp(230,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setMaxlength("50");
          // /signup.jsp(230,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setStyleId("fullname");
          // /signup.jsp(230,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setStyleClass("validate[required,custom[onlyLetter]] text-input");
          int _jspx_eval_html_005ftext_005f0 = _jspx_th_html_005ftext_005f0.doStartTag();
          if (_jspx_th_html_005ftext_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
          out.write("\n");
          out.write("                                                \n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Email</div>\n");
          out.write("\t\t\t\t\t\t\t");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f1 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f1.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
          // /signup.jsp(234,7) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setProperty("email");
          // /signup.jsp(234,7) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setStyleId("email");
          // /signup.jsp(234,7) name = onblur type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setOnblur("emailAvailabilityCheck();");
          // /signup.jsp(234,7) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setSize("50");
          // /signup.jsp(234,7) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setMaxlength("50");
          // /signup.jsp(234,7) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setValue(email );
          // /signup.jsp(234,7) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setStyleClass("validate[required,custom[email]] text-input");
          int _jspx_eval_html_005ftext_005f1 = _jspx_th_html_005ftext_005f1.doStartTag();
          if (_jspx_th_html_005ftext_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f1);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f1);
          out.write("\n");
          out.write("\t\t\t\t\t\t\t<div id=\"email_available_msg\" style=\"position:absolute; margin-top:-60px; margin-left:400px; display: none\"><img src=\"images/email_register.png\" style=\"border:none\"/></div>\n");
          out.write("                            <div class=\"frmline\"></div>  \n");
          out.write("                            <div class=\"lable\">Password</div>\n");
          out.write("                            ");
          if (_jspx_meth_html_005fpassword_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Confirm Password</div>                 \n");
          out.write("                            <input type=\"password\" value=\"\" name=\"confirmpassword\" id=\"confirmpass\" size=\"30\" maxlength=\"30\" class=\"validate[required,equals[password]] text-input\"/>\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Birth Date</div>                    \n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f2 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f2.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
          // /signup.jsp(244,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setProperty("birthdate");
          // /signup.jsp(244,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setValue(birthdate );
          // /signup.jsp(244,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setStyleId("birthdate");
          // /signup.jsp(244,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setStyleClass("validate[required]");
          // /signup.jsp(244,28) name = readonly type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setReadonly(true);
          int _jspx_eval_html_005ftext_005f2 = _jspx_th_html_005ftext_005f2.doStartTag();
          if (_jspx_th_html_005ftext_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f2);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f2);
          out.write("\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Gender</div>\n");
          out.write("                            <div style=\"float:left; height:30px; background-color:#bbb; width:1px\">&nbsp;</div>\n");
          out.write("                                 <!-- \n");
          out.write("                          \tChanges done by Dharam Chag in \n");
          out.write("                          \tChecked should be male by default\n");
          out.write("                           -->\n");
          out.write("                     \n");
          out.write("                           \n");
          out.write("                           ");
 if(gender.toString().trim().toLowerCase().equals("Male".toLowerCase()) || gender.equals("")) { 
          out.write("\n");
          out.write("                            <div class=\"gender\">\n");
          out.write("        \t\t\t\t\t<input type=\"radio\" id=\"gender\" name=\"gender\" value=\"male\"  checked=\"checked\" class=\"styled\" > Male</input>&nbsp;&nbsp;&nbsp;</div>\n");
          out.write("        \t\t\t\t\t<div class=\"gender\">\n");
          out.write("        \t\t\t\t\t<input type=\"radio\" id=\"gender\" name=\"gender\" value=\"Female\"  class=\"styled\">Female</input>\n");
          out.write("        \t\t\t\t    </div>   \n");
          out.write("                             ");
 } else { 
          out.write("\n");
          out.write("        \t\t\t\t\t <div class=\"gender\">\n");
          out.write("\t\t\t\t\t        <input type=\"radio\" id=\"gender\" name=\"gender\" value=\"male\" class=\"styled\" > Male</input>&nbsp;&nbsp;&nbsp;</div>\n");
          out.write("\t\t\t\t\t        <div class=\"gender\">         \n");
          out.write("\t\t\t\t\t        <input type=\"radio\" id=\"gender\" name=\"gender\" value=\"Female\" class=\"styled\" checked=\"checked\" >Female</input>\n");
          out.write("                             </div>\n");
          out.write("                              ");
}
          out.write("\n");
          out.write("                     \n");
          out.write("                            <!--");
          if (_jspx_meth_html_005fradio_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("&nbsp;&nbsp;&nbsp;\n");
          out.write("                            ");
          if (_jspx_meth_html_005fradio_005f1(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                          -->  \n");
          out.write("                                                 <!--<div class=\"lable\">Gender</div>\n");
          out.write("                            ");
          if (_jspx_meth_html_005ftext_005f3(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                             \n");
          out.write("                        --></div>\n");
          out.write("                        \n");
          out.write("                    <div class=\"heading\" style=\"margin-top:30px;\">\n");
          out.write("                    \t<img src=\"images/location_icon.png\" align=\"absbottom\"/> Set Up your Location\n");
          out.write("                    </div>\n");
          out.write("\n");
          out.write("                    <div class=\"generalfrm\">\n");
          out.write("                        <!--<div class=\"lable\">Country</div>\n");
          out.write("                        ");
          if (_jspx_meth_html_005ftext_005f4(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                        <div class=\"frmline\"></div>\n");
          out.write("                        <div class=\"lable\">State</div>\n");
          out.write("                        ");
          if (_jspx_meth_html_005ftext_005f5(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                        <div class=\"frmline\"></div>\n");
          out.write("                         <div class=\"lable\">Street</div>\n");
          out.write("                        ");
          if (_jspx_meth_html_005ftext_005f6(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                        <div class=\"frmline\"></div>\n");
          out.write("                        -->\n");
          out.write("                        <div class=\"lable\">City</div>\n");
          out.write("                        <!-- code commented by Dharam Chag \n");
          out.write("                        \t");
          if (_jspx_meth_html_005ftext_005f7(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                         -->\n");
          out.write("                         ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f8 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f8.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f8.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
          // /signup.jsp(295,25) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setProperty("locCity");
          // /signup.jsp(295,25) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setValue(city);
          // /signup.jsp(295,25) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setStyleId("city");
          // /signup.jsp(295,25) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setStyleClass("validate[required]");
          // /signup.jsp(295,25) name = onblur type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setOnblur("showStreetAddress('',this.value);");
          int _jspx_eval_html_005ftext_005f8 = _jspx_th_html_005ftext_005f8.doStartTag();
          if (_jspx_th_html_005ftext_005f8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody.reuse(_jspx_th_html_005ftext_005f8);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody.reuse(_jspx_th_html_005ftext_005f8);
          out.write("\n");
          out.write("                        \n");
          out.write("                        <div id=\"list\" style=\"display: none;\"></div>\n");
          out.write("                         <!--<div class=\"frmline\"></div>\n");
          out.write("                        <div class=\"lable\">Postal Code</div>\n");
          out.write("                        ");
          if (_jspx_meth_html_005ftext_005f9(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                    \t--></div>\n");
          out.write("                    \t");
          if (_jspx_meth_html_005fhidden_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                     \t");
          if (_jspx_meth_html_005fhidden_005f1(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("<!--\n");
          out.write("                    \t<script>getCity_latitude_longitude(document.getElementById(\"city\").value);</script>\n");
          out.write("                    \t--><p align=\"right\" style=\"font-size:12px; text-align:right; margin-bottom:-10px; margin-top:20px;\">Drag icon in map and place it on your exact location.</p>\n");
          out.write("                        <div class=\"googlemap\" id=\"map\">\n");
          out.write("      \t\t    \t\t\t<div id=\"map_canvas\" style=\"width: 670px; height: 350px;\"></div>\n");
          out.write("\t\t   \t\t\t\t</div>\n");
          out.write("\t\t   \t\t\t\t\n");
          out.write("\t\t   \t\t\t\t   \t\t\t\t\n");
          out.write("\t\t   \t\t\t\t\n");
          out.write("\t\t   \t\t\t<input class=\"validate[required] checkbox\" type=\"checkbox\" name=\"Accept\" id=\"Accept\"/> &nbsp; I Agree to <a href=\"javascript:TermsCondition()\">Terms & Conditions</a>\n");
          out.write("\t\t    \t\t\t\t\n");
          out.write("\t\t   \t\t\t\t\t\t   \t\t\t\t\n");
          out.write("                   <div class=\"logonsection\">                   \n");
          out.write("                    ");
          if (_jspx_meth_html_005fsubmit_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("&nbsp;&nbsp;\n");
          out.write("                    <input type=\"button\" class=\"buttonorgsmall\" value=\"Cancel\" onclick=\"callMyMeetin();\" /> \n");
          out.write("                    </div>                                      \n");
          out.write("                    ");
          int evalDoAfterBody = _jspx_th_html_005fform_005f0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_005fform_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
        return;
      }
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
      out.write("\n");
      out.write("                </div><!-- content ends here -->\n");
      out.write("            </div>                                          \n");
      out.write("            \n");
      out.write("        </div>\n");
      out.write("    </div><!--mainsite starts here -->\n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("    <div class=\"footer\">                                        \n");
      out.write("    \t<p><a href=\"index.jsp\">Home</a>| \n");
      out.write("        \t<a href=\"How_It_Works.jsp\">How It Works</a>|          \n");
      out.write("            <a href=\"ComingSoon.jsp\">Features</a>|              \n");
      out.write("            <a href=\"feedback.jsp\">Feedback</a>|                \n");
      out.write("            <a href=\"contact.jsp\">Contact Us</a>|\n");
      out.write("\t\t\t\t\t<a href=\"ComingSoon.jsp\">Privacy Policy</a>|\n");
      out.write("\t\t\t\t\t<a href=\"ComingSoon.jsp\">Disclaimer</a>                \n");
      out.write("        </p> \n");
      out.write("        <p>&nbsp;</p>                                           \n");
      out.write("    \t<p>meetIn is an application of <a href=\"http://www.offshoremobiledevelopment.com\"  target=\"_blank\"  class=\"ft_link\">Verve Mobile Labs</a> | iPhone is trademarks of Apple Inc., registered in U.S. and other countries. App Store is a service mark of Apple Inc.</p>\n");
      out.write("        <p class=\"copyright\">Copyright @ 2012 meetIn. All rights reserved. </p>\n");
      out.write("    </div><!--footer ends here -->                                          \n");
      out.write("</div>\n");
      out.write("</body>\n");
      out.write("</html>\n");
      out.write(" ");

  }catch(Exception e){
 	System.out.println("error occured 0 *----  " +e );
 }
 
 
      out.write("\n");
      out.write(" \n");
      out.write(" \n");
      out.write(" \n");
      out.write(" \n");
      out.write("<!-- These two divs are used to show lightbox popup for user profile details -->\n");
      out.write("<!-- Start Div -->\n");
      out.write("<div id=\"light\" class=\"white_content\"></div>\n");
      out.write("<div id=\"fade\" class=\"black_overlay\"></div>\n");
      out.write("\n");
      out.write("<!-- End Div -->\n");
      out.write("</body>\n");
      out.write("</html>\n");
      out.write(" ");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_html_005fpassword_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:password
    org.apache.struts.taglib.html.PasswordTag _jspx_th_html_005fpassword_005f0 = (org.apache.struts.taglib.html.PasswordTag) _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.PasswordTag.class);
    _jspx_th_html_005fpassword_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fpassword_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(238,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setProperty("password");
    // /signup.jsp(238,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setSize("30");
    // /signup.jsp(238,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setMaxlength("30");
    // /signup.jsp(238,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setStyleId("password");
    // /signup.jsp(238,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setStyleClass("validate[required,length[6,11]] text-input");
    int _jspx_eval_html_005fpassword_005f0 = _jspx_th_html_005fpassword_005f0.doStartTag();
    if (_jspx_th_html_005fpassword_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005fpassword_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005fpassword_005f0);
    return false;
  }

  private boolean _jspx_meth_html_005fradio_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:radio
    org.apache.struts.taglib.html.RadioTag _jspx_th_html_005fradio_005f0 = (org.apache.struts.taglib.html.RadioTag) _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty.get(org.apache.struts.taglib.html.RadioTag.class);
    _jspx_th_html_005fradio_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fradio_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(268,32) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f0.setProperty("gender");
    // /signup.jsp(268,32) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f0.setStyleId("gender");
    // /signup.jsp(268,32) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f0.setValue("male");
    // /signup.jsp(268,32) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f0.setStyleClass("validate[required] styled");
    int _jspx_eval_html_005fradio_005f0 = _jspx_th_html_005fradio_005f0.doStartTag();
    if (_jspx_eval_html_005fradio_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_html_005fradio_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_html_005fradio_005f0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_html_005fradio_005f0.doInitBody();
      }
      do {
        out.write("Male");
        int evalDoAfterBody = _jspx_th_html_005fradio_005f0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_html_005fradio_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_html_005fradio_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty.reuse(_jspx_th_html_005fradio_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty.reuse(_jspx_th_html_005fradio_005f0);
    return false;
  }

  private boolean _jspx_meth_html_005fradio_005f1(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:radio
    org.apache.struts.taglib.html.RadioTag _jspx_th_html_005fradio_005f1 = (org.apache.struts.taglib.html.RadioTag) _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty.get(org.apache.struts.taglib.html.RadioTag.class);
    _jspx_th_html_005fradio_005f1.setPageContext(_jspx_page_context);
    _jspx_th_html_005fradio_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(269,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f1.setProperty("gender");
    // /signup.jsp(269,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f1.setStyleId("gender");
    // /signup.jsp(269,28) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f1.setValue("female");
    // /signup.jsp(269,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fradio_005f1.setStyleClass("validate[required] styled");
    int _jspx_eval_html_005fradio_005f1 = _jspx_th_html_005fradio_005f1.doStartTag();
    if (_jspx_eval_html_005fradio_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_html_005fradio_005f1 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_html_005fradio_005f1.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_html_005fradio_005f1.doInitBody();
      }
      do {
        out.write("Female");
        int evalDoAfterBody = _jspx_th_html_005fradio_005f1.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_html_005fradio_005f1 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_html_005fradio_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty.reuse(_jspx_th_html_005fradio_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fradio_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty.reuse(_jspx_th_html_005fradio_005f1);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f3(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f3 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f3.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f3.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(272,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setProperty("gender");
    // /signup.jsp(272,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setValue("");
    // /signup.jsp(272,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setStyleId("gender");
    // /signup.jsp(272,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setStyleClass("validate[required]");
    int _jspx_eval_html_005ftext_005f3 = _jspx_th_html_005ftext_005f3.doStartTag();
    if (_jspx_th_html_005ftext_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f3);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f3);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f4(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f4 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f4.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f4.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(282,24) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setProperty("locCountry");
    // /signup.jsp(282,24) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setValue("<%%>");
    // /signup.jsp(282,24) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setStyleId("country");
    // /signup.jsp(282,24) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setStyleClass("validate[required,custom[onlyLetter]]");
    int _jspx_eval_html_005ftext_005f4 = _jspx_th_html_005ftext_005f4.doStartTag();
    if (_jspx_th_html_005ftext_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f4);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f4);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f5(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f5 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f5.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f5.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(285,24) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f5.setProperty("locState");
    // /signup.jsp(285,24) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f5.setValue("<% %>");
    // /signup.jsp(285,24) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f5.setStyleId("state");
    // /signup.jsp(285,24) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f5.setStyleClass("validate[required,custom[onlyLetter]]");
    int _jspx_eval_html_005ftext_005f5 = _jspx_th_html_005ftext_005f5.doStartTag();
    if (_jspx_th_html_005ftext_005f5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f5);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f5);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f6(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f6 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fstyle_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f6.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f6.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(288,24) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f6.setProperty("locStreet");
    // /signup.jsp(288,24) name = style type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f6.setStyle("width:450");
    // /signup.jsp(288,24) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f6.setStyleId("street");
    // /signup.jsp(288,24) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f6.setStyleClass("validate[required,length[0,50]] text-input");
    int _jspx_eval_html_005ftext_005f6 = _jspx_th_html_005ftext_005f6.doStartTag();
    if (_jspx_th_html_005ftext_005f6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fstyle_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f6);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fstyle_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f6);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f7(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f7 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f7.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f7.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(293,25) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f7.setProperty("locCity");
    // /signup.jsp(293,25) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f7.setValue("");
    // /signup.jsp(293,25) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f7.setStyleId("city");
    // /signup.jsp(293,25) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f7.setStyleClass("validate[required]");
    // /signup.jsp(293,25) name = onblur type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f7.setOnblur("setCurrentLocation(this.value);");
    int _jspx_eval_html_005ftext_005f7 = _jspx_th_html_005ftext_005f7.doStartTag();
    if (_jspx_th_html_005ftext_005f7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody.reuse(_jspx_th_html_005ftext_005f7);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fproperty_005fonblur_005fnobody.reuse(_jspx_th_html_005ftext_005f7);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f9(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f9 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f9.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f9.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(300,24) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f9.setProperty("locPin");
    // /signup.jsp(300,24) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f9.setStyleId("pincode");
    // /signup.jsp(300,24) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f9.setStyleClass("validate[required] text-input");
    int _jspx_eval_html_005ftext_005f9 = _jspx_th_html_005ftext_005f9.doStartTag();
    if (_jspx_th_html_005ftext_005f9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f9);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f9);
    return false;
  }

  private boolean _jspx_meth_html_005fhidden_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:hidden
    org.apache.struts.taglib.html.HiddenTag _jspx_th_html_005fhidden_005f0 = (org.apache.struts.taglib.html.HiddenTag) _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody.get(org.apache.struts.taglib.html.HiddenTag.class);
    _jspx_th_html_005fhidden_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fhidden_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(302,21) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fhidden_005f0.setProperty("locLat");
    // /signup.jsp(302,21) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fhidden_005f0.setStyleId("destinationLatitude");
    int _jspx_eval_html_005fhidden_005f0 = _jspx_th_html_005fhidden_005f0.doStartTag();
    if (_jspx_th_html_005fhidden_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody.reuse(_jspx_th_html_005fhidden_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody.reuse(_jspx_th_html_005fhidden_005f0);
    return false;
  }

  private boolean _jspx_meth_html_005fhidden_005f1(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:hidden
    org.apache.struts.taglib.html.HiddenTag _jspx_th_html_005fhidden_005f1 = (org.apache.struts.taglib.html.HiddenTag) _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody.get(org.apache.struts.taglib.html.HiddenTag.class);
    _jspx_th_html_005fhidden_005f1.setPageContext(_jspx_page_context);
    _jspx_th_html_005fhidden_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(303,22) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fhidden_005f1.setProperty("locLang");
    // /signup.jsp(303,22) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fhidden_005f1.setStyleId("destinationLongitude");
    int _jspx_eval_html_005fhidden_005f1 = _jspx_th_html_005fhidden_005f1.doStartTag();
    if (_jspx_th_html_005fhidden_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody.reuse(_jspx_th_html_005fhidden_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fhidden_0026_005fstyleId_005fproperty_005fnobody.reuse(_jspx_th_html_005fhidden_005f1);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f0 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleId_005fstyleClass_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /signup.jsp(316,20) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setStyleClass("buttonorg");
    // /signup.jsp(316,20) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setStyleId("createaccount");
    // /signup.jsp(316,20) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setValue("Create Account");
    int _jspx_eval_html_005fsubmit_005f0 = _jspx_th_html_005fsubmit_005f0.doStartTag();
    if (_jspx_th_html_005fsubmit_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleId_005fstyleClass_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleId_005fstyleClass_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
    return false;
  }
}
