package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.text.SimpleDateFormat;
import com.verve.meetin.interest.*;
import java.util.*;

public final class postlogin_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

 List<String> userinfo = new ArrayList<String>();
  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005fenctype_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyle_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fvalue_005fstyleId_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fstyle_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fselect_0026_005fstyleId_005fstyle_005fproperty_005fmultiple;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005foption_0026_005fvalue;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005fenctype_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyle_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fvalue_005fstyleId_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fstyle_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fselect_0026_005fstyleId_005fstyle_005fproperty_005fmultiple = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005foption_0026_005fvalue = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005fenctype_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyle_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fvalue_005fstyleId_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fstyle_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fselect_0026_005fstyleId_005fstyle_005fproperty_005fmultiple.release();
    _005fjspx_005ftagPool_005fhtml_005foption_0026_005fvalue.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write(" <!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write('\n');
      out.write('\n');
 System.out.println("/postlogin.jsp"); 
      out.write("\n");
      out.write("<html>\n");
      out.write("<head>\n");
      out.write("<title>meetIn Postlogin Page</title>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
      out.write("<meta http-equiv=\"Pragma\" content=\"no-cache\" />\n");
      out.write("<script type=\"text/javascript\" src=\"js/meetin.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/ajaxupload.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/profile.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write("\n");
      out.write("  \t<script src=\"js/cropper.js\" type=\"text/javascript\"></script>\n");
      out.write("  \t<script src=\"js/CropImage.js\" type=\"text/javascript\"></script>\n");
      out.write("  \t<link rel=\"stylesheet\" type=\"text/css\" href=\"css/ImageCrop.css\" />\n");
      out.write("<!---------------------Google analytics code Start------------------------------->\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("  var _gaq = _gaq || [];\n");
      out.write("  _gaq.push(['_setAccount', 'UA-9594176-11']);\n");
      out.write("  _gaq.push(['_trackPageview']);\n");
      out.write("\n");
      out.write("  (function() {\n");
      out.write("    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;\n");
      out.write("    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';\n");
      out.write("    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);\n");
      out.write("  })();\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("</head>\n");
      out.write("<!---------------------Google analytics code End ------------------------------->\n");
      out.write("\n");
      out.write("</head>\n");
      out.write("<body >\t\n");
      out.write("\t\t\n");
      out.write("\t\t\n");
      out.write("\t\t\n");
      out.write("           <div style=\"overflow:hidden; height:auto\">\n");
      out.write("                <div class=\"innercontainer\">\n");
      out.write("                <div class=\"heading\" style=\"overflow:hidden;\">\n");
      out.write("                <div style=\"float: left;\">\n");
      out.write("                    \t<img src=\"images/aboutme_icon.png\" align=\"bottom\"/> About Me\n");
      out.write("                    \t</div>\n");
      out.write("                    \t");

                    	if(request.getParameter("ref") !=null && request.getParameter("ref").equals("profile"))
                    	{
                    	
      out.write("\n");
      out.write("                    \t\t<div class=\"username\" style=\"float: right; font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\"><img align=\"absmiddle\" onclick=\"changePasswordView();\" title=\"Change Password\" src=\"images/change_password.png\" style=\"padding-right:5px;\"><a href=\"javascript:changePasswordView()\" title=\"Change Password\">Change Password</a> </div> \n");
      out.write("                    \t");

                    	}
                    	 
      out.write("\n");
      out.write("                    </div>\n");
      out.write("                      ");

                         if(session.getAttribute("UserProfileSaved") !=null)
                         {  
                      
      out.write("\n");
      out.write("                       <!--  This is a div tag for indicate that user has updated profile successfully -->\n");
      out.write("                   \t\t <!--<div class=\"error\"> \n");
      out.write("                    \t\t<img src=\"images/success_icon.png\" align=\"absmiddle\"/> Profile details updated successfully \n");
      out.write("                    \t </div>  \n");
      out.write("                      -->");

                       // Removing the session object value
 					    	session.removeAttribute("UserProfileSaved");
                         }
                      
      out.write("\n");
      out.write("                      \n");
      out.write("                   <!--    ");
      //  html:form
      org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f0 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005faction.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_005fform_005f0.setPageContext(_jspx_page_context);
      _jspx_th_html_005fform_005f0.setParent(null);
      // /postlogin.jsp(77,27) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setAction("/imagepreview");
      // /postlogin.jsp(77,27) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setStyleId("imageForm");
      int _jspx_eval_html_005fform_005f0 = _jspx_th_html_005fform_005f0.doStartTag();
      if (_jspx_eval_html_005fform_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\n");
          out.write("                               <input type=\"hidden\" value=\"imagepreview\" name=\"action\"/>\n");
          out.write("                       -->\n");
          out.write("                      <div class=\"postlogin generalfrm\">\n");
          out.write("                        ");

                        	String imagePath ="";
                        	if(request.getAttribute("userinfo") != null)
                        	{
                        		userinfo = (List<String>)request.getAttribute("userinfo");
                        	}
                         
          out.write("\n");
          out.write("                            <div class=\"lable\">Profile Picture</div>\n");
          out.write("                            ");

                            String path = request.getContextPath();
							String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";
		
		
							if(session.getAttribute("image") == null)
							{				
									
								if(userinfo.get(0) == null || userinfo.get(0).equals(""))
								{
                               		if(userinfo.get(12).toString().toLowerCase().equals("male"))
                            	   		imagePath = "images/male.png";
                            	   	else
                            	   	 	imagePath = "images/female.png";
								}
								else
								{
									imagePath = basePath + "profileimage/" + userinfo.get(0).toString();
									System.out.println("else case "+imagePath);	
	  								//imagePath = basePath + "profileimage/" + (Integer)session.getAttribute("UserID") + "_" + userinfo.get(0).toString();
	  							}
	  						}
	  						else
	  						{
	  								System.out.println("else case ");	  	
	  								imagePath = basePath +"profileimage1/" + session.getAttribute("image").toString();
	  								//session.removeAttribute("image")	;			
	  								System.out.println("image path "+ imagePath);
	  								
	  						}
	  							
	  					
                            //if(userinfo.get(0).toString().equals("")) 
                            if(session.getAttribute("image") == null)
                            {
                          				if(userinfo.get(0) == null || userinfo.get(0).equals(""))
                          				{
                          	
          out.write("\t\t\t\n");
          out.write("                          \t          \t<div id=\"UPLOAD\" style=\"float:left; width: 100px;\" align=\"left\"><img src=\"images/male.png\" /></div>\n");
          out.write("                            ");
			}
                            			else
                            			{
                            
          out.write("\t\t\t\n");
          out.write("                            \t\t\t<div id=\"UPLOAD\" style=\"float:left; width: 120px;\" align=\"left\"><img src=\"");
          out.print(imagePath);
          out.write("\" height=\"120\" width=\"120\"/> </div>\n");
          out.write("                            ");
			
                            			}
                            }
                            else{ 
          out.write("\n");
          out.write("                            <div id=\"UPLOAD\" style=\"float:left; width: 120px;\" align=\"left\"><img src=\"");
          out.print(imagePath);
          out.write("\" height=\"120\" width=\"120\"/> </div>\n");
          out.write("\t                        ");
}
          out.write("\n");
          out.write("                            \n");
          out.write("                            <!-- styleClass=\"file\" -->\n");
          out.write("                \n");
          out.write("                \t\t<input type=\"hidden\" id=\"userid\" value=\"");
          out.print(session.getAttribute("UserID").toString());
          out.write("\"/>    \n");
          out.write("\t\t\t\t\n");
          out.write("\t\t\t\t\n");
          out.write("\t\t\t\t\t\t<div style=\"float:left\">\n");
          out.write("                 \t\t\t<input type=\"hidden\" id=\"imagepath\" value=\"");
          out.print(imagePath);
          out.write("\"/>\t \n");
          out.write("\n");
          out.write("\t\t\t<a href=\"#\" onclick=\"imagePage()\" style=\"padding-left: 30px;\">Click to upload the image</a>\n");
          out.write("\n");
          out.write("\t             <!--        <input type=\"button\" class=\"browsebutton\" onclick=\"\" />      -->  \n");
          out.write("                         </div>\n");
          out.write("                    \n");
          out.write("                    <!-- changes done  -->\n");
          out.write("                    \n");
          out.write("                    \n");
          out.write("                       </div>\n");
          out.write("                    <!--   ");
          int evalDoAfterBody = _jspx_th_html_005fform_005f0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_005fform_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005faction.reuse(_jspx_th_html_005fform_005f0);
        return;
      }
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005faction.reuse(_jspx_th_html_005fform_005f0);
      out.write("  -->\n");
      out.write("                      ");
      //  html:form
      org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f1 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005fenctype_005faction.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_005fform_005f1.setPageContext(_jspx_page_context);
      _jspx_th_html_005fform_005f1.setParent(null);
      // /postlogin.jsp(158,22) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f1.setAction("/postlogin");
      // /postlogin.jsp(158,22) name = method type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f1.setMethod("post");
      // /postlogin.jsp(158,22) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f1.setStyleId("frmpostlogin");
      // /postlogin.jsp(158,22) name = enctype type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f1.setEnctype("multipart/form-data");
      // /postlogin.jsp(158,22) name = onsubmit type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f1.setOnsubmit("return validate_Fullname()");
      int _jspx_eval_html_005fform_005f1 = _jspx_th_html_005fform_005f1.doStartTag();
      if (_jspx_eval_html_005fform_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\n");
          out.write("                      <input type=\"hidden\" value=\"postlogin\" name=\"action\"/>\n");
          out.write("                      <div class=\"postloginprofile generalfrm\" style=\"margin-top: -25px; border-top: 0px;\">\n");
          out.write("                      <div style=\"text-align:center; color:black;margin-top: 10px;\">Upload image of 120 x 120 pixel size for best result</div>\n");
          out.write("                      <div class=\"frmline\"></div>\n");
          out.write("                      ");

                        	if(request.getAttribute("userinfo") != null)
                        	{
                        		userinfo = (List<String>)request.getAttribute("userinfo");
        
                        	}
        
                      
          out.write("\n");
          out.write("                            \n");
          out.write("                            \n");
          out.write("                            ");

                            	String imagevalue ="";
                            	if(session.getAttribute("image") == null)
                            	{
                            		imagevalue = userinfo.get(0).toString();
                            	
                            	}
                            	else
                            	{
                            		imagevalue = session.getAttribute("image").toString();
                            
                            	}
                            
                             
          out.write("\n");
          out.write("                            \n");
          out.write("                            \n");
          out.write("                            \n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f0 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyle_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f0.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(190,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setProperty("image");
          // /postlogin.jsp(190,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setValue(imagevalue);
          // /postlogin.jsp(190,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setStyleId("image");
          // /postlogin.jsp(190,28) name = style type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f0.setStyle("display:none;");
          int _jspx_eval_html_005ftext_005f0 = _jspx_th_html_005ftext_005f0.doStartTag();
          if (_jspx_th_html_005ftext_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyle_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyle_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
          out.write("\n");
          out.write("                            ");
	
	                          if(request.getParameter("ref") !=null && request.getParameter("ref").equals("profile"))
	                    	  {
                    		
          out.write("\n");
          out.write("                            <div class=\"lable\">Full Name</div>\n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f1 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f1.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(196,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setProperty("fullname");
          // /postlogin.jsp(196,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setValue(userinfo.get(10).toString() );
          // /postlogin.jsp(196,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setSize("50");
          // /postlogin.jsp(196,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setMaxlength("50");
          // /postlogin.jsp(196,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setStyleId("fullname");
          // /postlogin.jsp(196,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setStyleClass("validate[required,custom[noSpecialCaractersAndNumbers]] text-input");
          int _jspx_eval_html_005ftext_005f1 = _jspx_th_html_005ftext_005f1.doStartTag();
          if (_jspx_th_html_005ftext_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f1);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f1);
          out.write("\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">User Name</div>\n");
          out.write("                            \n");
          out.write("                            ");

                            
                            System.out.println(userinfo.get(13).toString());
                            System.out.println(userinfo.get(13).toString());
                            System.out.println(userinfo.get(13).toString());
                            if(userinfo.get(13) == null || userinfo.get(13).equals(""))
                            {
                             
          out.write("\n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f2 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f2.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(208,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setProperty("username");
          // /postlogin.jsp(208,28) name = onblur type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setOnblur("userNameAvailabilityCheck();");
          // /postlogin.jsp(208,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setValue(userinfo.get(10).toString() );
          // /postlogin.jsp(208,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setSize("50");
          // /postlogin.jsp(208,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setMaxlength("50");
          // /postlogin.jsp(208,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setStyleId("username");
          // /postlogin.jsp(208,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setStyleClass("validate[required,custom[alphanum]] text-input");
          int _jspx_eval_html_005ftext_005f2 = _jspx_th_html_005ftext_005f2.doStartTag();
          if (_jspx_th_html_005ftext_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f2);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f2);
          out.write("\n");
          out.write("                            ");

                            }
                            else
                            {
                             
          out.write("\n");
          out.write("                           ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f3 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f3.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f3.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(214,27) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f3.setProperty("username");
          // /postlogin.jsp(214,27) name = onblur type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f3.setOnblur("userNameAvailabilityCheck();");
          // /postlogin.jsp(214,27) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f3.setValue(userinfo.get(13).toString() );
          // /postlogin.jsp(214,27) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f3.setSize("50");
          // /postlogin.jsp(214,27) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f3.setMaxlength("50");
          // /postlogin.jsp(214,27) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f3.setStyleId("username");
          // /postlogin.jsp(214,27) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f3.setStyleClass("validate[required,custom[alphanum]] text-input");
          int _jspx_eval_html_005ftext_005f3 = _jspx_th_html_005ftext_005f3.doStartTag();
          if (_jspx_th_html_005ftext_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f3);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005fproperty_005fonblur_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f3);
          out.write(" \n");
          out.write("                            \n");
          out.write("                            \n");
          out.write("                            ");
} 
          out.write("\n");
          out.write("                            \n");
          out.write("                            <div id=\"email_available_msg\" style=\"position:absolute; margin-top:-60px; margin-left:400px; display: none\"><img src=\"images/already-exists.png\" style=\"border:none\"/></div>\n");
          out.write("                            <div style=\"margin-left: 10px; color:black;float: left;\"><i>Shall be used in making profile public.</i></div>\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Birth date</div>\n");
          out.write("                            ");

                            	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                            	SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
                            	String birthdate = sdf1.format(sdf.parse(userinfo.get(11).toString()));
                            
          out.write("\n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f4 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f4.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f4.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(228,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f4.setProperty("birthdate");
          // /postlogin.jsp(228,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f4.setValue(birthdate );
          // /postlogin.jsp(228,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f4.setStyleId("birthdate");
          // /postlogin.jsp(228,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f4.setStyleClass("validate[required]");
          // /postlogin.jsp(228,28) name = readonly type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f4.setReadonly(true);
          int _jspx_eval_html_005ftext_005f4 = _jspx_th_html_005ftext_005f4.doStartTag();
          if (_jspx_th_html_005ftext_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f4);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005freadonly_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f4);
          out.write("\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                             <div class=\"lable\">Gender</div>\n");
          out.write("                            <div style=\"float:left; height:30px; background-color:#bbb; width:1px\">&nbsp;</div>\n");
          out.write("                            ");
 if(userinfo.get(12).toString().trim().toLowerCase().equals("Male".toLowerCase())) {
          out.write("\n");
          out.write("                            <div class=\"gender\">\n");
          out.write("                            <input type=\"radio\" id=\"gender\" name=\"gender\" value=\"male\" class=\"styled\" checked=\"checked\"> Male</input>&nbsp;&nbsp;&nbsp;</div>\n");
          out.write("                            <div class=\"gender\">\n");
          out.write("                            <input type=\"radio\" id=\"gender\" name=\"gender\" value=\"Female\" class=\"styled\">Female</input>\n");
          out.write("                            </div>\n");
          out.write("                            ");
 } else { 
          out.write("\n");
          out.write("                            <div class=\"gender\">\n");
          out.write("                            <input type=\"radio\" id=\"gender\" name=\"gender\" value=\"male\" class=\"styled\" > Male</input>&nbsp;&nbsp;&nbsp;</div>\n");
          out.write("                            <div class=\"gender\">\n");
          out.write("                            <input type=\"radio\" id=\"gender\" name=\"gender\" value=\"Female\" class=\"styled\" checked=\"checked\">Female</input>\n");
          out.write("                            </div>\n");
          out.write("                            ");
}
          out.write("\n");
          out.write("                           <div class=\"frmline\"></div>\n");
          out.write("                           ");
} 
          out.write("\n");
          out.write("                            <div class=\"lable\">About me</div>\n");
          out.write("                            <!--<textarea name=\"aboutme\"></textarea>\n");
          out.write("                            -->\n");
          out.write("                            ");
          //  html:textarea
          org.apache.struts.taglib.html.TextareaTag _jspx_th_html_005ftextarea_005f0 = (org.apache.struts.taglib.html.TextareaTag) _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fvalue_005fstyleId_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextareaTag.class);
          _jspx_th_html_005ftextarea_005f0.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftextarea_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(250,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftextarea_005f0.setProperty("aboutMe");
          // /postlogin.jsp(250,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftextarea_005f0.setValue(userinfo.get(1).toString() );
          // /postlogin.jsp(250,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftextarea_005f0.setStyleId("aboutMe");
          int _jspx_eval_html_005ftextarea_005f0 = _jspx_th_html_005ftextarea_005f0.doStartTag();
          if (_jspx_th_html_005ftextarea_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fvalue_005fstyleId_005fproperty_005fnobody.reuse(_jspx_th_html_005ftextarea_005f0);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fvalue_005fstyleId_005fproperty_005fnobody.reuse(_jspx_th_html_005ftextarea_005f0);
          out.write("\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Company</div>\n");
          out.write("                            <!--<input type=\"text\" value=\"\" name=\"company\"/>-->\n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f5 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f5.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f5.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(254,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f5.setProperty("company");
          // /postlogin.jsp(254,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f5.setValue(userinfo.get(2).toString());
          // /postlogin.jsp(254,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f5.setSize("50");
          // /postlogin.jsp(254,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f5.setMaxlength("50");
          // /postlogin.jsp(254,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f5.setStyleId("company");
          int _jspx_eval_html_005ftext_005f5 = _jspx_th_html_005ftext_005f5.doStartTag();
          if (_jspx_th_html_005ftext_005f5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f5);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f5);
          out.write("\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Position</div>\n");
          out.write("                            <!--<input type=\"text\" value=\"\" name=\"jobtitle\"/>-->\n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f6 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f6.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f6.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(258,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f6.setProperty("jobTitle");
          // /postlogin.jsp(258,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f6.setValue(userinfo.get(4).toString());
          // /postlogin.jsp(258,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f6.setSize("30");
          // /postlogin.jsp(258,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f6.setMaxlength("30");
          // /postlogin.jsp(258,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f6.setStyleId("jobTitle");
          int _jspx_eval_html_005ftext_005f6 = _jspx_th_html_005ftext_005f6.doStartTag();
          if (_jspx_th_html_005ftext_005f6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f6);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f6);
          out.write("\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Industry</div>\n");
          out.write("                            <!--<input type=\"text\" value=\"\" name=\"industry\"/>-->\n");
          out.write("                            ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f7 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f7.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f7.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(262,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f7.setProperty("industry");
          // /postlogin.jsp(262,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f7.setValue(userinfo.get(6).toString() );
          // /postlogin.jsp(262,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f7.setSize("30");
          // /postlogin.jsp(262,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f7.setMaxlength("30");
          // /postlogin.jsp(262,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f7.setStyleId("industry");
          int _jspx_eval_html_005ftext_005f7 = _jspx_th_html_005ftext_005f7.doStartTag();
          if (_jspx_th_html_005ftext_005f7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f7);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f7);
          out.write("  \n");
          out.write("                           \t<div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Degree/College</div>\n");
          out.write("                            <!--<input type=\"text\" value=\"\" name=\"degreeCollege\"/>-->\n");
          out.write("                          \t");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f8 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f8.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f8.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(266,27) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setProperty("degreeCollege");
          // /postlogin.jsp(266,27) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setValue(userinfo.get(7).toString());
          // /postlogin.jsp(266,27) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setSize("50");
          // /postlogin.jsp(266,27) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setMaxlength("50");
          // /postlogin.jsp(266,27) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f8.setStyleId("degreeCollege");
          int _jspx_eval_html_005ftext_005f8 = _jspx_th_html_005ftext_005f8.doStartTag();
          if (_jspx_th_html_005ftext_005f8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f8);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f8);
          out.write(" \n");
          out.write("                           \t<!--<div class=\"frmline\"></div>\n");
          out.write("                        \t<div class=\"lable\">Other Specify</div>\n");
          out.write("                        \t<input type=\"text\" value=\"\" name=\"otherspecify\" />\n");
          out.write("                        \t");
          if (_jspx_meth_html_005ftext_005f9(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write("-->\n");
          out.write("                        \t</div>\n");
          out.write("                        ");
	
                          if(request.getParameter("ref") !=null && request.getParameter("ref").equals("profile"))
                    	  {
                    	   // If the condition is true only show the content require to display for user profile from My Profile Menu
                    	
          out.write("\n");
          out.write("                    \t<div class=\"logonsection\">\n");
          out.write("                       \t \t<input type=\"hidden\" name=\"fromprofile\" value=\"profilereference\"/><!--\n");
          out.write("                       \t    ");
          if (_jspx_meth_html_005fsubmit_005f0(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                       \t    -->");
          if (_jspx_meth_html_005fsubmit_005f1(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                       \t       ");
          if (_jspx_meth_html_005fsubmit_005f2(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write(" \n");
          out.write("                       \t     <!--");
          if (_jspx_meth_html_005fform_005f2(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                       \t    ");
          if (_jspx_meth_html_005fsubmit_005f4(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                       --></div>\n");
          out.write("                    \t");

                    	}
                    	else
                    	{
                    	   // If the condition is false show the content require to display for as a part of post login process
                    	 
          out.write("\n");
          out.write("                    <div class=\"heading\" style=\"margin-top:30px;\">\n");
          out.write("                    \t<img src=\"images/interest_icon.png\" align=\"bottom\"/> Choose your area of Interests\n");
          out.write("                    </div>\n");
          out.write("                <p align=\"right\" style=\"font-size:12px; text-align:right; margin-bottom:-10px; margin-top:20px;\">Press Control key to select multiple interests.</p>\n");
          out.write("                    <div class=\"generalfrm\">\n");
          out.write("                        <div class=\"lable\">Interests area</div>\n");
          out.write("                        ");
          //  html:select
          org.apache.struts.taglib.html.SelectTag _jspx_th_html_005fselect_005f0 = (org.apache.struts.taglib.html.SelectTag) _005fjspx_005ftagPool_005fhtml_005fselect_0026_005fstyleId_005fstyle_005fproperty_005fmultiple.get(org.apache.struts.taglib.html.SelectTag.class);
          _jspx_th_html_005fselect_005f0.setPageContext(_jspx_page_context);
          _jspx_th_html_005fselect_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
          // /postlogin.jsp(300,24) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005fselect_005f0.setStyleId("interest");
          // /postlogin.jsp(300,24) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005fselect_005f0.setProperty("interest");
          // /postlogin.jsp(300,24) name = multiple type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005fselect_005f0.setMultiple("multiple");
          // /postlogin.jsp(300,24) name = style type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005fselect_005f0.setStyle("height:93px");
          int _jspx_eval_html_005fselect_005f0 = _jspx_th_html_005fselect_005f0.doStartTag();
          if (_jspx_eval_html_005fselect_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            if (_jspx_eval_html_005fselect_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
              out = _jspx_page_context.pushBody();
              _jspx_th_html_005fselect_005f0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
              _jspx_th_html_005fselect_005f0.doInitBody();
            }
            do {
              out.write("\n");
              out.write("                        ");

                             List interestList = new ArrayList();
                             interestList = new InterestDAO().getInterest();
                             if(interestList !=null && interestList.size() >0){
                             for(int i=0; i < interestList.size(); i++){
                             Interestmaster interest = new Interestmaster();
                             interest = (Interestmaster)interestList.get(i);
                         
              out.write("\n");
              out.write("                        ");
              //  html:option
              org.apache.struts.taglib.html.OptionTag _jspx_th_html_005foption_005f0 = (org.apache.struts.taglib.html.OptionTag) _005fjspx_005ftagPool_005fhtml_005foption_0026_005fvalue.get(org.apache.struts.taglib.html.OptionTag.class);
              _jspx_th_html_005foption_005f0.setPageContext(_jspx_page_context);
              _jspx_th_html_005foption_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fselect_005f0);
              // /postlogin.jsp(309,24) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
              _jspx_th_html_005foption_005f0.setValue( Integer.toString(interest.getInterestId()));
              int _jspx_eval_html_005foption_005f0 = _jspx_th_html_005foption_005f0.doStartTag();
              if (_jspx_eval_html_005foption_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                if (_jspx_eval_html_005foption_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.pushBody();
                  _jspx_th_html_005foption_005f0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
                  _jspx_th_html_005foption_005f0.doInitBody();
                }
                do {
                  out.print(interest.getName());
                  int evalDoAfterBody = _jspx_th_html_005foption_005f0.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
                if (_jspx_eval_html_005foption_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
                  out = _jspx_page_context.popBody();
                }
              }
              if (_jspx_th_html_005foption_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                _005fjspx_005ftagPool_005fhtml_005foption_0026_005fvalue.reuse(_jspx_th_html_005foption_005f0);
                return;
              }
              _005fjspx_005ftagPool_005fhtml_005foption_0026_005fvalue.reuse(_jspx_th_html_005foption_005f0);
              out.write("\n");
              out.write("                        ");

                        	}
                        }
                        
              out.write("\n");
              out.write("\t\t\t\t\t\t");
              int evalDoAfterBody = _jspx_th_html_005fselect_005f0.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
            if (_jspx_eval_html_005fselect_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
              out = _jspx_page_context.popBody();
            }
          }
          if (_jspx_th_html_005fselect_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005fselect_0026_005fstyleId_005fstyle_005fproperty_005fmultiple.reuse(_jspx_th_html_005fselect_005f0);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005fselect_0026_005fstyleId_005fstyle_005fproperty_005fmultiple.reuse(_jspx_th_html_005fselect_005f0);
          out.write("<!--\n");
          out.write("                        <div class=\"frmline\"></div>\n");
          out.write("                        <div class=\"lable\">Other Specify</div>\n");
          out.write("                        <input type=\"text\" value=\"\" name=\"otherspecify\" />\n");
          out.write("                        ");
          if (_jspx_meth_html_005ftext_005f10(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                    \t--></div>\n");
          out.write("                    \t<div class=\"sectionbottom\"></div>\n");
          out.write("                       <div class=\"logonsection\">\n");
          out.write("                       \t    ");
          if (_jspx_meth_html_005fsubmit_005f5(_jspx_th_html_005fform_005f1, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                       </div>\n");
          out.write("                       ");

                       	  }
                       
          out.write("\n");
          out.write("                   ");
          int evalDoAfterBody = _jspx_th_html_005fform_005f1.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_005fform_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005fenctype_005faction.reuse(_jspx_th_html_005fform_005f1);
        return;
      }
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fonsubmit_005fmethod_005fenctype_005faction.reuse(_jspx_th_html_005fform_005f1);
      out.write("\n");
      out.write("                </div> \n");
      out.write("            </div> \n");
      out.write("     <!--   </div>\n");
      out.write("     </div>mainsite starts here -->\n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("    <!--<div class=\"footer\">\n");
      out.write("    \n");
      out.write("    \t\t\t<p><a href=\"index.html\">Home</a>|\n");
      out.write("        \t\t<a href=\"mediainquiry.html\">How It Works</a>|\n");
      out.write("            <a href=\"features.html\">Features</a>|\n");
      out.write("            <a href=\"review.html\">Review</a>|\n");
      out.write("            <a href=\"contact.html\">ContactUs</a>\n");
      out.write("        </p>\n");
      out.write("        <p>&nbsp;</p>\n");
      out.write("    \t<p>meetIn is an application of <a href=\"http://www.offshoremobiledevelopment.com\"  target=\"_blank\"  class=\"ft_link\">Verve Mobile Labs</a> | iPhone is trademarks of Apple Inc., registered in U.S. and other countries. App Store is a service mark of Apple Inc.</p>\n");
      out.write("        <p class=\"copyright\">Copyright Â@ 2012 meetIn. All rights reserved. </p>\n");
      out.write("    </div>footer ends here \n");
      out.write("</div>-->\n");
      out.write("</body>\n");
      out.write("</html>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_html_005ftext_005f9(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f9 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f9.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f9.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(270,25) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f9.setProperty("otherSpecify");
    // /postlogin.jsp(270,25) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f9.setValue("");
    int _jspx_eval_html_005ftext_005f9 = _jspx_th_html_005ftext_005f9.doStartTag();
    if (_jspx_th_html_005ftext_005f9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f9);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f9);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f0 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fstyle_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(279,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setStyleClass("buttonorgsmall");
    // /postlogin.jsp(279,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setValue("Save");
    // /postlogin.jsp(279,28) name = style type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setStyle("margin-left:-10px;");
    int _jspx_eval_html_005fsubmit_005f0 = _jspx_th_html_005fsubmit_005f0.doStartTag();
    if (_jspx_th_html_005fsubmit_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fstyle_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fstyle_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f1(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f1 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f1.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(280,31) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f1.setStyleClass("buttonorgsmall");
    // /postlogin.jsp(280,31) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f1.setValue("Save");
    // /postlogin.jsp(280,31) name = onclick type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f1.setOnclick("javascript:submitAboutme();");
    int _jspx_eval_html_005fsubmit_005f1 = _jspx_th_html_005fsubmit_005f1.doStartTag();
    if (_jspx_th_html_005fsubmit_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f1);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f2(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f2 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f2.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(281,31) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f2.setStyleClass("buttonorgsmall");
    // /postlogin.jsp(281,31) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f2.setValue("Next");
    // /postlogin.jsp(281,31) name = onclick type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f2.setOnclick("locationPage();");
    int _jspx_eval_html_005fsubmit_005f2 = _jspx_th_html_005fsubmit_005f2.doStartTag();
    if (_jspx_th_html_005fsubmit_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f2);
    return false;
  }

  private boolean _jspx_meth_html_005fform_005f2(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:form
    org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f2 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.get(org.apache.struts.taglib.html.FormTag.class);
    _jspx_th_html_005fform_005f2.setPageContext(_jspx_page_context);
    _jspx_th_html_005fform_005f2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(282,33) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fform_005f2.setAction("/locationEdit");
    // /postlogin.jsp(282,33) name = method type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fform_005f2.setMethod("post");
    // /postlogin.jsp(282,33) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fform_005f2.setStyleId("frmregister");
    int _jspx_eval_html_005fform_005f2 = _jspx_th_html_005fform_005f2.doStartTag();
    if (_jspx_eval_html_005fform_005f2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\n");
        out.write("                      \t\t\t<input type=\"hidden\" name=\"action\" value=\"location_edit\"/>\n");
        out.write("                            \t ");
        if (_jspx_meth_html_005fsubmit_005f3(_jspx_th_html_005fform_005f2, _jspx_page_context))
          return true;
        out.write("\n");
        out.write("                            ");
        int evalDoAfterBody = _jspx_th_html_005fform_005f2.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_html_005fform_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f2);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f3(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f2, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f3 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f3.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f3.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f2);
    // /postlogin.jsp(284,30) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f3.setStyleClass("buttonorgsmall");
    // /postlogin.jsp(284,30) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f3.setValue("Next");
    int _jspx_eval_html_005fsubmit_005f3 = _jspx_th_html_005fsubmit_005f3.doStartTag();
    if (_jspx_th_html_005fsubmit_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody.reuse(_jspx_th_html_005fsubmit_005f3);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody.reuse(_jspx_th_html_005fsubmit_005f3);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f4(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f4 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f4.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f4.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(286,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f4.setStyleClass("buttonorgsmall");
    // /postlogin.jsp(286,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f4.setValue("Next");
    // /postlogin.jsp(286,28) name = onclick type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f4.setOnclick("javascript:getPage('location_edit');");
    int _jspx_eval_html_005fsubmit_005f4 = _jspx_th_html_005fsubmit_005f4.doStartTag();
    if (_jspx_th_html_005fsubmit_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f4);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f4);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f10(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f10 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f10.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f10.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(318,24) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f10.setProperty("otherSpecify");
    // /postlogin.jsp(318,24) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f10.setValue("");
    int _jspx_eval_html_005ftext_005f10 = _jspx_th_html_005ftext_005f10.doStartTag();
    if (_jspx_th_html_005ftext_005f10.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f10);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fproperty_005fnobody.reuse(_jspx_th_html_005ftext_005f10);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f5(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f1, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f5 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f5.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f5.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f1);
    // /postlogin.jsp(322,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f5.setStyleClass("buttonorgsmall");
    // /postlogin.jsp(322,28) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f5.setValue("Continue");
    int _jspx_eval_html_005fsubmit_005f5 = _jspx_th_html_005fsubmit_005f5.doStartTag();
    if (_jspx_th_html_005fsubmit_005f5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody.reuse(_jspx_th_html_005fsubmit_005f5);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fnobody.reuse(_jspx_th_html_005fsubmit_005f5);
    return false;
  }
}
