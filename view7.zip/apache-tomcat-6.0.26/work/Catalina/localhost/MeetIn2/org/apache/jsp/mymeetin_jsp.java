package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.verve.meetin.user.*;

public final class mymeetin_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

 String   email=""; 
  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.release();
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");

	System.out.println("mymeetin");
	 String path = request.getContextPath();
	 String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";
					  String username = request.getParameter("username");
					  String getUrl=request.getQueryString();
					String getString="";
		if(getUrl!=null){
	    for (String retval: getUrl.split("=")){
	       
	       while(retval.equalsIgnoreCase("fwdurl")){
	      	getString=retval;
	       	break;
	       }
	       break;
	    }
    }

					

      out.write("\t\t\t\n");
      out.write("  \n");
      out.write("\n");
      out.write("<html xmlns=\"http://www.w3.org/1999/xhtml\">\n");
      out.write("<head>\n");
      out.write("\n");
      out.write("<!---------------------Google analytics code Start------------------------------->\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("  var _gaq = _gaq || [];\n");
      out.write("  _gaq.push(['_setAccount', 'UA-9594176-7']);\n");
      out.write("  _gaq.push(['_trackPageview']);\n");
      out.write("\n");
      out.write("  (function() {\n");
      out.write("    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;\n");
      out.write("    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';\n");
      out.write("    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);\n");
      out.write("  })();\n");
      out.write("\n");
      out.write("</script>  \n");
      out.write("<!---------------------Google analytics code End ------------------------------->\n");
      out.write("\n");
      out.write("\n");
      out.write("<meta http-equiv='cache-control' content='no-cache'/><meta http-equiv='expires' content='0'/><meta http-equiv='pragma' content='no-cache'/>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.js\">\n");
      out.write("</script>\n");
      out.write("\t\t<script type=\"text/javascript\" src=\"js/imagescroll.js\">\n");
      out.write("</script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/curvycorners.js\">\n");
      out.write("</script>\n");
      out.write("\t\t<script type=\"text/javascript\" src=\"js/custom-form-elements.js\">\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"js/meetin.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/setupnetwork.js\"></script>\n");
      out.write("\n");
      out.write("<meta name=\"description\" content=\"Enter your details and start meeting people from all over the world, Update your location status by using our Travel Plan tracker. Also add your interests and specialty and based on this you can search your contacts with ease.\" />\n");
      out.write("\n");
      out.write("<meta name=\"keywords\" content=\"meetIn login page, find friends near a city, Update your location status, search your contacts\" />\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
if(request.getParameter("username")!=null){
	UserAccountDAO useracc = new UserAccountDAO();
	int id = useracc.getuserId(username);
	User user =(User)new UserAccountDAO().getUserProfileDetails(id);
     if(user !=null)
        {

      out.write("\n");
      out.write("<title>meetIn login page, find friends near a city</title>\n");
} }else 
      out.write("\n");
      out.write("<title>meetIn login page, find friends near a city</title>\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write("<link rel=\"shortcut icon\" href=\"images/meetin_icon.png\" />\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.js\"></script>\n");
if (session.getAttribute("name")==null){ 
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"js/imagescroll.js\"></script>\n");
} 
      out.write("\n");
      out.write("<!-- This is jquery validation engine  -->\n");
      out.write("<link rel=\"stylesheet\" href=\"css/validationEngine.jquery.css\" type=\"text/css\" media=\"screen\" title=\"no title\" charset=\"utf-8\" />\n");
      out.write("<link rel=\"stylesheet\" href=\"css/template.css\" type=\"text/css\" media=\"screen\" title=\"no title\" charset=\"utf-8\" />\n");
      out.write("<script src=\"js/jquery.min.js\" type=\"text/javascript\"></script>\n");
      out.write("<script src=\"js/jquery.validationEngine-en.js\" type=\"text/javascript\"></script>\n");
      out.write("<script src=\"js/jquery.validationEngine.js\" type=\"text/javascript\"></script>\n");
      out.write("\n");
      out.write("<script src=\"js/setupnetwork.js\" type=\"text/javascript\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/custom-form-elements.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write("<script>\n");
      out.write("\tjQuery.noConflict();\n");
      out.write("\t\n");
      out.write("\tjQuery(document).ready(function() {\n");
      out.write("\t   \n");
      out.write("\t\t\t\tjQuery(\"#frmlogin\").validationEngine({inlineValidation: false})\n");
      out.write("\t});\n");
      out.write("</script>\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("// Created by Rupal Kathiriya to set cookie in browser while clicking on keep me logged in dated on 6th august 2012\n");
      out.write("/*function saveCookie(name) {\n");
      out.write("if(document.getElementById(\"remember\").checked==true){\n");
      out.write("var username = document.getElementById(\"email\").value;\n");
      out.write("\tif(username){\n");
      out.write("\t\tvar date=new Date();\n");
      out.write("\t\tdate.setDate(date.getDate()+1);\n");
      out.write("\t\tdocument.cookie = name + \"=\" + username+\"; expires=\" + date + \"; path=/\";\n");
      out.write("\t}\n");
      out.write("}else{\n");
      out.write("\treturn true;\n");
      out.write("}\n");
      out.write("}*/\n");
      out.write("function resetFields()\n");
      out.write("{\n");
      out.write("   document.getElementById(\"password\").value =\"\";\n");
      out.write("   document.getElementById(\"email\").value =\"\";\n");
      out.write("   document.getElementById('email').focus();\n");
      out.write("}\n");
      out.write("\n");
      out.write("function showiphonecont()\n");
      out.write("{\n");
      out.write("\tdocument.getElementById(\"iphonecontainer_pubpro\").style.display = 'block';\n");
      out.write("\tdocument.getElementById(\"iphonecontainer\").style.display = 'none';\n");
      out.write("}\n");
      out.write("function showdiv()\n");
      out.write("{\n");
      out.write("\t\tdocument.getElementById(\"secssionfalse\").style.display = 'none';\n");
      out.write("\t\tdocument.getElementById(\"secssiontrue\").style.display = 'block';\n");
      out.write("}\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("</head>\n");
if(request.getParameter("username")!=null || session.getAttribute("name") != null){

      out.write("\n");
      out.write("<body onload=\"resetFields();CustomizedHtmlControl(); public_profile('");
      out.print(username );
      out.write("'); showiphonecont(); showdiv()\">\n");
} else 
      out.write("\n");
      out.write("<body onload=\"CustomizedHtmlControl();\">\n");
      out.write("<div class=\"wrapper\">\n");
      out.write("\t<!--mainsite starts here -->\n");
      out.write("\t<div class=\"mainsite\">\n");
      out.write("\t");
 if(session.getAttribute("name")!=null ){  
		response.sendRedirect("peoplefinder.do?action=people"); 
 	
      out.write("\n");
      out.write(" \t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, false);
      out.write('\n');
      out.write(' ');

 	}else 
      out.write("\n");
      out.write(" \t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "loginHeader.jsp", out, false);
      out.write("\n");
      out.write("    \t<div class=\"leftside\">\n");
      out.write("    \t<a href=\"index.jsp\">\n");
      out.write("    \t <div class=\"logo\"></div></a>\n");
      out.write("        \t");
if(session.getAttribute("name") != null){ 
      out.write("\n");
      out.write("        \t<div id=\"iphonecontainer_pubpro\" class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("                  \t\t<div class=\"buttoncontainer\">\n");
      out.write("                        \t<div><img src=\"images/location_xsmall.png\"/><a href=\"peoplefinder.do?action=people\"><input id=\"peoplenearmebtn\" type=\"button\" class=\"iphonebutton active\" value=\"People Near Me\"/></a></div>\n");
      out.write("                       \t    <div><img src=\"images/upcomingtrip_icon.png\"/><input id=\"upcommingtripbtn\" type=\"button\" onclick=\"people_upCommingTrip();\" class=\"iphonebutton\" value=\"On Upcoming Trip\"/></div>\n");
      out.write("                            <input type=\"hidden\" name=\"action\" value=\"upCommingTrip\" />\n");
      out.write("                            <div><img src=\"images/search_icon.png\"/><input id=\"advancesearchbtn\" type=\"button\" onclick=\"advanceSearch();\" class=\"iphonebutton\" value=\"Advance Search\"/></a></div>\n");
      out.write("                        </div>\n");
      out.write("               \t\t  \t<img id=\"screen1\" src=\"images/proplefinder_bg.png\" />\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\n");
      out.write("            </div>\n");
      out.write("            ");
} else if(session.getAttribute("name")==null)
      out.write("\n");
      out.write("        \t<div id=\"iphonecontainer\" class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("               \t\t  <img id=\"screen1\" src=\"images/screen01.jpg\" alt=\"Splash Screen\">\n");
      out.write("               \t\t  <img id=\"screen2\" src=\"images/screen02.jpg\" alt=\"meetIn Screen\" style=\"left: 202px;\">\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\t\n");
      out.write("            </div>\n");
      out.write("            \n");
      out.write("               \n");
      out.write("    <div class=\"appstore\"  style=\"margin-left: 14px;\"><a href=\"https://itunes.apple.com/us/app/meetin/id590629564?ls=1&mt=8\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-iphone.png\" style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-midtext.png\" style=\"float: left\"/> </a><a href=\"https://play.google.com/store/apps/details?id=com.meetin&feature=search_result#?t=W251bGwsMSwyLDEsImNvbS5tZWV0aW4iXQ..\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-androide.png\" style=\"float: left\"/>  </div></a> \n");
      out.write("            <a href=\"how_it_works.jsp\"><div class=\"appvideo\"><img id=\"appvideo\" src=\"images/appvideo_new.png\" /></div></a>\n");
      out.write("\n");
      out.write("            \n");
      out.write("            <div class=\"followus\">\n");
      out.write("            \tFollow Us on:\n");
      out.write("                <div class=\"socialnetwork\">\n");
      out.write("\t\t\t   <a href=\"javascript:void(0)\" onclick=\"window.open('https://www.facebook.com/pages/MeetIn/495222843824206', '_blank')\">\n");
      out.write("                <div class=\"facebook\"></div></a>\n");
      out.write("             \n");
      out.write("                 <a href=\"javascript:void(0)\" onclick=\"window.open('https://twitter.com/mymeetIn', '_blank')\"><div class=\"twitter\"></div></a>\n");
      out.write("                  <a href=\"javascript:void(0)\" onclick=\"window.open('https://plus.google.com/b/108083242642551656394/?partnerid=gplp0', '_blank')\">\n");
      out.write("                 <div class=\"google_plus\"></div></a>\n");
      out.write("                </div>\n");
      out.write("            </div>\n");
      out.write("        </div>\n");
      out.write("        \n");
      out.write("        <div class=\"rightside\">\n");
      out.write("        ");
if(session.getAttribute("name")!=null ){
     
         
      out.write("\n");
      out.write("        <div id=\"navigation\" style=\"display: block;\">\n");
      out.write("         \t\t<div id=\"navinner\" class=\"submitBtn active\"><a href=\"peoplefinder.do?action=people\"><span>People Finder</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"addtrip.jsp\"><span>My Travel Plan</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"friend.do?fparam=myfriends\"><span>My Friends</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"myprofile.jsp?action=profilevisitors\"><span>My Profile</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"contact.jsp\"><span>Contact Us</span></a></div>                \n");
      out.write("        \t</div>\n");
      out.write("        \t");
} 
      out.write("\n");
      out.write("        \t");
if(session.getAttribute("name")==null) {
        	
        	
      out.write("\n");
      out.write("        \t<div id=\"navigation\" style=\"display: block;\">\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"index.jsp\"><span>Home</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn active\"><a href=\"mymeetin.jsp\"><span>My meetIn</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"how_it_works.jsp\"><span>How It Works</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"features.jsp\"><span>Features</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"feedback.jsp\"><span>Feedback</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"contact.jsp\"><span>Contact Us</span></a></div>\n");
      out.write("        \t</div>\n");
      out.write("\t\t\t\t");
} 
      out.write("\n");
      out.write("            <div style=\"overflow:hidden; height:auto\">\n");
      out.write("            <div id=\"publicprofile\" name=\"publicprofile\" style=\"display: block; overflow: hidden;\">\n");
      out.write("                <div class=\"mymeetincontainer1\">\n");
      out.write("\t\t\t\t\t<div class=\"heading\">\n");
      out.write("                    \t<img src=\"images/lock.png\" align=\"absbottom\"/> Log On to your account\n");
      out.write("                                        \t\n");
      out.write("                    </div>\n");
      out.write("                    \t");

					//*******************************************************************	
					// code changed on 28-8-2012
							if(session.getAttribute("emailRegistered") != null)
							{
								//System.out.println("User Already Registered.");
						
						
      out.write("\t\t\n");
      out.write("\t\t\t\t\t\t\t <div class=\"error\" style=\"display:block\"> \n");
      out.write("                    \t\t<img src=\"images/error_icon.png\" align=\"absmiddle\"/> User ID already Registered. \n");
      out.write("                    \t\t</div>\n");
      out.write("                    \n");
      out.write("                    \t");

                    		session.removeAttribute("emailRegistered");
							}	
					
 							
      out.write("\n");
      out.write("                    ");

                       if(request.getParameter("login") !=null)
                       {
                       	email = (String)request.getAttribute("InvalidLogin");
                     
      out.write("\n");
      out.write("                    <!--  This is a div tag for login error message -->\n");
      out.write("                    <div class=\"error\" style=\"display:block\"> \n");
      out.write("                    \t<img src=\"images/error_icon.png\" align=\"absmiddle\"/> Invalid email or password. \n");
      out.write("                    </div>\n");
      out.write("                    ");

                      }
      out.write("\n");
      out.write("                      \n");
      out.write("                       \n");
      out.write("                      \n");
      out.write("                    ");
      //  html:form
      org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f0 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_005fform_005f0.setPageContext(_jspx_page_context);
      _jspx_th_html_005fform_005f0.setParent(null);
      // /mymeetin.jsp(262,20) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setAction("/login");
      // /mymeetin.jsp(262,20) name = method type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setMethod("post");
      // /mymeetin.jsp(262,20) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setStyleId("frmlogin");
      int _jspx_eval_html_005fform_005f0 = _jspx_th_html_005fform_005f0.doStartTag();
      if (_jspx_eval_html_005fform_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\n");
          out.write("                   \n");
          out.write("                    <input type=\"hidden\" name=\"fwdurl\" value=\"");
          out.print(getString);
          out.write("\" id=\"fwdurl\" />\n");
          out.write("                    <input type=\"hidden\" name=\"action\" value=\"login\"/>\n");
          out.write("                    <div class=\"frmcontainer1\">\n");
          out.write("                        \t<div class=\"lable\">Email</div>\n");
          out.write("                        \t");
          if (_jspx_meth_html_005ftext_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                        \t<!--<input type=\"text\" value=\"\" name=\"email\"/>-->\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div class=\"lable\">Password</div>\n");
          out.write("                            ");
          if (_jspx_meth_html_005fpassword_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                           \t<!--<input type=\"password\" value=\"\" name=\"password\" /> -->\n");
          out.write("                            <div class=\"frmline\"></div>\n");
          out.write("                            <div style=\"width:140px\"   class=\"lable\">Keep me logged in</div>\n");
          out.write("                         \t <div style=\"float: left;\"> \n");
          out.write("                           \t<input type=\"checkbox\" name=\"remember\" id=\"remember\" class=\"styled\" style=\"margin-top: 7px;\"/>\n");
          out.write("                           \t</div>\n");
          out.write("                           \t<div style=\"float: left;margin: 7px 0px 0px 120px;\"> \n");
          out.write("\t\t\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"color:#000000; text-decoration: none;\" onclick=\"popupwindow('forgotpassword.jsp','Forgot Password','500','300');\">Forgot your password?</a>  \n");
          out.write("                           \t</div> \n");
          out.write("                          </div>\n");
          out.write("                    <div class=\"logonsection\" >\n");
          out.write("                    \t<!--<input type=\"submit\" class=\"buttonorg\" value=\"Log On\" />-->\n");
          out.write("                    \t");
          if (_jspx_meth_html_005fsubmit_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                                  \n");
          out.write("                        <p style=\"font-size:13px; margin:20px 0px 0px 10px\"><strong>Don't have a meetIn ID?</strong></p>\n");
          out.write("                     \n");
          out.write("                     \n");
          out.write("                     \n");
          out.write("                        <input type=\"button\" class=\"buttonmeetin\" value=\"Sign Up with\" onclick=\"callsignup();\" />\n");
          out.write("                    \n");
          out.write("                     \n");
          out.write("                     <!--\n");
          out.write("                     code commented  \n");
          out.write("                    <input type=\"button\" class=\"buttonmeetin\" value=\"Sign Up with\" onclick=\"redirect();\" />\n");
          out.write("                    -->\n");
          out.write("                    \n");
          out.write("                    </div>\n");
          out.write("                   ");
          int evalDoAfterBody = _jspx_th_html_005fform_005f0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_005fform_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
        return;
      }
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fstyleId_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
      out.write("<!--feedback.jsp\n");
      out.write("                    <div class=\"heading\" style=\"margin-top:60px;\">\n");
      out.write("                    \t<img src=\"images/facebooklock.png\" align=\"absbottom\"/> Sign Up from facebook account\n");
      out.write("                    </div>\n");
      out.write("                 \n");
      out.write("                    <div class=\"frmcontainer\">\n");
      out.write("                        \t<div class=\"lable\">Email</div>\n");
      out.write("                           \t<input type=\"text\" value=\"\" name=\"email\" />\n");
      out.write("                            <div class=\"frmline\"></div>\n");
      out.write("                            <div class=\"lable\">Password</div>\n");
      out.write("                           \t<input type=\"password\" value=\"\" name=\"password\" />\n");
      out.write("                    </div>\n");
      out.write("                 \n");
      out.write("                    -->\n");
      out.write("                 <div class=\"logonsection\">\n");
      out.write("                    \t<input type=\"hidden\" name=\"facebookbLogin\" value=\"facebookLogin\"/>\n");
      out.write("                    \t\n");
      out.write("              <input type=\"button\" class=\"buttonfacebook\" value=\"Sign Up with\"  \n");
      out.write("              onclick=\"facebookLogin('");
      if (_jspx_meth_bean_005fmessage_005f0(_jspx_page_context))
        return;
      out.write("',\n");
      out.write("     '");
      if (_jspx_meth_bean_005fmessage_005f1(_jspx_page_context))
        return;
      out.write('\'');
      out.write(',');
      out.write('\'');
      if (_jspx_meth_bean_005fmessage_005f2(_jspx_page_context))
        return;
      out.write("');\" />\n");
      out.write("                    \t");
 session.setAttribute("facebookRedirect","/signup.jsp "); 
      out.write("\n");
      out.write("                    \t\n");
      out.write("                    \t\n");
      out.write("                   \t</div>\n");
      out.write("                \n");
      out.write("                </div>\n");
      out.write("                <!-- content ends here -->\n");
      out.write("            </div> \n");
      out.write("        </div>\n");
      out.write("    </div><!--mainsite starts here -->\n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("    <div class=\"footer\">\n");
      out.write("    ");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, false);
      out.write("\t\t\n");
      out.write("    </div><!--footer ends here -->\n");
      out.write("</div>\n");
      out.write("</body>\n");
      out.write("</html>\n");
      out.write("\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_html_005ftext_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f0 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /mymeetin.jsp(268,25) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setProperty("email");
    // /mymeetin.jsp(268,25) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleId("email");
    // /mymeetin.jsp(268,25) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setSize("50");
    // /mymeetin.jsp(268,25) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setMaxlength("50");
    // /mymeetin.jsp(268,25) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleClass("validate[required,custom[email]] text-input");
    int _jspx_eval_html_005ftext_005f0 = _jspx_th_html_005ftext_005f0.doStartTag();
    if (_jspx_th_html_005ftext_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
    return false;
  }

  private boolean _jspx_meth_html_005fpassword_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:password
    org.apache.struts.taglib.html.PasswordTag _jspx_th_html_005fpassword_005f0 = (org.apache.struts.taglib.html.PasswordTag) _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.PasswordTag.class);
    _jspx_th_html_005fpassword_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fpassword_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /mymeetin.jsp(272,28) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setProperty("password");
    // /mymeetin.jsp(272,28) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setSize("30");
    // /mymeetin.jsp(272,28) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setMaxlength("30");
    // /mymeetin.jsp(272,28) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setStyleId("password");
    // /mymeetin.jsp(272,28) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fpassword_005f0.setStyleClass("validate[required] text-input");
    int _jspx_eval_html_005fpassword_005f0 = _jspx_th_html_005fpassword_005f0.doStartTag();
    if (_jspx_th_html_005fpassword_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005fpassword_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fpassword_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005fpassword_005f0);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f0 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /mymeetin.jsp(285,21) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setValue("Log In");
    // /mymeetin.jsp(285,21) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setStyleClass("buttonorg");
    // /mymeetin.jsp(285,21) name = onclick type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setOnclick("saveCookie('mycookie');");
    int _jspx_eval_html_005fsubmit_005f0 = _jspx_th_html_005fsubmit_005f0.doStartTag();
    if (_jspx_th_html_005fsubmit_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f0 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f0.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f0.setParent(null);
    // /mymeetin.jsp(318,38) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f0.setKey("facebook.app_id");
    int _jspx_eval_bean_005fmessage_005f0 = _jspx_th_bean_005fmessage_005f0.doStartTag();
    if (_jspx_th_bean_005fmessage_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f0);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f1 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f1.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f1.setParent(null);
    // /mymeetin.jsp(319,6) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f1.setKey("facebook.redirect_uri");
    int _jspx_eval_bean_005fmessage_005f1 = _jspx_th_bean_005fmessage_005f1.doStartTag();
    if (_jspx_th_bean_005fmessage_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f1);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f2(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f2 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f2.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f2.setParent(null);
    // /mymeetin.jsp(319,52) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f2.setKey("facebook.scope");
    int _jspx_eval_bean_005fmessage_005f2 = _jspx_th_bean_005fmessage_005f2.doStartTag();
    if (_jspx_th_bean_005fmessage_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f2);
    return false;
  }
}
