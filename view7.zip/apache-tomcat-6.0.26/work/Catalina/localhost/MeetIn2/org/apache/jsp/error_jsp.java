package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.verve.meetin.user.*;

public final class error_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<html xmlns=\"http://www.w3.org/1999/xhtml\">\n");
      out.write("<head>\n");
      out.write("<title>Error Page</title>\n");
      out.write("<meta http-equiv='cache-control' content='no-cache'/>\n");
      out.write("<meta http-equiv='expires' content='0'/>\n");
      out.write("<meta http-equiv='pragma' content='no-cache'/>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
      out.write("<meta name=\"description\" content=\"Enter your details and start meeting people from all over the world, Update your location status by using our Travel Plan tracker. Also add your interests and specialty and based on this you can search your contacts with ease.\" />\n");
      out.write("<meta name=\"keywords\" content=\"meetIn login page, find friends near a city, Update your location status, search your contacts\" />\n");
      out.write("<link rel=\"shortcut icon\" href=\"images/meetin_icon.png\" />\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/imagescroll.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write("</head>\n");
      out.write("<body>\n");
      out.write("<div class=\"wrapper\">\n");
      out.write("\t<!--mainsite starts here -->\n");
      out.write("\t<div class=\"mainsite\">\n");
      out.write("\t");
 if(session.getAttribute("name")!=null ){   
 
      out.write('\n');
      out.write(' ');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, false);
      out.write('\n');
      out.write(' ');
} 
      out.write("\n");
      out.write("\t\t<div class=\"leftside\">\n");
      out.write("    \t<a href=\"index.jsp\">\n");
      out.write("    \t <div class=\"logo\"></div></a>\n");
      out.write("        \t<div id=\"iphonecontainer\" class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("               \t\t  <img id=\"screen1\" src=\"images/screen01.jpg\" alt=\"Splash Screen\">\n");
      out.write("               \t\t  <img id=\"screen2\" src=\"images/screen02.jpg\" alt=\"meetIn Screen\" style=\"left: 202px;\">\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\t\n");
      out.write("            </div>\n");
      out.write("            \n");
      out.write("               \n");
      out.write("    <div class=\"appstore\"  style=\"margin-left: 14px;\"><a href=\"https://itunes.apple.com/us/app/meetin/id590629564?ls=1&mt=8\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-iphone.png\" style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-midtext.png\" style=\"float: left\"/> </a><a href=\"https://play.google.com/store/apps/details?id=com.meetin&feature=search_result#?t=W251bGwsMSwyLDEsImNvbS5tZWV0aW4iXQ..\" target=\"_blank\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-androide.png\" style=\"float: left\"/>  </div></a> \n");
      out.write("            <a href=\"how_it_works.jsp\"><div class=\"appvideo\"><img id=\"appvideo\" src=\"images/appvideo_new.png\" /></div></a>\n");
      out.write("            <div class=\"followus\">\n");
      out.write("            \tFollow Us on:\n");
      out.write("               <div class=\"socialnetwork\">\n");
      out.write("\t\t\t   <a href=\"javascript:void(0)\" onclick=\"window.open('https://www.facebook.com/pages/MeetIn/495222843824206', '_blank')\">\n");
      out.write("               <div class=\"facebook\"></div></a>\n");
      out.write("               <a href=\"javascript:void(0)\" onclick=\"window.open('https://twitter.com/mymeetIn', '_blank')\"><div class=\"twitter\"></div></a>\n");
      out.write("                <a href=\"javascript:void(0)\" onclick=\"window.open('https://plus.google.com/b/108083242642551656394/?partnerid=gplp0', '_blank')\">\n");
      out.write("                 <div class=\"google_plus\"></div></a>\n");
      out.write("               </div>\n");
      out.write("            </div>\n");
      out.write("        </div>\n");
      out.write("        \n");
      out.write("        <div class=\"rightside\">\n");
      out.write("        \t<div id=\"navigation\" style=\"display: block;\">\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"index.jsp\"><span>Home</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn active\"><a href=\"mymeetin.jsp\"><span>My meetIn</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"how_it_works.jsp\"><span>How It Works</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"features.jsp\"><span>Features</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"feedback.jsp\"><span>Feedback</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"contact.jsp\"><span>Contact Us</span></a></div>\n");
      out.write("        \t</div>\n");
      out.write("            <div style=\"overflow:hidden; height:auto\">\n");
      out.write("            <div id=\"publicprofile\" name=\"publicprofile\" style=\"display: block; overflow: hidden;\">\n");
      out.write("                <div class=\"mymeetincontainer\" style=\"margin-top: 55px;\">\n");
      out.write("\t\t\t\t\t\t<div class=\"innercontainer\">\n");
      out.write("\t\t\t\t\t\t\t\t<div class=\"errorClass\" align=\"left\">\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<img src =\"images/error_page_icon.png\" align=\"left\"/>\n");
      out.write(" \t\t\t\t\t\t\t\t\t\t<p class=\"paddnone\"><span>OOPS !!</span></p>\n");
      out.write(" \t\t\t\t\t\t\t\t\t\t<p>Something went wrong.</p>\n");
      out.write(" \t\t\t\t\t\t\t\t\t\t<p class=\"paddnone\">Our team is looking at the problem. Click here to <a href=\"mymeetin.jsp\">login</a> again.</p>\n");
      out.write("\t\t\t\t\t\t\t\t</div>\n");
      out.write("\t\t\t\t\t\t</div>\n");
      out.write("                </div>\n");
      out.write("                <!-- content ends here -->\n");
      out.write("            </div> \n");
      out.write("        </div>\n");
      out.write("    </div><!--mainsite starts here -->\n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("    <div class=\"footer\">\n");
      out.write("    ");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, false);
      out.write("\t\t\n");
      out.write("    </div><!--footer ends here -->\n");
      out.write("</div>\n");
      out.write("</body>\n");
      out.write("</html>\n");
      out.write(">\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
