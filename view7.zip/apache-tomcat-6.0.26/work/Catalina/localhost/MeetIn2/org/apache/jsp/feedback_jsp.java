package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.List;
import com.verve.meetin.feedback.FeedbackDAO;
import com.verve.meetin.contact.ContactDAO;

public final class feedback_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fform_0026_005fmethod_005faction;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fmethod_005faction = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fhtml_005fform_0026_005fmethod_005faction.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
      out.write("\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

String imagePath = basePath +"profileimage/" ;


      out.write("\n");
      out.write("<html xmlns=\"http://www.w3.org/1999/xhtml\">\n");
      out.write("<head>\n");
      out.write("<meta http-equiv='cache-control' content='no-cache'/>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
      out.write("<meta http-equiv='expires' content='0'/>\n");
      out.write("<meta http-equiv='pragma' content='no-cache'/>\n");
      out.write("<meta name=\"google-site-verification\" content=\"4bD4-uieb4wk--K8JxjnNaGQ01IFin05EQa-1ZFJ6Yw\" />\n");
      out.write("<title>Awaits for your precious feedback to reply you promptly.</title>\n");
      out.write("\n");
      out.write("<meta name=\"description\" content=\"Awaits for your precious feedback to reply you promptly.\" />\n");
      out.write("\n");
      out.write("<meta name=\"keywords\" content=\"Awaits for your precious feedback to reply you promptly.\" />\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\" src=\"js/meetin.js\">\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("\t\n");
      out.write("\n");
      out.write("\n");
      out.write("<link rel=\"shortcut icon\" href=\"images/meetin_icon.png\" />\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("function resetfields() {\n");
      out.write("\t\n");
      out.write("\tdocument.getElementById(\"fname\").value = \"\";\n");
      out.write("\tdocument.getElementById(\"femail\").value = \"\";\n");
      out.write("\tdocument.getElementById(\"frating\").value = \"\";\n");
      out.write("\tdocument.getElementById(\"fcomment\").value = \"\";\n");
      out.write("\tdocument.getElementById(\"fname\").focus();\n");
      out.write("}\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("<!--<script type=\"text/javascript\" src=\"js/jquery-1.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/imagescroll.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/curvycorners.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/meetin.js\"></script>\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("--><!---------------------Google analytics code Start------------------------------->\n");
      out.write("\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("\n");
      out.write("  var _gaq = _gaq || [];\n");
      out.write("  _gaq.push(['_setAccount', 'UA-9594176-11']);\n");
      out.write("  _gaq.push(['_trackPageview']);\n");
      out.write("\n");
      out.write("  (function() {\n");
      out.write("    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;\n");
      out.write("    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';\n");
      out.write("    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);\n");
      out.write("  })();\n");
      out.write("\n");
      out.write("</script>\n");
      out.write("\n");
      out.write("\n");
      out.write("<!---------------------Google analytics code End ------------------------------->\n");
      out.write("\n");
      out.write("\n");
      out.write("</head>\n");
      out.write("<body onload=\"resetfields()\">\n");
  
System.out.println("/feedback.jsp");
	

      out.write("\n");
      out.write("<div class=\"wrapper\">\n");
      out.write("\t<!--mainsite starts here -->\n");
      out.write("\t<div class=\"mainsite\">\n");
      out.write("\t\n");
      out.write("\t\t\t\t");

					if (session.getAttribute("name") != null) {
				
      out.write("\n");
      out.write("\t\t\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, false);
      out.write("\n");
      out.write("\t\t\t\t");

					}
				
      out.write("\n");
      out.write("\n");
      out.write("    \t<div class=\"leftside\">\n");
      out.write("    \t\n");
      out.write("    \t<a href=\"index.jsp\">\n");
      out.write("    \t<div class=\"logo\" ></div>\n");
      out.write("    \t</a>\n");
      out.write("        \t<div class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("               \t\t  <img id=\"screen1\" src=\"images/screen01.jpg\" alt=\"Splash Screen\">\n");
      out.write("               \t\t  <img id=\"screen2\" src=\"images/screen02.jpg\" alt=\"meetIn Screen\" style=\"left: 202px;\">\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\t\n");
      out.write("            </div>\n");
      out.write("            \n");
      out.write("        \n");
      out.write("    <div class=\"appstore\"  style=\"margin-left: 12px;\"><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-iphone.png\" style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-midtext.png\" style=\"float: left\"/> </a><a href=\"javascript:void(0);\"><img id=\"appstore\" src=\"images/appstorebtn-meetin-androide.png\" style=\"float: left\"/>  </div></a> \n");
      out.write("            <a href=\"How_It_Works.jsp\"><div class=\"appvideo\"><img id=\"appvideo\" src=\"images/appvideo_new.png\" /></div></a>\n");
      out.write("        \n");
      out.write("        \n");
      out.write("            <div class=\"followus\">\n");
      out.write("            \tFollow Us on:\n");
      out.write("                <div class=\"socialnetwork\">\n");
      out.write("                <a href=\"javascript:void(0)\" onclick=\"window.open('https://www.facebook.com/pages/MeetIn/495222843824206', '_blank')\">\n");
      out.write("                <div class=\"facebook\"></div></a>\n");
      out.write("                 <a href=\"javascript:void(0)\" onclick=\"window.open('https://twitter.com/mymeetIn', '_blank')\"><div class=\"twitter\"></div></a>\n");
      out.write("                </div>\n");
      out.write("            </div>\n");
      out.write("        </div>\n");
      out.write("\n");
      out.write("        <div class=\"rightside\">\n");
      out.write("        \t<div id=\"navigation\">\n");
      out.write("                <div id=\"nav\" class=\"submitBtn \"><a href=\"index.jsp\"><span>Home</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"mymeetin.jsp\"><span>My meetIn</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"How_It_Works.jsp\"><span>How It Works</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"ComingSoon.jsp\"><span>Features</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn active\"><a href=\"feedback.jsp\"><span>Feedback</span></a></div>\n");
      out.write("                <div id=\"nav\" class=\"submitBtn\"><a href=\"contact.jsp\"><span>Contact Us</span></a></div>\n");
      out.write("        \t</div>\n");
      out.write("\t\t\t\t\n");
      out.write("            <div style=\"overflow:hidden; height:auto\">\n");
      out.write("            \t\n");
      out.write("            \t<div style=\"display: block; overflow: hidden;\" name=\"publicprofile\" id=\"publicprofile\">\n");
      out.write("      \n");
      out.write("      \n");
      out.write("      <!--           <div class=\"mymeetincontainer\"> -->\n");
      out.write("\t\t\t\t\t                    \t\n");
      out.write("                    \n");
      out.write("                      ");
      //  html:form
      org.apache.struts.taglib.html.FormTag _jspx_th_html_005fform_005f0 = (org.apache.struts.taglib.html.FormTag) _005fjspx_005ftagPool_005fhtml_005fform_0026_005fmethod_005faction.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_005fform_005f0.setPageContext(_jspx_page_context);
      _jspx_th_html_005fform_005f0.setParent(null);
      // /feedback.jsp(139,22) name = action type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setAction("/feedback");
      // /feedback.jsp(139,22) name = method type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_html_005fform_005f0.setMethod("post");
      int _jspx_eval_html_005fform_005f0 = _jspx_th_html_005fform_005f0.doStartTag();
      if (_jspx_eval_html_005fform_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\n");
          out.write("                    <div class=\"generalfrm\">\n");
          out.write("                    <div class=\"lable\">Name</div>\n");
          out.write("                      \t\n");
          out.write("                      \t");

                      		if (session.getAttribute("name") == null) {
                      		System.out.println("if case");
                      	 
          out.write("\t\n");
          out.write("                      \t");
          if (_jspx_meth_html_005ftext_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                                           \n");
          out.write("                    \t");
}else{ 
                    	System.out.println("else case");
                    	
          out.write("\n");
          out.write("                    ");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f1 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f1.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
          // /feedback.jsp(152,20) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setProperty("fname");
          // /feedback.jsp(152,20) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setStyleId("fname");
          // /feedback.jsp(152,20) name = readonly type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setReadonly(false);
          // /feedback.jsp(152,20) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setValue(session.getAttribute("name").toString() );
          // /feedback.jsp(152,20) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setSize("50");
          // /feedback.jsp(152,20) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setMaxlength("50");
          // /feedback.jsp(152,20) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f1.setStyleClass("validate[required,custom[onlyLetter]] text-input");
          int _jspx_eval_html_005ftext_005f1 = _jspx_th_html_005ftext_005f1.doStartTag();
          if (_jspx_th_html_005ftext_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f1);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f1);
          out.write("\n");
          out.write("                        \n");
          out.write("                    ");
} 
          out.write("\n");
          out.write("                        <div class=\"feedbackfrmline\"></div>\n");
          out.write("                    \n");
          out.write("                    \n");
          out.write("                     \t<div class=\"lable\">Email</div>\n");
          out.write("                    ");

                    	if (session.getAttribute("UserID") != null) {
                    		System.out.println("if case");
                    	int userid = Integer.parseInt(session
															.getAttribute("UserID").toString());

													ContactDAO contactDAO = new ContactDAO();
													String emailID = contactDAO.retrieveEmailId(userid);
                    	System.out.println("email id of the users is "+emailID);
                      
          out.write("\t\n");
          out.write(" \t");
          //  html:text
          org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f2 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
          _jspx_th_html_005ftext_005f2.setPageContext(_jspx_page_context);
          _jspx_th_html_005ftext_005f2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
          // /feedback.jsp(169,2) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setProperty("femail");
          // /feedback.jsp(169,2) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setStyleId("femail");
          // /feedback.jsp(169,2) name = readonly type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setReadonly(false);
          // /feedback.jsp(169,2) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setValue(emailID );
          // /feedback.jsp(169,2) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setSize("50");
          // /feedback.jsp(169,2) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setMaxlength("50");
          // /feedback.jsp(169,2) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
          _jspx_th_html_005ftext_005f2.setStyleClass("validate[required,custom[email]] text-input");
          int _jspx_eval_html_005ftext_005f2 = _jspx_th_html_005ftext_005f2.doStartTag();
          if (_jspx_th_html_005ftext_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
            _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f2);
            return;
          }
          _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fvalue_005fstyleId_005fstyleClass_005fsize_005freadonly_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f2);
          out.write("\n");
          out.write("                    \n");
          out.write("                    ");
}else{ 
                    System.out.println("if case");
                    
          out.write("\n");
          out.write("                    \t\n");
          out.write("                  ");
          if (_jspx_meth_html_005ftext_005f3(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("  \n");
          out.write("                    ");
} 
          out.write("\n");
          out.write("                            <div class=\"feedbackfrmline\"></div>\n");
          out.write("                            <div class=\"lable\">Rating</div>\n");
          out.write("  ");
          if (_jspx_meth_html_005ftext_005f4(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write("                    \n");
          out.write("                            <div class=\"feedbackfrmline\"></div>\n");
          out.write("                            <div class=\"lable\">Comments</div>\n");
          out.write(" \n");
          out.write(" ");
          if (_jspx_meth_html_005ftextarea_005f0(_jspx_th_html_005fform_005f0, _jspx_page_context))
            return;
          out.write("\n");
          out.write(" \n");
          out.write("                            </div>\n");
          out.write("                            \n");
          out.write("                          </div>\n");
          out.write("                    <div class=\"logonsection\">\n");
          out.write("                    \t<!--<input type=\"submit\" class=\"buttonorg\" value=\"Log On\" />-->\n");
          out.write("                    \t\n");
          out.write("                    \t");

                    	if (session.getAttribute("name") != null) {
                    	 
          out.write("\n");
          out.write("                    \t\t<input type=\"submit\" class=\"buttonorg\" value=\"Add Feedback\"/>\n");
          out.write("                    \t\t");

                    	}
                    	else
                    	{ 
                    	
	                    		if(request.getParameter("param") != null)
	                    		{
	                    			out.println("<p><b>please login to give feedback.</b></p><br>");
	                    		}
                    	
          out.write("\n");
          out.write("                    \t\t<input type=\"button\" class=\"buttonorg\" value=\"Add Feedback\" onclick=\"feedback()\" />\n");
          out.write("                    \t\t");

                    	}
                    	 
          out.write("\n");
          out.write("                    </div>\n");
          out.write("                   \n");
          out.write("                            \n");
          out.write("                          </div>\n");
          out.write("                 ");
          int evalDoAfterBody = _jspx_th_html_005fform_005f0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_005fform_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        _005fjspx_005ftagPool_005fhtml_005fform_0026_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
        return;
      }
      _005fjspx_005ftagPool_005fhtml_005fform_0026_005fmethod_005faction.reuse(_jspx_th_html_005fform_005f0);
      out.write("   \n");
      out.write("                 \n");
      out.write("                 <!-- feedback stared -->\n");
      out.write("                 \n");
      out.write("                   <div class=\"tableheading feedback\">\n");
      out.write("                 \t\t\t\tFeedback and Comments\n");
      out.write("                 </div> \n");
      out.write("                 \n");
      out.write("              \t<div class=\"dynamicrow feedback-comm\">\n");
      out.write("                 \n");
      out.write("                   ");

               //feed back
               
               
               
               
               	List list =	new FeedbackDAO().getFeedback();
               	if(list != null)
               	{
               		
               		System.out.println("size of list "+list.size());
               		
                	for(int i=0;i<list.size();i++)
                 	{
                 	
                 		Object[] object = (Object[]) list.get(i);
                 	
      out.write("\n");
      out.write("                 \t\t");
imagePath = imagePath + (String)object[6]; 
      out.write("\n");
      out.write("                 \t\t<div class=\"row date\">\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t<div style=\"float: left; width:60px;\">\n");
      out.write("                 \t\t\t <img src =\"");
      out.print(imagePath);
      out.write("\" height=\"60\" width=\"60\"/>\n");
      out.write("                 \t\t\t\n");
      out.write("                 \t\t</div>\n");
      out.write("                 \t\t<div style=\"float:left; margin-left:20px; color:#575757; font:normal 14px arial;\">\n");
      out.write("                 \t\t\t<span style=\"border-bottom:1px solid #ccc; margin-bottom:5px; padding-bottom:5px; display:block; width : 550px;font:normal 14px arial !important; text-transform:capitalize; color:#575757;\">");
out.println(""+(String)object[1]); 
      out.write("<em style=\"font-style: normal; color:#ff9900; margin-left:10px;\"> ");
out.println(""+(String)object[5]); //date
      out.write("</em></span>\n");
      out.write("                 \t\t\t<p>");
out.println(""+(String)object[4]); //comment
      out.write("</p>\t\n");
      out.write("                 \t\t\t<p style=\"margin-top: 10px;\"><label>Rating : </label>");
out.println(""+(Integer)object[3]);//rating 
      out.write("\t</p>\n");
      out.write("                 \t\t</div>\n");
      out.write("                 \t\t<div style=\"clear: both; overflow:hidden;\"></div>\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t \n");
      out.write("                 \t\t\n");
      out.write("                 \t\t<strong>");
//out.println(""+(String)object[4]); //comment
      out.write("</strong>\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t");
//out.println(""+(String)object[6]); 
      out.write("\n");
      out.write("                 \t\t\n");
      out.write("                 \t\t");
//out.println(""+imagePath); 
      out.write("\n");
      out.write("                 \t \n");
      out.write("                 \t\t</div>\n");
      out.write("                 \t");

                 	}
                 	 
      out.write("\n");
      out.write("              \n");
      out.write("               \t");
	
               		
               	}
               	else
               	{
               		System.out.println("no feed back");
               	}
                 
                  
      out.write("\n");
      out.write("                \n");
      out.write("                 </div>   \n");
      out.write("                   \t\n");
      out.write("                </div><!-- content ends here -->\n");
      out.write("            </div>\n");
      out.write("            \t\n");
      out.write("            \t\t</div>\n");
      out.write("            \t</div>\n");
      out.write("            \t\n");
      out.write("            </div>\n");
      out.write("                 \n");
      out.write("                 \n");
      out.write("                 \n");
      out.write("                   \n");
      out.write("                      \n");
      out.write("                      <!-- feedback end -->\n");
      out.write("                          \n");
      out.write("            </div> \n");
      out.write("        </div>\n");
      out.write("    </div>\n");
      out.write("    \n");
      out.write("    <!--mainsite starts here -->\n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("  \t\t<div class=\"footer\">\n");
      out.write("\t\t\t\t<p>\n");
      out.write("\t\t\t\t\t<a href=\"index.jsp\">Home</a>|\n");
      out.write("\t\t\t\t\t<a href=\"How_It_Works.jsp\">How It Works</a>|\n");
      out.write("\t\t\t\t\t<a href=\"ComingSoon.jsp\">Features</a>|\n");
      out.write("\t\t\t\t\t<a href=\"feedback.jsp\">Feedback</a>|\n");
      out.write("\t\t\t\t\t<a href=\"contact.jsp\">Contact Us</a>|\n");
      out.write("\t\t\t\t\t<a href=\"ComingSoon.jsp\">Privacy Policy</a>|\n");
      out.write("\t\t\t\t\t<a href=\"ComingSoon.jsp\">Disclaimer</a>\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t\t<p>\n");
      out.write("\t\t\t\t\t&nbsp;\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t\t<p>\n");
      out.write("\t\t\t\t\tmeetIn is an application of <a href=\"http://www.offshoremobiledevelopment.com\" target=\"_blank\" class=\"ft_link\">Verve Mobile Labs</a> | iPhone is\n");
      out.write("\t\t\t\t\ttrademarks of Apple Inc., registered in U.S. and other countries.\n");
      out.write("\t\t\t\t\tApp Store is a service mark of Apple Inc.\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t\t<p class=\"copyright\">\n");
      out.write("\t\t\t\t\tCopyright @ 2012 meetIn. All rights reserved.\n");
      out.write("\t\t\t\t</p>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<!--footer ends here -->\n");
      out.write("\t\t\n");
      out.write("\n");
      out.write("\n");
      out.write("</body>\n");
      out.write("</html>\n");
      out.write("\n");
      out.write("\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_html_005ftext_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f0 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /feedback.jsp(147,23) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setProperty("fname");
    // /feedback.jsp(147,23) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleId("fname");
    // /feedback.jsp(147,23) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setSize("50");
    // /feedback.jsp(147,23) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setMaxlength("50");
    // /feedback.jsp(147,23) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f0.setStyleClass("validate[required,custom[onlyLetter]] text-input");
    int _jspx_eval_html_005ftext_005f0 = _jspx_th_html_005ftext_005f0.doStartTag();
    if (_jspx_th_html_005ftext_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f0);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f3(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f3 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f3.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f3.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /feedback.jsp(175,18) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setProperty("femail");
    // /feedback.jsp(175,18) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setStyleId("femail");
    // /feedback.jsp(175,18) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setSize("50");
    // /feedback.jsp(175,18) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setMaxlength("50");
    // /feedback.jsp(175,18) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f3.setStyleClass("validate[required,custom[email]] text-input");
    int _jspx_eval_html_005ftext_005f3 = _jspx_th_html_005ftext_005f3.doStartTag();
    if (_jspx_th_html_005ftext_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f3);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f3);
    return false;
  }

  private boolean _jspx_meth_html_005ftext_005f4(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:text
    org.apache.struts.taglib.html.TextTag _jspx_th_html_005ftext_005f4 = (org.apache.struts.taglib.html.TextTag) _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_005ftext_005f4.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftext_005f4.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /feedback.jsp(179,2) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setProperty("frating");
    // /feedback.jsp(179,2) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setStyleId("frating");
    // /feedback.jsp(179,2) name = size type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setSize("50");
    // /feedback.jsp(179,2) name = maxlength type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setMaxlength("50");
    // /feedback.jsp(179,2) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftext_005f4.setStyleClass("validate[required] text-input");
    int _jspx_eval_html_005ftext_005f4 = _jspx_th_html_005ftext_005f4.doStartTag();
    if (_jspx_th_html_005ftext_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f4);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftext_0026_005fstyleId_005fstyleClass_005fsize_005fproperty_005fmaxlength_005fnobody.reuse(_jspx_th_html_005ftext_005f4);
    return false;
  }

  private boolean _jspx_meth_html_005ftextarea_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_html_005fform_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:textarea
    org.apache.struts.taglib.html.TextareaTag _jspx_th_html_005ftextarea_005f0 = (org.apache.struts.taglib.html.TextareaTag) _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.get(org.apache.struts.taglib.html.TextareaTag.class);
    _jspx_th_html_005ftextarea_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005ftextarea_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_html_005fform_005f0);
    // /feedback.jsp(184,1) name = property type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftextarea_005f0.setProperty("fcomment");
    // /feedback.jsp(184,1) name = styleId type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftextarea_005f0.setStyleId("fcomment");
    // /feedback.jsp(184,1) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005ftextarea_005f0.setStyleClass("validate[required,length[0,250]]");
    int _jspx_eval_html_005ftextarea_005f0 = _jspx_th_html_005ftextarea_005f0.doStartTag();
    if (_jspx_th_html_005ftextarea_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftextarea_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005ftextarea_0026_005fstyleId_005fstyleClass_005fproperty_005fnobody.reuse(_jspx_th_html_005ftextarea_005f0);
    return false;
  }
}
