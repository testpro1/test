package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.List;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.*;
import com.verve.meetin.network.NetworkDAO;

public final class advanceSearch_005flist_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("<div class=\"heading\" style=\"margin-top: 30px;height: auto; overflow: hidden;\">\n");
      out.write("\t\t<div style=\"float:left\"><img src=\"images/search_friends.png\" align=\"bottom\" />\n");
      out.write("\t\tSearch Result\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<div style=\"float: right; font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\" class=\"username\"> \n");
      out.write("\t\t\t<a href=\"peoplefinder.do?action=advancesearch\" style=\"color:#fff;\">Back</a>\n");
      out.write("\t\t</div>\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("<div class=\"tableheading\">\n");
      out.write("<div class=\"sourcecol\">&nbsp;</div>\n");
      out.write("    <div class=\"namecol\" style=\"width:435px;\">Name</div>\n");
      out.write("    <div class=\"sourcecol\"></div>\n");
      out.write("</div>\n");
      out.write("<div class=\"dynamicrow\">\n");
      out.write("        ");

        
        
		Hashtable<String, List<String>> friends = new Hashtable<String, List<String>>();
		
		String friend_id = "";
		if(session.getAttribute("friends") != null) 
		 {

		 
			friends = (Hashtable<String, List<String>>)session.getAttribute("friends");
			//friends = (Map<String, List<String>>) session.getAttribute("friends");
			if(friends.size() > 0) 
			{    
				/*Iterator<String> iterator = friends.keySet().iterator();
				while(iterator. hasNext()) {
					friend_id = iterator.next();
					friend_info = friends.get(friend_id);
					}*/
				
					List sorted_list = new ArrayList();
			 		List<String> name = new ArrayList();
					 Enumeration<String> em = friends.keys();
					 while(em.hasMoreElements())
						{
							String key = em.nextElement();
							name.add(friends.get(key.toString()).get(0)+"::"+key);
							
						}
						
					 Collections.sort(name, String.CASE_INSENSITIVE_ORDER);
					 //List sorted_list = new ArrayList();
					 Iterator<String> iter = name.iterator();
					 
					 Iterator<String> iter1 = name.iterator();
					 
					 //Modified by Rupal Kathiriya to get tripwise  by date wise and location wise dated on 8th august 2012
						
					 while(iter.hasNext())
						{
					
					//System.out.println("while ");
						try{
							List sort_name = new ArrayList();
							String nkey = iter.next();
							
							sort_name.add(nkey.split("::")[1]);
							sort_name.add(nkey.split("::")[0]);
							sort_name.add(friends.get(nkey.split("::")[1]).get(1));
							sort_name.add(friends.get(nkey.split("::")[1]).get(2));
							sort_name.add(friends.get(nkey.split("::")[1]).get(3));
							
							//sort_name.add(friends.get(nkey.split("::")[1]).get(4));
							sorted_list.add(sort_name);
							}catch(Exception e){
							e.printStackTrace();
							}							
						}
					
                     // Implement the Navigation
					int start = Integer.parseInt(session.getAttribute("start").toString());
                    int end = Integer.parseInt(session.getAttribute("end").toString());
                    if(request.getParameter("event") != null && request.getParameter("event").equals("next"))
                    {
                         
                         //System.out.println("if loop -- - * - * * * * * * *  * * *    * ");
                            session.setAttribute("start", String.valueOf(end));
                            start = end;
                            if(sorted_list.size() < 10)
                            {
                                    session.setAttribute("end", String.valueOf(sorted_list.size()));
                                    end = sorted_list.size();
                            }
                            else if((end+10) < sorted_list.size())
                            { 
                                    session.setAttribute("end", String.valueOf(end+10));
                                    end = end + 10;
                            }
                            else if((end+10) > sorted_list.size())
                            {
                                    session.setAttribute("end", String.valueOf(end + (sorted_list.size() - end)));
                                    end = end + (sorted_list.size() - end);
                            }
                            else if((end+10) >= sorted_list.size())
                            {
                                    session.setAttribute("end", String.valueOf(end + (sorted_list.size() - end)));
                                    end = sorted_list.size();
                            }
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("prev"))
                    {
                            if(start >= 10)
                            {
                                    session.setAttribute("start", String.valueOf(start-10));
                                    start = start - 10;
                            }
                            else if(start < 10)
                            {
                                    session.setAttribute("start", String.valueOf(start-start));
                                    start = start - start;
                            }
                            session.setAttribute("end", String.valueOf(start+10));
                            end = start + 10;
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("first")) 
                    {
                    	start = 0;
                    	if(sorted_list.size() < 10)
                    		end = sorted_list.size();
                    	else
                    		end = 10;
                    	session.setAttribute("end", end);
                    	session.setAttribute("start", start);
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("last")) 
                    {
                    	end = sorted_list.size();
                    	if(sorted_list.size() < 10)
                    		start = 0;
                    	else
                    	{
                    		start = (sorted_list.size() / 10) * 10;
                    		if(start == sorted_list.size())
                    			start = start - 10;
                    	} 
                    	session.setAttribute("end", end);
                    	session.setAttribute("start", start);
                    }
                    else if(request.getParameter("event") != null && request.getParameter("event").equals("pagi_combo"))
                    {
                    	String[] s = request.getParameter("pagi_combo").split("-");
                    	start = Integer.parseInt(s[0]);
                    	end = Integer.parseInt(s[1]);
                    	session.setAttribute("end", end);
		                session.setAttribute("start", start);
                    }
                     // End Navigation	
					if(sorted_list != null && sorted_list.size() > 0) 
							{
								
								for(int i=start;i<end;i++)
								{
									List friend_info = (List)sorted_list.get(i);
									
		
      out.write("\n");
      out.write("\t\t<div class=\"row\">\n");
      out.write("\t\t\t<div class=\"dynamicsourcecol\"><img src=\"");
      out.print(friend_info.get(3) );
      out.write("\" /></div>\n");
      out.write("         \t<div class=\"dynamicnamecol\" onclick=\"\">");
      out.print(friend_info.get(1) );
      out.write("</div>\n");
      out.write("             \t");

             		String[] socialnetwork = friend_info.get(3).toString().split("/");
             	            	
             	            	
             	    //System.out.println("social network "+socialnetwork);        	
             	    //System.out.println("Friend Info 1 :::   "+friend_info.get(3).toString().split("/"));        	
             	    //System.out.println("social network "+socialnetwork);        	
             	            	
             	            	
					if(socialnetwork[1].equals("meetin_icon.png"))
              			{
              			//System.out.println("meetin_icon.png");
	          	
      out.write("\n");
      out.write("\t          \t<div class=\"dynamicviewcol\" style=\"width: 134px !important\">\n");
      out.write("\t          \t\n");
      out.write("\t     ");
System.out.println(friend_info.get(2)); 
      out.write("\n");
      out.write("\t         <a href=\"javascript:void(0);\" onclick=\"scrollTo(0,0); viewUserProfile('");
      out.print(friend_info.get(2).toString());
      out.write("');\">\n");
      out.write("\t           \t<img src=\"images/view_icon.png\" style=\"border: none;\"/>\n");
      out.write("\t        </a>\n");
      out.write("\t    \n");
      out.write("\t           \t ");

	   	 								
				String nkey = iter1.next();
				String locationValue = friends.get(nkey.split("::")[1]).get(3);
				String paramValue = "userid="+nkey.split("::")[1]+"&location="+session.getAttribute("location");
				System.out.println("11111111111111111111111111" + paramValue);
				
				
				String userId = friend_info.get(2).toString();
				userId = userId.substring(userId.indexOf("=")+1,userId.length());
				
				
				
      out.write("\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t \t <a href=\"javascript:void(0);\" onclick=\" scrollTo(0,0); viewUserTripList('");
      out.print(friend_info.get(2).toString());
      out.write("');\"><img src=\"images/view_trip_icon.png\" title=\"Trip List\" border=\"none\"/></a>\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t\t<a href=\"javascript:void(0);\"\n");
      out.write("\t\t\t\t\tonclick=\"callFriendMeetingInviteView(");
      out.print(userId);
      out.write(',');
      out.write('\'');
      out.print(friend_info.get(1).toString());
      out.write("')\"\n");
      out.write("\t\t\t\t\tclass=\"\" title=\"Send Message\"><img src=\"images/invite_msg.png\"\n");
      out.write("\t\t\t\t\t\tborder=\"none\" /> </a>\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t");

					if(session.getAttribute("location").toString().equalsIgnoreCase(locationValue))
					{
									
				 	 
      out.write("\n");
      out.write("\t\t\t\t\t\n");
      out.write("\t\t\t\t \t <!--\n");
      out.write("\t   \t       \t    \t<a href=\"javascript:void(0);\" onclick=\"scrollTo(0,0); getPeopleUpcomingTripDetail('");
      out.print(paramValue);
      out.write("');\">\n");
      out.write("\t    \t\t\t\t<img src=\"images/view_uptrip.png\" border=\"none\"/>\n");
      out.write("\t\t\t\t\t\t</a>\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t\t\t \n");
      out.write("\t\t\t\t\t\t<a href=\"javascript:void(0);\" onclick=\"scrollTo(0,0); callMeetingInviteView('");
      out.print(nkey.split("::")[1]);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(session.getAttribute("location"));
      out.write("');\" title=\"Send Message\">\n");
      out.write("\t\t\t\t\t\t<img src=\"images/invite_msg.png\" border=\"none\"/>\n");
      out.write("\t\t\t\t\t\t</a>\n");
      out.write("\t\t\t\t\t\t -->\n");
      out.write("\t\t\t\t\t\t\t   \t       \t  \n");
      out.write("\t   \t       \t  \t");
	
					}
					else
					{
					String idstr = friend_info.get(2).toString();
					int  id = idstr.lastIndexOf('=');
				
					String userid = idstr.substring(id+1,idstr.length()); 
					
				
      out.write("\n");
      out.write("\t\t\t\t<!-- \n");
      out.write("\t\t \t\t<a href=\"javascript:void(0);\" onclick=\"scrollTo(0,0); callMeetingInviteView('");
      out.print(userid);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(session.getAttribute("location"));
      out.write("');\" title=\"Send Message\" class=\"Message\">\n");
      out.write("\t\t\t\t<img src=\"images/invite_msg.png\" border=\"none\"/>\n");
      out.write("\t\t\t\t</a>\n");
      out.write("\t\t\t\t -->\t   \t       \t  \n");
      out.write("\t \t\t\t");

					}
				  
      out.write("  \n");
      out.write("\t   \t       \t  </div>\n");
      out.write("\t   \t       \t\n");
      out.write("\t          ");

	            }
	              	else if(socialnetwork[1].equals("1_facebook_icon.png"))
	               	{
	                   	////System.out.println("facebbok_icon.png");
	            
	          
      out.write("\n");
      out.write("\t           <div class=\"dynamicviewcol\" >\n");
      out.write("\t           <a href=\"javascript:void(0);\" onclick=\"window.open('");
      out.print(friend_info.get(2).toString() );
      out.write("','name','height=600,width=1000,scrollbars=1');\">\n");
      out.write("\t\t\t\t <img src=\"images/view_icon.png\" border=\"none\"/>\n");
      out.write("\t\t\t\t</a>\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\t\t   \t     \n");
      out.write("\t           </div>\n");
      out.write("\t         ");

	               	    }
         		//change by lokesh for linkedin
							       else if(socialnetwork[1].equals("2_linkedin_icon.png"))
		                                     {
		                                     //System.out.println("linked_icon.png");
                             
      out.write("\n");
      out.write("                             <div class=\"dynamicviewcol\" >\n");
      out.write("               <a href=\"javascript:void(0);\" style=\"cursor: auto;\"> <img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/view_icon_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\t\t\n");
      out.write("                               </div>\n");
      out.write("\t\t\t\t\t\t\t");
 				 }
                                  ///////
                                  //change by lokesh for gmail
							       else if(socialnetwork[1].equals("gmail_icon.png"))
		                                     {
		                                 
                             
      out.write("\n");
      out.write("                               <div class=\"dynamicviewcol\" >\n");
      out.write("               <a href=\"javascript:void(0);\" style=\"cursor: auto;\"> <img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/view_icon_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("                               </div>\n");
      out.write("\t\t\t\t\t\t\t");
 				 }
							else if(socialnetwork[1].equals("twitter.png"))
		                                     {
		                                 
                             
      out.write("\n");
      out.write("                               <div class=\"dynamicviewcol\" >\n");
      out.write("               <a href=\"javascript:void(0);\" style=\"cursor: auto;\"> <img\n");
      out.write("\t\t\t\t\t\tsrc=\"images/view_icon_inactive.png\" border=\"none\" /> </a>\n");
      out.write("\t\t\t\t<a href=\"javascript:void(0);\" style=\"cursor: auto;\" onclick=\"\"><img src=\"images/view_trip_icon_inactive.png\" border=\"none\"/></a>\t\t\n");
      out.write("\t\t\t\t\t\t\n");
      out.write("                               </div>\n");
      out.write("\t\t\t\t\t\t\t");
 				 }
	     		
      out.write("\n");
      out.write("         \t\t\n");
      out.write("           </div>\n");
      out.write("           ");

           }
            
      out.write("           \n");
      out.write("           <div class=\"pagination\">\n");
      out.write("\t\t\t\t\t ");
 if(start > 0) {
      out.write("\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"first\" class=\"first\" onclick=\"nevigation_advancesearch('first','');\" title=\"First\" />\n");
      out.write("\t\t       \t\t\t<input type=\"button\" name=\"prev\" onclick=\"nevigation_advancesearch('prev','');\" title=\"Previous\" class=\"previous\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"input\" disabled=\"disabled\"  name=\"first\" class=\"first_disable\"   />\n");
      out.write("\t\t            <input type=\"input\" disabled=\"disabled\"  name=\"prev\" class=\"previous_disable\" />\n");
      out.write("\t\t       \t\t");
} 
      out.write("\n");
      out.write("\t\t       \t\t<div class=\"inputcontainer\">\n");
      out.write("\t\t            <div class=\"inputleft\"></div>\n");
      out.write("\t\t            <div class=\"inputrepeat\">\n");
      out.write("\t\t           \t\t<select id=\"pagi_combo\" name=\"pagi_combo\" class=\"select\" style=\"width: 100px;\" onchange=\"nevigation_advancesearch('pagi_combo');\">\n");
      out.write("\t\t           \t\t\t");
for(int i=0; i<sorted_list.size(); i+=10){
		           				int j = i + 10; 
		           				if(j > sorted_list.size())
		           					j = sorted_list.size();
		           			
      out.write("\n");
      out.write("\t\t           \t\t\t\t<option ");
 String sel = start+"-"+end; if(sel.equals(i+"-"+j)){ 
      out.write(" selected=\"selected\" ");
} 
      out.write(" value=\"");
      out.print(i );
      out.write('-');
      out.print(j );
      out.write('"');
      out.write('>');
      out.print(i+1 );
      out.write(' ');
      out.write('-');
      out.write(' ');
      out.print(j );
      out.write("</option>\n");
      out.write("\t\t           \t\t\t");
} 
      out.write("\n");
      out.write("\t\t           \t\t</select>\n");
      out.write("\t\t           \t</div>\n");
      out.write("\t\t           \t<div class=\"inputright\"></div>\n");
      out.write("\t\t               <div class=\"number\"> of ");
      out.print(sorted_list.size() );
      out.write(" </div>\n");
      out.write("\t\t \t\t\t</div>\n");
      out.write("\t\t       \t\t");
 if(end < sorted_list.size()) { 
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" onclick=\"nevigation_advancesearch('next','');\" class=\"next\" title=\"Next\" />\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"last\" onclick=\"nevigation_advancesearch('last','');\" class=\"last\" title=\"Last\" />\n");
      out.write("\t\t       \t\t");
} else {
      out.write("\n");
      out.write("\t\t       \t\t<input type=\"button\" name=\"next\" class=\"next_disable\" disabled=\"disabled\"/>\n");
      out.write("\t\t            <input type=\"button\" name=\"last\" class=\"last_disable\" disabled=\"disabled\" />\n");
      out.write("\t\t      \t\t");
} 
      out.write("\n");
      out.write("\t\t\t </div>\n");
      out.write("\t\t    ");

		   
		  }
		    }	
				else 
				{
			
      out.write("\n");
      out.write("\t\t\t <!-- Div tag for Message format -->          \n");
      out.write("               <div class=\"infomsg\" style=\"display: block;\">\n");
      out.write("\t\t <img align=\"absmiddle\" hspace=\"5\" src=\"images/info_icon.png\">\n");
      out.write("         No results found that match your criteria\n");
      out.write("         </div>\n");
      out.write("         \t\t");

        	}
         }
         else
         {
         
      out.write("\n");
      out.write("         <div class=\"infomsg\" style=\"display: block;\">\n");
      out.write("\t\t <img align=\"absmiddle\" hspace=\"5\" src=\"images/info_icon.png\">\n");
      out.write("         No results found that match your criteria\n");
      out.write("         </div>\n");
      out.write("        ");
	
         }
       
       
        
      out.write("\n");
      out.write("      \t\n");
      out.write("       \n");
      out.write("  </div>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
