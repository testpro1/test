package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.verve.meetin.network.NetworkDAO;
import com.verve.meetin.network.Networkmaster;
import com.google.api.client.googleapis.auth.oauth2.draft10.GoogleAuthorizationRequestUrl;
import com.google.api.client.auth.oauth2.draft10.AuthorizationRequestUrl;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;

public final class setupnetwork_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


 		/*  private static final String SCOPE = "http://www.google.com/m8/feeds/";
          private static final String CALLBACK_URL = //"http://localhost:8080/MeetIn/gmailAccessToken.jsp";
         // private static final HttpTransport TRANSPORT = new NetHttpTransport();
         // private static final JsonFactory JSON_FACTORY = new JacksonFactory();
        
          private static final String CLIENT_ID = "230618342024.apps.googleusercontent.com";
          private static final String CLIENT_SECRET = "5h8cDP40_P43uLwMvNKWZWQ8";*/
 
  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.release();
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
      out.write("\n");
 System.out.println("/setupnetwork.jsp");System.out.println("/setupnetwork.jsp");System.out.println("/setupnetwork.jsp");
 
      out.write('\n');
      out.write("\n");
      out.write("<!--<html xmlns=\"http://www.w3.org/1999/xhtml\">\n");
      out.write("--><!--<head>\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
      out.write("<title>meetIn</title>\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />\n");
      out.write("[if gt IE 6]> \n");
      out.write("        <link rel=\"stylesheet\" type=\"text/css\" href=\"css/ie.css\" /> \n");
      out.write("<![endif]\n");
      out.write("<script type=\"text/javascript\" src=\"js/setupnetwork.js\"></script>\n");
      out.write("<script src=\"js/meetin.js\" type=\"text/javascript\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.js\"></script>\n");
      out.write("<script type=\"text/javascript\" src=\"js/imagescroll.js\"></script>\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("function callprivacysetting(){\n");
      out.write("  window.location.href =\"privacysetting.jsp\";\n");
      out.write("}\n");
      out.write("function callPeopleFinder(){\n");
      out.write("window.location.href =\"/MeetIn/peoplefinder.do?action=people\";\n");
      out.write("}\n");
      out.write("function addNetwork() {\n");
      out.write("\taddSocialNetwork('LinkedIn');\n");
      out.write("}\n");
      out.write("</script>\n");
      out.write("</head>\n");
      out.write("\n");
      out.write("<body>\n");
      out.write("<div class=\"wrapper\">\n");
      out.write("\tmainsite starts here \n");
      out.write("\t<div class=\"mainsite\">\n");
      out.write("    \t<div class=\"leftside\">\n");
      out.write("        \t<div class=\"iphonecontainer\">\n");
      out.write("              <div id=\"iphoneScreen\" style=\"overflow: hidden; position:absolute; width:202px; height: 385px; margin-left: 30px;\">\n");
      out.write("              \t<div class=\"reflect\"></div>\n");
      out.write("           \t\t  <div id=\"screenImages\" style=\"position:absolute; left:0px; margin-top:83px;\">\n");
      out.write("                  \t\t<div class=\"buttoncontainer\">\n");
      out.write("                        \t<div><img src=\"images/profilevisitor_icon.png\" style=\"margin-top:2px\"/><input type=\"button\" class=\"iphonebutton\" value=\"Profile Visitors\"/></div>\n");
      out.write("                            <div><img src=\"images/about_icon.png\" style=\"margin-top:2px;\"/><input type=\"button\" class=\"iphonebutton\" value=\"About Me\"/></div>\n");
      out.write("                            <div><img src=\"images/location_xsmall.png\"/><input type=\"button\" class=\"iphonebutton\" value=\"Set Up Location\"/></div>\n");
      out.write("                            <div><img src=\"images/interest_xsmall.png\"/><input type=\"button\" class=\"iphonebutton\" value=\"Interest\"/></div>\n");
      out.write("                            <div><img src=\"images/network_xsmall.png\"/><input type=\"button\" class=\"iphonebutton\" value=\"Set Up Network\"/></div>\n");
      out.write("                            <div><img src=\"images/setting_xsmall.png\"/><input type=\"button\" class=\"iphonebutton\" value=\"Privacy Setting\"/></div>\n");
      out.write("                        </div>\n");
      out.write("               \t\t  \t<img id=\"screen1\" src=\"images/myprofile_bg.png\" >\n");
      out.write("                  </div>\n");
      out.write("   \t\t\t  </div>\t\n");
      out.write("            </div>\n");
      out.write("            \n");
      out.write("            <a href=\"#\"><div class=\"appstore\"></div></a>\n");
      out.write("            <a href=\"#\"><div class=\"appvideo\"></div></a>\n");
      out.write("            <div class=\"followus\">\n");
      out.write("            \tFollow Us on:\n");
      out.write("                <div class=\"socialnetwork\">\n");
      out.write("                <a href=\"#\"><div class=\"facebook\"></div></a>\n");
      out.write("                 <a href=\"javascript:void(0)\" onclick=\"window.open('https://twitter.com/mymeetIn', '_blank')\"><div class=\"twitter\"></div></a>\n");
      out.write("                </div>\n");
      out.write("            </div>\n");
      out.write("        </div>\n");
      out.write("        \n");
      out.write("        <div class=\"rightside\">\n");
      out.write("        \t<div class=\"username\">\n");
      out.write("            \t<p align=\"right\">Welcome, <strong></strong> &nbsp;&nbsp; | &nbsp;&nbsp; <a href=\"/MeetIn/login.do?action=signout\">Logout</a></p>\n");
      out.write("            </div>\n");
      out.write("        \t<div id=\"navigation\">\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"/MeetIn/peoplefinder.do?action=people\"><span>People Finder</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"addtrip.jsp\"><span>My Travel Plan</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"myfriends.html\"><span>My Friends</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn active\"><a href=\"#\"><span>My Profile</span></a></div>\n");
      out.write("                <div id=\"navinner\" class=\"submitBtn\"><a href=\"contact.html\"><span>Contact Us</span></a></div>                \n");
      out.write("        \t</div>-->\n");
      out.write("\t\t\t\t\n");
      out.write("            <div style=\"overflow:hidden; height:auto\">\n");
      out.write("                <div class=\"innercontainer\">\n");
      out.write("\t\t\t\t\t<div class=\"heading\" style=\"overflow:hidden;\"> \n");
      out.write("\t\t\t\t\t\t<div style=\"float: left;\"> \n");
      out.write("\t\t\t\t\t\t   <img src=\"images/network_icon.png\" align=\"absbottom\"/> Set Up your Network\n");
      out.write("\t\t\t\t\t\t</div> \n");
      out.write("\t\t\t\t\t\t<div class=\"username\" style=\"float: right; font-size: 14px; width: auto; margin: 0px; position: relative; line-height: 35px;\"><img align=\"absmiddle\" onclick=\"changePasswordView();\" title=\"Change Password\" src=\"images/change_password.png\" style=\"padding-right:5px;\"><a href=\"javascript:changePasswordView()\" title=\"Change Password\">Change Password</a> </div> \n");
      out.write("                    </div>\n");
      out.write("                    <form action=\"\" method=\"post\">\n");
      out.write("                    \n");
      out.write("                    <div class=\"networkfrm\">\n");
      out.write("                         ");

                           	 List networkList = new ArrayList();
                             networkList = new NetworkDAO().getSocialNetworkSites();
                             
                             if(networkList !=null && networkList.size() > 0){
                             
                               for(int i=0; i < networkList.size(); i++){
                                  Networkmaster network = new Networkmaster();
                                   network = (Networkmaster)networkList.get(i);
                                   
                         
      out.write("\n");
      out.write("                         \n");
      out.write("                        \n");
      out.write("                    \t<div class=\"img\"><img src=\"");
      out.print(network.getSocialNetworkSiteIcon() );
      out.write("\" /></div>\n");
      out.write("                    \t");

                    		String networkusername = new NetworkDAO().getNetworkUserName((Integer)session.getAttribute("UserID"), network.getSocialNetworkSiteId());
                    		if(networkusername.equals(""))
                    			networkusername = "";
                    		
                    	 
      out.write("\n");
      out.write("                        <div class=\"lable\" style=\"width:auto;\">\n");
      out.write("                        \t<div  style=\"float:left;\">");
      out.print(network.getSocialNetworkSiteName() );
      out.write(" &nbsp;</div> <div style=\"float:left; font-size: 11px;\">");
if(!networkusername.equals("")) out.print("("+networkusername+")"); 
      out.write("</div>\n");
      out.write("                       \t</div>\n");
      out.write("                        <div class=\"connect\" style=\"display:inline; float: right\">\n");
      out.write("                        ");

                        
                         if(session.getAttribute("UserID") !=null){
                            boolean result = new NetworkDAO().checkUserSocialNetwork((Integer)session.getAttribute("UserID"),network.getSocialNetworkSiteId());
                            if(result){
                         
      out.write("\n");
      out.write("                        \n");
      out.write("                        <!--<a href=\"javascript: void(0);\" onclick=\"popupwindow('addsocialnetwork.jsp?operation=edit&userid=");
      out.print(session.getAttribute("UserID"));
      out.write("&siteid=");
      out.print(network.getSocialNetworkSiteId());
      out.write("','Social Network Window',600,290);\"><img src=\"images/edit.png\" border=\"none\" title=\"Edit\" hspace=\"5px\"/></a>\n");
      out.write("                        --><a href=\"usernetwork.do?action=remove&userid=");
      out.print(session.getAttribute("UserID"));
      out.write("&siteid=");
      out.print(network.getSocialNetworkSiteId() );
      out.write("\" onclick=\"return confirmSubmit();\"><img src=\"images/remove.png\" border=\"none\" title=\"Remove\" hspace=\"10px\"/></a>\n");
      out.write("                        ");

                            }else{
                            	if(network.getSocialNetworkSiteName().equals("Facebook"))
                            	{
                         
      out.write("\n");
      out.write("                        \n");
      out.write("                        <a href=\"javascript: void(0);\" onclick=\"facebookLogin('");
      if (_jspx_meth_bean_005fmessage_005f0(_jspx_page_context))
        return;
      out.write('\'');
      out.write(',');
      out.write('\'');
      if (_jspx_meth_bean_005fmessage_005f1(_jspx_page_context))
        return;
      out.write('\'');
      out.write(',');
      out.write('\'');
      if (_jspx_meth_bean_005fmessage_005f2(_jspx_page_context))
        return;
      out.write("');\"><img src=\"images/create.png\" border=\"none\" title=\"Add\" hspace=\"5px\" /></a>\n");
      out.write("                        ");
 session.setAttribute("facebookRedirect","/setupnetwork.jsp "); 
      out.write("  <!-- This session Attribute is for facebook redirect Flag -->\n");
      out.write("                        ");

                        		}
                        		else if(network.getSocialNetworkSiteName().equals("LinkedIn")) 
                        		{
                        
      out.write("\n");
      out.write("                        <a href=\"javascript: void(0);\" onclick=\"LinkedInLogin();\"><img src=\"images/create.png\" border=\"none\" title=\"Add\" hspace=\"5px\" /></a>\n");
      out.write("                        ");
		}
                        else if(network.getSocialNetworkSiteName().equals("Twitter")) 
                        		{
                        
      out.write("\n");
      out.write("                        <a href=\"javascript: void(0);\" onclick=\"twitterLogin();\"><img src=\"images/create.png\" border=\"none\" title=\"Add\" hspace=\"5px\" /></a>\n");
      out.write("                        ");
		}
                        		else if(network.getSocialNetworkSiteName().equals("Gmail")) 
                        		{
                        		   ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
                        			String authorizeUrl = new GoogleAuthorizationRequestUrl(resource.getString("gmail.client.id").toString(),resource.getString("gmail.callback.url"),resource.getString("gmail.scope.url")).setAccessType("offline").setApprovalPrompt("force").build();
                        
      out.write("\n");
      out.write("                       <a href=\"javascript: void(0);\" onclick=\"GmailLogin('");
      out.print(authorizeUrl );
      out.write("');\"><img src=\"images/create.png\" border=\"none\" title=\"Add\" hspace=\"5px\" /></a>\n");
      out.write("                       ");

                        		}
                        		else if(network.getSocialNetworkSiteName().equals("GooglePlus")) 
                        		{
                        		   ResourceBundle resource = ResourceBundle.getBundle("com/verve/meetin/struts/ApplicationResources");
                        			String authorizeUrl = new GoogleAuthorizationRequestUrl(resource.getString("googleplus.client.id").toString(),resource.getString("googleplus.callback.url"),resource.getString("googleplus.scope.url")).build();
                        
      out.write("\n");
      out.write("                       <a href=\"javascript: void(0);\" onclick=\"GooglePlusLogin('");
      out.print(authorizeUrl );
      out.write("');\"><img src=\"images/create.png\" border=\"none\" title=\"Add\" hspace=\"5px\" /></a>\n");
      out.write("                       ");

                        		}
                        	else if(network.getSocialNetworkSiteName().equals("Orkut")) 
                        		{
                        
      out.write("\n");
      out.write("                        <a href=\"javascript: void(0);\" onclick=\"OrkutLogin();\"><img src=\"images/create.png\" border=\"none\" title=\"Add\" hspace=\"5px\" /></a>\n");
      out.write("                        ");
		}
                        else if(network.getSocialNetworkSiteName().equals("Myspace")) 
                        		{
                        
      out.write("\n");
      out.write("                        <a href=\"javascript: void(0);\" onclick=\"myspaceLogin();\"><img src=\"images/create.png\" border=\"none\" title=\"Add\" hspace=\"5px\" /></a>\n");
      out.write("                        ");
		}
                        		
                          	}
                          }
                        
      out.write("\n");
      out.write("                        </div>\n");
      out.write("                        ");

                           if(i != networkList.size()-1){
                        
      out.write("\n");
      out.write("                        <div class=\"frmline\"></div>\n");
      out.write("                        ");
 
                        			}   
                        		     
                        		}                        
                        
                        	}
                        
      out.write("\n");
      out.write("\n");
      out.write("                    </div>\n");
      out.write("                    </form>\n");
      out.write("                     <div class=\"logonsection\">\n");
      out.write("                     ");
      if (_jspx_meth_html_005fsubmit_005f0(_jspx_page_context))
        return;
      out.write("\n");
      out.write("                    ");

                       if(request.getParameter("ref") != null && request.getParameter("ref").equals("postloginsetup"))
                       {
                        // If this condition is true only show the content require as a part of post login process
                     
      out.write("\n");
      out.write("                    <div class=\"logonsection\">\n");
      out.write("                        <input type=\"button\" class=\"buttonorgsmall\" value=\"Continue\" style=\"margin-left:0px;\" onclick=\"callprivacysetting();\"/>\n");
      out.write("                        <input type=\"button\" class=\"buttonorgsmall\" value=\"Skip\" style=\"margin-left:10px;\" onclick=\"callPeopleFinder();\" />\n");
      out.write("                     </div>\n");
      out.write("                    ");

                     	}
                    
      out.write("\n");
      out.write("                </div><!-- content ends here -->\n");
      out.write("            </div> \n");
      out.write("        <!--</div>\n");
      out.write("    </div>mainsite starts here -->\n");
      out.write("    \n");
      out.write("    <!--footer starts here -->\n");
      out.write("    <!--<div class=\"footer\">\n");
      out.write("    \t<p><a href=\"index.html\">Home</a>|\n");
      out.write("        \t<a href=\"mediainquiry.html\">How It Works</a>|\n");
      out.write("            <a href=\"features.html\">Features</a>|\n");
      out.write("            <a href=\"review.html\">Review</a>|\n");
      out.write("            <a href=\"contact.html\">ContactUs</a>\n");
      out.write("        </p>\n");
      out.write("        <p>&nbsp;</p>\n");
      out.write("    \t<p>meetIn is an application of <a href=\"http://www.offshoremobiledevelopment.com\"  target=\"_blank\"  class=\"ft_link\">Verve Mobile Labs</a> | iPhone is trademarks of Apple Inc., registered in U.S. and other countries. App Store is a service mark of Apple Inc.</p>\n");
      out.write("        <p class=\"copyright\">Copyright @ 2012 meetIn. All rights reserved. </p>\n");
      out.write("    </div>footer ends here -->\n");
      out.write("<!--</div>\n");
      out.write("</body>\n");
      out.write("</html>\n");
      out.write("-->");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_bean_005fmessage_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f0 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f0.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f0.setParent(null);
    // /setupnetwork.jsp(145,79) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f0.setKey("facebook.app_id");
    int _jspx_eval_bean_005fmessage_005f0 = _jspx_th_bean_005fmessage_005f0.doStartTag();
    if (_jspx_th_bean_005fmessage_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f0);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f1 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f1.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f1.setParent(null);
    // /setupnetwork.jsp(145,119) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f1.setKey("facebook.redirect_uri");
    int _jspx_eval_bean_005fmessage_005f1 = _jspx_th_bean_005fmessage_005f1.doStartTag();
    if (_jspx_th_bean_005fmessage_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f1);
    return false;
  }

  private boolean _jspx_meth_bean_005fmessage_005f2(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  bean:message
    org.apache.struts.taglib.bean.MessageTag _jspx_th_bean_005fmessage_005f2 = (org.apache.struts.taglib.bean.MessageTag) _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.get(org.apache.struts.taglib.bean.MessageTag.class);
    _jspx_th_bean_005fmessage_005f2.setPageContext(_jspx_page_context);
    _jspx_th_bean_005fmessage_005f2.setParent(null);
    // /setupnetwork.jsp(145,165) name = key type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_bean_005fmessage_005f2.setKey("facebook.scope");
    int _jspx_eval_bean_005fmessage_005f2 = _jspx_th_bean_005fmessage_005f2.doStartTag();
    if (_jspx_th_bean_005fmessage_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fbean_005fmessage_0026_005fkey_005fnobody.reuse(_jspx_th_bean_005fmessage_005f2);
    return false;
  }

  private boolean _jspx_meth_html_005fsubmit_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  html:submit
    org.apache.struts.taglib.html.SubmitTag _jspx_th_html_005fsubmit_005f0 = (org.apache.struts.taglib.html.SubmitTag) _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.get(org.apache.struts.taglib.html.SubmitTag.class);
    _jspx_th_html_005fsubmit_005f0.setPageContext(_jspx_page_context);
    _jspx_th_html_005fsubmit_005f0.setParent(null);
    // /setupnetwork.jsp(205,21) name = styleClass type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setStyleClass("buttonorgsmall");
    // /setupnetwork.jsp(205,21) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setValue("Next");
    // /setupnetwork.jsp(205,21) name = onclick type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_html_005fsubmit_005f0.setOnclick("getPage('privacysetting');");
    int _jspx_eval_html_005fsubmit_005f0 = _jspx_th_html_005fsubmit_005f0.doStartTag();
    if (_jspx_th_html_005fsubmit_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fhtml_005fsubmit_0026_005fvalue_005fstyleClass_005fonclick_005fnobody.reuse(_jspx_th_html_005fsubmit_005f0);
    return false;
  }
}
