package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\n");
      out.write("<head>\n");
      out.write("<title>QR Code in Java Servlet - viralpatel.net</title>\n");
      out.write("\t<TITLE>Clearable Textboxes in jQuery</TITLE>\n");
      out.write("<STYLE>\n");
      out.write("body, input{\n");
      out.write("\tfont-family: Calibri, Arial;\n");
      out.write("\tmargin: 0px;\n");
      out.write("\tpadding: 0px;\n");
      out.write("}\n");
      out.write("a {\n");
      out.write("\tcolor: #0254EB\n");
      out.write("}\n");
      out.write("a:visited {\n");
      out.write("\tcolor: #0254EB\n");
      out.write("}\n");
      out.write("#header h2 {\n");
      out.write("\tcolor: white;\n");
      out.write("\tbackground-color: #3275A8;\n");
      out.write("\tmargin:0px;\n");
      out.write("\tpadding: 5px;\n");
      out.write("\theight: 40px;\n");
      out.write("\tpadding: 15px;\n");
      out.write("}\n");
      out.write("html, body, #container { height: 100%; }\n");
      out.write("body > #container { height: auto; min-height: 100%; }\n");
      out.write("\n");
      out.write("#footer{\n");
      out.write("\tfont-size: 12px;\n");
      out.write("\tclear: both;\n");
      out.write("\tposition: relative;\n");
      out.write("\tz-index: 10;\n");
      out.write("\theight: 3em;\n");
      out.write("\tmargin-top: -3em;\n");
      out.write("\ttext-align:center;\n");
      out.write("}\n");
      out.write("#content { padding-bottom: 3em; padding: 10px;}\n");
      out.write("\n");
      out.write("input {\n");
      out.write("\tfont-size: 15px;\n");
      out.write("}\n");
      out.write(".style1 {\n");
      out.write("\tborder: 3px solid #ffaa00;\n");
      out.write("\tfont-size: 20px;\n");
      out.write("}\n");
      out.write(".style2 {\n");
      out.write("\tborder: 2px solid #aaff77;\n");
      out.write("\tfont-size: 18px;\n");
      out.write("}\n");
      out.write("</STYLE>\n");
      out.write("</HEAD>\n");
      out.write("<BODY>\n");
      out.write("<div id=\"container\">\n");
      out.write("<div id=\"header\">\n");
      out.write("<H2>\n");
      out.write("\t<a href=\"http://viralpatel.net\"><img border=\"0px\" src=\"logo.gif\" align=\"left\"/></a>\n");
      out.write("\tCreate QR Code in Java Servlet\n");
      out.write("</H2>\n");
      out.write("</div>\n");
      out.write("<div id=\"content\">\n");
      out.write("\t<form action=\"qrservlet\" method=\"get\">\n");
      out.write("\t\t<p>Enter Text to create QR Code</p>\n");
      out.write("\t\t<input type=\"text\" name=\"qrtext\" />\n");
      out.write("\t\t<input type=\"submit\" value=\"Generate QR Code\" />\n");
      out.write("\t</form>\n");
      out.write("<br/>\n");
      out.write("</div>\n");
      out.write("<div id=\"footer\">\n");
      out.write("\tCopyright &copy; <a href=\"http://viralpatel.net\">viralpatel.net</a>\n");
      out.write("</div>\n");
      out.write("\n");
      out.write("</BODY>\n");
      out.write("</HTML>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
